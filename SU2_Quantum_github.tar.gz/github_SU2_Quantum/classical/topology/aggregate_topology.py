#!/usr/bin/env python3
"""
aggregate_topology.py
Combine the per rank measurement files meas_topo_L{L}_rank*.jsonl into one
summary with errors. Runs on a login node, no MPI.

Errors: each rank is an independent Markov chain, so the error of any
average is the spread of the per chain means / sqrt(number of chains).
With a single chain the measurements are cut into 10 consecutive blocks.

Usage
    python aggregate_topology.py runs/L16 16          # writes summary_topo_L16.json
"""

import glob
import json
import os
import re
import sys

import numpy as np


def _load(outdir, L):
    files = sorted(glob.glob(os.path.join(outdir, f'meas_topo_L{L}_rank*.jsonl')),
                   key=lambda p: int(re.search(r'rank(\d+)', p).group(1)))
    chains = []
    for p in files:
        with open(p) as f:
            rows = [json.loads(s) for s in f if s.strip()]
        if rows:
            chains.append(rows)
    if len(chains) == 1 and len(chains[0]) >= 20:          # block a single chain
        rows = chains[0]
        nb = 10
        n = len(rows) // nb
        chains = [rows[i * n:(i + 1) * n] for i in range(nb)]
    return chains


def _stat(chains, fn):
    """fn(row) -> array; returns mean, error over chain means."""
    per = np.array([np.mean([np.asarray(fn(r), float) for r in ch], axis=0) for ch in chains])
    m = per.mean(0)
    e = per.std(0, ddof=1) / np.sqrt(len(per)) if len(per) > 1 else np.zeros_like(m)
    return m, e


def _pair(m, e):
    if np.ndim(m) == 0:
        return [float(m), float(e)]
    return [np.asarray(m).tolist(), np.asarray(e).tolist()]


def aggregate(outdir, L):
    chains = _load(outdir, L)
    rows = [r for ch in chains for r in ch]
    S = dict(L=L, n_configs=len(rows), n_chains=len(chains))
    if not rows:
        return S

    for key in ('mean_c0', 'mean_c0sq', 'sumvar_ck', 'Q_sq_per_cell',
                'Q_abs_per_cell', 'charged_fraction'):
        S[key] = _pair(*_stat(chains, lambda r, k=key: r[k]))
    S['Q_total_max_abs'] = int(max(abs(r['Q_total']) for r in rows))
    hist = {}
    for r in rows:
        for q, c in r['Q_hist'].items():
            hist[int(q)] = hist.get(int(q), 0) + c
    S['Q_hist'] = {str(k): hist[k] for k in sorted(hist)}

    # charge correlator
    shells = sorted(rows[0]['corr']['C_shell'], key=int)
    S['C_Q_shell'] = {s: _pair(*_stat(chains, lambda r, s=s: r['corr']['C_shell'][s]['C']))
                      for s in shells}
    S['C_Q_shell_count'] = {s: rows[0]['corr']['C_shell'][s]['n'] for s in shells}
    S['C_Q_profile'] = _pair(*_stat(chains, lambda r: r['corr']['C_profile']))
    S['C_Q_running_sum'] = _pair(*_stat(chains, lambda r: r['corr']['running_sum']))
    ks = sorted(rows[0]['corr']['chi_k'], key=int)
    S['chi_k'] = {k: _pair(*_stat(chains, lambda r, k=k: r['corr']['chi_k'][k])) for k in ks}

    # Wilson loops
    Wm, We = _stat(chains, lambda r: r['W'])
    S['W'] = _pair(Wm, We)
    rmax = Wm.shape[0] - 1
    # Creutz ratios chi(R,R) with the error from the spread over chains
    perW = np.array([np.mean([np.asarray(r['W'], float) for r in ch], axis=0) for ch in chains])
    cr = {}
    for R in range(2, rmax + 1):
        a, b, c = Wm[R, R], Wm[R - 1, R - 1], Wm[R, R - 1]
        if a > 3 * We[R, R] and b > 0 and c > 0:
            val = float(-np.log(a * b / c ** 2))
            # jackknife over chains
            n = len(perW)
            if n > 1:
                jk = []
                for i in range(n):
                    w = np.delete(perW, i, axis=0).mean(0)
                    if w[R, R] > 0 and w[R, R - 1] > 0:
                        jk.append(-np.log(w[R, R] * w[R - 1, R - 1] / w[R, R - 1] ** 2))
                err = float(np.sqrt((n - 1) / n * np.sum((np.array(jk) - np.mean(jk)) ** 2)))
            else:
                err = 0.0
            cr[R] = [val, err]
    S['creutz_ratio'] = cr
    # holonomy / neutrino probe around loops
    Rs = sorted(rows[0]['holonomy'], key=int)
    hol = {}
    for R in Rs:
        Cn = _stat(chains, lambda r, R=R: r['holonomy'][R]['C_n'])
        Vn = _stat(chains, lambda r, R=R: r['holonomy'][R]['V_nu'])
        h = np.sum([r['holonomy'][R]['psi_hist'] for r in rows], axis=0)
        hol[R] = dict(C_n=_pair(*Cn), V_nu=_pair(*Vn), psi_hist=h.tolist())
    S['holonomy'] = hol

    # lock test
    lk = {}
    for R in sorted(rows[0]['lock'], key=int):
        out = {}
        for tag in ('byN', 'byq'):
            acc = np.sum([np.array(r['lock'][R][tag]) for r in rows], axis=0)  # (2, nb, 2)
            with np.errstate(invalid='ignore', divide='ignore'):
                mean = acc[..., 0] / acc[..., 1]
            per = np.array([np.sum([np.array(r['lock'][R][tag]) for r in ch], axis=0) for ch in chains])
            with np.errstate(invalid='ignore', divide='ignore'):
                import warnings; warnings.simplefilter('ignore', RuntimeWarning)
                pm = per[..., 0] / per[..., 1]
            err = np.nanstd(pm, axis=0, ddof=min(1, len(chains)-1)) / np.sqrt(np.sum(np.isfinite(pm), axis=0)) \
                if len(chains) > 1 else np.zeros_like(mean)
            out[tag] = dict(real_mean=np.nan_to_num(mean[0], nan=-9).tolist(),
                            real_err=np.nan_to_num(err[0], nan=0).tolist(),
                            real_count=acc[0, :, 1].astype(int).tolist(),
                            null_mean=np.nan_to_num(mean[1], nan=-9).tolist(),
                            null_err=np.nan_to_num(err[1], nan=0).tolist(),
                            null_count=acc[1, :, 1].astype(int).tolist())
        lk[R] = out
    S['lock'] = lk

    # center vortices
    vch = [[r for r in ch if 'vortex' in r] for ch in chains]
    vch = [c for c in vch if c]
    vrows = [r for c in vch for r in c]
    if vrows:
        V = dict(n_configs=len(vrows))
        for key in ('pvortex_density', 'mcg_objective', 'faces_pv_charged', 'faces_pv_neutral',
                    'frac_charged_on_vortex', 'frac_neutral_on_vortex'):
            V[key] = _pair(*_stat(vch, lambda r, k=key: r['vortex'][k]))
        loops = {}
        for R in sorted(vrows[0]['vortex']['loops'], key=int):
            acc = np.sum([np.array(r['vortex']['loops'][R]['acc']) for r in vrows], axis=0)
            per = np.array([np.sum([np.array(r['vortex']['loops'][R]['acc']) for r in c], axis=0)
                            for c in vch])
            cnt = acc[:, 0]
            nc = acc.shape[1]                                # 8: columns up to cos 6psi (older files: cos 4psi)
            if not np.any(acc[:, 6:]):
                nc = 6
            with np.errstate(invalid='ignore', divide='ignore'):
                mean = acc[:, 1:nc] / cnt[:, None]          # W, W^2, cos2psi .. cos(nc-2)psi
                pm = per[:, :, 1:nc] / per[:, :, :1]
                ratio = mean[:, 0] / mean[0, 0]
                pr = pm[:, :, 0] / pm[:, :1, 0]
            nC = len(vch)
            if nC > 1:
                err = np.nanstd(pm, axis=0, ddof=1) / np.sqrt(nC)
                rerr = np.nanstd(pr, axis=0, ddof=1) / np.sqrt(nC)
            else:
                err = np.zeros_like(mean); rerr = np.zeros_like(ratio)
            h = np.sum([np.array(r['vortex']['loops'][R]['psi_hist_even_odd']) for r in vrows], axis=0)
            loops[R] = dict(count=cnt.astype(int).tolist(),
                            W=np.nan_to_num(mean[:, 0]).tolist(), W_err=np.nan_to_num(err[:, 0]).tolist(),
                            ratio=np.nan_to_num(ratio).tolist(), ratio_err=np.nan_to_num(rerr).tolist(),
                            cos2=np.nan_to_num(mean[:, 2]).tolist(), cos3=np.nan_to_num(mean[:, 3]).tolist(),
                            cos4=np.nan_to_num(mean[:, 4]).tolist(),
                            # probe coherence C_n = <cos n psi> per vortex class, n = 1 .. nmax, with errors
                            C_n=[np.nan_to_num(np.concatenate([mean[i, :1], mean[i, 2:]])).tolist()
                                 for i in range(mean.shape[0])],
                            C_n_err=[np.nan_to_num(np.concatenate([err[i, :1], err[i, 2:]])).tolist()
                                     for i in range(mean.shape[0])],
                            psi_hist_even=h[0].tolist(), psi_hist_odd=h[1].tolist())
        V['loops'] = loops
        S['vortex'] = V
    return S


if __name__ == '__main__':
    if len(sys.argv) < 3:
        sys.exit('usage: aggregate_topology.py <outdir> <L>')
    d, L = sys.argv[1], int(sys.argv[2])
    S = aggregate(d, L)
    p = os.path.join(d, f'summary_topo_L{L}.json')
    with open(p, 'w') as f:
        json.dump(S, f, indent=1)
    print('wrote', p, ' configs:', S['n_configs'])
