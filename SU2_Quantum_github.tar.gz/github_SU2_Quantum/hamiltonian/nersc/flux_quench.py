#!/usr/bin/env python3
"""
flux_quench.py: real time formation of the eye. A Z2 center flux is pinned on
one plaquette and then released; the exact Kogut Susskind evolution shows how
it spreads over the torus.

    python flux_quench.py --system torus2x2 --jmax 1.5 --g2 1.8181818 --out results/quench_t22_j1.5

Part of the SU2_Quantum project (R. Sakidja, Missouri State University).
Code drafted with AI (LLM) assistance (Claude, Anthropic) and reviewed by the author.

Protocol
--------
H(kappa) = (g^2/2) sum E^2 + (4/g^2) sum_p kappa_p (1 - s_p c0_p).
1. Prepare: ground state of H with kappa = pin on every plaquette except the
   chosen one (kappa = 1 there). The stiff plaquettes refuse the twist, so the
   frustration of the twisted sector (s_p = -1 on one plaquette) is pushed onto
   the soft plaquette: the flux starts pinned there.
2. Release: evolve with the uniform H (kappa = 1) and record, per plaquette,
   e_p(t) = (4/g^2)(1 - s_p <c0_p>)   magnetic energy (where the flux is)
   v_p(t) = 1 - <c0_p^2>               sum_k <c_k^2>, the variance
3. The same protocol in the untwisted sector is the control: it carries only the
   pinning quench, so twisted minus untwisted isolates the flux itself.
Which plaquette carries s = -1 is a convention (a Z2 relabeling of links); the
pinning decides where the flux physically starts.
<c0^2> is <psi|C_p C_p|psi> with the truncated operator, accurate when jmax is
converged; the exact sum_k Var values come from run.py.

Outputs: <out>.json, <out>_lines.png (per plaquette e_p and v_p against time,
twisted minus untwisted) and <out>_movie.gif (the torus as tiles, colour = excess
magnetic energy, one frame per time step) when Pillow is available.
"""
import argparse
import json
import time

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

from su2ham.systems2 import build2

LAYOUT = {"torus2x2": {"P00": (0, 0), "P10": (1, 0), "P01": (0, 1), "P11": (1, 1)},
          "torus3x1": {"P_0": (0, 0), "P_1": (1, 0), "P_2": (2, 0)},
          "torus2x1": {"P_A": (0, 0), "P_B": (1, 0)}}


def ham(sysm, g2, signs, kappa):
    H = 0.5 * g2 * sysm.Eel
    I = sp.identity(sysm.n)
    for s, k, C in zip(signs, kappa, sysm.Cp):
        H = H + (4.0 / g2) * k * (I - s * C)
    return H.tocsr()


def ground(H):
    if H.shape[0] <= 1500:
        w, v = np.linalg.eigh(H.toarray())
        return w[0], v[:, 0]
    w, v = spla.eigsh(H, k=1, which="SA", tol=1e-11)
    return w[0], v[:, 0]


def run_sector(sysm, g2, signs, pin, p0, times):
    nP = len(sysm.Cp)
    kappa = [pin] * nP
    kappa[p0] = 1.0
    _, psi0 = ground(ham(sysm, g2, signs, kappa))
    H = ham(sysm, g2, signs, [1.0] * nP)
    Eeq, psi_eq = ground(H)
    C2 = [C @ C for C in sysm.Cp]
    psis = spla.expm_multiply(-1j * H, psi0.astype(complex), start=times[0], stop=times[-1],
                              num=len(times), endpoint=True)
    c0 = np.array([[np.real(np.vdot(ps, C @ ps)) for C in sysm.Cp] for ps in psis])
    c0sq = np.array([[np.real(np.vdot(ps, C @ ps)) for C in C2] for ps in psis])
    E = np.array([np.real(np.vdot(ps, H @ ps)) for ps in psis])
    s = np.array(signs, float)
    eq_c0 = np.array([np.real(psi_eq @ (C @ psi_eq)) for C in sysm.Cp])
    eq_c0sq = np.array([np.real(psi_eq @ (C @ psi_eq)) for C in C2])
    return dict(signs=list(signs), e=((4.0 / g2) * (1 - s * c0)).tolist(), v=(1 - c0sq).tolist(),
                energy=E.tolist(), energy_drift=float(np.ptp(E)), E_ground=float(Eeq),
                e_eq=((4.0 / g2) * (1 - s * eq_c0)).tolist(), v_eq=(1 - eq_c0sq).tolist())


def figures(out, rec):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    t = np.array(rec["t"]); names = rec["names"]
    tw, un = rec["twisted"], rec["untwisted"]
    de = np.array(tw["e"]) - np.array(un["e"])
    dv = np.array(tw["v"]) - np.array(un["v"])
    fig, ax = plt.subplots(1, 3, figsize=(15, 4))
    for p, nm in enumerate(names):
        ax[0].plot(t, de[:, p], label=nm)
        ax[1].plot(t, dv[:, p], label=nm)
        ax[2].plot(t, np.array(tw["e"])[:, p], label=nm)
    ax[0].set_title("excess magnetic energy e_p (twisted minus untwisted)")
    ax[1].set_title("excess variance sum_k c_k^2 (twisted minus untwisted)")
    ax[2].set_title("magnetic energy e_p, twisted sector")
    for a in ax:
        a.set_xlabel("time (lattice units)"); a.legend(fontsize=8)
    fig.suptitle(f"{rec['system']} jmax {rec['jmax']}, g^2 = {rec['g2']:.4f}: flux pinned on {names[rec['pinned']]} and released")
    fig.tight_layout(); fig.savefig(out + "_lines.png", dpi=130); plt.close(fig)

    lay = LAYOUT.get(rec["system"])
    if lay is None:
        return
    try:
        from matplotlib.animation import FuncAnimation, PillowWriter
    except Exception:
        return
    nx = 1 + max(v[0] for v in lay.values()); ny = 1 + max(v[1] for v in lay.values())
    vmax = np.abs(de).max()
    fig, ax = plt.subplots(figsize=(1.8 * nx + 1.5, 1.8 * ny + 1))
    grid = np.zeros((ny, nx))
    im = ax.imshow(grid, origin="lower", cmap="RdBu_r", vmin=-vmax, vmax=vmax)
    txt = [ax.text(lay[nm][0], lay[nm][1], "", ha="center", va="center", fontsize=9) for nm in names]
    ax.set_xticks([]); ax.set_yticks([])
    plt.colorbar(im, ax=ax, fraction=0.05, label="excess e_p")
    title = ax.set_title("")

    def frame(k):
        for p, nm in enumerate(names):
            grid[lay[nm][1], lay[nm][0]] = de[k, p]
            txt[p].set_text(f"{nm}\n{de[k, p]:+.3f}")
        im.set_data(grid)
        title.set_text(f"t = {t[k]:.2f}")
        return [im, title] + txt

    anim = FuncAnimation(fig, frame, frames=len(t), blit=False)
    try:
        anim.save(out + "_movie.gif", writer=PillowWriter(fps=12))
    except Exception as e:
        print(f"[warn] movie not written: {e}")
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--system", default="torus2x2")
    ap.add_argument("--jmax", type=float, default=1.0)
    ap.add_argument("--g2", type=float, default=1.8181818)
    ap.add_argument("--pin", type=float, default=4.0, help="kappa on the stiff plaquettes during preparation")
    ap.add_argument("--plaquette", type=int, default=0, help="where the flux starts")
    ap.add_argument("--tmax", type=float, default=20.0)
    ap.add_argument("--nt", type=int, default=201)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    t0 = time.time()
    sysm = build2(a.system, a.jmax)
    nP = len(sysm.Cp)
    print(f"{a.system} jmax={a.jmax}: n={sysm.n}, build {time.time()-t0:.1f}s", flush=True)
    times = np.linspace(0, a.tmax, a.nt)
    tw_signs = [1] * nP; tw_signs[a.plaquette] = -1
    rec = dict(system=a.system, jmax=a.jmax, g2=a.g2, pin=a.pin, pinned=a.plaquette, names=sysm.names,
               n=sysm.n, t=times.tolist())
    for name, signs in [("twisted", tw_signs), ("untwisted", [1] * nP)]:
        rec[name] = run_sector(sysm, a.g2, signs, a.pin, a.plaquette, times)
        r = rec[name]
        e0 = "  ".join(f"{nm} {x:.3f}" for nm, x in zip(sysm.names, r["e"][0]))
        eT = "  ".join(f"{nm} {np.mean(np.array(r['e'])[len(times)//2:, p]):.3f}" for p, nm in enumerate(sysm.names))
        eq = "  ".join(f"{nm} {x:.3f}" for nm, x in zip(sysm.names, r["e_eq"]))
        print(f"  {name}: e_p at t=0 [{e0}]   late time mean [{eT}]   ground state [{eq}]   energy drift {r['energy_drift']:.1e}", flush=True)
        json.dump(rec, open(a.out + ".json", "w"))
    try:
        figures(a.out, rec)
    except Exception as e:
        print(f"[warn] figures not written: {e}")
    print(f"wrote {a.out}.json ({time.time()-t0:.1f}s)")


if __name__ == "__main__":
    main()
