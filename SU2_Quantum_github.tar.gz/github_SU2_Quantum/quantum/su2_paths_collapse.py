#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
su2_paths_collapse.py
Same tautology, different paths: three energy-injection protocols on the
L x L SU(2) lattice, for NERSC Perlmutter (MPI) or any workstation.

The geometric floor m* >= 1 is analytic and is claimed as mathematics.
The physics is the PATH: where each ensemble sits above the floor and how
it moves with driving. Three protocols inject energy differently:

    uniform : params ~ U(-alpha*pi, +alpha*pi)
    gaussian: params ~ N(0, alpha*pi/sqrt(3))     (matched std, tails)
    binary  : params in {-alpha*pi, +alpha*pi}    (two-point, extreme)

All protocols share the circuit, estimators, seed scheme, and alpha grid;
no optimization anywhere. The collapse test re-plots mass against the
measured variance: if all protocols fall on one curve, variance is the
sufficient statistic.

Usage (serial):
    python3 su2_paths_collapse.py --L 3 --samples 10000 --outdir paths_L3
Usage (MPI):
    srun -n 32 python3 su2_paths_collapse.py --L 3 --samples 10000 \
         --device lightning.qubit --outdir paths_L3

Note: rotations by exactly +/-pi differ only by a global phase, so the
binary protocol at alpha = 1 is a single coherent state (Var = 0,
m* = pi/2 exactly). This degeneracy is physical and is the sharpest
witness of the collapse: maximal amplitude, zero variance, coherent mass.
"""
import argparse, json, os, sys, time
import numpy as np

try:
    from mpi4py import MPI
    COMM = MPI.COMM_WORLD
    RANK, NPROCS = COMM.Get_rank(), COMM.Get_size()
except ImportError:
    COMM, RANK, NPROCS = None, 0, 1

def log(msg):
    if RANK == 0:
        print(msg, flush=True)

class Lattice:
    def __init__(self, L):
        self.L = L; self.n = L * L
        self.links = []
        for y in range(L):
            for x in range(L):
                i = y * L + x
                if x + 1 < L: self.links.append((i, i + 1))
                if y + 1 < L: self.links.append((i, i + L))
        self.gauge_links = [(a, b) for (a, b) in self.links if a and b]
        self.nu_nb = sorted({b for (a, b) in self.links if a == 0}
                            | {a for (a, b) in self.links if b == 0})
        self.n_rot = 3 * (self.n - 1)
        self.n_params = self.n_rot + len(self.gauge_links) + 1

def build_circuit(lat, device_name):
    import pennylane as qml
    dev = qml.device(device_name, wires=lat.n)
    @qml.qnode(dev)
    def circuit(params):
        for i in range(lat.n - 1):
            g = i + 1
            qml.RY(params[3 * i], wires=g)
            qml.RZ(params[3 * i + 1], wires=g)
            qml.RX(params[3 * i + 2], wires=g)
        for m, (a, b) in enumerate(lat.gauge_links):
            qml.CNOT(wires=[a, b])
            qml.RZ(params[lat.n_rot + m], wires=b)
            qml.CNOT(wires=[a, b])
        qml.RY(params[lat.n_rot + len(lat.gauge_links)], wires=0)
        for nb in lat.nu_nb:
            qml.CNOT(wires=[nb, 0])
        return qml.state()
    return circuit

class Estimators:
    def __init__(self, n):
        self.n = n
        idx = np.arange(2 ** n, dtype=np.uint64)
        par = idx.copy(); s = 1
        while s < n:
            par ^= par >> np.uint64(s); s *= 2
        self.z_diag = (1.0 - 2.0 * (par & np.uint64(1))).astype(np.float32)
        del idx, par

    def measure(self, psi):
        psi = np.asarray(psi).astype(np.complex64)
        probs = psi.real ** 2 + psi.imag ** 2
        mean = float(self.z_diag @ probs)
        var = 1.0 - mean * mean
        c = np.zeros(3)
        for q in range(1, self.n):
            A, B = 2 ** q, 2 ** (self.n - q - 1)
            pt = psi.reshape(A, 2, B)
            r01 = np.einsum("ab,ab->", pt[:, 0, :], pt[:, 1, :].conj())
            pz = probs.reshape(A, 2, B)
            c[0] += 2 * r01.real
            c[1] += -2 * r01.imag
            c[2] += float(pz[:, 0, :].sum() - pz[:, 1, :].sum())
        c /= (self.n - 1)
        u = float(np.linalg.norm(c))
        c0 = np.sqrt(max(0.0, 1 - u * u))
        theta = np.arccos(np.clip(c0, -1, 1))
        # analytic limit arcsin(u)/u -> 1 as u -> 0 (degenerate discrete
        # protocols can reach u = 0 exactly; the limit is the correct value)
        mstar = 1.0 if u < 1e-9 else theta / u
        return mean, var, mstar, c0

def draw(protocol, rng, alpha, size):
    w = alpha * np.pi
    if protocol == "uniform":
        return rng.uniform(-w, w, size)
    if protocol == "gaussian":
        return rng.normal(0.0, w / np.sqrt(3.0), size)
    if protocol == "binary":
        return w * rng.choice([-1.0, 1.0], size)
    raise ValueError(protocol)

def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--L", type=int, default=3)
    ap.add_argument("--samples", type=int, default=10000,
                    help="total samples per (protocol, alpha) point")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--device", default="lightning.qubit")
    ap.add_argument("--outdir", default="paths_out")
    ap.add_argument("--protocols", default="uniform,gaussian,binary")
    ap.add_argument("--alphas", default="0.05,0.1,0.2,0.3,0.5,0.7,1.0")
    args = ap.parse_args()

    protocols = args.protocols.split(",")
    alphas = [float(a) for a in args.alphas.split(",")]
    lat = Lattice(args.L)
    log("=" * 66)
    log(f"paths/collapse: {args.L}x{args.L} ({lat.n} qubits), "
        f"{len(protocols)} protocols x {len(alphas)} alphas x "
        f"{args.samples} samples, {NPROCS} rank(s)")
    log("random sampling only; no optimization. floor m* >= 1 is analytic.")
    log("=" * 66)

    try:
        circuit = build_circuit(lat, args.device)
    except Exception as e:
        log(f"{args.device} unavailable ({e}); using default.qubit")
        circuit = build_circuit(lat, "default.qubit")
    est = Estimators(lat.n)
    os.makedirs(args.outdir, exist_ok=True)

    my_n = args.samples // NPROCS + (1 if RANK < args.samples % NPROCS else 0)
    results = []
    for protocol in protocols:
        for alpha in alphas:
            rng = np.random.default_rng(args.seed + RANK)
            V, M = [], []
            t0 = time.time()
            for _ in range(my_n):
                params = draw(protocol, rng, alpha, lat.n_params)
                _, v, m, _ = est.measure(np.asarray(circuit(params)))
                V.append(v); M.append(m)
            V, M = np.array(V), np.array(M)
            if COMM is not None and NPROCS > 1:
                V = np.concatenate(COMM.allgather(V))
                M = np.concatenate(COMM.allgather(M))
            if RANK == 0:
                rec = {"protocol": protocol, "alpha": alpha,
                       "n_samples": int(len(M)),
                       "var": [float(V.mean()), float(V.std())],
                       "m": [float(M.mean()), float(M.std())],
                       "m_min": float(M.min()),
                       "below_floor": int((M < 1.0).sum())}
                results.append(rec)
                np.savez(os.path.join(args.outdir,
                         f"raw_{protocol}_a{alpha}.npz"), var=V, m=M)
                log(f"{protocol:8s} alpha={alpha:4.2f}  "
                    f"Var={rec['var'][0]:.4f}  m*={rec['m'][0]:.4f}\u00b1"
                    f"{rec['m'][1]:.4f}  min={rec['m_min']:.4f}  "
                    f"below_floor={rec['below_floor']}  "
                    f"({time.time()-t0:.0f}s)")
    if RANK != 0:
        return
    json.dump(results, open(os.path.join(args.outdir,
              "paths_summary.json"), "w"), indent=1)

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        colors = {"uniform": "#2E86AB", "gaussian": "#A23B72",
                  "binary": "#F18F01"}
        fig, (a1, a2) = plt.subplots(1, 2, figsize=(13.5, 5))
        for p in protocols:
            rows = [r for r in results if r["protocol"] == p]
            al = [r["alpha"] for r in rows]
            m = [r["m"][0] for r in rows]; e = [r["m"][1] for r in rows]
            mn = [r["m_min"] for r in rows]
            v = [r["var"][0] for r in rows]
            col = colors.get(p, None)
            a1.errorbar(al, m, yerr=e, marker="o", lw=1.6, capsize=3,
                        color=col, label=p)
            a1.plot(al, mn, ls="--", lw=1.0, color=col, alpha=0.6)
            order = np.argsort(v)
            a2.plot(np.array(v)[order], np.array(m)[order], marker="o",
                    lw=1.4, color=col, label=p)
        a1.axhline(1, color="black", lw=1.4)
        a1.axhline(np.pi / 2, color="gray", ls=":", lw=1.1)
        a1.set_xlabel("excitation amplitude \u03b1"); a1.set_ylabel("m*")
        a1.set_title("Same tautology, different paths")
        a1.legend(); a1.grid(alpha=0.3)
        a2.axhline(1, color="black", lw=1.2)
        a2.set_xlabel(f"measured Var(Z\u2297{lat.n})")
        a2.set_ylabel("\u27e8m*\u27e9")
        a2.set_title("Collapse test: mass vs measured variance")
        a2.legend(); a2.grid(alpha=0.3)
        fig.suptitle(f"Three energy-injection protocols, "
                     f"{args.L}\u00d7{args.L} lattice, "
                     f"{args.samples} samples/point, seed {args.seed}",
                     fontweight="bold")
        fig.tight_layout()
        fig.savefig(os.path.join(args.outdir, "paths_collapse.png"), dpi=200)
        log(f"wrote {args.outdir}/paths_collapse.png")
    except Exception as e:
        log(f"(figure skipped: {e})")

if __name__ == "__main__":
    main()
