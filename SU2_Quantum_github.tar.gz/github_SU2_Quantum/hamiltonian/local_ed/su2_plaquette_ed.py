"""
Exact diagonalization of the gauge fixed single plaquette SU(2)
Kogut Susskind Hamiltonian, with the discarded Pauli component variance
as an explicit observable.

Part of the SU2_Quantum project (R. Sakidja, Missouri State University).
Code drafted with AI (LLM) assistance (Claude, Anthropic) and reviewed by the author.

Physics
-------
Hamiltonian (lattice units, a = 1):
    H = (g^2/2) sum_links E_l^2 + (4/g^2) sum_p (1 - c0_p)
with U_p = c0 1 + i sum_k c_k sigma_k, c0 = (1/2) Tr U_p, c0^2 + sum_k c_k^2 = 1.

Single plaquette, open boundary, 4 links. Gauge fixing on a maximal tree sets
3 links to the identity. Gauss law forces all 4 links to carry the same
representation j, so the gauge invariant basis is |j> = chi_j(U), j = 0, 1/2, 1, ...
    electric:  4 * (g^2/2) * j(j+1) = 2 g^2 j(j+1)       (diagonal)
    magnetic:  <j +- 1/2 | c0 | j> = 1/2                  (tridiagonal, from chi_1/2 chi_j = chi_{j+1/2} + chi_{j-1/2})

Observables in the ground state:
    <c_k> = 0 exactly (residual conjugation symmetry at the root site)
    sum_k Var(c_k) = <sum_k c_k^2> = 1 - <c0^2>   (exact SU(2) identity)
    E_B = (4/g^2)(1 - <c0>)                        magnetic energy
    Delta = E_1 - E_0                              gap

<c0^2> is evaluated without truncation error for the given state:
the state is padded by one level and c0 is applied twice.
"""
import numpy as np
import argparse, json


def basis(jmax):
    """Representations j = 0, 1/2, ..., jmax (jmax a multiple of 1/2)."""
    n = int(round(2 * jmax)) + 1
    return np.arange(n) / 2.0


def c0_matrix(n):
    """c0 in the orthonormal character basis, n levels."""
    C = np.zeros((n, n))
    for i in range(n - 1):
        C[i, i + 1] = C[i + 1, i] = 0.5
    return C


def hamiltonian(g2, jmax):
    js = basis(jmax)
    n = len(js)
    H = np.diag(2.0 * g2 * js * (js + 1.0))
    H += (4.0 / g2) * (np.eye(n) - c0_matrix(n))
    return H


def observables(g2, jmax):
    H = hamiltonian(g2, jmax)
    w, v = np.linalg.eigh(H)
    psi = v[:, 0]
    n = len(psi)
    C = c0_matrix(n)
    c0 = psi @ C @ psi
    # exact <c0^2>: pad one level so c0 psi has no truncation loss
    Cp = c0_matrix(n + 1)
    psip = np.append(psi, 0.0)
    c0sq = (Cp @ psip) @ (Cp @ psip)
    js = basis(jmax)
    EE = 2.0 * g2 * np.sum(psi**2 * js * (js + 1.0))
    EB = (4.0 / g2) * (1.0 - c0)
    return {
        "g2": g2,
        "jmax": jmax,
        "E0": w[0],
        "gap": w[1] - w[0],
        "c0": c0,
        "c0sq": c0sq,
        "sumVar_ck": 1.0 - c0sq,
        "E_electric": EE,
        "E_magnetic": EB,
        "p_j": (psi**2).tolist(),
    }


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--out", default="su2_plaquette_results.json")
    args = ap.parse_args()

    results = {"coupling_scan": [], "truncation_scan": []}

    # coupling scan at a converged truncation
    for g2 in np.geomspace(0.05, 20.0, 60):
        results["coupling_scan"].append(observables(float(g2), 20.0))

    # truncation scan at selected couplings
    for g2 in [0.5, 1.0, 4.0 / 2.2, 3.0, 5.0]:
        for jmax in [0.5, 1.0, 1.5, 2.0, 3.0, 5.0, 10.0, 20.0]:
            r = observables(g2, jmax)
            r.pop("p_j")
            results["truncation_scan"].append(r)

    with open(args.out, "w") as f:
        json.dump(results, f, indent=1)

    # console summary
    print("Truncation scan (sum_k Var(c_k), gap):")
    print(f"{'g2':>7} {'jmax':>5} {'<c0>':>9} {'sumVar':>9} {'gap':>9}")
    for r in results["truncation_scan"]:
        print(f"{r['g2']:7.3f} {r['jmax']:5.1f} {r['c0']:9.5f} {r['sumVar_ck']:9.5f} {r['gap']:9.5f}")


if __name__ == "__main__":
    main()
