#!/usr/bin/env python3
"""
Probe test: does the twist variance of the gauge vacuum shift a probe's phase
(an energy shift, read as a mass) or only damp its coherence?

Part of the SU2_Quantum project (R. Sakidja, Missouri State University).
Code drafted with AI (LLM) assistance (Claude, Anthropic) and reviewed by the author.

Setup
-----
Probe: two level system, prepared in |+>. Coupling to one plaquette p:
    H = H_gauge (x) 1 + lambda * W_p (x) |1><1|,    W_p = sum_k c_k^2 = 1 - c0^2.
W_p is gauge invariant. Because <c_k> = 0 exactly, <W_p> = sum_k Var(c_k).
The probe coherence is the overlap
    C(t) = <0| exp(i H0 t) exp(-i (H0 + lambda W) t) |0>,   H0 = H_gauge, |0> its ground state.
Phase phi(t) = -arg C(t); visibility |C(t)|.

Exact decomposition (eigenstates |n'> of H0 + lambda W):
    C(t) = sum_n |<n'|0>|^2 exp(-i (E'_n - E_0) t)
* Coherent part: weight Z = |<0'|0>|^2 rotating at the exact energy shift
      dE = E'_0 - E_0 = lambda <W> - lambda^2 sum_n |<n|W|0>|^2/(E_n - E_0) + ...
  The first term is the variance itself; the second is the Lamb shift type correction.
* Incoherent part: weight 1 - Z spread over excited frequencies. On a finite
  (gapped) lattice this is bounded, oscillating coherence loss, not decay.
Trace only (mean value) baseline: replacing c_k by <c_k> = 0 gives W = 0, no phase.
"""
import argparse, json
import numpy as np
from su2ham.systems import BUILDERS
from su2ham.engine import apply_word_trace


def W_matrix(sysm, p):
    """<a| (1 - c0_p^2) |b> in the invariant basis, exact (intermediate reps untruncated)."""
    n = sysm.n
    M = np.zeros((n, n))
    word = sysm.plaquettes[p]
    for js, V in sysm.blocks.items():
        o_s, n_s = sysm.index[js]
        img = apply_word_trace({js: V}, word)            # c0 |b>, no truncation of intermediate reps
        img2 = apply_word_trace(img, word)               # c0^2 |b>, projected onto the basis below
        for key, T in img2.items():
            if key not in sysm.blocks:
                continue
            o_t, n_t = sysm.index[key]
            M[o_t:o_t + n_t, o_s:o_s + n_s] += sysm.blocks[key].reshape(n_t, -1) @ T.reshape(n_s, -1).T
    C2 = 0.5 * (M + M.T)
    return np.eye(n) - C2


def probe(sysm, g2, lam, p=0, signs=None, tmax=40.0, nt=801):
    H0 = sysm.hamiltonian(g2, signs).toarray()
    W = W_matrix(sysm, p)
    E, V = np.linalg.eigh(H0)
    psi0 = V[:, 0]
    meanW = float(psi0 @ W @ psi0)
    E1, V1 = np.linalg.eigh(H0 + lam * W)
    ov = V1.T @ psi0
    weights = ov ** 2
    dE = E1[0] - E[0]
    Wn0 = V.T @ (W @ psi0)
    lamb = -lam ** 2 * np.sum(Wn0[1:] ** 2 / (E[1:] - E[0]))
    loss_pt = lam ** 2 * np.sum(Wn0[1:] ** 2 / (E[1:] - E[0]) ** 2)
    t = np.linspace(0, tmax, nt)
    Ct = (weights[None, :] * np.exp(-1j * np.outer(t, E1 - E[0]))).sum(axis=1)
    phase = -np.unwrap(np.angle(Ct))
    slope = np.polyfit(t[nt // 2:], phase[nt // 2:], 1)[0]
    return dict(g2=g2, lam=lam, sumVar=meanW, dE=float(dE), first_order=lam * meanW,
                lamb_pt=float(lamb), Z=float(weights[0]), coherence_loss=1 - float(weights[0]),
                coherence_loss_pt=float(loss_pt), varW=float(Wn0[1:] @ Wn0[1:]),
                gap=float(E[1] - E[0]), phase_slope=float(slope),
                min_visibility=float(np.abs(Ct).min()), t=t.tolist(), phase=phase.tolist(),
                visibility=np.abs(Ct).tolist())


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--system", default="single")
    ap.add_argument("--jmax", type=float, default=10.0)
    ap.add_argument("--g2", type=float, nargs="+", default=[0.5, 1.0, 4 / 2.2, 3.0, 5.0])
    ap.add_argument("--lam", type=float, nargs="+", default=[0.1, 0.5, 1.0])
    ap.add_argument("--twist", type=int, nargs="+", default=None)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    S = BUILDERS[a.system](a.jmax)
    recs = []
    for g in a.g2:
        for lam in a.lam:
            r = probe(S, g, lam, signs=a.twist)
            r.update(system=a.system, jmax=a.jmax, twist=a.twist)
            recs.append(r)
            print(f"{a.system} tw={a.twist} g2={g:.4f} lam={lam:.2f}: <W>=SumVar={r['sumVar']:.5f}  "
                  f"dE={r['dE']:.6f} (1st order {r['first_order']:.6f}, Lamb {r['lamb_pt']:+.6f})  "
                  f"slope={r['phase_slope']:.6f}  coherence loss={r['coherence_loss']:.2e} "
                  f"(pt {r['coherence_loss_pt']:.2e})  min vis={r['min_visibility']:.4f}", flush=True)
    json.dump(recs, open(a.out, "w"))
