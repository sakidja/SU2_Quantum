#!/usr/bin/env python3
"""Figure for the SU(3) Z3 lock: python su3_lock_figs.py [su3_lock_results.json]"""
import json
import os
import sys

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

COL = ['#2A6FB0', '#C27A12', '#2E9E6B', '#B4457A', '#555555']
FS = float(os.environ.get('FIGSCALE', '1'))   # FIGSCALE=1.5 for paper figures (larger text)
plt.rcParams.update({'font.size': 11 * FS, 'axes.spines.top': False, 'axes.spines.right': False})

d = json.load(open(sys.argv[1] if len(sys.argv) > 1 else 'su3_lock_results.json'))
n = np.arange(len(d['random']['C_re']))
fig, ax = plt.subplots(1, 3, figsize=(16, 5.6))

ex = np.array(d['expected_Z3']['re'])
ax[0].plot(n, ex, 'k:', lw=1, zorder=0)
ax[0].plot(n, d['locked_Z3']['C_re'], 'o-', color=COL[0], ms=6*FS**0.5, label=r'Z$_3$ vortex, $a=2\pi/3$')
ax[0].plot(n, d['locked_pi2']['C_re'], 's-', color=COL[2], ms=5*FS**0.5, label=r'non center, $a=\pi/2$')
ax[0].plot(n, d['random']['C_re'], 'o-', color=COL[1], ms=5*FS**0.5, label='random')
ax[0].axhline(0, color='k', lw=0.6)
ax[0].set_xlabel('number of loops n'); ax[0].set_ylabel(r'Re $C_n$ = Re $\frac{1}{3}$Tr $W^n$')
ax[0].set_title('(a) locked vs random'); ax[0].legend(fontsize=8.5*FS, loc='upper center', bbox_to_anchor=(0.5, -0.18), ncol=1)

for i, eta in enumerate(['0.05', '0.1', '0.2']):
    ax[1].plot(n, d[f'locked_Z3_noise{eta}']['C_re'], 'o-', color=COL[i], ms=5*FS**0.5,
               label=rf'locked $\eta$={eta}')
    ax[1].plot(n, d[f'random_noise{eta}']['C_re'], 'x--', color=COL[i], ms=5*FS**0.5, alpha=0.6,
               label=rf'random $\eta$={eta}')
ax[1].axhline(0, color='k', lw=0.6)
ax[1].set_xlabel('number of loops n'); ax[1].set_ylabel(r'Re $C_n$')
ax[1].set_title('(b) link noise'); ax[1].legend(fontsize=8.5*FS, loc='upper center', bbox_to_anchor=(0.5, -0.18), ncol=2)

names = ['random', 'locked_Z3', 'locked_pi2']
labs = ['random', r'Z$_3$', r'$\pi/2$']
vals = [d[k]['local_Sigma'] for k in names]
ax[2].bar(range(3), vals, color=[COL[1], COL[0], COL[2]], width=0.6)
ax[2].axhline(8 / 9, color='k', ls='--', lw=1, label='Haar 8/9')
for i, v in enumerate(vals):
    ax[2].text(i, v + 0.01, f'{v:.3f}', ha='center', fontsize=8.5*FS)
ax[2].set_xticks(range(3)); ax[2].set_xticklabels(labs)
ax[2].set_ylim(0, 1.05)
ax[2].set_ylabel(r'$1-\langle|\frac{1}{3}\mathrm{Tr}\,U|^2\rangle$ per link')
ax[2].set_title('(c) local statistic'); ax[2].legend(fontsize=9*FS, loc='lower right')
fig.tight_layout()
fig.savefig('Fig_N9_su3_lock.png', dpi=250, bbox_inches='tight')
print('saved Fig_N9_su3_lock.png')
