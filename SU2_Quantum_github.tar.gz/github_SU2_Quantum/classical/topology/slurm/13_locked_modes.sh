#!/bin/bash -l
# Job 13: three mode test at the scale of the lock (Figure T8).
#   sbatch slurm/13_locked_modes.sh        (L = 24, about 1 h)
#   sbatch slurm/13_locked_modes.sh 32     (larger volume, about 2.5 h)
# Resubmit the same line to resume if the time limit is hit.
#SBATCH -A mXXXX                  # <-- your NERSC project
#SBATCH -C cpu
#SBATCH -q regular
#SBATCH -N 1
#SBATCH -t 03:00:00
#SBATCH -J su2topo_lmodes
#SBATCH -o %x_%j.out
L=${1:-24}
cd "$SLURM_SUBMIT_DIR/.."
source slurm/env_perlmutter.sh
srun -n 128 -c 2 --cpu-bind=cores "$PY" locked_modes.py \
     --L $L --ntherm 500 --nmeas 100 --skip 10 --rmax 7 \
     --out runs/lm$L --wall $(( 3*3600 - 900 ))
FIGSCALE=1.55 "$PY" locked_modes_analysis.py runs/lm$L --outdir figures_lmodes_L$L
