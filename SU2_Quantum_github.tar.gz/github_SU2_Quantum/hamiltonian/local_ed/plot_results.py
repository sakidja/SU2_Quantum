import json, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
R = json.load(open("su2_plaquette_results.json"))
cs = R["coupling_scan"]; ts = R["truncation_scan"]
g2 = np.array([r["g2"] for r in cs])
sv = np.array([r["sumVar_ck"] for r in cs]); c0 = np.array([r["c0"] for r in cs])
gap = np.array([r["gap"] for r in cs])
C = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4"]
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.edgecolor": "#888", "axes.grid": True, "grid.color": "#e6e6e6", "grid.linewidth": 0.6})
fig, ax = plt.subplots(1, 3, figsize=(13, 3.9))
a = ax[0]
a.plot(g2, sv, color=C[0], lw=2, label=r"$\Sigma_k\,\mathrm{Var}(c_k) = 1-\langle c_0^2\rangle$")
a.plot(g2, c0, color=C[1], lw=2, label=r"$\langle c_0\rangle = \frac{1}{2}\langle \mathrm{Tr}\,U_p\rangle$")
a.axhline(0.75, color="#666", lw=1, ls="--"); a.text(0.06, 0.765, "Haar limit 3/4", color="#444", fontsize=8.5)
gb = 4/2.2
a.axvline(gb, color="#aaa", lw=1, ls=":")
a.plot([gb], [0.617], "D", ms=8, mfc="white", mec="#222", mew=1.5, label=r"Wilson ensemble, $\beta=2.2$")
a.set_xscale("log"); a.set_xlabel(r"$g^2$"); a.set_ylim(0, 1.02)
a.set_title("(a) Ground state, single plaquette", loc="left", fontsize=10.5)
a.legend(fontsize=8.5, frameon=False, loc="lower right", bbox_to_anchor=(1.0, 0.16))
b = ax[1]
b.plot(g2, gap, color=C[0], lw=2)
i = np.argmin(gap); b.plot(g2[i], gap[i], "o", ms=8, color=C[0], mec="white", mew=2)
b.annotate(f"min {gap[i]:.2f} at $g^2$={g2[i]:.2f}", (g2[i], gap[i]), xytext=(8, 14), textcoords="offset points", fontsize=8.5)
b.set_xscale("log"); b.set_yscale("log"); b.set_xlabel(r"$g^2$")
b.set_title(r"(b) Gap $\Delta = E_1-E_0$ (lattice units)", loc="left", fontsize=10.5)
c = ax[2]
for k, gg in enumerate(sorted({r["g2"] for r in ts})):
    rows = [r for r in ts if r["g2"] == gg]
    jm = [r["jmax"] for r in rows]; s = [r["sumVar_ck"] for r in rows]
    c.plot(jm, s, "-o", color=C[k], lw=2, ms=6, mec="white", mew=1.5, label=f"$g^2$={gg:.3g}")
c.set_xscale("log"); c.set_xlabel(r"truncation $j_{\max}$"); c.set_xlim(0.4, 35)
c.set_title(r"(c) $\Sigma_k\,\mathrm{Var}(c_k)$ vs truncation", loc="left", fontsize=10.5)
c.legend(fontsize=8.5, frameon=False, loc="center left", bbox_to_anchor=(1.01, 0.5))
fig.tight_layout(); fig.savefig("su2_plaquette_v3.png", dpi=200)
