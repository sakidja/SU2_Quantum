"""Twist energy on the 1x1 and 2x1 periodic lattices at matched couplings."""
import json, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from su2_two_plaquette_ed import build_torus, solve_torus
from su2_torus21_ed import build
S2 = build(2.0)
print(f"2x1 jmax=2 Casimir check {S2['cas_err']:.1e}")
R = json.load(open("su2_torus21_results.json"))
St = build_torus(4.0)
rows = []
for u15, t15, u2, t2 in zip(R["1.5"]["untwisted"], R["1.5"]["twisted"], R["2.0"]["untwisted"], R["2.0"]["twisted"]):
    g = u2["g2"]
    a = solve_torus(St, g); b = solve_torus(St, g, s=-1)
    d1 = b["E"][0] - a["E"][0]; d2 = t2["E"][0] - u2["E"][0]; d2p = t15["E"][0] - u15["E"][0]
    rows.append(dict(g2=g, dE_1x1=d1, dE_2x1=d2, dE_2x1_trunc_shift=d2 - d2p, ratio=d2 / d1,
                     SV_1x1_u=a["sumVar"], SV_1x1_t=b["sumVar"], SV_2x1_u=u2["sumVar_A"], SV_2x1_t=t2["sumVar_A"]))
    print(f"g2={g:.3f}  dE(1x1)={d1:.4f}  dE(2x1)={d2:.4f} (jmax 1.5->2 shift {d2-d2p:+.4f})  ratio={d2/d1:.3f}"
          f"  SumVar 2x1 untw={u2['sumVar_A']:.4f} tw={t2['sumVar_A']:.4f}")
json.dump(rows, open("su2_twist_size_comparison.json", "w"), indent=1)
g = np.array([r["g2"] for r in rows]); ok = np.array([abs(r["dE_2x1_trunc_shift"]) < 0.01 for r in rows])
C = ["#2a78d6", "#eb6834", "#1baf7a"]
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.edgecolor": "#888", "axes.grid": True, "grid.color": "#e6e6e6", "grid.linewidth": 0.6})
fig, ax = plt.subplots(1, 3, figsize=(14, 4.0))
a = ax[0]
a.plot(g[ok], [r["dE_1x1"] for r, k in zip(rows, ok) if k], "-o", color=C[0], lw=2, ms=6, mec="white", mew=1.5, label="1x1 periodic")
a.plot(g[ok], [r["dE_2x1"] for r, k in zip(rows, ok) if k], "-o", color=C[1], lw=2, ms=6, mec="white", mew=1.5, label="2x1 periodic")
a.set_xscale("log"); a.set_yscale("log"); a.set_xlabel(r"$g^2$")
a.set_title(r"(a) Center twist energy $\Delta E$", loc="left", fontsize=10.5); a.legend(frameon=False, fontsize=9)
b = ax[1]
b.plot(g[ok], [r["ratio"] for r, k in zip(rows, ok) if k], "-o", color=C[2], lw=2, ms=6, mec="white", mew=1.5)
b.axhline(1, color="#666", lw=1, ls="--"); b.text(1.85, 1.02, "size independent", fontsize=8.5, color="#444")
b.set_xscale("log"); b.set_xlabel(r"$g^2$"); b.set_ylim(0, 1.15)
b.set_title(r"(b) $\Delta E(2\times1)\,/\,\Delta E(1\times1)$", loc="left", fontsize=10.5)
c = ax[2]
c.plot(g[ok], [r["SV_2x1_u"] for r, k in zip(rows, ok) if k], "-o", color=C[0], lw=2, ms=6, mec="white", mew=1.5, label="untwisted")
c.plot(g[ok], [r["SV_2x1_t"] for r, k in zip(rows, ok) if k], "-o", color=C[2], lw=2, ms=6, mec="white", mew=1.5, label="twisted")
c.axhline(0.75, color="#666", lw=1, ls=":")
c.set_xscale("log"); c.set_xlabel(r"$g^2$")
c.set_title(r"(c) 2x1 periodic: $\Sigma_k\,\mathrm{Var}(c_k)$ per plaquette", loc="left", fontsize=10.5); c.legend(frameon=False, fontsize=9)
fig.tight_layout(); fig.savefig("su2_twist_size_v3.png", dpi=200)
