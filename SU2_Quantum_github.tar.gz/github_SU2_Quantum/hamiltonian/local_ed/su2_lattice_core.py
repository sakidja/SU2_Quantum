"""
Core machinery for gauge fixed SU(2) Kogut Susskind Hamiltonians with one
or two dynamical link variables, in the Peter Weyl basis D^j_{mn}(U).

Part of the SU2_Quantum project (R. Sakidja, Missouri State University).
Code drafted with AI (LLM) assistance (Claude, Anthropic) and reviewed by the author.

A wavefunction of one link is f(U) = sum_{j,m,n} c_{jmn} e^j_{mn}(U), with the
Haar orthonormal functions e^j_{mn} = sqrt(2j+1) D^j_{mn}(U).
Multiplication by a matrix element of the fundamental, D^{1/2}_{ab}(U),
is exact through the Clebsch Gordan series
    D^{1/2}_{ab} D^j_{cd} = sum_k <1/2 a; j c|k a+c> <1/2 b; j d|k b+d> D^k_{a+c, b+d}.
Gauge invariant states of two links (U1, U2) under the residual global
conjugation U -> g U g^-1 are built explicitly:
    c_{(J m n),(j2 m' n')} = sum_M <J m; j2 m'|j1 M> <J n; j2 n'|j1 M>
labelled by (J, j2, j1).
"""
import numpy as np
import scipy.sparse as sp
from functools import lru_cache
from sympy import Rational
from sympy.physics.wigner import clebsch_gordan


def half(x):
    return Rational(int(round(2 * x)), 2)


@lru_cache(maxsize=None)
def cg(j1, m1, j2, m2, j, m):
    if abs(m1) > j1 or abs(m2) > j2 or abs(m) > j or abs(m1 + m2 - m) > 1e-12:
        return 0.0
    return float(clebsch_gordan(half(j1), half(j2), half(j), half(m1), half(m2), half(m)))


def jlist(jcut):
    return [k / 2 for k in range(int(round(2 * jcut)) + 1)]


def mlist(j):
    return [j - k for k in range(int(round(2 * j)) + 1)]


class LinkSpace:
    """Peter Weyl basis of one link, j <= jcut."""

    def __init__(self, jcut):
        self.jcut = jcut
        self.idx = {}
        self.labels = []
        for j in jlist(jcut):
            for m in mlist(j):
                for n in mlist(j):
                    self.idx[(j, m, n)] = len(self.labels)
                    self.labels.append((j, m, n))
        self.dim = len(self.labels)
        self.casimir = np.array([j * (j + 1) for (j, m, n) in self.labels])
        self._M = {}

    def M(self, a, b):
        """Multiplication by D^{1/2}_{ab}(U), a, b in {+1/2, -1/2}."""
        key = (a, b)
        if key in self._M:
            return self._M[key]
        rows, cols, vals = [], [], []
        for s, (j, c, d) in enumerate(self.labels):
            for k in (j - 0.5, j + 0.5):
                if k < 0 or k > self.jcut + 1e-9:
                    continue
                # orthonormal (Haar) basis e^j_{cd} = sqrt(2j+1) D^j_{cd}
                v = cg(0.5, a, j, c, k, a + c) * cg(0.5, b, j, d, k, b + d) * np.sqrt((2 * j + 1) / (2 * k + 1))
                if v != 0.0:
                    rows.append(self.idx[(k, a + c, b + d)])
                    cols.append(s)
                    vals.append(v)
        op = sp.csr_matrix((vals, (rows, cols)), shape=(self.dim, self.dim))
        self._M[key] = op
        return op

    def Mdag(self, a, b):
        """Multiplication by (U^dagger)_{ab} = conj(U_{ba}) = (-1)^(b-a) U_{-b,-a}."""
        sign = (-1) ** int(round(b - a))
        return sign * self.M(-b, -a)

    def half_trace(self):
        return 0.5 * (self.M(0.5, 0.5) + self.M(-0.5, -0.5))

    def spin_mats(self, j):
        ms = mlist(j)
        d = len(ms)
        Sz = np.diag(ms)
        Sp = np.zeros((d, d))
        for i in range(1, d):
            m = ms[i]
            Sp[i - 1, i] = np.sqrt(j * (j + 1) - m * (m + 1))
        Sx = 0.5 * (Sp + Sp.T)
        Sy = -0.5j * (Sp - Sp.T)
        return [Sx, Sy, Sz]

    def generators(self):
        """Left multiplication generators L^a (c -> S^T c) and conjugation K^a = L^a + R^a."""
        L = [sp.lil_matrix((self.dim, self.dim), dtype=complex) for _ in range(3)]
        K = [sp.lil_matrix((self.dim, self.dim), dtype=complex) for _ in range(3)]
        for j in jlist(self.jcut):
            ms = mlist(j)
            S = self.spin_mats(j)
            for a in range(3):
                ST = S[a].T
                for (i1, m) in enumerate(ms):
                    for (i2, n) in enumerate(ms):
                        src = self.idx[(j, m, n)]
                        # (S^T c)_{m' n} = sum_m ST[m', m] c_{m n}
                        for (k, mp) in enumerate(ms):
                            v = ST[k, i1]
                            if v != 0:
                                L[a][self.idx[(j, mp, n)], src] += v
                                K[a][self.idx[(j, mp, n)], src] += v
                        # -(c S^T)_{m n'} = -sum_n c_{m n} ST[n, n']
                        for (k, np_) in enumerate(ms):
                            v = ST[i2, k]
                            if v != 0:
                                K[a][self.idx[(j, m, np_)], src] -= v
        return [x.tocsr() for x in L], [x.tocsr() for x in K]


def invariant_basis_two_links(sp1, sp2, jmax, j1max=None):
    """Columns = normalized gauge invariant states (J, j2, j1), all reps on sp1/sp2 <= jmax.
    Returns sparse matrix (dim1*dim2, n_inv) and the label list."""
    rows, cols, vals, labels = [], [], [], []
    col = 0
    for J in jlist(jmax):
        for j2 in jlist(jmax):
            j1 = abs(J - j2)
            while j1 <= J + j2 + 1e-9:
                if j1max is None or j1 <= j1max + 1e-9:
                    entries = {}
                    for M in mlist(j1):
                        for m in mlist(J):
                            mp = M - m
                            if abs(mp) > j2 + 1e-9:
                                continue
                            a = cg(J, m, j2, mp, j1, M)
                            if a == 0.0:
                                continue
                            for n in mlist(J):
                                np_ = M - n
                                if abs(np_) > j2 + 1e-9:
                                    continue
                                b = cg(J, n, j2, np_, j1, M)
                                if b == 0.0:
                                    continue
                                r = sp1.idx[(J, m, n)] * sp2.dim + sp2.idx[(j2, mp, np_)]
                                entries[r] = entries.get(r, 0.0) + a * b
                    norm = np.sqrt(sum(v * v for v in entries.values()))
                    for r, v in entries.items():
                        rows.append(r)
                        cols.append(col)
                        vals.append(v / norm)
                    labels.append((J, j2, j1))
                    col += 1
                j1 += 1.0
    B = sp.csr_matrix((vals, (rows, cols)), shape=(sp1.dim * sp2.dim, col))
    return B, labels


def kron(A, B):
    return sp.kron(A, B, format="csr")
