#!/bin/bash
# Larger lattices with the compact engine (engine2): the 3x1 torus at jmax 2.5
# (replaces the cancelled job) and the 2x2 torus at jmax 1, 1.5 and 2.
#   bash slurm/submit_large.sh
# Memory estimates (stored bases): 3x1 j2.5 about 1.5 GB, 2x2 j1.5 about 1.4 GB,
# 2x2 j2 about 70 GB; each worker also holds one batch (SU2HAM_CHUNK entries,
# default 2e8, about 1.6 GB) plus its images. The 2x2 j2 job is compute bound.
# Part of the SU2_Quantum project. Drafted with AI (LLM) assistance (Claude, Anthropic).
set -e
mkdir -p logs results
sub () {  # name system jmax walltime nproc twists
  sbatch --job-name=$1 --time=$4 \
         --export=ALL,SYSTEM=$2,JMAX=$3,NPROC=$5,TAG=,TWISTS="$6" slurm/run_case.sbatch
}
sub su2_t31_j2.5 torus3x1 2.5 24:00:00 64 "--twist 1 1 1 --twist -1 1 1"
sub su2_t22_j1   torus2x2 1   01:00:00 128 "--twist 1 1 1 1 --twist -1 1 1 1"
sub su2_t22_j1.5 torus2x2 1.5 12:00:00 64  "--twist 1 1 1 1 --twist -1 1 1 1"
sub su2_t22_j2   torus2x2 2   48:00:00 32  "--twist 1 1 1 1 --twist -1 1 1 1"
