#!/usr/bin/env python3
"""
su2_4d_potential.py
The string tension of 4D SU(2), measured the same way at every coupling, with the
multihit (link integration) method of Parisi, Petronzio and Rapuano.

Each time direction link of a Wilson loop in a (space, time) plane is replaced by its
exact average in the heat bath of its neighbours,

    <U_t(x)> = [I_2(beta k) / I_1(beta k)] * Abar^+ ,   A = k Abar (the staple sum),

the same distribution the Creutz heat bath samples (su2_4d_core.sweep). The loop is
linear in each such link and no two replaced links share a plaquette when the loop is
at least two sites wide, so <W(R,T)> is unchanged while its noise falls sharply.
Loops with R = 1 are measured without replacement.

Per configuration: W(R,T) for R = 1..rmax and T = 1..tmax (tmax defaults to rmax), averaged over sites and the three
(space, time) planes, with and without multihit. The static potential follows from
V(R) = ln[W(R,T)/W(R,T+1)] at large T, and a^2 sigma from a fit
V(R) = V0 + sigma R - e/R (su2_4d_potential_analysis.py).

Resumable npz per rank: <out>/pot_L{L}_b{beta}_rank{r}.npz

  python su2_4d_potential.py --L 8 --beta 2.3 --ntherm 100 --nmeas 10 --out runs/pot8     # laptop
  srun -n 128 -c 2 --cpu-bind=cores python su2_4d_potential.py --L 16 --beta 2.3 --out runs/pot_L16_b2.3
"""
import argparse
import json
import os
import sys
import time

import numpy as np
from scipy.special import ive

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from su2_4d_core import (ND, qmul, qconj, shift, checkerboard, sweep, staple_sum,   # noqa: E402
                         line_products, rect_loop)

try:
    from mpi4py import MPI
    COMM = MPI.COMM_WORLD
    RANK, SIZE = COMM.Get_rank(), COMM.Get_size()
except Exception:
    COMM, RANK, SIZE = None, 0, 1

T_DIR = 3


def multihit_links(links, beta):
    """Heat bath average of every time direction link: [I2/I1](beta k) * conj(A/k)."""
    A = staple_sum(links, T_DIR)
    k = np.linalg.norm(A, axis=-1)
    b = beta * k
    f = ive(2, b) / ive(1, b)                      # exponentially scaled ratio, stable for large b
    return f[..., None] * qconj(A / k[..., None])


def measure(links, beta, rmax, tmax=None):
    tmax = tmax or rmax
    Ut = multihit_links(links, beta)
    raw = np.zeros((rmax + 1, tmax + 1))
    mh = np.zeros((rmax + 1, tmax + 1))
    tl_raw = line_products(links[T_DIR], T_DIR, tmax)
    tl_mh = line_products(Ut, T_DIR, tmax)
    for mu in range(3):                            # spatial direction of the loop
        sl = line_products(links[mu], mu, rmax)
        for R in range(1, rmax + 1):
            for T in range(1, tmax + 1):
                lines_raw = {mu: sl, T_DIR: tl_raw}
                w = rect_loop(lines_raw, mu, T_DIR, R, T)[..., 0].mean()
                raw[R, T] += w / 3
                if R >= 2:
                    lines_mh = {mu: sl, T_DIR: tl_mh}
                    mh[R, T] += rect_loop(lines_mh, mu, T_DIR, R, T)[..., 0].mean() / 3
                else:
                    mh[R, T] += w / 3
    return raw, mh


def rng_state_json(rng):
    return json.dumps(rng.bit_generator.state)


def rng_from_json(s):
    rng = np.random.default_rng()
    rng.bit_generator.state = json.loads(s)
    return rng


def save(path, links, rng, sweeps, raws, mhs, args):
    tmp = path + '.tmp.npz'
    np.savez(tmp, links=links, rng=rng_state_json(rng), sweeps_done=sweeps,
             raw=np.array(raws) if raws else np.zeros((0, args.rmax + 1, args.tmax + 1)),
             mh=np.array(mhs) if mhs else np.zeros((0, args.rmax + 1, args.tmax + 1)),
             meta=json.dumps(dict(L=args.L, beta=args.beta, rmax=args.rmax, tmax=args.tmax, skip=args.skip,
                                  ntherm=args.ntherm, seed=args.seed, nd=ND)))
    os.replace(tmp, path)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--L', type=int, default=16)
    ap.add_argument('--beta', type=float, default=2.3)
    ap.add_argument('--ntherm', type=int, default=300)
    ap.add_argument('--nmeas', type=int, default=100)
    ap.add_argument('--skip', type=int, default=10)
    ap.add_argument('--rmax', type=int, default=0, help='largest R (0: L/2)')
    ap.add_argument('--tmax', type=int, default=0, help='largest T (0: same as rmax; at most L/2)')
    ap.add_argument('--seed', type=int, default=20261001)
    ap.add_argument('--out', default='runs/pot')
    ap.add_argument('--ckpt_every', type=int, default=10)
    ap.add_argument('--wall', type=float, default=0)
    args = ap.parse_args()
    args.rmax = args.rmax or args.L // 2
    args.tmax = args.tmax or args.rmax
    if args.tmax > args.L // 2:
        raise SystemExit('tmax must be <= L/2')
    L = args.L
    os.makedirs(args.out, exist_ok=True)
    path = os.path.join(args.out, f'pot_L{L}_b{args.beta}_rank{RANK}.npz')
    t0 = time.time()
    idx = checkerboard(L)
    if os.path.exists(path):
        z = np.load(path, allow_pickle=False)
        links = z['links'].copy(); rng = rng_from_json(str(z['rng'])); sweeps = int(z['sweeps_done'])
        raws, mhs = list(z['raw']), list(z['mh'])
    else:
        rng = np.random.default_rng([args.seed, RANK])
        links = np.zeros((ND,) + (L,) * ND + (4,)); links[..., 0] = 1.0
        sweeps, raws, mhs = 0, [], []
    if RANK == 0:
        print(f'[potential] L={L} beta={args.beta} ranks={SIZE} rmax={args.rmax} nmeas={args.nmeas}', flush=True)
    stopped = False
    while sweeps < args.ntherm:
        sweep(links, args.beta, rng, idx); sweeps += 1
        if sweeps % 50 == 0:
            save(path, links, rng, sweeps, raws, mhs, args)
            if args.wall and time.time() - t0 > args.wall:
                stopped = True; break
    while not stopped and len(raws) < args.nmeas:
        for _ in range(args.skip):
            sweep(links, args.beta, rng, idx); sweeps += 1
        r, m = measure(links, args.beta, args.rmax, args.tmax)
        raws.append(r); mhs.append(m)
        if len(raws) % args.ckpt_every == 0 or len(raws) == args.nmeas:
            save(path, links, rng, sweeps, raws, mhs, args)
            if RANK == 0:
                print(f'  meas {len(raws)}/{args.nmeas}  W(2,2) raw {r[2,2]:.5f} multihit {m[2,2]:.5f}  '
                      f't={time.time()-t0:.0f}s', flush=True)
        if args.wall and time.time() - t0 > args.wall:
            stopped = True
    save(path, links, rng, sweeps, raws, mhs, args)
    if COMM is not None:
        COMM.Barrier()
    if RANK == 0:
        print('stopped at wall limit; rerun the same command to resume' if stopped else 'done', flush=True)


if __name__ == '__main__':
    main()
