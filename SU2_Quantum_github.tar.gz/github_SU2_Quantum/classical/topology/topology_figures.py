#!/usr/bin/env python3
"""
topology_figures.py
Figures from one or more summary_topo_L*.json files (any volumes).

  FigT1  hedgehog charge correlator: contact term, negative tail, running sum
         S(R) -> 0 (the total charge vanishes, so chi(k=0) = 0 exactly)
  FigT2  Wilson loops: -ln W(R,R) and Creutz ratios (points with W > 3 sigma)
  FigT3  neutrino probe around loops: holonomy angle histogram vs Haar density,
         coherence C_n = <cos n psi>, probe variance V_nu(R)
  FigT5  center vortices: W_{n_v}/W_0 vs (-1)^{n_v}, holonomy angle for even and
         odd vortex number, hedgehogs vs vortices
  FigT6  ground state counterpart of Figure 17: coherence C_n after n turns by vortex
         parity; odd turns flip sign with odd n_v, even turns are blind to the lock
  FigT4  lock test: <W> binned by hedgehog count next to the loop surface,
         real configuration vs displaced (null) charge field

Usage
    python topology_figures.py runs/L16/summary_topo_L16.json [more ...] --outdir figures
"""
import argparse
import json
import os

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

COL = ['#2A6FB0', '#C27A12', '#2E9E6B', '#B4457A', '#555555']
FS = float(os.environ.get('FIGSCALE', '1'))   # FIGSCALE=1.5 for paper figures (larger text)
plt.rcParams.update({'font.size': 11 * FS, 'axes.spines.top': False, 'axes.spines.right': False})


def load(paths):
    out = []
    for p in paths:
        with open(p) as f:
            out.append(json.load(f))
    return sorted(out, key=lambda s: s['L'])


def fig1(S, od):
    fig, ax = plt.subplots(1, 2, figsize=(12, 4.6))
    for i, s in enumerate(S):
        sh = s['C_Q_shell']
        r = np.sqrt([int(k) for k in sh])
        m = np.array([v[0] for v in sh.values()]); e = np.array([v[1] for v in sh.values()])
        ax[0].errorbar(r[1:], m[1:], yerr=e[1:], fmt='o-', color=COL[i], ms=5*FS**0.5, capsize=3,
                       label=f"L = {s['L']}   C(0) = {m[0]:.4f}")
        rs, rse = np.array(s['C_Q_running_sum'][0]), np.array(s['C_Q_running_sum'][1])
        ax[1].errorbar(np.arange(len(rs)), rs, yerr=rse, fmt='o-', color=COL[i], ms=5*FS**0.5,
                       capsize=3, label=f"L = {s['L']}")
    ax[0].axhline(0, color='k', lw=0.8)
    ax[0].set_xlabel('separation |r| (lattice units)'); ax[0].set_ylabel(r'$C_Q(r)=\langle Q(x)Q(x+r)\rangle$')
    ax[0].set_title('(a) charge correlator, r > 0')
    ax[0].legend(fontsize=9*FS)
    ax[1].axhline(0, color='k', lw=0.8)
    ax[1].set_xlabel('R'); ax[1].set_ylabel(r'$S(R)=\sum_{|r|\leq R} C_Q(r)$')
    ax[1].set_title('(b) running sum S(R)')
    ax[1].legend(fontsize=9*FS)
    fig.tight_layout(); fig.savefig(os.path.join(od, 'FigT1_charge_correlator.png'), dpi=250)
    plt.close(fig)


def fig2(S, od):
    fig, ax = plt.subplots(1, 2, figsize=(12, 4.6))
    for i, s in enumerate(S):
        W, We = np.array(s['W'][0]), np.array(s['W'][1])
        R = np.arange(1, W.shape[0])
        d = np.diag(W)[1:]; de = np.diag(We)[1:]
        ok = d > 3 * np.maximum(de, 1e-12)
        ax[0].errorbar(R[ok], -np.log(d[ok]), yerr=de[ok] / d[ok], fmt='o', color=COL[i],
                       ms=5*FS**0.5, capsize=3, label=f"L = {s['L']}")
        cr = s.get('creutz_ratio', {})
        if cr:
            ax[1].errorbar([int(k) for k in cr], [v[0] for v in cr.values()],
                           yerr=[v[1] for v in cr.values()], fmt='o-', color=COL[i], ms=5*FS**0.5,
                           capsize=3, label=f"L = {s['L']}")
    ax[0].set_xlabel('R'); ax[0].set_ylabel(r'$-\ln W(R,R)$'); ax[0].set_title('square Wilson loops')
    ax[0].legend(fontsize=8*FS)
    ax[1].set_xlabel('R'); ax[1].set_ylabel(r'Creutz ratio $\chi(R,R)$')
    ax[1].set_title('Creutz ratios (string tension estimate)'); ax[1].legend(fontsize=9*FS)
    fig.tight_layout(); fig.savefig(os.path.join(od, 'FigT2_wilson_loops.png'), dpi=250)
    plt.close(fig)


def fig3(S, od):
    s = S[-1]
    hol = s['holonomy']
    fig, ax = plt.subplots(1, 3, figsize=(16, 4.6))
    nb = len(hol[next(iter(hol))]['psi_hist'])
    edges = np.linspace(0, np.pi, nb + 1); cen = 0.5 * (edges[1:] + edges[:-1])
    for i, R in enumerate([k for k in hol if int(k) in (1, 2, 3, 4)]):
        h = np.array(hol[R]['psi_hist'], float)
        ax[0].plot(cen, h / h.sum() / (edges[1] - edges[0]), '-', color=COL[i], lw=1.8,
                   label=f'R = {R}')
    ax[0].plot(cen, 2 / np.pi * np.sin(cen) ** 2, 'k--', lw=1.2, label='Haar')
    ax[0].axvline(np.pi, color='grey', lw=0.6)
    ax[0].set_xlabel(r'holonomy angle $\psi$'); ax[0].set_ylabel('density')
    ax[0].set_title(f"(a) holonomy angle, L = {s['L']}"); ax[0].legend(fontsize=9*FS)
    for i, R in enumerate([k for k in hol if int(k) in (1, 2, 3, 4)]):
        c, e = np.array(hol[R]['C_n'][0]), np.array(hol[R]['C_n'][1])
        n = np.arange(1, len(c) + 1)
        ax[1].errorbar(n, c, yerr=e, fmt='o-', color=COL[i], ms=5*FS**0.5, capsize=3, label=f'R = {R}')
    ax[1].axhline(0, color='k', lw=0.8)
    ax[1].plot([1, 2, 3, 4, 5, 6], [0, -0.5, 0, 0, 0, 0], 'kx', ms=8, label='Haar')
    ax[1].set_xlabel('number of loops n'); ax[1].set_ylabel(r'$C_n=\langle\cos n\psi\rangle$')
    ax[1].set_title('(b) coherence after n loops'); ax[1].legend(fontsize=9*FS)
    for i, s2 in enumerate(S):
        h2 = s2['holonomy']
        Rs = sorted(h2, key=int)
        v = [h2[R]['V_nu'][0] for R in Rs]; ve = [h2[R]['V_nu'][1] for R in Rs]
        ax[2].errorbar([int(R) for R in Rs], v, yerr=ve, fmt='o-', color=COL[i], ms=5*FS**0.5,
                       capsize=3, label=f"L = {s2['L']}")
    ax[2].axhline(0.75, color='k', ls='--', lw=1, label='Haar value 3/4')
    ax[2].set_xlabel('loop side R'); ax[2].set_ylabel(r'$V_\nu = 1-\langle(\frac{1}{2}\mathrm{Tr}W)^2\rangle$')
    ax[2].set_title('(c) probe variance per loop'); ax[2].legend(fontsize=9*FS)
    fig.tight_layout(); fig.savefig(os.path.join(od, 'FigT3_holonomy_probe.png'), dpi=250)
    plt.close(fig)


def fig4(S, od):
    s = S[-1]
    lk = s['lock']
    Rs = sorted(lk, key=int)
    fig, ax = plt.subplots(1, len(Rs), figsize=(4.2 * len(Rs), 4.3), squeeze=False)
    for j, R in enumerate(Rs):
        d = lk[R]['byN']
        for tag, c, lab, off in [('real', COL[0], 'real charges', -0.08),
                                 ('null', COL[1], 'displaced (null)', 0.08)]:
            m = np.array(d[f'{tag}_mean']); e = np.array(d[f'{tag}_err'])
            n = np.array(d[f'{tag}_count'])
            ok = n > 2000
            x = np.arange(len(m))[ok]
            ax[0, j].errorbar(x + off, m[ok], yerr=e[ok], fmt='o-', color=c, ms=5*FS**0.5, capsize=3, label=lab)
        ax[0, j].set_xlabel('hedgehogs next to the surface, N = sum |Q|')
        ax[0, j].set_title(f'R = {R}')
        if j == 0:
            ax[0, j].set_ylabel(r'$\langle \frac{1}{2} \mathrm{Tr}\,W \mid N\rangle$')
            ax[0, j].legend(fontsize=9*FS)
    fig.suptitle(f"lock test, L = {s['L']}: does the loop feel the hedgehogs it spans?", y=1.02)
    fig.tight_layout(); fig.savefig(os.path.join(od, 'FigT4_lock_test.png'), dpi=250, bbox_inches='tight')
    plt.close(fig)


def fig5(S, od):
    Sv = [x for x in S if 'vortex' in x]
    if not Sv:
        return
    s = max(Sv, key=lambda x: x['vortex']['n_configs'])   # most configurations
    V = s['vortex']; lp = V['loops']
    Rs = [R for R in sorted(lp, key=int) if int(R) >= 2 and lp[R]['count'][0] > 2000
          and sum(1 for c, e in zip(lp[R]['count'], lp[R]['ratio_err']) if c > 2000 and e < 0.15) >= 3][:4]
    fig, ax = plt.subplots(1, 3, figsize=(16, 4.6))
    for i, R in enumerate(Rs):
        c = np.array(lp[R]['count']); r = np.array(lp[R]['ratio']); e = np.array(lp[R]['ratio_err'])
        ok = (c > 2000) & (e < 0.15)
        ok[-1] = False                     # last bin collects n_v >= nv_max
        n = np.arange(len(c))[ok]
        ax[0].errorbar(n + 0.05 * (i - 1.5), r[ok], yerr=e[ok], fmt='o-', color=COL[i], ms=5*FS**0.5,
                       capsize=3, label=f'R = {R}')
    n = np.arange(len(lp[Rs[0]]['count']) - 1)
    ax[0].plot(n, (-1.0) ** n, 'kx', ms=9, mew=2, label=r'Z$_2$ lock $(-1)^{n_v}$')
    ax[0].axhline(0, color='k', lw=0.6)
    ax[0].set_xticks(n)
    ax[0].set_xlabel(r'vortices piercing the loop, $n_v$')
    ax[0].set_ylabel(r'$W_{n_v}/W_0$')
    ax[0].set_title('(a) sign per vortex')
    ax[0].legend(fontsize=9*FS, loc='upper center', bbox_to_anchor=(0.5, -0.3), ncol=2)
    nb = len(lp[Rs[0]]['psi_hist_even'])
    edges = np.linspace(0, np.pi, nb + 1); cen = 0.5 * (edges[1:] + edges[:-1]); dw = edges[1] - edges[0]
    for i, R in enumerate(Rs[:2]):
        he = np.array(lp[R]['psi_hist_even'], float); ho = np.array(lp[R]['psi_hist_odd'], float)
        ax[1].plot(cen, he / he.sum() / dw, '-', color=COL[i], lw=1.8, label=f'R = {R}, even $n_v$')
        ax[1].plot(cen, ho / ho.sum() / dw, '--', color=COL[i], lw=1.8, label=f'R = {R}, odd $n_v$')
    ax[1].plot(cen, 2 / np.pi * np.sin(cen) ** 2, 'k:', lw=1.2, label='Haar')
    ax[1].set_xlabel(r'holonomy angle $\psi$'); ax[1].set_ylabel('density')
    ax[1].set_title(r'(b) even vs odd $n_v$'); ax[1].legend(fontsize=8*FS)
    lab = [r'$Q \neq 0$', r'$Q = 0$']
    vals = [V['faces_pv_charged'][0], V['faces_pv_neutral'][0]]
    errs = [V['faces_pv_charged'][1], V['faces_pv_neutral'][1]]
    ax[2].bar([0, 1], vals, yerr=errs, color=[COL[3], COL[4]], capsize=4, width=0.6)
    ax[2].set_xticks([0, 1]); ax[2].set_xticklabels(lab)
    ax[2].set_ylabel('vortex faces per cell')
    ax[2].set_title('(c) hedgehogs and vortices')
    if FS == 1:
        fig.suptitle(f"center vortices after maximal center gauge, L = {s['L']}, {V['n_configs']} configs", y=1.02)
    fig.tight_layout(); fig.savefig(os.path.join(od, 'FigT5_vortex_lock.png'), dpi=250, bbox_inches='tight')
    plt.close(fig)


def fig6(S, od):
    """Ground state counterpart of Figure 17: probe coherence after n turns,
    sorted by the number of center vortices piercing the loop."""
    Sv = [x for x in S if 'vortex' in x and 'C_n' in next(iter(x['vortex']['loops'].values()))]
    if not Sv:
        return
    s = max(Sv, key=lambda x: x['vortex']['n_configs'])
    lp = s['vortex']['loops']
    Rsel = '3' if '3' in lp else sorted(lp, key=int)[0]
    fig, ax = plt.subplots(1, 2, figsize=(13, 4.8))
    haar = {1: 0.0, 2: -0.5}
    l = lp[Rsel]
    for nv, c in zip(range(3), [COL[0], COL[3], COL[2]]):
        m = np.array(l['C_n'][nv]); e = np.array(l['C_n_err'][nv]); n = np.arange(1, len(m) + 1)
        ax[0].errorbar(n + 0.06 * (nv - 1), m, yerr=e, fmt='o-', color=c, ms=6 * FS ** 0.5, capsize=3,
                       label=rf'$n_v$ = {nv}  ({"odd" if nv % 2 else "even"})')
    n = np.arange(1, len(l['C_n'][0]) + 1)
    ax[0].plot(n, [haar.get(k, 0.0) for k in n], 'kx', ms=9, mew=2, label='Haar, no lock')
    ax[0].axhline(0, color='k', lw=0.6)
    ax[0].set_xticks(n)
    ax[0].set_xlabel('number of turns n around the loop')
    ax[0].set_ylabel(r'$C_n = \langle\cos n\psi\rangle$')
    ax[0].set_title(f'(a) coherence after n turns, R = {Rsel}')
    ax[0].legend(fontsize=9 * FS)
    Rs = [R for R in sorted(lp, key=int) if 2 <= int(R) <= 6 and lp[R]['count'][1] > 2000]
    for k, (nturn, mk) in enumerate([(1, 'o'), (3, 's')]):
        for nv, c in zip((0, 1), (COL[0], COL[3])):
            y = [lp[R]['C_n'][nv][nturn - 1] for R in Rs]
            ye = [lp[R]['C_n_err'][nv][nturn - 1] for R in Rs]
            ax[1].errorbar([int(R) + 0.05 * (2 * k - 1) for R in Rs], y, yerr=ye, fmt=mk + ('-' if k == 0 else '--'),
                           color=c, ms=6 * FS ** 0.5, capsize=3,
                           label=rf'n = {nturn}, $n_v$ = {nv}')
    ax[1].axhline(0, color='k', lw=0.6)
    ax[1].set_xticks([int(R) for R in Rs])
    ax[1].set_xlabel('loop side R')
    ax[1].set_ylabel(r'$C_n$')
    ax[1].set_title('(b) odd turns: sign set by vortex parity')
    ax[1].legend(fontsize=9 * FS, ncol=2)
    if FS == 1:
        fig.suptitle(f"ground state lock, L = {s['L']}, {s['vortex']['n_configs']} configurations", y=1.02)
    fig.tight_layout(); fig.savefig(os.path.join(od, 'FigT6_ground_state_coherence.png'), dpi=250, bbox_inches='tight')
    plt.close(fig)


def table(S):
    print(f"{'L':>4} {'configs':>8} {'<c0>':>16} {'SumVar c_k':>16} {'<Q^2>/cell':>16} {'|Q_tot|max':>10}")
    for s in S:
        f = lambda k: f"{s[k][0]:.4f}({s[k][1]*1e4:.0f})"
        print(f"{s['L']:>4} {s['n_configs']:>8} {f('mean_c0'):>16} {f('sumvar_ck'):>16} "
              f"{f('Q_sq_per_cell'):>16} {s['Q_total_max_abs']:>10}")


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('summaries', nargs='+')
    ap.add_argument('--outdir', default='figures')
    a = ap.parse_args()
    os.makedirs(a.outdir, exist_ok=True)
    S = load(a.summaries)
    table(S)
    fig1(S, a.outdir); fig2(S, a.outdir); fig3(S, a.outdir); fig4(S, a.outdir); fig5(S, a.outdir); fig6(S, a.outdir)
    print('figures written to', a.outdir)


if __name__ == '__main__':
    main()
