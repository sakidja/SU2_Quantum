#!/usr/bin/env python3
"""
Twist-channel visualization from rank checkpoints (Figures S10 and S11).

Reads ckpt_cl_L32_rank*.npz (key 'links': SU(2) gauge field as scalar-first
unit quaternions, shape (3, L, L, L, 4)) and computes the plaquette Pauli
vector magnitude |c(x)| = sqrt(1 - c0^2) = sin(theta(x)), averaged over the
three plaquette planes at each site.

Outputs:
  figS10: 4x8 grid of lightly smoothed mid-plane slices, all configurations
  figS11: per-configuration means + ensemble-averaged two-point correlation

Usage:
    python twist_visualization.py [--glob 'ckpt_cl_L32_rank*.npz']
                                  [--smooth 1.0] [--outdir .]
"""

import argparse
import glob
import re
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from scipy.ndimage import gaussian_filter


def qmul(p, q):
    a0, av = p[..., 0], p[..., 1:]
    b0, bv = q[..., 0], q[..., 1:]
    c0 = a0 * b0 - (av * bv).sum(-1)
    cv = a0[..., None] * bv + b0[..., None] * av + np.cross(av, bv)
    return np.concatenate([c0[..., None], cv], axis=-1)


def qconj(q):
    out = q.copy()
    out[..., 1:] *= -1
    return out


def shift(a, mu):
    return np.roll(a, -1, axis=mu)


def twist_field(links):
    """Plane-averaged plaquette Pauli-vector magnitude |c(x)| = sin(theta)."""
    acc = 0
    for mu, nu in [(0, 1), (0, 2), (1, 2)]:
        P = qmul(qmul(links[mu], shift(links[nu], mu)),
                 qmul(qconj(shift(links[mu], nu)), qconj(links[nu])))
        acc = acc + np.sqrt(np.clip(1 - P[..., 0] ** 2, 0, None))
    return acc / 3.0


def correlation_profile(tw, rmax=16):
    L = tw.shape[0]
    f0 = tw - tw.mean()
    F = np.fft.fftn(f0)
    corr = np.fft.ifftn(F * np.conj(F)).real / f0.size / f0.var()
    ax = np.minimum(np.arange(L), L - np.arange(L))
    xx, yy, zz = np.meshgrid(ax, ax, ax, indexing='ij')
    rr = np.sqrt(xx ** 2 + yy ** 2 + zz ** 2)
    return [corr[(rr >= r) & (rr < r + 1)].mean() for r in range(rmax)]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--glob', default='ckpt_cl_L32_rank*.npz')
    ap.add_argument('--smooth', type=float, default=1.0)
    ap.add_argument('--outdir', default='.')
    args = ap.parse_args()

    files = sorted(glob.glob(args.glob),
                   key=lambda p: int(re.search(r'rank(\d+)', p).group(1)))
    print(len(files), 'checkpoints')

    slices, means, profiles = [], [], []
    for p in files:
        tw = twist_field(np.load(p)['links'])
        means.append(tw.mean())
        profiles.append(correlation_profile(tw))
        sm = gaussian_filter(tw, sigma=args.smooth, mode='wrap')
        slices.append(sm[:, :, tw.shape[2] // 2])
    means = np.array(means)
    profiles = np.array(profiles)
    n = len(files)

    # --- Figure S10: grid of slices
    allv = np.array(slices)
    vmin, vmax = np.percentile(allv, [1, 99])
    ncols = 8
    nrows = int(np.ceil(n / ncols))
    fig, axes = plt.subplots(nrows, ncols, figsize=(20, 2.7 * nrows))
    for i, ax in enumerate(np.ravel(axes)):
        if i < n:
            im = ax.imshow(slices[i].T, origin='lower', cmap='magma',
                           vmin=vmin, vmax=vmax, interpolation='bicubic')
            ax.set_title(str(i), fontsize=9, pad=2)
        ax.set_xticks([]); ax.set_yticks([])
    fig.colorbar(im, ax=axes, shrink=0.7,
                 label='twist magnitude (lightly smoothed)')
    fig.suptitle('Twist channel: mid-plane slices, all configurations', fontsize=15)
    fig.savefig(f'{args.outdir}/figS10_twist_grid.png', dpi=300,
                bbox_inches='tight')

    # --- Figure S11: means + correlation
    mu, sd = means.mean(), means.std(ddof=1)
    cm = profiles.mean(0)
    ce = profiles.std(0, ddof=1) / np.sqrt(n)
    fig, axes = plt.subplots(1, 2, figsize=(13.5, 5))
    axes[0].plot(range(n), means, 'o', ms=6, color='#443983')
    axes[0].axhline(mu, color='crimson', ls='--', lw=1.2,
                    label=f'ensemble mean {mu:.5f}')
    axes[0].fill_between([-1, n], mu - sd, mu + sd, alpha=0.15, color='crimson',
                         label=f'one std ({sd:.5f})')
    axes[0].set_xlim(-1, n)
    axes[0].set_xlabel('configuration (rank index)', fontsize=11)
    axes[0].set_ylabel('mean plaquette Pauli-vector magnitude', fontsize=11)
    axes[0].set_title(f'per-configuration mean, {n} configurations', fontsize=11)
    axes[0].legend(fontsize=9)
    axes[1].errorbar(range(1, len(cm)), cm[1:], yerr=ce[1:], fmt='o-', ms=5,
                     capsize=3, color='#21918c')
    axes[1].axhline(0, color='k', lw=0.8)
    axes[1].set_xlabel('separation r (lattice units)', fontsize=11)
    axes[1].set_ylabel('C(r)', fontsize=11)
    axes[1].set_title('two-point correlation, ensemble average', fontsize=11)
    axes[1].set_yscale('symlog', linthresh=1e-4)
    fig.tight_layout()
    fig.savefig(f'{args.outdir}/figS11_twist_statistics.png', dpi=300)

    print(f'mean twist: {mu:.5f} +/- {sd:.5f}')
    print(f'C(1) = {cm[1]:+.6f} +/- {ce[1]:.6f}')
    print('saved figS10 and figS11')


if __name__ == '__main__':
    main()
