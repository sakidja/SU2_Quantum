"""
Scalable engine for gauge fixed SU(2) Kogut Susskind Hamiltonians with a few
dynamical links, in a block sparse Peter Weyl representation.

Part of the SU2_Quantum project (R. Sakidja, Missouri State University).
Code drafted with AI (LLM) assistance (Claude, Anthropic) and reviewed by the author.

Representation
--------------
A wavefunction of N dynamical links is stored block by block. A block is a
tuple of representations (j_1, ..., j_N); its tensor has axes
(m_1, n_1, m_2, n_2, ..., m_N, n_N), the left and right indices of e^{j}_{mn}(U)
= sqrt(2j+1) D^j_{mn}(U) on each link (Haar orthonormal). Index i on an axis
of dimension 2j+1 stands for m = j - i.

Nothing of size prod_l (sum_j (2j+1)^2) is ever formed, so truncations far
beyond what fits as a dense product space are reachable.

Operators
---------
* Multiplication by D^{1/2}_{pq}(U_l): exact Clebsch Gordan series, j -> j +- 1/2.
* Generators on link l: L (left multiplication, acts on m_l with S^T),
  R (right multiplication by the inverse, acts on n_l with -S), K = L + R.
* Plaquette operators c0 = (1/2) Tr(W_1 W_2 ... W_n), W = U_l or U_l^dagger.

Gauge invariant basis (residual global conjugation): in each block,
    sum_M |chain_p, J M>_left (x) |chain_q, J M>_right / sqrt(2J+1)
with chain_p, chain_q any coupling paths of (j_1, ..., j_N) to total J.
"""
import itertools
import os
import multiprocessing as mp
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla
from functools import lru_cache
from sympy import Rational
from sympy.physics.wigner import clebsch_gordan

HALF = (0.5, -0.5)


def R2(x):
    return Rational(int(round(2 * x)), 2)


@lru_cache(maxsize=None)
def cg(j1, m1, j2, m2, j, m):
    if abs(m1) > j1 + 1e-9 or abs(m2) > j2 + 1e-9 or abs(m) > j + 1e-9 or abs(m1 + m2 - m) > 1e-9:
        return 0.0
    return float(clebsch_gordan(R2(j1), R2(j2), R2(j), R2(m1), R2(m2), R2(m)))


def dim(j):
    return int(round(2 * j)) + 1


def mvals(j):
    return [j - i for i in range(dim(j))]


def jvals(jmax):
    return [k / 2 for k in range(int(round(2 * jmax)) + 1)]


@lru_cache(maxsize=None)
def cg_tensor(j1, j2, J):
    """C[i1, i2, I] = <j1 m1; j2 m2 | J M>."""
    C = np.zeros((dim(j1), dim(j2), dim(J)))
    for i1, m1 in enumerate(mvals(j1)):
        for i2, m2 in enumerate(mvals(j2)):
            M = m1 + m2
            if abs(M) <= J + 1e-9:
                C[i1, i2, int(round(J - M))] = cg(j1, m1, j2, m2, J, M)
    return C


@lru_cache(maxsize=None)
def mult_matrix(a, k, p):
    """A[i', i] = <1/2 p; a m | k m'> with m' = p + m (acts on one index of link rep a -> k)."""
    A = np.zeros((dim(k), dim(a)))
    for i, m in enumerate(mvals(a)):
        mp = p + m
        if abs(mp) <= k + 1e-9:
            A[int(round(k - mp)), i] = cg(0.5, p, a, m, k, mp)
    return A


@lru_cache(maxsize=None)
def spin_matrices(j):
    ms = mvals(j)
    d = len(ms)
    Sz = np.diag(ms).astype(complex)
    Sp = np.zeros((d, d), dtype=complex)
    for i in range(1, d):
        m = ms[i]
        Sp[i - 1, i] = np.sqrt(j * (j + 1) - m * (m + 1))
    return (0.5 * (Sp + Sp.T), -0.5j * (Sp - Sp.T), Sz)


def apply_on_axis(Mat, T, axis):
    """new[..., i', ...] = sum_i Mat[i', i] T[..., i, ...] on the given axis
    (axis counted without the leading vector axis; T has a leading vector axis)."""
    out = np.tensordot(Mat, T, axes=([1], [axis + 1]))
    return np.moveaxis(out, 0, axis + 1)


# ---------------------------------------------------------------- block dicts
def bd_add(acc, key, T):
    if key in acc:
        acc[key] = acc[key] + T
    else:
        acc[key] = T


def apply_mult(state, link, p, q, dagger=False):
    """Multiply every block by D^{1/2}_{pq}(U_link) or (U_link^dagger)_{pq}.
    state: dict block -> array (nv, axes...)."""
    if dagger:
        sign = (-1) ** int(round(q - p))
        p, q = -q, -p
    else:
        sign = 1.0
    out = {}
    for key, T in state.items():
        a = key[link]
        for k in (a - 0.5, a + 0.5):
            if k < -1e-9:
                continue
            Ap = mult_matrix(a, k, p)
            Aq = mult_matrix(a, k, q)
            if not Ap.any() or not Aq.any():
                continue
            fac = sign * np.sqrt((2 * a + 1) / (2 * k + 1))
            U = apply_on_axis(Ap, T, 2 * link)
            U = apply_on_axis(Aq, U, 2 * link + 1)
            nk = list(key)
            nk[link] = k
            bd_add(out, tuple(nk), fac * U)
    return out


def apply_word_trace(state, word, coef=0.5):
    """coef * Tr(W_1 ... W_n) applied to state; word = [(link, dagger), ...]."""
    n = len(word)
    out = {}
    for idx in itertools.product(HALF, repeat=n):
        cur = state
        for s, (link, dag) in enumerate(word):
            p, q = idx[s], idx[(s + 1) % n]
            cur = apply_mult(cur, link, p, q, dagger=dag)
            if not cur:
                break
        for key, T in cur.items():
            bd_add(out, key, coef * T)
    return out


def apply_field_casimir(state, pieces):
    """sum_a (sum_pieces G^a)^2 on each block; pieces = [(link, 'L'|'R'|'K'), ...]."""
    out = {}
    for key, T in state.items():
        T = T.astype(complex)
        acc = np.zeros_like(T)
        for a in range(3):
            def F(X):
                r = np.zeros_like(X)
                for (link, kind) in pieces:
                    S = spin_matrices(key[link])[a]
                    if kind in ("L", "K"):
                        r = r + apply_on_axis(S.T, X, 2 * link)
                    if kind in ("R", "K"):
                        r = r + apply_on_axis(-S, X, 2 * link + 1)
                return r
            acc = acc + F(F(T))
        out[key] = acc
    return out


def inner(sa, sb):
    """<a|b> for single vector block dicts (leading axis of size 1) -> scalar,
    or matrix (nv_a, nv_b) when both carry several vectors."""
    tot = 0.0
    for key, A in sa.items():
        if key in sb:
            B = sb[key]
            tot = tot + np.conj(A.reshape(A.shape[0], -1)) @ B.reshape(B.shape[0], -1).T
    return tot


# ---------------------------------------------------------------- invariant basis
def coupling_paths(js):
    """All coupling chains of js to total J: list of (path, J, A[M, m1, ..., mN])."""
    paths = [((), js[0], np.eye(dim(js[0])))]
    for j in js[1:]:
        new = []
        for path, Jp, A in paths:
            Jn = abs(Jp - j)
            while Jn <= Jp + j + 1e-9:
                C = cg_tensor(Jp, j, Jn)          # [Mp, m, M]
                B = np.tensordot(C, A, axes=([0], [0]))   # [m, M, m1..m_{N-1}]
                B = np.moveaxis(B, 1, 0)                  # [M, m, m1..]
                B = np.moveaxis(B, 1, -1)                 # [M, m1.., m]
                new.append((path + (Jp,), Jn, B))
                Jn += 1.0
        paths = new
    return paths


def block_basis(js):
    """Orthonormal invariant vectors of block js: array (nv, axes...) and labels."""
    N = len(js)
    paths = coupling_paths(js)
    byJ = {}
    for path, J, A in paths:
        byJ.setdefault(round(J * 2), []).append((path, A))
    letters = "abcdefghijklmnopqrstuvw"
    left = letters[:N]
    right = letters[N:2 * N]
    out_ax = "".join(left[i] + right[i] for i in range(N))
    spec = f"Z{left},Z{right}->{out_ax}"
    vecs, labels = [], []
    for J2, lst in byJ.items():
        J = J2 / 2
        for (pl, Al) in lst:
            for (pr, Ar) in lst:
                T = np.einsum(spec, Al, Ar) / np.sqrt(2 * J + 1)
                vecs.append(T)
                labels.append((pl, pr, J))
    if not vecs:
        return None, []
    return np.array(vecs), labels


_WORKER_SYS = None


def _operator_block(js):
    """Matrix elements of one plaquette word with source block js (runs in workers)."""
    blocks, index, word = _WORKER_SYS
    V = blocks[js]
    o_s, n_s = index[js]
    res = apply_word_trace({js: V}, word)
    rows, cols, vals = [], [], []
    for key, T in res.items():
        if key not in blocks:
            continue
        o_t, n_t = index[key]
        M = blocks[key].reshape(n_t, -1) @ T.reshape(n_s, -1).T     # (n_t, n_s)
        r, c = np.nonzero(np.abs(M) > 1e-14)
        rows.append(o_t + r)
        cols.append(o_s + c)
        vals.append(M[r, c])
    if not rows:
        return np.zeros(0, int), np.zeros(0, int), np.zeros(0)
    return np.concatenate(rows), np.concatenate(cols), np.concatenate(vals)


def _basis_block(args):
    """Invariant vectors of one block, with constrained fields truncated and the
    electric energy matrix (runs in workers)."""
    js, jcap, constraints, energy = args
    V, labels = block_basis(js)
    if V is None:
        return js, None, None
    st = {js: V}
    for pieces in constraints:
        C = np.real(inner(st, apply_field_casimir(st, pieces)))
        C = 0.5 * (C + C.T)
        w, U = np.linalg.eigh(C)
        keep = w <= jcap
        if not keep.any():
            return js, None, None
        V = np.tensordot(U[:, keep].T, V, axes=([1], [0]))
        st = {js: V}
    nv = V.shape[0]
    E = np.zeros((nv, nv))
    for coef, kind, data in energy:
        if kind == "cas":
            j = js[data]
            E += coef * j * (j + 1) * np.eye(nv)
        else:
            C = np.real(inner(st, apply_field_casimir(st, data)))
            E += coef * 0.5 * (C + C.T)
    return js, V, E


class GaugeFixedSystem:
    """
    links: number of dynamical links N
    jmax: truncation for every dynamical link and every constrained field
    plaquettes: list of words [(link, dagger), ...]
    energy: list of (coef, kind, data):
        ('cas', link)      coef * j_link(j_link+1)
        ('field', pieces)  coef * (sum pieces)^2   (a gauge fixed link's field)
    constraints: list of pieces lists; each such field must also have j <= jmax
    """

    def __init__(self, N, jmax, plaquettes, energy, constraints=(), verbose=False):
        self.N, self.jmax = N, jmax
        self.plaquettes = plaquettes
        self.blocks = {}
        jcap = jmax * (jmax + 1) + 1e-8
        Ediag = []
        offset = 0
        self.index = {}
        tasks = [(js, jcap, list(constraints), list(energy))
                 for js in itertools.product(jvals(jmax), repeat=N)]
        nproc = int(os.environ.get("SU2HAM_NPROC", "1"))
        if nproc > 1:
            with mp.get_context("fork").Pool(nproc) as pool:
                built = pool.map(_basis_block, tasks, chunksize=1)
        else:
            built = [_basis_block(t) for t in tasks]
        for js, V, E in built:
            if V is None:
                continue
            nv = V.shape[0]
            self.blocks[js] = V
            self.index[js] = (offset, nv)
            Ediag.append(E)
            offset += nv
        self.n = offset
        self.Eel = sp.block_diag(Ediag, format="csr") if Ediag else None
        # plaquette operators in the invariant basis
        self.Cp = [self._operator(w) for w in plaquettes]
        if verbose:
            print(f"  {self.n} invariant states in {len(self.blocks)} blocks", flush=True)

    def _operator(self, word):
        global _WORKER_SYS
        _WORKER_SYS = (self.blocks, self.index, word)
        keys = sorted(self.blocks, key=lambda k: -self.blocks[k].size)
        nproc = int(os.environ.get("SU2HAM_NPROC", "1"))
        if nproc > 1 and len(keys) > 1:
            ctx = mp.get_context("fork")
            with ctx.Pool(nproc) as pool:
                parts = pool.map(_operator_block, keys, chunksize=1)
        else:
            parts = [_operator_block(k) for k in keys]
        rows = np.concatenate([p[0] for p in parts]) if parts else np.zeros(0, int)
        cols = np.concatenate([p[1] for p in parts]) if parts else np.zeros(0, int)
        vals = np.concatenate([p[2] for p in parts]) if parts else np.zeros(0)
        A = sp.csr_matrix((vals, (rows, cols)), shape=(self.n, self.n))
        # c0 is a real multiplication operator, so A must be symmetric; record the check
        asym = abs(A - A.T).max() if A.nnz else 0.0
        self.max_asymmetry = max(getattr(self, "max_asymmetry", 0.0), float(asym))
        return 0.5 * (A + A.T)

    def hamiltonian(self, g2, signs=None):
        signs = signs or [1] * len(self.Cp)
        H = 0.5 * g2 * self.Eel
        for s, C in zip(signs, self.Cp):
            H = H + (4.0 / g2) * (sp.identity(self.n) - s * C)
        return H.tocsr()

    def lowest(self, g2, signs=None, k=4):
        H = self.hamiltonian(g2, signs)
        if self.n <= 1500:
            w, v = np.linalg.eigh(H.toarray())
            return w[:k], v[:, :k]
        w, v = spla.eigsh(H, k=k, which="SA", tol=1e-11)
        o = np.argsort(w)
        return w[o], v[:, o]

    def state(self, coeffs):
        st = {}
        for js, V in self.blocks.items():
            o, nv = self.index[js]
            st[js] = np.tensordot(coeffs[o:o + nv], V, axes=([0], [0]))[None]
        return st

    def plaquette_moments(self, psi_state):
        """<c0_p> and <c0_p^2> for each plaquette (exact: intermediate reps untruncated)."""
        res = []
        images = []
        for w in self.plaquettes:
            img = apply_word_trace(psi_state, w)
            c0 = float(np.real(inner(psi_state, img)).ravel()[0])
            c0sq = float(np.real(inner(img, img)).ravel()[0])
            res.append((c0, c0sq))
            images.append(img)
        return res, images
