#!/usr/bin/env python3
"""
Stiffness-floor extraction from production pooled m*_CTC histograms (Figure S9).

Reads results_cl_L{16,24,32}.npz (keys: mctc_hist_counts, mctc_hist_edges),
computes the lower-edge quantile ladder (q0.01%, q0.1%, q1%) per volume, and
produces the two-panel figure: pooled distributions overlaid + quantiles vs L.

Usage:
    python floor_quantiles.py [--datadir DIR] [--out figS9.png]
"""

import argparse
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

VOLS = [16, 24, 32]
COLORS = {16: '#443983', 24: '#21918c', 32: '#a0da39'}


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--datadir', default='.')
    ap.add_argument('--out', default='figS9_floor.png')
    args = ap.parse_args()

    fig, axes = plt.subplots(1, 2, figsize=(15, 5.5))
    results = {}
    for L in VOLS:
        z = np.load(f'{args.datadir}/results_cl_L{L}.npz')
        h = z['mctc_hist_counts'].astype(float)
        e = z['mctc_hist_edges']
        c = 0.5 * (e[:-1] + e[1:])
        tot = h.sum()
        cdf = np.cumsum(h) / tot

        def q(p):
            return c[np.searchsorted(cdf, p)]

        results[L] = dict(q0001=q(1e-4), q001=q(1e-3), q01=q(1e-2))
        frac = h / tot / np.diff(e)
        axes[0].semilogy(c, np.where(frac > 0, frac, np.nan), color=COLORS[L],
                         lw=1.4, label=f'L = {L}   ({tot/1e6:.0f} million sites)')

    axes[0].axvline(results[32]['q001'], color='k', ls='--', lw=1.2)
    axes[0].annotate(f"floor  q0.1% = {results[32]['q001']:.3f}",
                     xy=(results[32]['q001'], 3e-3), xytext=(0.30, 8e-4),
                     fontsize=11, arrowprops=dict(arrowstyle='->', lw=1.0))
    axes[0].set_xlim(0, 1.0)
    axes[0].set_ylim(1e-5, 12)
    axes[0].set_xlabel('m* = theta / |div F|  (lattice units)', fontsize=12)
    axes[0].set_ylabel('probability density', fontsize=12)
    axes[0].legend(fontsize=11)
    axes[0].set_title('Mass distribution in the twist channel, three volumes overlaid',
                      fontsize=12)

    for key, lab, mk, col in [('q0001', 'q = 0.01%', 's', '#d62728'),
                              ('q001', 'q = 0.1%', '^', '#1f77b4'),
                              ('q01', 'q = 1%', 'D', '#2ca02c')]:
        vals = [results[L][key] for L in VOLS]
        axes[1].plot(VOLS, vals, marker=mk, ms=9, lw=1.5, color=col, label=lab)
        for L, v in zip(VOLS, vals):
            axes[1].annotate(f'{v:.4f}', (L, v), textcoords='offset points',
                             xytext=(0, 9), ha='center', fontsize=9)
        print(f'{lab}: ' + '  '.join(f'L={L}: {results[L][key]:.4f}' for L in VOLS))

    axes[1].set_ylim(0.09, 0.26)
    axes[1].set_xlim(14.5, 33.5)
    axes[1].set_xticks(VOLS)
    axes[1].set_xlabel('lattice size L', fontsize=12)
    axes[1].set_ylabel('lower edge of m* distribution', fontsize=12)
    axes[1].legend(fontsize=11, loc='lower left', framealpha=0.95)
    axes[1].set_title('The lower edge is unchanged across volumes', fontsize=12)
    fig.suptitle('SU(2) lattice, beta = 2.2, 2000 configurations per volume', fontsize=13)
    fig.tight_layout()
    fig.savefig(args.out, dpi=300)
    print('saved', args.out)


if __name__ == '__main__':
    main()
