#!/bin/bash -l
# Dedicated production for paper Figure 25 and Figure T6 (the center vortex lock).
# 128 independent chains on one CPU node, loops up to R = 8.
#   sbatch 10_vortex_lock.sh 32     main run (about 1 h)
#   sbatch 10_vortex_lock.sh 40     optional volume check (about 2 h)
# If the time limit is hit the job stops cleanly; resubmit the same line to resume.
#SBATCH -A mXXXX                  # <-- your NERSC project
#SBATCH -C cpu
#SBATCH -q regular
#SBATCH -N 1
#SBATCH -t 03:00:00
#SBATCH -J su2_vlock
#SBATCH -o %x_%j.out
L=${1:-32}
cd "$SLURM_SUBMIT_DIR/.."
source slurm/env_perlmutter.sh
srun -n 128 -c 2 --cpu-bind=cores "$PY" vortex_lock_production.py \
     --L $L --ntherm 500 --nmeas 100 --skip 10 --rmax 8 --gribov 1 \
     --out runs/vl$L --wall $(( 3*3600 - 900 ))
FIGSCALE=1.55 "$PY" vortex_lock_analysis.py runs/vl$L --outdir figures_vlock_L$L
