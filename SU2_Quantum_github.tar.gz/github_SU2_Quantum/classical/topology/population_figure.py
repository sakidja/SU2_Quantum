#!/usr/bin/env python3
"""
population_figure.py
The main result stated directly: the three populations of the SU(2) twist modes
against loop size, at every coupling, beside the measured electron neutrino row.

Input (already in the repository, no new runs):
  data/nersc_summaries/lmodes_summary_L24.json          beta = 2.2 (job 13)
  data/nersc_summaries/lmodes_summary_L32_b{3.0,4.0,5.0}.json   (job 14)
  data/nersc_summaries/bscan_summary.json               fixed point, loop size where the lock completes
Optional: 4D summaries from ../topology4d/su2_4d_analysis.py (--four_d summary_4d_*.json)

Populations: s_i^2 / sum s^2 of the colour by space matrix of the three R x R loops at
a site (one per plane), averaged over all sites; real loops and the null that keeps each
loop's magnitude and vortex parity but removes its relative orientation.

  python population_figure.py
  python population_figure.py --four_d ../topology4d/figures_4d_L16_b2.3/summary_4d_L16_b2.3.json
  FIGSCALE=1.55 python population_figure.py            # paper sized text

Writes figures_population/FigPop_populations.png and populations_by_R.json.
"""
import argparse
import json
import os

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

FS = float(os.environ.get('FIGSCALE', '1'))
plt.rcParams.update({'font.size': 11 * FS, 'axes.spines.top': False, 'axes.spines.right': False})
HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, '..', '..', 'data', 'nersc_summaries')

MODE_COL = ['#2a78d6', '#eb6834', '#1baf7a']          # mode 1, 2, 3 (identity = mode)
INK, INK2, GRID = '#0b0b0b', '#52514e', '#d9d8d3'
MEASURED = [0.677, 0.301, 0.022]                       # electron neutrino row, NuFIT 6.0, normal ordering
RUNS = [(2.2, 'lmodes_summary_L24.json', 24, 'o'),
        (3.0, 'lmodes_summary_L32_b3.0.json', 32, 's'),
        (4.0, 'lmodes_summary_L32_b4.0.json', 32, '^'),
        (5.0, 'lmodes_summary_L32_b5.0.json', 32, 'D')]


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--four_d', nargs='*', default=[], help='4D summary JSON files to overlay')
    ap.add_argument('--outdir', default=os.path.join(HERE, 'figures_population'))
    a = ap.parse_args()
    os.makedirs(a.outdir, exist_ok=True)
    bscan = json.load(open(os.path.join(DATA, 'bscan_summary.json')))
    fixed = bscan['fixed_point']
    rlock = {float(k.split('_')[0][4:]): v['R_lock'] for k, v in bscan['runs'].items()}

    fig, ax = plt.subplots(1, 2, figsize=(14, 5.6), gridspec_kw=dict(width_ratios=[1.25, 1]))
    a0, a1 = ax
    out = dict(fixed_point=fixed, measured_electron_row=MEASURED, runs={})
    for beta, fname, L, mk in RUNS:
        d = json.load(open(os.path.join(DATA, fname)))
        real = np.array(d['shares_real_all']); null = np.array(d['shares_null_all'])
        R = np.arange(1, len(real) + 1)
        x = 4 * R / beta                                   # physical size R a g^2
        out['runs'][f'beta{beta}_L{L}'] = dict(R=R.tolist(), real=real.tolist(), null=null.tolist(),
                                              n_configs=d['n_configs'], R_lock=rlock.get(beta))
        for j in range(3):
            for axx, xv in ((a0, R), (a1, x)):
                axx.plot(xv, real[:, j], mk + '-', color=MODE_COL[j], ms=6.5 * FS ** 0.5, lw=1.2, alpha=0.9,
                         mec='white', mew=0.8, zorder=3)
                axx.plot(xv, null[:, j], mk, mfc='none', mec=INK2, ms=9 * FS ** 0.5, mew=0.9, zorder=2)
    for n4 in a.four_d:
        s = json.load(open(n4))
        pops = s['populations']
        R = np.array(sorted(int(k) for k in pops))
        P = np.array([pops[str(r)]['real'] if str(r) in pops else pops[r]['real'] for r in R])
        for j in range(3):
            a0.plot(R, P[:, j], 'P', color=MODE_COL[j], ms=10 * FS ** 0.5, mec=INK, mew=0.8, zorder=4)
        out.setdefault('four_d', {})[f"L{s['L']}_b{s['beta']}"] = dict(R=R.tolist(), real=P.tolist())

    for axx in ax:
        for j in range(3):
            axx.axhline(fixed[j], color=INK2, lw=0.9, ls='--', zorder=1)
        axx.set_ylim(-0.02, 0.8); axx.grid(axis='y', color=GRID, lw=0.6); axx.set_axisbelow(True)
        axx.set_ylabel(r'population $s_i^2/\sum s^2$')

    # measured electron neutrino row, set beside the lattice values
    xm = 13.9
    for j in range(3):
        a0.plot(xm, MEASURED[j], '*', color=INK, ms=15 * FS ** 0.5, zorder=5)
        a0.annotate(f'{MEASURED[j]:.3f}', (xm, MEASURED[j]), xytext=(9, -4), textcoords='offset points',
                    fontsize=9.5 * FS, color=INK)
        a0.annotate(f'{fixed[j]:.3f}', (-0.75, fixed[j]), xytext=(0, 4), textcoords='offset points',
                    fontsize=9.5 * FS, color=INK2)
    a0.axvline(13.2, color=GRID, lw=1)
    a0.set_xlim(-0.9, 15.2); a0.set_xticks(list(range(1, 14)))
    a0.set_xlabel(r'loop side $R$ (lattice units)')
    a0.set_title(r'(a) the three populations at every loop size and coupling, and the measured $\nu_e$ row',
                 fontsize=11 * FS)
    a0.text(xm, 0.76, r'measured' + '\n' + r'$|U_{ei}|^2$', ha='center', va='top', fontsize=9.5 * FS, color=INK)

    a1.axvspan(7.0, 12.5, color='#f1f0ec', zorder=0)
    a1.text(7.2, 0.52, 'lock complete\n' + r'($W_{odd}/W_{even}=-1$ from $\approx 7/g^2$)', fontsize=9.5 * FS,
            color=INK2, va='top')
    a1.set_xlim(0, 12.5)
    a1.set_xlabel(r'physical loop size $R\,a\,g^2 = 4R/\beta$')
    a1.set_title('(b) the same against physical size: unchanged by the lock', fontsize=11 * FS)

    # legend: modes (colour), couplings (marker), null, fixed point, measured, 4D
    from matplotlib.lines import Line2D
    h = [Line2D([], [], color=MODE_COL[j], lw=2.5, label=f'mode {j + 1}') for j in range(3)]
    h += [Line2D([], [], marker=mk, ls='none', color=INK2, ms=7, label=rf'$\beta$ = {b}, L = {L}')
          for b, _, L, mk in RUNS]
    h += [Line2D([], [], marker='o', ls='none', mfc='none', mec=INK2, ms=9, label='null (orientation removed)'),
          Line2D([], [], color=INK2, ls='--', lw=0.9, label='SU(2) fixed point'),
          Line2D([], [], marker='*', ls='none', color=INK, ms=13, label=r'measured $\nu_e$ row (NuFIT 6.0)')]
    if a.four_d:
        h.append(Line2D([], [], marker='P', ls='none', color=INK2, mec=INK, ms=10, label='4D, spatial planes'))
    fig.legend(handles=h, loc='lower center', ncol=6 if not a.four_d else 7, fontsize=9 * FS, frameon=False,
               bbox_to_anchor=(0.5, -0.08))
    fig.tight_layout()
    fig.savefig(os.path.join(a.outdir, 'FigPop_populations.png'), dpi=250, bbox_inches='tight')
    json.dump(out, open(os.path.join(a.outdir, 'populations_by_R.json'), 'w'), indent=1)

    print('fixed point', fixed, '  measured electron row', MEASURED)
    print(' beta   L    R_lock   populations at the largest R (real)          (null)')
    for k, v in out['runs'].items():
        r, n = v['real'][-1], v['null'][-1]
        print(f" {k:12s} {v['R_lock']:>3}   {r[0]:.4f} {r[1]:.4f} {r[2]:.4f}   {n[0]:.4f} {n[1]:.4f} {n[2]:.4f}")
    print('wrote', a.outdir)


if __name__ == '__main__':
    main()
