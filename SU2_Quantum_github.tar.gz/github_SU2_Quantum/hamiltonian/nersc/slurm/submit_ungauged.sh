#!/bin/bash
# No gauge fixing, no Gauss law constraint, optional explicit breaking term.
#   bash slurm/submit_ungauged.sh        (from the nersc folder)
# Outputs: results/ungauged_<case>.json
# Part of the SU2_Quantum project. Drafted with AI (LLM) assistance (Claude, Anthropic).
set -e
mkdir -p logs results
G2="1.0 1.4 1.8181818 2.5 3.0"
KAP="0 0.01 0.03 0.1 0.3 1.0 3.0"
u () {  # name walltime args
  sbatch --job-name=$1 --time=$2 \
         --export=ALL,NPROC=1,OMP=64,CMD="python ungauged.py $3 --g2 $G2 --kappa $KAP --levels 24 --out results/$1" \
         slurm/run_script.sbatch
}
u ungauged_single_j1     01:00:00 "--system single   --jmax 1"
u ungauged_single_j1.5   12:00:00 "--system single   --jmax 1.5"
u ungauged_t11_j3        01:00:00 "--system torus1x1 --jmax 3"
u ungauged_t11_j4        02:00:00 "--system torus1x1 --jmax 4"
u ungauged_t21_j1        02:00:00 "--system torus2x1 --jmax 1"
u ungauged_t21_j1.5      12:00:00 "--system torus2x1 --jmax 1.5"
