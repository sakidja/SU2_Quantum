# SU(2) Hamiltonian campaign for the v3 addendum (Perlmutter)

Exact diagonalization of gauge fixed SU(2) Kogut Susskind Hamiltonians on four
small lattices, measuring the discarded Pauli component variance
Σₖ Var(cₖ) = 1 − ⟨c₀²⟩ per plaquette and the energy of the center (π) twist
sector. Part of the SU2_Quantum project (R. Sakidja, Missouri State University).
Code drafted with AI (LLM) assistance (Claude, Anthropic) and reviewed by the author.

## Lattices

| system | geometry | dynamical links | plaquettes | what it tests |
|---|---|---|---|---|
| `single` | open single plaquette | 1 | 1 | exact zero mean with nonzero variance; gap |
| `open2x1` | open 2×1 | 2 | 2 | neighbour twist correlation T₁₂; twist control (exactly zero cost) |
| `torus1x1` | periodic 1×1 | 2 | 1 | center twist energy, smallest size |
| `torus2x1` | periodic 2×1 | 3 | 2 | center twist energy at twice the length |

H = (g²/2) Σ E² + (4/g²) Σₚ (1 − sₚ c₀ₚ), with sₚ = −1 on a twisted plaquette.
Every link, including the gauge fixed ones (through Gauss law), is truncated at j ≤ jmax.
β = 2.2 corresponds to g² = 4/2.2 = 1.8181818 at tree level.

## Steps on Perlmutter

```bash
cd /pscratch/sd/r/rsakidja/quantum
unzip su2_v3_hamiltonian.zip && cd su2_v3_hamiltonian/nersc
bash slurm/setup_env.sh                       # once; environment goes in $SCRATCH
module load python && source $SCRATCH/envs/su2ham/bin/activate
python validate.py                            # about 10 s on a login node; must print PASSED
bash slurm/submit_campaign.sh                 # 15 jobs, account m4675, CPU nodes
```

Progress, without squeue:

```bash
sacct -u rsakidja --starttime today --format=JobID,JobName%28,State,Elapsed,MaxRSS
tail -n 3 logs/*.out
```

Each job writes `results/<system>_j<jmax>.json` after every coupling, so a job that
reaches its wall time keeps everything it finished.

When the jobs are done:

```bash
python analyze.py results     # summary.csv, summary.json, campaign.png
```

## Expected cost

Building the operators dominates and runs on all 128 cores of a node
(`SU2HAM_NPROC`). Single core timings measured for `torus2x1`: jmax 2 in 16 s,
jmax 2.5 in 2 min (1.6 GB). The cost grows by about 7× per half step in jmax, so
jmax 3.5 and 4 are the jobs that need Perlmutter. The other lattices finish in minutes.
Wall times in `submit_campaign.sh` are generous; adjust after the first jobs.

## Reading the output

* `analyze.py` reports each quantity at the largest jmax with its **shift** from the
  next smaller jmax (the larger of the last two shifts when three exist). Points with
  |shift| ≥ 0.005 are marked not converged and left out of the figure.
* `ratio_2x1_over_1x1` = ΔE(2×1)/ΔE(1×1). A ratio near 1 means a size independent
  twist cost; a falling ratio means the cost spreads out with size.
* The main open question this campaign answers: the ratio below g² ≈ 2 (β ≥ 2), which
  the 18 Oct runs could not converge.

## Reference values (18 Oct 2026, reproduced by validate.py)

| quantity | value |
|---|---|
| single plaquette Σₖ Var(cₖ) at β = 2.2 | 0.695177 |
| open 2×1 Σₖ Var(cₖ) at β = 2.2 | 0.694733 |
| open lattice twist cost | 0 (to 10⁻¹⁴) |
| periodic 1×1 twist energy at β = 2.2 | 1.00184 |
| periodic 2×1 twist energy at β = 2.2, jmax 1.5 | 0.71845 |

## Not in this package

The hedgehog density ⟨ΣQ²⟩/V of the Monte Carlo campaign is not computed here. That
campaign is a 3D Euclidean lattice, whose Hamiltonian counterpart is 2+1 dimensional,
so the matching observable needs a decision about how the three plaquette planes
(one spatial, two involving time) map onto Hamiltonian operators. See the notes
that accompany this package.

## Files

* `su2ham/engine.py`: block sparse Peter Weyl engine, gauge invariant basis, operators
* `su2ham/systems.py`: the four lattices, with gauge fixing trees and Gauss law fields
* `run.py`: driver (one system and jmax per call; several couplings and twist sectors)
* `validate.py`: reproduces the reference values and the exact symmetry checks
* `analyze.py`: convergence and size comparison
* `slurm/`: environment setup, job script, campaign submission
* `../reference/`: the 18 Oct scripts, results and figures this campaign extends

## Lock tests (added 18 Oct 2026, evening)

```bash
bash slurm/submit_3x1.sh          # third lattice size (if not yet submitted)
bash slurm/submit_lock_tests.sh   # 30 jobs: localization, probe, angle distributions
python summarize_lock.py results  # after the jobs finish
```

* **Vortex localization:** `run.py` now records `K_u`, the connected correlation of
  u_p = s_p c0_p between plaquettes. Outputs `results/<system>_j<jmax>_lock.json`.
* **Probe phase versus damping:** `probe_phase.py`, probe coupled to W = sum_k c_k^2.
  Outputs `results/probe_<case>.json`.
* **Angle distribution:** `angle_distribution.py`, Haar sampling weighted by |psi|^2,
  validated against the exact <c0> and <c0^2> in every case. Outputs
  `results/angle_<system>_j<jmax>_g<g2>.npz/.json`.
* `summarize_lock.py` writes `lock_localization.csv/.png`, `lock_probe.csv/.png`,
  `lock_angles.csv/.png`.

Every output has its own file name; no earlier result is overwritten.

## Larger lattices: compact engine (added 18 Oct 2026, night)

`su2ham/engine2.py` stores only the gauge invariant content of each state and
builds every basis vector only while its matrix elements are computed. It uses
the same basis and truncation as `engine.py` and reproduces it to 1e-15
(`validate.py` checks this). `run.py` now uses it by default (`--engine original`
selects the old one). Memory for the stored bases: 3x1 at jmax 2.5 about 1.5 GB,
2x2 at jmax 1.5 about 1.4 GB, 2x2 at jmax 2 about 70 GB.

```bash
bash slurm/submit_large.sh    # 3x1 jmax 2.5; 2x2 jmax 1, 1.5, 2
```

The 2x2 lattice (`torus2x2`, defined in `su2ham/systems.py` and `systems2.py`)
is the first one whose twisted plane is two dimensional.
