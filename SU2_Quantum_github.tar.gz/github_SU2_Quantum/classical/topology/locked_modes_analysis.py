#!/usr/bin/env python3
"""
locked_modes_analysis.py
Analysis of job 13 (locked_modes.py). Login node, no MPI.

  python locked_modes_analysis.py runs/lm24 [--outdir figures_lmodes_L24]
  FIGSCALE=1.55 python locked_modes_analysis.py runs/lm24

Figure T8, three panels:
  (a) mode populations s_i^2 / sum s^2: real minus null (x 1000) against loop side R,
      for loops with all three planes even and with at least one odd plane;
  (b) axis alignment between planes, <m_p . m_q>, by the number of odd loops in the pair,
      real and null (random axes: 0);
  (c) histogram of the split ratio (s2 - s3)/(s1 - s3) at R = 4, real and null.
Errors: delete one chain jackknife.
"""
import argparse
import glob
import json
import os
import re
import warnings

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

warnings.simplefilter('ignore', RuntimeWarning)
COL = ['#2A6FB0', '#C27A12', '#2E9E6B', '#B4457A', '#555555']
FS = float(os.environ.get('FIGSCALE', '1'))
plt.rcParams.update({'font.size': 11 * FS, 'axes.spines.top': False, 'axes.spines.right': False})


def load(d):
    files = sorted(glob.glob(os.path.join(d, 'lmodes_L*_rank*.npz')),
                   key=lambda p: int(re.search(r'rank(\d+)', p).group(1)))
    ch, meta = [], None
    for p in files:
        z = np.load(p, allow_pickle=False)
        if len(z['sv']) == 0:
            continue
        meta = json.loads(str(z['meta']))
        ch.append({k: z[k] for k in ('sv', 'sh', 'pr', 'extra', 'wparity')})
    if len(ch) == 1:
        c = ch[0]; cut = np.array_split(np.arange(len(c['sv'])), min(10, len(c['sv'])))
        ch = [{k: v[i] for k, v in c.items()} for i in cut]
    return ch, meta


def jack(ch, fn):
    S = [{k: v.sum(0) for k, v in c.items()} for c in ch]
    tot = {k: sum(s[k] for s in S) for k in S[0]}
    full = np.asarray(fn(tot), float)
    n = len(S)
    if n < 2:
        return full, np.zeros_like(full)
    jk = np.array([np.asarray(fn({k: tot[k] - S[i][k] for k in tot}), float) for i in range(n)])
    return full, np.sqrt((n - 1) / n * np.nansum((jk - np.nanmean(jk, 0)) ** 2, 0))


def shares(t):          # (R, kind, grp, 3) with grp 0: all even, 1: any odd, 2: all loops
    sv = t['sv']
    g = [sv[:, :, 0], sv[:, :, 1:].sum(2), sv.sum(2)]
    return np.stack([x[..., 4:7] / x[..., :1] for x in g], 2)


def share_diff(t):
    s = shares(t)
    return s[:, 0] - s[:, 1]            # (R, grp, 3)


def split_mean(t):
    sv = t['sv']
    return sv[..., 7] / sv[..., 0]      # (R, kind, class)


def align(t):
    pr = t['pr']
    return pr[..., 1:] / pr[..., :1]    # (R, kind, pair class, 3)


def parity_ratio(t):
    w = t['wparity']
    return w[:, 1] / w[:, 0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('rundir')
    ap.add_argument('--outdir', default=None)
    a = ap.parse_args()
    ch, meta = load(a.rundir)
    if not ch:
        raise SystemExit('no measurements in ' + a.rundir)
    out = a.outdir or f"figures_lmodes_L{meta['L']}"
    os.makedirs(out, exist_ok=True)
    nconf = sum(len(c['sv']) for c in ch)
    sh, she = jack(ch, shares)
    sd, sde = jack(ch, share_diff)
    sp, spe = jack(ch, split_mean)
    al, ale = jack(ch, align)
    pw, pwe = jack(ch, parity_ratio)
    Rn = sd.shape[0]

    print(f"L = {meta['L']}, {nconf} configurations, {len(ch)} chains")
    print('check: W_odd/W_even (mean 1/2 Tr W, odd over even loops):',
          ' '.join(f'R={R+1}: {pw[R]:+.3f}' for R in range(Rn)))
    print('\nmode populations s_i^2/sum s^2, all loops: real | null | real minus null (x1000) +/- err')
    for R in range(Rn):
        print(f'  R={R+1}  {np.round(sh[R,0,2],4)} | {np.round(sh[R,1,2],4)} | '
              f'{np.round(1e3*sd[R,2],2)} +/- {np.round(1e3*sde[R,2],2)}')
    print('\n  same, loops with all three planes even | at least one odd (x1000):')
    for R in range(Rn):
        print(f'  R={R+1}  even {np.round(1e3*sd[R,0],2)} +/- {np.round(1e3*sde[R,0],2)}   '
              f'odd {np.round(1e3*sd[R,1],2)} +/- {np.round(1e3*sde[R,1],2)}')
    print('\nsplit ratio (s2-s3)/(s1-s3) by number of odd planes 0..3: real | null')
    for R in range(Rn):
        print(f'  R={R+1}  {np.round(sp[R,0],4)} | {np.round(sp[R,1],4)}')
    print('\naxis alignment <m_p.m_q> by odd loops in the pair (0, 1, 2): real | null   (random: 0)')
    for R in range(Rn):
        print(f'  R={R+1}  {np.round(al[R,0,:,0],4)} +/- {np.round(ale[R,0,:,0],4)} | {np.round(al[R,1,:,0],4)}')
    print('\n<(m_p.m_q)^2> all pairs pooled: real | null   (random: 1/3)')
    for R in range(Rn):
        pr = sum(c['pr'].sum(0) for c in ch)[R]
        r_ = pr[0, :, 3].sum() / pr[0, :, 0].sum(); n_ = pr[1, :, 3].sum() / pr[1, :, 0].sum()
        print(f'  R={R+1}  {r_:.5f} | {n_:.5f}')

    S = dict(L=meta['L'], beta=meta.get('beta'), n_configs=nconf, n_chains=len(ch),
             w_odd_over_even=[[float(pw[R]), float(pwe[R])] for R in range(Rn)],
             shares_real_all=[sh[R, 0, 2].tolist() for R in range(Rn)],
             shares_null_all=[sh[R, 1, 2].tolist() for R in range(Rn)],
             share_diff_all=[[sd[R, 2].tolist(), sde[R, 2].tolist()] for R in range(Rn)],
             share_diff_even=[[sd[R, 0].tolist(), sde[R, 0].tolist()] for R in range(Rn)],
             share_diff_odd=[[sd[R, 1].tolist(), sde[R, 1].tolist()] for R in range(Rn)],
             split_real=[sp[R, 0].tolist() for R in range(Rn)],
             split_null=[sp[R, 1].tolist() for R in range(Rn)],
             align_real=[[al[R, 0, :, 0].tolist(), ale[R, 0, :, 0].tolist()] for R in range(Rn)],
             align_null=[[al[R, 1, :, 0].tolist(), ale[R, 1, :, 0].tolist()] for R in range(Rn)])
    with open(os.path.join(out, f"lmodes_summary_L{meta['L']}.json"), 'w') as f:
        json.dump(S, f, indent=1)

    fig, ax = plt.subplots(1, 3, figsize=(18, 5.2))
    Rs = np.arange(1, Rn + 1)
    for gi, (lab, col) in enumerate([('all planes even', COL[0]), ('an odd plane', COL[3])]):
        for j, mk in enumerate(['o', 's', '^']):
            ax[0].errorbar(Rs + 0.07 * (gi - 0.5), 1e3 * sd[:, gi, j], yerr=1e3 * sde[:, gi, j], fmt=mk + '-',
                           color=col, ms=5 * FS ** 0.5, capsize=3, label=(lab if j == 0 else None))
    ax[0].axhline(0, color='k', lw=0.8); ax[0].axvspan(3.5, Rn + 0.5, color='0.92', zorder=0)
    ax[0].set_xlabel('loop side R'); ax[0].set_ylabel(r'$10^3\,\Delta(s_i^2/\sum s^2)$, real $-$ null')
    ax[0].set_title(r'(a) mode populations: $s_1$ (o), $s_2$ (s), $s_3$ (^)'); ax[0].legend(fontsize=9 * FS)
    for c, (lab, col) in enumerate([('both even', COL[0]), ('one odd', COL[1]), ('both odd', COL[3])]):
        ax[1].errorbar(Rs, al[:, 0, c, 0], yerr=ale[:, 0, c, 0], fmt='o-', color=col, ms=5 * FS ** 0.5,
                       capsize=3, label=f'{lab}, real')
        ax[1].plot(Rs, al[:, 1, c, 0], 'x--', color=col, ms=7, alpha=0.7, label=f'{lab}, null')
    ax[1].axhline(0, color='k', lw=0.8); ax[1].axvspan(3.5, Rn + 0.5, color='0.92', zorder=0)
    ax[1].set_xlabel('loop side R'); ax[1].set_ylabel(r'$\langle m_p\cdot m_q\rangle$')
    ax[1].set_title('(b) axis alignment between planes'); ax[1].legend(fontsize=8 * FS, ncol=2)
    R4 = min(4, Rn) - 1
    tot = sum(c['sh'].sum(0) for c in ch)[R4]
    x = (np.arange(20) + 0.5) / 20
    for k, (lab, st) in enumerate([('real', '-'), ('null', '--')]):
        h = tot[k].sum(0); h = h / h.sum() * 20
        ax[2].plot(x, h, st, color=COL[k * 2], lw=2, label=lab)
    ax[2].set_xlabel(r'split ratio $(s_2-s_3)/(s_1-s_3)$'); ax[2].set_ylabel('density')
    ax[2].set_title(f'(c) mode pattern at R = {R4+1}'); ax[2].legend(fontsize=9 * FS)
    fig.tight_layout(); fig.savefig(os.path.join(out, 'FigT8_locked_modes.png'), dpi=250, bbox_inches='tight')
    plt.close(fig)
    print('\nwrote', out)


if __name__ == '__main__':
    main()
