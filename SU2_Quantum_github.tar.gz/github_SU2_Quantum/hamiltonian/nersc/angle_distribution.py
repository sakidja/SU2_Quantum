#!/usr/bin/env python3
"""
Plaquette angle distribution P(theta), c0 = cos(theta), in exact ground states.

Part of the SU2_Quantum project (R. Sakidja, Missouri State University).
Code drafted with AI (LLM) assistance (Claude, Anthropic) and reviewed by the author.

The ground state is a function psi(U_1, ..., U_N) of the dynamical links,
psi = sum c e^{j}_{mn}(U) with e^{j}_{mn} = sqrt(2j+1) D^j_{mn}(U), orthonormal
in Haar measure. Links are drawn Haar uniformly and weighted by |psi|^2
(whose Haar mean is 1, a check). Each sample gives the plaquette holonomies and
their angles theta_p in [0, pi]; theta_p = pi is U_p = -1.

D^j(U) for U = cos(phi) + i sin(phi) n.sigma is exp(2 i phi n.S^{(j)}), with the
same spin matrices and index order (m = j, ..., -j) as the engine, so that
D^{1/2}(U) = U. Validation: the weighted <c0> and <c0^2> must reproduce the
exact engine values.

Twist populations (added): each sample also gives the Pauli vectors c_p of all
plaquettes. In the maximal tree gauge the tree links are the identity, so all
holonomies sit in the frame of the root site. With nP >= 3 plaquettes the
matrix M (nP x 3, rows c_p) defines the twist ellipsoid M^T M; its eigenvalues
divided by the trace, sorted, are the three twist populations. For three
independent Haar holonomies their means are the fixed point
0.69235 / 0.26642 / 0.04122 of the Monte Carlo analysis; the measured electron
neutrino row (NuFIT 6.0) is 0.677 / 0.301 / 0.022. The |psi|^2 weighted means
are reported per sector (untwisted, twisted), and the Pauli vectors are saved.
"""
import argparse, json
import numpy as np
from su2ham.systems import BUILDERS
from su2ham.engine import spin_matrices, jvals, apply_word_trace, inner

SIG = np.array([[[0, 1], [1, 0]], [[0, -1j], [1j, 0]], [[1, 0], [0, -1]]])


def haar(n, rng):
    q = rng.normal(size=(n, 4))
    q /= np.linalg.norm(q, axis=1, keepdims=True)
    U = q[:, 0, None, None] * np.eye(2) + 1j * np.einsum("sk,kab->sab", q[:, 1:], SIG)
    return q, U


def wigner(q, j):
    """e^j(U) = sqrt(2j+1) D^j(U) for a batch of unit quaternions q."""
    if j == 0:
        return np.ones((len(q), 1, 1), complex)
    S = spin_matrices(j)
    qv = q[:, 1:]
    s = np.linalg.norm(qv, axis=1)
    phi = np.arctan2(s, q[:, 0])
    n = qv / np.where(s[:, None] > 0, s[:, None], 1.0)
    A = np.einsum("sk,kab->sab", n, np.array(S))          # n.S, Hermitian
    lam, V = np.linalg.eigh(A)
    ph = np.exp(2j * phi[:, None] * lam)
    D = np.einsum("sai,si,sbi->sab", V, ph, V.conj())
    return np.sqrt(2 * j + 1) * D


def psi_values(sysm, coeffs, qs, jmax):
    st = sysm.state(coeffs)
    E = [{j: wigner(q, j) for j in jvals(jmax)} for q in qs]
    out = np.zeros(len(qs[0]), complex)
    for js, T in st.items():
        R = T[0].astype(complex)[None]                     # (1, m1, n1, m2, n2, ...)
        R = np.broadcast_to(R, (len(qs[0]),) + T.shape[1:])
        for l, j in enumerate(js):
            R = np.einsum("smn...,smn->s...", R, E[l][j])
        out += R
    return out


def plaquette_quat(word, Us):
    """(c0, c1, c2, c3) of the holonomy U_p = c0 + i c.sigma for each sample."""
    P = np.broadcast_to(np.eye(2, dtype=complex), Us[0].shape).copy()
    for (l, dag) in word:
        M = np.conj(np.transpose(Us[l], (0, 2, 1))) if dag else Us[l]
        P = P @ M
    c0 = 0.5 * np.real(np.trace(P, axis1=1, axis2=2))
    ck = [0.5 * np.imag(np.einsum("sab,ba->s", P, SIG[k])) for k in range(3)]
    return np.stack([c0] + ck, axis=1)


def plaquette_c0(word, Us):
    return plaquette_quat(word, Us)[:, 0]


def populations(CV):
    """Sorted eigenvalues of M^T M / trace per sample, M = rows c_p (nP x 3)."""
    G = np.einsum("spk,spl->skl", CV, CV)
    ev = np.linalg.eigvalsh(G)[:, ::-1]
    return ev / np.maximum(ev.sum(axis=1, keepdims=True), 1e-300)


def run(system, jmax, g2, signs, nsamp, seed, chunk=20000):
    S = BUILDERS[system](jmax)
    w, v = S.lowest(g2, signs=signs)
    c = v[:, 0]
    psi = S.state(c)
    exact = []
    for wd in S.plaquettes:
        img = apply_word_trace(psi, wd)
        exact.append((float(np.real(inner(psi, img)).ravel()[0]), float(np.real(inner(img, img)).ravel()[0])))
    rng = np.random.default_rng(seed)
    W, Q = [], []
    for start in range(0, nsamp, chunk):
        m = min(chunk, nsamp - start)
        qs, Us = zip(*[haar(m, rng) for _ in range(S.N)])
        W.append(np.abs(psi_values(S, c, qs, jmax)) ** 2)
        Q.append(np.stack([plaquette_quat(wd, Us) for wd in S.plaquettes], axis=1))
    W = np.concatenate(W); Q = np.concatenate(Q)          # Q: (nsamp, nP, 4)
    C0 = Q[:, :, 0]
    ess = W.sum() ** 2 / (W ** 2).sum()
    sampled = [(float((W * C0[:, p]).sum() / W.sum()), float((W * C0[:, p] ** 2).sum() / W.sum()))
               for p in range(C0.shape[1])]
    rec = dict(system=system, jmax=jmax, g2=g2, signs=signs, mean_weight=float(W.mean()), ess=float(ess),
               exact=exact, sampled=sampled)
    if Q.shape[1] >= 3:
        pop = populations(Q[:, :, 1:])
        mw = (W[:, None] * pop).sum(0) / W.sum()
        sd = np.sqrt((W[:, None] * (pop - mw) ** 2).sum(0) / W.sum())
        rec["populations"] = mw.tolist()
        rec["populations_err"] = (sd / np.sqrt(ess)).tolist()
        rec["populations_haar"] = pop.mean(0).tolist()       # unweighted: the Haar reference
    return rec, W, C0, Q[:, :, 1:].astype(np.float32)


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--system", required=True)
    ap.add_argument("--jmax", type=float, required=True)
    ap.add_argument("--g2", type=float, nargs="+", default=[1.0, 1.8181818, 3.0])
    ap.add_argument("--nsamp", type=int, default=200000)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    S0 = BUILDERS[a.system](0.5)
    nP = len(S0.plaquettes)
    store = {}
    meta = []
    for g in a.g2:
        for name, signs in [("untwisted", [1] * nP), ("twisted", [-1] + [1] * (nP - 1))]:
            r, W, C0, CV = run(a.system, a.jmax, g, signs, a.nsamp, a.seed)
            r["sector"] = name
            meta.append(r)
            store[f"{name}_g{g:.4f}_W"] = W
            store[f"{name}_g{g:.4f}_C0"] = C0
            store[f"{name}_g{g:.4f}_CV"] = CV
            chk = "  ".join(f"P{p}: exact <c0>={e[0]:+.4f} sampled {s[0]:+.4f}, <c0^2> {e[1]:.4f}/{s[1]:.4f}"
                            for p, (e, s) in enumerate(zip(r["exact"], r["sampled"])))
            print(f"{a.system} j{a.jmax} g2={g:.4f} {name}: mean|psi|^2={r['mean_weight']:.4f} ESS={r['ess']:.0f}  {chk}", flush=True)
            if "populations" in r:
                p, e, h = r["populations"], r["populations_err"], r["populations_haar"]
                print(f"    twist populations {p[0]:.4f}({e[0]*1e4:.0f}) {p[1]:.4f}({e[1]*1e4:.0f}) {p[2]:.4f}({e[2]*1e4:.0f})"
                      f"   Haar reference {h[0]:.4f} {h[1]:.4f} {h[2]:.4f}   electron row 0.677 0.301 0.022", flush=True)
            # saved after every case, so a job that hits its wall time keeps what it finished
            np.savez_compressed(a.out + ".npz", **store)
            json.dump(meta, open(a.out + ".json", "w"), indent=1)
