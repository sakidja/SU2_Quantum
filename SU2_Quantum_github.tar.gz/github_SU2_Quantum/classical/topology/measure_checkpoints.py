#!/usr/bin/env python3
"""
measure_checkpoints.py
Run the topology measurements (topo_measure.py) on EXISTING gauge
configurations, e.g. the 32 production checkpoints ckpt_cl_L32_rank*.npz
(key 'links', shape (3, L, L, L, 4)).

Quaternion storage order: the S6 production checkpoints store the scalar part
LAST. --convention auto (default) tries scalar first, scalar last and the
conjugate, and keeps the reading with the largest plaquette <c0>: the heat bath
maximizes Re Tr P, so the physical reading gives <c0> = 0.493 at beta = 2.2 and a
wrong reading about 0.12. The choice is printed for every file.

Each checkpoint is one thermalized configuration. Optionally continue the
heat bath from each checkpoint for more configurations (--extra N with
--skip sweeps between them), which reuses the thermalization already paid.

MPI: files are distributed round robin over ranks. Output layout is the
same as su2_topology_heatbath.py, so aggregate_topology.py and
topology_figures.py work unchanged.

Usage
    # one configuration per checkpoint, 32 ranks, a few minutes at L = 32
    srun -n 32 python measure_checkpoints.py --glob 'ckpt_cl_L32_rank*.npz' --out runs/ckpt32

    # plus 50 further configurations from each checkpoint, 10 sweeps apart
    srun -n 32 python measure_checkpoints.py --glob 'ckpt_cl_L32_rank*.npz' \
         --extra 50 --skip 10 --out runs/ckpt32x
"""
import argparse
import glob
import json
import os
import re
import sys

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from topo_measure import measure, qmul, qconj, shift               # noqa: E402
from su2_topology_heatbath import sweep, to_jsonable, RANK, SIZE, COMM  # noqa: E402


def mean_c0(U):
    tot = 0.0
    for mu, nu in [(0, 1), (0, 2), (1, 2)]:
        P = qmul(qmul(U[mu], shift(U[nu], mu)), qmul(qconj(shift(U[mu], nu)), qconj(U[nu])))
        tot += P[..., 0].mean()
    return tot / 3


def to_scalar_first(U, convention='auto'):
    cands = {'scalar_first': U, 'scalar_last': np.roll(U, 1, axis=-1), 'conjugate': qconj(U)}
    if convention != 'auto':
        return cands[convention], convention, None
    c0 = {k: mean_c0(v) for k, v in cands.items()}
    best = max(c0, key=c0.get)
    return np.ascontiguousarray(cands[best]), best, c0


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--glob', default='ckpt_cl_L32_rank*.npz')
    ap.add_argument('--out', default='runs/ckpt')
    ap.add_argument('--beta', type=float, default=2.2)
    ap.add_argument('--extra', type=int, default=0)
    ap.add_argument('--skip', type=int, default=10)
    ap.add_argument('--rmax', type=int, default=0)
    ap.add_argument('--slab', type=int, default=1)
    ap.add_argument('--vortex_every', type=int, default=1)
    ap.add_argument('--seed', type=int, default=777)
    ap.add_argument('--convention', default='auto', choices=['auto', 'scalar_first', 'scalar_last', 'conjugate'])
    args = ap.parse_args()

    files = sorted(glob.glob(args.glob),
                   key=lambda p: int(re.search(r'rank(\d+)', p).group(1)) if re.search(r'rank(\d+)', p) else 0)
    if RANK == 0:
        print(f'{len(files)} checkpoint files, {SIZE} ranks', flush=True)
    os.makedirs(args.out, exist_ok=True)
    L = None
    for i, p in enumerate(files):
        if i % SIZE != RANK:
            continue
        links = np.load(p)['links'].astype(float).copy()
        links /= np.linalg.norm(links, axis=-1, keepdims=True)
        links, conv, c0 = to_scalar_first(links, args.convention)
        print(f'rank {RANK}: {os.path.basename(p)} read as {conv}'
              + (' (<c0>: ' + ', '.join(f'{k} {v:.4f}' for k, v in c0.items()) + ')' if c0 else ''), flush=True)
        L = links.shape[1]
        rng = np.random.default_rng([args.seed, i])
        idx = np.indices((L, L, L)).sum(0) % 2
        mf = os.path.join(args.out, f'meas_topo_L{L}_rank{i}.jsonl')
        with open(mf, 'w') as f:
            for k in range(args.extra + 1):
                if k:
                    for _ in range(args.skip):
                        sweep(links, args.beta, rng, idx)
                res = measure(links, rmax=args.rmax or None, slab=args.slab, rng=rng,
                              vortex=args.vortex_every > 0 and k % args.vortex_every == 0)
                res['source'] = os.path.basename(p); res['step'] = k
                f.write(json.dumps(to_jsonable(res)) + '\n'); f.flush()
        print(f'rank {RANK}: {os.path.basename(p)} done  <c0>={res["mean_c0"]:.4f} '
              f'Q2={res["Q_sq_per_cell"]:.4f} Qtot={res["Q_total"]}', flush=True)

    if COMM is not None:
        Ls = COMM.gather(L, root=0)
        COMM.Barrier()
        L = next((x for x in (Ls or []) if x), L)
    if RANK == 0 and L:
        from aggregate_topology import aggregate
        S = aggregate(args.out, L)
        S.update(source_glob=args.glob, extra=args.extra, skip=args.skip, beta=args.beta)
        with open(os.path.join(args.out, f'summary_topo_L{L}.json'), 'w') as f:
            json.dump(S, f, indent=1)
        print('summary written', flush=True)


if __name__ == '__main__':
    main()
