#!/usr/bin/env python3
"""
Collect the campaign results, estimate truncation convergence, and compare the
center twist energy on the 1x1 and 2x1 periodic lattices.

    python analyze.py results/          -> summary.csv, summary.json, campaign.png

For every quantity the value at the largest jmax is reported together with
its change from the next smaller jmax ("shift"), the truncation error estimate.
A point is marked converged when |shift| < TOL (default 0.005).

Part of the SU2_Quantum project (R. Sakidja, Missouri State University).
Code drafted with AI (LLM) assistance (Claude, Anthropic) and reviewed by the author.
"""
import sys, os, glob, json, csv
from collections import defaultdict
import numpy as np

TOL = float(os.environ.get("TOL", "0.005"))
d = sys.argv[1] if len(sys.argv) > 1 else "results"
recs = []
for f in sorted(glob.glob(os.path.join(d, "*.json"))):
    recs += json.load(open(f))["records"]
if not recs:
    raise SystemExit(f"no results in {d}")

# table[(system, twist, g2)][jmax] = record
table = defaultdict(dict)
for r in recs:
    table[(r["system"], tuple(r["twist"]), round(r["g2"], 6))][r["jmax"]] = r


def shift(vals):
    """Truncation error estimate from a sequence ordered by jmax: the last change,
    or the larger of the last two changes when three or more truncations exist
    (guards against an accidental crossing between two truncations)."""
    if len(vals) < 2:
        return None
    d1 = vals[-1] - vals[-2]
    if len(vals) >= 3 and abs(vals[-2] - vals[-3]) > abs(d1):
        return np.sign(d1 or 1) * abs(vals[-2] - vals[-3])
    return d1


def best(key, fn):
    """(value at largest jmax, shift from next smaller jmax or None, largest jmax)."""
    byj = table.get(key, {})
    js = sorted(byj)
    if not js:
        return None, None, None
    v = fn(byj[js[-1]])
    s = shift([fn(byj[j]) for j in js])
    if s is None and key[0] == "single":
        s = 0.0   # the single plaquette is run once at jmax 10, converged far below TOL
    return v, s, js[-1]


def twist_energy(system, g2, tw_u, tw_t):
    ku, kt = (system, tw_u, g2), (system, tw_t, g2)
    common = sorted(set(table.get(ku, {})) & set(table.get(kt, {})))
    if not common:
        return None, None, None
    dE = lambda j: table[kt][j]["E"][0] - table[ku][j]["E"][0]
    v = dE(common[-1])
    return v, shift([dE(j) for j in common]), common[-1]


rows = []
g2s = sorted({k[2] for k in table})
for g2 in g2s:
    row = dict(g2=g2)
    for sysname, tw in [("single", (1,)), ("open2x1", (1, 1)), ("torus1x1", (1,)), ("torus2x1", (1, 1))]:
        v, s, j = best((sysname, tw, g2), lambda r: list(r["plaquettes"].values())[0]["sumVar"])
        row[f"{sysname}_sumVar"], row[f"{sysname}_sumVar_shift"], row[f"{sysname}_jmax"] = v, s, j
    v, s, j = best(("open2x1", (1, 1), g2), lambda r: r.get("T12", np.nan))
    row["open2x1_T12"], row["open2x1_T12_shift"] = v, s
    v, s, j = twist_energy("open2x1", g2, (1, 1), (-1, 1))
    row["open2x1_twist_dE"] = v
    for sysname, tu, tt in [("torus1x1", (1,), (-1,)), ("torus2x1", (1, 1), (-1, 1))]:
        v, s, j = twist_energy(sysname, g2, tu, tt)
        row[f"{sysname}_dE"], row[f"{sysname}_dE_shift"], row[f"{sysname}_dE_jmax"] = v, s, j
        v, s, j = best((sysname, tt, g2), lambda r: list(r["plaquettes"].values())[0]["sumVar"])
        row[f"{sysname}_twisted_sumVar"] = v
    a, b = row["torus1x1_dE"], row["torus2x1_dE"]
    row["ratio_2x1_over_1x1"] = (b / a) if (a and b is not None) else None
    sa, sb = row["torus1x1_dE_shift"], row["torus2x1_dE_shift"]
    row["ratio_converged"] = bool(sa is not None and sb is not None and abs(sa) < TOL and abs(sb) < TOL)
    rows.append(row)

keys = list(rows[0].keys())
with open("summary.csv", "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=keys)
    w.writeheader()
    w.writerows(rows)
json.dump(rows, open("summary.json", "w"), indent=1)

fmt = lambda x, p=4: "   n/a " if x is None else f"{x:.{p}f}"
print(f"{'g2':>8} {'dE 1x1':>9} {'shift':>9} {'dE 2x1':>9} {'shift':>9} {'ratio':>7} conv  {'SV 2x1 u/t':>15}")
for r in rows:
    print(f"{r['g2']:8.4f} {fmt(r['torus1x1_dE'])} {fmt(r['torus1x1_dE_shift'],5)} {fmt(r['torus2x1_dE'])} "
          f"{fmt(r['torus2x1_dE_shift'],5)} {fmt(r['ratio_2x1_over_1x1'],3)} {'yes ' if r['ratio_converged'] else 'no  '}"
          f" {fmt(r['torus2x1_sumVar'])}/{fmt(r['torus2x1_twisted_sumVar'])}")

try:
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    C = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100"]
    plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False,
                         "axes.grid": True, "grid.color": "#e6e6e6"})
    fig, ax = plt.subplots(1, 3, figsize=(15, 4.2))
    g = np.array([r["g2"] for r in rows])

    def series(k, conv_key=None):
        y = np.array([np.nan if r[k] is None else r[k] for r in rows], float)
        if conv_key:
            ok = np.array([r[conv_key] is not None and abs(r[conv_key]) < TOL for r in rows])
            y[~ok] = np.nan
        return y
    for i, (k, lab) in enumerate([("single_sumVar", "single plaquette"), ("open2x1_sumVar", "open 2x1"),
                                  ("torus1x1_sumVar", "periodic 1x1"), ("torus2x1_sumVar", "periodic 2x1")]):
        ax[0].plot(g, series(k, k + "_shift"), "-o", ms=4, color=C[i], lw=2, label=lab)
    ax[0].plot([4 / 2.2], [0.617], "D", ms=8, mfc="white", mec="#222", label=r"Wilson MC, $\beta=2.2$")
    ax[0].set_title(r"(a) $\Sigma_k\,\mathrm{Var}(c_k)$, untwisted, converged points", loc="left")
    ax[1].plot(g, series("torus1x1_dE", "torus1x1_dE_shift"), "-o", ms=4, color=C[0], lw=2, label="periodic 1x1")
    ax[1].plot(g, series("torus2x1_dE", "torus2x1_dE_shift"), "-o", ms=4, color=C[1], lw=2, label="periodic 2x1")
    ax[1].set_yscale("log")
    ax[1].set_title(r"(b) Center twist energy $\Delta E$", loc="left")
    rr = np.array([r["ratio_2x1_over_1x1"] if r["ratio_converged"] else np.nan for r in rows], float)
    ax[2].plot(g, rr, "-o", ms=4, color=C[2], lw=2)
    ax[2].axhline(1, color="#666", ls="--", lw=1)
    ax[2].set_ylim(0, 1.2)
    ax[2].set_title(r"(c) $\Delta E(2\times1)/\Delta E(1\times1)$, converged", loc="left")
    for a_ in ax:
        a_.set_xscale("log"); a_.set_xlabel(r"$g^2$")
    ax[0].legend(frameon=False, fontsize=8); ax[1].legend(frameon=False, fontsize=8)
    fig.tight_layout(); fig.savefig("campaign.png", dpi=200)
    print("wrote summary.csv, summary.json, campaign.png")
except ImportError:
    print("wrote summary.csv, summary.json (matplotlib not available for the figure)")
