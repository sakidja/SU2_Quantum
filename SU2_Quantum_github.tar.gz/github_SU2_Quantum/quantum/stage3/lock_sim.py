"""
Stage 3: does a topological lock retain what fluctuations erase?
A neutrino probe qubit is put in superposition; one branch is transported around a
closed loop of N gauge links (controlled SU(2) gates applied in sequence to a target
qubit that forms a Bell pair with a reference). The neutrino coherence after n loops is
C_n = (1/2) Tr(W^n), W the loop holonomy (Wilson loop).

Random ensemble : every link an independent Haar random SU(2) matrix.
Locked ensemble : U_j = V_j R V_{j+1}^dag with V_j Haar random and R a fixed twist
                  exp(i (psi/N) m.sigma) (m random per configuration). Each link is
                  still exactly Haar distributed, so single link statistics are identical
                  (mean 0, Sum Var(c_k) = 3/4), but the loop carries a fixed winding:
                  W = V_1 exp(i psi m.sigma) V_1^dag.  psi = pi is the Z2 center vortex, W = -1.
Noise: every link multiplied by exp(i eta u.sigma), small random eta, to test robustness.
"""
import numpy as np, json
I2=np.eye(2,dtype=complex); SX=np.array([[0,1],[1,0]],complex); SY=np.array([[0,-1j],[1j,0]]); SZ=np.diag([1,-1]).astype(complex)
def su2(c): return c[0]*I2+1j*(c[1]*SX+c[2]*SY+c[3]*SZ)
def haar(rng): x=rng.normal(size=4); return su2(x/np.linalg.norm(x))
def axis_rot(ang,m): return np.cos(ang)*I2+1j*np.sin(ang)*(m[0]*SX+m[1]*SY+m[2]*SZ)
def rand_axis(rng): v=rng.normal(size=3); return v/np.linalg.norm(v)
def ck(U): return np.array([np.real(np.trace(U))/2]+[np.real(np.trace(s@U)/2j) for s in (SX,SY,SZ)])
def noise(rng,eta): return axis_rot(eta*rng.normal(),rand_axis(rng)) if eta>0 else I2
def config(rng,N,kind,psi=np.pi,eta=0.0):
    if kind=="random": links=[haar(rng) for _ in range(N)]
    else:
        V=[haar(rng) for _ in range(N)]; m=rand_axis(rng); R=axis_rot(psi/N,m)
        links=[V[j]@R@V[(j+1)%N].conj().T for j in range(N)]
    return [noise(rng,eta)@U for U in links]
def holonomy(links):
    W=I2.copy()
    for U in links: W=W@U
    return W
def run(kind,N=8,n_max=12,n_cfg=4000,psi=np.pi,eta=0.0,seed=0):
    rng=np.random.default_rng(seed); C=np.zeros((n_cfg,n_max+1)); allc=[]
    for i in range(n_cfg):
        L=config(rng,N,kind,psi,eta); W=holonomy(L); Wn=I2.copy()
        allc.extend(ck(U) for U in L)
        for n in range(n_max+1):
            C[i,n]=np.real(np.trace(Wn))/2; Wn=Wn@W
    allc=np.array(allc)
    return {"kind":kind,"N":N,"psi":psi,"eta":eta,"n_cfg":n_cfg,
            "mean_ck":allc[:,1:].mean(0).tolist(),"sumvar_ck":float(allc[:,1:].var(0).sum()),
            "C_mean":C.mean(0).tolist(),"C_err":(C.std(0)/np.sqrt(n_cfg)).tolist(),
            "C_abs_mean":np.abs(C).mean(0).tolist()}
if __name__=="__main__":
    out={}
    out["random"]=run("random",seed=1)
    for psi,name in [(np.pi,"locked_pi"),(np.pi/2,"locked_pi2"),(np.pi/3,"locked_pi3")]:
        out[name]=run("locked",psi=psi,seed=2)
    for eta in [0.05,0.1,0.2]:
        out[f"locked_pi_noise{eta}"]=run("locked",psi=np.pi,eta=eta,seed=3)
        out[f"random_noise{eta}"]=run("random",eta=eta,seed=4)
    json.dump(out,open("lock_results.json","w"),indent=1)
    for k,v in out.items():
        print(f"{k:22s} <c_k>={np.round(v['mean_ck'],3)} SumVar={v['sumvar_ck']:.4f}  C_n(n=0..6)={np.round(v['C_mean'][:7],3)}")
