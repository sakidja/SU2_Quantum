#!/bin/bash
# Real time formation of the eye: flux pinned on one plaquette, then released.
#   bash slurm/submit_quench.sh        (from the nersc folder)
# Outputs: results/quench_<case>.json, _lines.png, _movie.gif
# Part of the SU2_Quantum project. Drafted with AI (LLM) assistance (Claude, Anthropic).
set -e
mkdir -p logs results
q () {  # name walltime args
  sbatch --job-name=$1 --time=$2 \
         --export=ALL,NPROC=128,OMP=1,CMD="python flux_quench.py $3 --tmax 30 --nt 301 --out results/$1" \
         slurm/run_script.sbatch
}
q quench_t21_j3       01:00:00 "--system torus2x1 --jmax 3   --g2 1.8181818"
q quench_t31_j1.5     01:00:00 "--system torus3x1 --jmax 1.5 --g2 1.8181818"
q quench_t31_j2       03:00:00 "--system torus3x1 --jmax 2   --g2 1.8181818"
q quench_t22_j1       01:00:00 "--system torus2x2 --jmax 1   --g2 1.8181818"
q quench_t22_j1.5     06:00:00 "--system torus2x2 --jmax 1.5 --g2 1.8181818"
# weaker and stronger coupling on the 2x2 torus
q quench_t22_j1_g1.0  01:00:00 "--system torus2x2 --jmax 1   --g2 1.0"
q quench_t22_j1_g3.0  01:00:00 "--system torus2x2 --jmax 1   --g2 3.0"
