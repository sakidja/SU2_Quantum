# Center twist free energy, SU(2), beta = 2.2

Builds on `su2_classical_twist.py` (included unchanged: same quaternion
algebra, exact Creutz heat bath, Wilson real trace action and twist readout).
Part of the SU2_Quantum project (R. Sakidja, Missouri State University).
Code drafted with AI (LLM) assistance (Claude, Anthropic) and reviewed by the author.

* `su2_twist_free_energy.py`: one lambda point. The xy plaquettes of one stack
  (one per time slice) carry weight 1 - 2 lambda, so lambda = 0 is the
  untwisted theory and lambda = 1 the Z2 center twisted one.
  dF = 2 beta * integral_0^1 <sum_stack c0>_lambda d lambda.
  At lambda = 0 and 1 the full readout of su2_classical_twist.py is recorded
  (mean c0, sum_k Var(c_k), hedgehog sum Q^2/V).
* `combine_twist.py`: Gauss Legendre integral over 8 lambda nodes.
* Checks done before packaging: the untwisted limit reproduces
  su2_classical_twist.py bit for bit (same seed); two stacks give dF = 0
  within errors (-0.05 +- 0.11 on L = 2, Lt = 8), one stack a positive dF.

## On Perlmutter (uses the su2ham environment)

```bash
cd /pscratch/sd/r/rsakidja/quantum/SU2/su2_v3_hamiltonian
unzip -o su2_twist_mc.zip && cd twist_mc
bash slurm/submit_twist_mc.sh        # 9 jobs
sacct -u rsakidja --starttime today --format=JobID,JobName%28,State,Elapsed -X | grep tw_
```

Each job writes `results/L<Lx>_T<Lt>_n<stacks>/twist_free_energy.json` and
prints the result at the end of its log in `logs/`. A job that hits its wall
time can be resubmitted unchanged; every chain resumes from its checkpoint.

| job | lattice | purpose |
|---|---|---|
| tw_L2_T16, tw_L2_T32 | 2 x 2 x Lt | compare dF/Lt with the Hamiltonian 2x2 twist energy |
| tw_L8_n2 | 8^3, two stacks | control: dF must vanish |
| tw_L4 ... tw_L32 | L^3, L = 4, 8, 12, 16, 24, 32 | volume trend of the twist free energy, same geometry as the hedgehog campaign |
