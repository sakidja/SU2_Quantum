import json, numpy as np, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
B="#2A6FB0"; M="#B4457A"; INK="#1F2937"; MUT="#6B7280"; GRID="#E5E7EB"
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":11,"axes.edgecolor":MUT,"axes.labelcolor":INK,"xtick.color":MUT,"ytick.color":MUT,"axes.spines.top":False,"axes.spines.right":False,"axes.grid":True,"grid.color":GRID,"grid.linewidth":0.6,"axes.axisbelow":True})
r=json.load(open("holonomy_results.json")); a=r["A_independent"]; b=r["B_screened"]
fig,ax=plt.subplots(1,2,figsize=(11,4.4))
x=np.arange(4); w=0.38
ax[0].bar(x-w/2,a["C_r"][:4],w,color=M,label=f"A independent, χ(k=0) = {a['chi_zero_mode']:.4f}")
ax[0].bar(x+w/2,b["C_r"][:4],w,color=B,label=f"B screened, χ(k=0) = {b['chi_zero_mode']:.4f}")
ax[0].axhline(0,color=MUT,lw=0.8); ax[0].set_xticks(x); ax[0].set_xticklabels(["r = 0\n(contact)","r = 1","r = 2","r = 3"])
ax[0].set_ylabel("charge correlator C(r)"); ax[0].legend(frameon=False,fontsize=9,loc="upper right")
ax[0].set_title("Same zero mode, different structure",fontsize=11,color=INK,loc="left")
R=np.array(a["loop_R"])
ax[1].semilogy(R,np.clip(a["W"],1e-4,None),marker="D",ms=5,color=M,lw=1.6,label="A independent: area law")
ax[1].semilogy(R,np.clip(b["W"],1e-4,None),marker="o",ms=5,color=B,lw=1.6,label="B screened: extra perimeter term")
ax[1].set_xlim(0.5,12.5); ax[1].set_ylim(1e-3,1.2)
ax[1].set_xlabel("loop size R (R × R Wilson loop)"); ax[1].set_ylabel("neutrino coherence ⟨W⟩")
ax[1].legend(frameon=False,fontsize=9,loc="lower left")
ax[1].set_title("The holonomy resolves how the vortices connect",fontsize=11,color=INK,loc="left")
fig.tight_layout(); fig.savefig("Fig_N8_holonomy_aggregation.png",dpi=300); print("ok")
