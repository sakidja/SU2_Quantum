#!/bin/bash
# Login node, after the runs: per run summaries and the lock profile across couplings.
#   bash slurm/22_4d_analysis.sh
cd "$(dirname "$0")/.."
source slurm/env_perlmutter.sh
# measured scale (Cornell fit to the static potential, Creutz ratio as fallback)
FIGSCALE=1.55 "$PY" su2_4d_analysis.py runs/L16_b2.2 runs/L16_b2.3 runs/L16_b2.4 runs/L20_b2.5 \
     --outdir figures_4d_bscan
# cross check with the literature string tension (approximate values, see README_4D.md)
FIGSCALE=1.55 "$PY" su2_4d_analysis.py runs/L16_b2.3 runs/L16_b2.4 runs/L20_b2.5 \
     --asig 2.3=0.369 2.4=0.266 2.5=0.188 --outdir figures_4d_bscan_litscale
# volume check at beta = 2.3
FIGSCALE=1.55 "$PY" su2_4d_analysis.py runs/L20_b2.3 --outdir figures_4d_L20_b2.3
