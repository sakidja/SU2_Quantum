#!/bin/bash -l
# One fresh beta = 2.2 ensemble: 128 independent chains on one CPU node.
#   sbatch 01_ensemble.sh 16      (about 20 min)
#   sbatch 01_ensemble.sh 24      (about 1 h)
#   sbatch 01_ensemble.sh 32      (about 2 h; center vortex analysis on every 2nd config)
# Each call is independent, so all three can be queued at once.
# If the time limit is hit, the job stops cleanly; resubmit the same line to resume.
#SBATCH -A mXXXX                  # <-- your NERSC project
#SBATCH -C cpu
#SBATCH -q regular
#SBATCH -N 1
#SBATCH -t 03:00:00
#SBATCH -J su2topo_ens
#SBATCH -o %x_%j.out
L=${1:-16}
cd "$SLURM_SUBMIT_DIR/.."
source slurm/env_perlmutter.sh
case $L in
  32) VEV=2 ;;
  *)  VEV=1 ;;
esac
srun -n 128 -c 2 --cpu-bind=cores "$PY" su2_topology_heatbath.py \
     --L $L --ntherm 500 --nmeas 100 --skip 10 --rmax 8 --vortex_every $VEV \
     --out runs/L$L --wall $(( 3*3600 - 900 ))
