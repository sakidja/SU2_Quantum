#!/bin/bash -l
# Run on a login node after the ensembles finish (no sbatch needed):
#   bash slurm/03_figures.sh
cd "$(dirname "$0")/.."
source slurm/env_perlmutter.sh
S=""
for L in 16 24 32; do
  [ -d runs/L$L ] && "$PY" aggregate_topology.py runs/L$L $L && S="$S runs/L$L/summary_topo_L$L.json"
done
"$PY" topology_figures.py $S --outdir figures
