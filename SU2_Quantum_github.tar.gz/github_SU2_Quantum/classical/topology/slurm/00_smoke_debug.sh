#!/bin/bash -l
# Quick check that everything works: debug queue, 1 node, under 5 minutes.
#SBATCH -A mXXXX                  # <-- your NERSC project
#SBATCH -C cpu
#SBATCH -q debug
#SBATCH -N 1
#SBATCH -t 00:10:00
#SBATCH -J su2topo_smoke
#SBATCH -o %x_%j.out
cd "$SLURM_SUBMIT_DIR/.."
source slurm/env_perlmutter.sh
srun -n 16 -c 2 --cpu-bind=cores "$PY" su2_topology_heatbath.py \
     --L 8 --ntherm 100 --nmeas 20 --skip 5 --out runs/smoke_L8
cat runs/smoke_L8/summary_topo_L8.json | head -40
