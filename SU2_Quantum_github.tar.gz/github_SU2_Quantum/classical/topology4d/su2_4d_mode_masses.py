#!/usr/bin/env python3
"""
su2_4d_mode_masses.py
The stiffness of each of the three twist modes, measured in Euclidean time instead of
assumed from the harmonic relation.

At every site the three square R x R loops in the three spatial planes (xy, xz, yz) of
its time slice give a 3 x 3 colour by space matrix, as in su2_4d_production.py (option A).
Its singular values s1 >= s2 >= s3 are gauge invariant. Per time slice t, averaged over
the L^3 sites of the slice (zero momentum):

    lam_i(t) = < s_i^2 >_slice      the variance carried by mode i
    e_i(t)   = < s_i^2 / sum s^2 >_slice   the population of mode i (sums to 1)
    w(t)     = < 1/2 Tr W >_slice   the plain loop, the reference 0++ operator

Nothing decays to zero: <O(0) O(t)> levels off at <O>^2, the floor. The analysis
(su2_4d_mode_masses_analysis.py) reads two things from each mode:
    the plateau <lam_i>, the height of the floor (the weight), and
    the decay of the connected part <O(0) O(t)> - <O>^2, the rate of return to the
    floor (the stiffness, the energy).

Spatial APE smearing (--ape: list of smearing levels) improves the overlap with the
lowest states without touching the time direction; level 0 is always kept and gives the
unsmeared populations of the paper.

Per configuration saved: O[level, R, op, t], op = lam1, lam2, lam3, e1, e2, e3, w.
Resumable npz per rank: <out>/mm_L{L}_b{beta}_rank{r}.npz

  python su2_4d_mode_masses.py --L 8 --beta 2.3 --ntherm 100 --nmeas 10 --out runs/mm8        # laptop
  srun -n 128 -c 2 --cpu-bind=cores python su2_4d_mode_masses.py --L 16 --beta 2.4 --out runs/mm_L16_b2.4
"""
import argparse
import json
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from su2_4d_core import ND, qmul, qconj, shift, checkerboard, sweep, line_products, rect_loop  # noqa: E402

try:
    from mpi4py import MPI
    COMM = MPI.COMM_WORLD
    RANK, SIZE = COMM.Get_rank(), COMM.Get_size()
except Exception:
    COMM, RANK, SIZE = None, 0, 1

T_DIR = 3
SPACE = (0, 1, 2)
SPATIAL_PLANES = [(0, 1), (0, 2), (1, 2)]
OPS = ['lam1', 'lam2', 'lam3', 'e1', 'e2', 'e3', 'w']


def ape_step(sl, alpha):
    """One spatial APE step on the three spatial links sl[0..2] (time links untouched)."""
    new = []
    for mu in SPACE:
        S = 0.0
        for nu in SPACE:
            if nu == mu:
                continue
            Um, Un = sl[mu], sl[nu]
            up = qmul(qmul(Un, shift(Um, nu)), qconj(shift(Un, mu)))
            Unm = shift(Un, nu, -1)
            dn = qmul(qmul(qconj(Unm), shift(Um, nu, -1)), shift(Unm, mu))
            S = S + up + dn
        V = (1 - alpha) * sl[mu] + (alpha / 4) * S
        new.append(V / np.linalg.norm(V, axis=-1, keepdims=True))
    return new


def slice_ops(sl, rlist, L):
    """O[R, op, t] from spatial links sl (3, L, L, L, L, 4)."""
    rmax = max(rlist)
    lines = {mu: line_products(sl[mu], mu, rmax) for mu in SPACE}
    out = np.zeros((len(rlist), len(OPS), L))
    for k, R in enumerate(rlist):
        W = np.stack([rect_loop(lines, mu, nu, R, R) for mu, nu in SPATIAL_PLANES])   # (3, L,L,L,L, 4)
        M = np.moveaxis(W[..., 1:], 0, -1)                     # (L,L,L,L, 3 colour, 3 plane)
        s2 = np.linalg.svd(M, compute_uv=False) ** 2            # (L,L,L,L, 3), descending
        e = s2 / (s2.sum(-1, keepdims=True) + 1e-300)
        ax = (0, 1, 2)                                          # average over space, keep time (axis 3)
        out[k, 0:3] = s2.mean(ax).T
        out[k, 3:6] = e.mean(ax).T
        out[k, 6] = W[..., 0].mean(0).mean(ax)
    return out


def measure(links, rlist, ape, alpha):
    L = links.shape[1]
    sl = [links[mu] for mu in SPACE]
    res, done = [], 0
    for lev in sorted(ape):
        while done < lev:
            sl = ape_step(sl, alpha); done += 1
        res.append(slice_ops(sl, rlist, L))
    return np.array(res)                                        # (level, R, op, t)


def rng_state_json(rng):
    return json.dumps(rng.bit_generator.state)


def rng_from_json(s):
    rng = np.random.default_rng()
    rng.bit_generator.state = json.loads(s)
    return rng


def save(path, links, rng, sweeps, obs, args):
    tmp = path + '.tmp.npz'
    shp = (0, len(args.ape), len(args.rlist), len(OPS), args.L)
    np.savez(tmp, links=links, rng=rng_state_json(rng), sweeps_done=sweeps,
             obs=np.array(obs) if obs else np.zeros(shp),
             meta=json.dumps(dict(L=args.L, beta=args.beta, rlist=args.rlist, ape=sorted(args.ape),
                                  alpha=args.alpha, ops=OPS, skip=args.skip, ntherm=args.ntherm,
                                  seed=args.seed, nd=ND)))
    os.replace(tmp, path)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--L', type=int, default=16)
    ap.add_argument('--beta', type=float, default=2.4)
    ap.add_argument('--ntherm', type=int, default=300)
    ap.add_argument('--nmeas', type=int, default=100)
    ap.add_argument('--skip', type=int, default=10)
    ap.add_argument('--rlist', default='1,2,3,4', help='loop sides R')
    ap.add_argument('--ape', default='0,10,25', help='spatial APE smearing levels (0 is always kept)')
    ap.add_argument('--alpha', type=float, default=0.5)
    ap.add_argument('--seed', type=int, default=20261002)
    ap.add_argument('--out', default='runs/mm')
    ap.add_argument('--ckpt_every', type=int, default=10)
    ap.add_argument('--wall', type=float, default=0)
    args = ap.parse_args()
    args.rlist = [int(r) for r in args.rlist.split(',')]
    args.ape = sorted({0} | {int(a) for a in args.ape.split(',')})
    L = args.L
    os.makedirs(args.out, exist_ok=True)
    path = os.path.join(args.out, f'mm_L{L}_b{args.beta}_rank{RANK}.npz')
    t0 = time.time()
    idx = checkerboard(L)
    if os.path.exists(path):
        z = np.load(path, allow_pickle=False)
        links = z['links'].copy(); rng = rng_from_json(str(z['rng'])); sweeps = int(z['sweeps_done'])
        obs = list(z['obs'])
    else:
        rng = np.random.default_rng([args.seed, RANK])
        links = np.zeros((ND,) + (L,) * ND + (4,)); links[..., 0] = 1.0
        sweeps, obs = 0, []
    if RANK == 0:
        print(f'[mode masses] L={L} beta={args.beta} ranks={SIZE} R={args.rlist} ape={args.ape} '
              f'nmeas={args.nmeas}', flush=True)
    stopped = False
    while sweeps < args.ntherm:
        sweep(links, args.beta, rng, idx); sweeps += 1
        if sweeps % 50 == 0:
            save(path, links, rng, sweeps, obs, args)
            if args.wall and time.time() - t0 > args.wall:
                stopped = True; break
    while not stopped and len(obs) < args.nmeas:
        for _ in range(args.skip):
            sweep(links, args.beta, rng, idx); sweeps += 1
        o = measure(links, args.rlist, args.ape, args.alpha)
        obs.append(o)
        if len(obs) % args.ckpt_every == 0 or len(obs) == args.nmeas:
            save(path, links, rng, sweeps, obs, args)
            if RANK == 0:
                e = o[0, -1, 3:6].mean(-1)
                print(f'  meas {len(obs)}/{args.nmeas}  populations R={args.rlist[-1]} '
                      f'{e[0]:.4f} {e[1]:.4f} {e[2]:.4f}  t={time.time()-t0:.0f}s', flush=True)
        if args.wall and time.time() - t0 > args.wall:
            stopped = True
    save(path, links, rng, sweeps, obs, args)
    if COMM is not None:
        COMM.Barrier()
    if RANK == 0:
        print('stopped at wall limit; rerun the same command to resume' if stopped else 'done', flush=True)


if __name__ == '__main__':
    main()
