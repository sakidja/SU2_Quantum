#!/bin/bash -l
# 10 minute debug check of the vortex lock scripts before the production run.
#SBATCH -A mXXXX                  # <-- your NERSC project
#SBATCH -C cpu
#SBATCH -q debug
#SBATCH -N 1
#SBATCH -t 00:10:00
#SBATCH -J su2_vlock_smoke
#SBATCH -o %x_%j.out
cd "$SLURM_SUBMIT_DIR/.."
source slurm/env_perlmutter.sh
srun -n 16 -c 2 --cpu-bind=cores "$PY" vortex_lock_production.py \
     --L 12 --ntherm 100 --nmeas 5 --skip 5 --rmax 6 --out runs/vl12_smoke
"$PY" vortex_lock_analysis.py runs/vl12_smoke --outdir figures_vlock_smoke
