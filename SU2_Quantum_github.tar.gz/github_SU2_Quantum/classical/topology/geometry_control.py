#!/usr/bin/env python3
"""
geometry_control.py
Laptop control for the three mode decomposition (Figure T12, part of the job 15 write up).

Question: is the split 0.692 / 0.266 / 0.041 a property of any three random vectors, or of
SU(2) specifically? And how do the mode correlators of job 15 compare with fields that have
no gauge dynamics at all?

1. Populations s_i^2 / sum s^2 of the 3 x 3 matrix whose columns are three independent vectors:
   generic Gaussian vectors in R^3, against the Pauli parts of three Haar SU(2) elements
   (bounded length sin psi <= 1, Haar weighting). Compared with the lattice fixed point
   (jobs 13, 14) and the measured electron neutrino row (NuFIT 6.0).
2. Mode correlators of featureless random fields on a 32^3 lattice (no gauge action, no vortices,
   no lock): three independent vector fields per site, smoothed to a correlation length, either
   Gaussian or normalized to SU(2). Same slice correlators and one step decay rates as job 15.
3. The job 15 lattice results (every mcorr_summary_*.json found), one step decay rates in lattice
   units and in units of g^2 (a g^2 = 4/beta), and the ratio of mode 3 to mode 1.

  python geometry_control.py                 # about 3 minutes; figures_geometry/
"""
import glob
import json
import os

import numpy as np
from scipy.ndimage import gaussian_filter
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

FS = float(os.environ.get('FIGSCALE', '1'))
plt.rcParams.update({'font.size': 11 * FS, 'axes.spines.top': False, 'axes.spines.right': False})
COL = ['#2A6FB0', '#C27A12', '#B4457A', '#2E9E6B', '#555555']
HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, '..', '..', 'data', 'nersc_summaries')
ROW = np.array([0.6767, 0.3012, 0.0222])          # NuFIT 6.0, normal ordering, with SK atmospheric


def shares(M):
    s = np.linalg.svd(M, compute_uv=False) ** 2
    return s / s.sum(-1, keepdims=True)


def pops(rng, n=2_000_000):
    g = shares(rng.normal(size=(n, 3, 3)))
    q = rng.normal(size=(n, 3, 4)); q /= np.linalg.norm(q, axis=-1, keepdims=True)
    h = shares(np.transpose(q[..., 1:], (0, 2, 1)))
    return g.mean(0), h.mean(0)


def field_rates(rng, sig, su2, L=32, nconf=40):
    acc, pp = [], []
    for _ in range(nconf):
        cols = []
        for _ in range(3):
            if su2:
                q = np.stack([gaussian_filter(rng.normal(size=(L, L, L)), sig, mode='wrap') for _ in range(4)], -1)
                q /= np.linalg.norm(q, axis=-1, keepdims=True); v = q[..., 1:]
            else:
                v = np.stack([gaussian_filter(rng.normal(size=(L, L, L)), sig, mode='wrap') for _ in range(3)], -1)
            cols.append(v)
        s = np.linalg.svd(np.stack(cols, -1).reshape(-1, 3, 3), compute_uv=False) ** 2
        pp.append((s / s.sum(1, keepdims=True)).mean(0))
        acc.append(s.reshape(L, L, L, 3).sum((0, 1)))
    O = np.array(acc)
    C = np.array([[(O[:, :, i] * np.roll(O[:, :, i], -t, 1)).mean() - O[:, :, i].mean() ** 2 for t in range(2)]
                  for i in range(3)])
    with np.errstate(invalid='ignore', divide='ignore'):
        r = np.log(C[:, 0] / C[:, 1])
    return np.mean(pp, 0), r


def main():
    rng = np.random.default_rng(20260926)
    out = os.path.join(HERE, 'figures_geometry'); os.makedirs(out, exist_ok=True)
    S = {}
    g, h = pops(rng)
    lat = np.array([0.69235, 0.26642, 0.04122])
    print('populations: generic Gaussian', g.round(4), ' SU(2) Haar', h.round(4), ' lattice', lat, ' electron row', ROW)
    print('  largest deviation from the electron row: generic %.3f, SU(2) %.3f' % (abs(g - ROW).max(), abs(h - ROW).max()))
    S['populations'] = dict(generic=g.tolist(), su2=h.tolist(), lattice=lat.tolist(), electron_row=ROW.tolist())
    S['fields'] = []
    for su2 in (False, True):
        for sig in (0.7, 1.0, 1.5):
            p, r = field_rates(rng, sig, su2)
            print(f"  {'SU(2)' if su2 else 'Gaussian'} field, smoothing {sig}: populations {p.round(4)}, "
                  f"one step rates {r.round(3)}, mode 3 / mode 1 {r[2]/r[0]:.2f}")
            S['fields'].append(dict(su2=su2, smoothing=sig, populations=p.tolist(), rates=r.tolist()))
    S['lattice'] = []
    for f in sorted(glob.glob(os.path.join(DATA, 'mcorr_summary_*.json'))):
        J = json.load(open(f)); b = J['beta']
        m = np.array(J['meff_over_g2'], float)[0, :, 0]; e = np.array(J['meff_over_g2_err'])[0, :, 0]
        print(f'  lattice beta {b}: one step rates / g^2 {m.round(3)} +/- {e.round(3)}, lattice units {(m*4/b).round(3)}, '
              f'mode 3 / mode 1 {m[2]/m[0]:.3f}')
        S['lattice'].append(dict(beta=b, rate_g2=m.tolist(), err_g2=e.tolist(), rate_lattice=(m * 4 / b).tolist()))
    json.dump(S, open(os.path.join(out, 'geometry_control.json'), 'w'), indent=1)

    fig, ax = plt.subplots(1, 3, figsize=(19, 5.2))
    x = np.arange(3); w = 0.2
    for k, (lab, v, c) in enumerate([('generic vectors', g, COL[4]), ('SU(2) Haar', h, COL[0]),
                                     ('lattice, every coupling', lat, COL[3]), ('electron row, NuFIT 6.0', ROW, COL[2])]):
        ax[0].bar(x + (k - 1.5) * w, v, w, color=c, label=lab)
    ax[0].set_xticks(x); ax[0].set_xticklabels(['mode 1', 'mode 2', 'mode 3']); ax[0].set_ylabel('population')
    ax[0].set_title('(a) populations: generic against SU(2)'); ax[0].legend(fontsize=8 * FS)
    L = S['lattice']
    if L:
        bs = np.array([d['beta'] for d in L])
        for i in range(3):
            ax[1].errorbar(bs, [d['rate_g2'][i] for d in L], yerr=[d['err_g2'][i] for d in L], fmt='o-', color=COL[i],
                           capsize=3, label=f'mode {i+1}, units of $g^2$')
            ax[1].plot(bs, [d['rate_lattice'][i] for d in L], 's--', color=COL[i], alpha=0.6, label=f'mode {i+1}, lattice units')
        ax[1].set_xlabel(r'$\beta$'); ax[1].set_ylabel('one step decay rate')
        ax[1].set_title('(b) lattice: physical against lattice units'); ax[1].legend(fontsize=7 * FS, ncol=2)
        ax[2].plot(bs, [d['rate_g2'][2] / d['rate_g2'][0] for d in L], 'o-', color=COL[3], ms=8, label='lattice')
    for k, su2 in enumerate((False, True)):
        F = [d for d in S['fields'] if d['su2'] == su2]
        ax[2].axhspan(min(d['rates'][2] / d['rates'][0] for d in F), max(d['rates'][2] / d['rates'][0] for d in F),
                      color=[COL[4], COL[0]][k], alpha=0.15, label=('SU(2)' if su2 else 'Gaussian') + ' random fields')
    ax[2].set_xlabel(r'$\beta$'); ax[2].set_ylabel('rate, mode 3 / mode 1'); ax[2].set_title('(c) ratio of the rates')
    ax[2].legend(fontsize=8 * FS)
    fig.tight_layout(); fig.savefig(os.path.join(out, 'FigT12_geometry_control.png'), dpi=250, bbox_inches='tight')
    print('wrote', out)


if __name__ == '__main__':
    main()
