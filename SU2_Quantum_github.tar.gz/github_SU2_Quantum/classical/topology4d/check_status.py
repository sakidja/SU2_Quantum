#!/usr/bin/env python3
"""
check_status.py
Progress of every 4D run in runs/: configurations saved so far against the target, read
from the checkpoint files (safe while jobs are running).

Status of each run:
  complete      target reached
  running       a checkpoint file was written in the last --fresh minutes
  stopped       below target and idle: resubmit its job script from inside slurm/
  thermalizing  running, no configurations yet
  retired       kept on disk but no longer needed (see RETIRED below); hidden unless --all

Below the table, the latest log of each job name (su2_4d_fine, su2_4d_pot, ...), with a
plain reading of its last line. Older logs are hidden unless --all.

  python check_status.py            # from classical/topology4d
  python check_status.py --all      # also retired runs and every log
  python check_status.py --nmeas L32_b2.6=10
"""
import argparse
import glob
import json
import os
import re
import time

import numpy as np

HERE = os.path.dirname(os.path.abspath(__file__))

# runs that stay on disk but are not needed any more, with the reason shown under --all
RETIRED = {
    'pot_L24_b2.6': 'superseded by pot_L24_b2.6_T12 (T up to 12 to reach the plateau)',
    'pot_L20_b2.5': 'used as is in the paper (7,875 configurations)',
    'smoke_L8_b2.3': 'setup check only',
}


def default_nmeas(name, L):
    if name.startswith('pot_'):
        return 40 if '_T' in name else (60 if L >= 24 else 100)
    if name.startswith('mm_'):
        return 150
    if 'gribov' in name:
        return 20
    if L >= 32:
        return 20
    return 40 if L >= 20 else 60


def read_run(d):
    files = [p for p in glob.glob(os.path.join(d, '*_rank*.npz')) if not p.endswith('.tmp.npz')]
    n, sw, meta, newest = 0, [], None, 0.0
    for p in files:
        newest = max(newest, os.path.getmtime(p))
        try:
            z = np.load(p, allow_pickle=False)
            key = next((k for k in ('raw', 'obs', 'wrt') if k in z.files), None)
            n += len(z[key]) if key else 0
            sw.append(int(z['sweeps_done']))
            meta = meta or json.loads(str(z['meta']))
        except Exception:
            pass                                    # file being written; counted next time
    for p in glob.glob(os.path.join(d, '*.tmp.npz')):
        newest = max(newest, os.path.getmtime(p))
    return files, n, sw, meta, newest


def log_reading(last):
    if last.startswith('done') or last.startswith('wrote figures'):
        return 'finished'
    if 'stopped at wall limit' in last:
        return 'stopped at wall limit: resubmit'
    if 'DUE TO TIME LIMIT' in last:
        return 'killed at time limit: resubmit (checkpoint kept)'
    if 'CANCELLED' in last:
        return 'cancelled'
    if re.search(r'Error|Traceback|error:', last):
        return 'ERROR: read the log'
    return 'running'


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--runs', default=os.path.join(HERE, 'runs'))
    ap.add_argument('--nmeas', nargs='*', default=[], help='NAME=nmeas per rank')
    ap.add_argument('--fresh', type=float, default=20, help='minutes since last checkpoint to count as running')
    ap.add_argument('--all', action='store_true', help='show retired runs and every log')
    a = ap.parse_args()
    override = dict(s.split('=') for s in a.nmeas)
    now = time.time()
    print(f"{'run':20s} {'ranks':>5s} {'configs':>8s} {'target':>7s} {'done':>5s}  {'sweeps/rank':11s}  status")
    hidden = []
    for d in sorted(glob.glob(os.path.join(a.runs, '*'))):
        name = os.path.basename(d)
        files, n, sw, meta, newest = read_run(d)
        if not files:
            continue
        if name in RETIRED and not a.all:
            hidden.append(name)
            continue
        L = meta['L'] if meta and 'L' in meta else int(re.search(r'L(\d+)', name).group(1))
        nm = int(override.get(name, default_nmeas(name, L)))
        target = nm * len(files)
        recent = (now - newest) < a.fresh * 60
        if name in RETIRED:
            status = 'retired: ' + RETIRED[name]
        elif n >= target:
            status = 'complete'
        elif recent:
            status = 'thermalizing' if n == 0 else 'running'
        else:
            status = 'stopped: resubmit'
        sws = f"{min(sw) if sw else 0}..{max(sw) if sw else 0}"
        print(f"{name:20s} {len(files):5d} {n:8d} {target:7d} {100 * n / max(target, 1):4.0f}%  {sws:11s}  {status}")
    if hidden:
        print(f"\n(retired, hidden: {', '.join(hidden)}; use --all to show)")

    logs = glob.glob(os.path.join(HERE, '*.out')) + glob.glob(os.path.join(HERE, 'slurm', '*.out'))
    logs.sort(key=os.path.getmtime)
    if not logs:
        return
    latest = {}
    for p in logs:                                   # keep the newest log per job name
        job = re.sub(r'_\d+\.out$', '', os.path.basename(p))
        latest[job] = p
    show = logs if a.all else sorted(latest.values(), key=os.path.getmtime)
    print('\njob logs' + (' (all, oldest first)' if a.all else ' (latest per job name)') + ':')
    for p in show:
        lines = [l.strip() for l in open(p, errors='replace') if l.strip()]
        last = lines[-1] if lines else '(empty)'
        print(f"  {os.path.basename(p):30s} {log_reading(last):34s} {last[:70]}")


if __name__ == '__main__':
    main()
