#!/bin/bash
# Twist free energy campaign at beta = 2.2.
#   bash slurm/submit_twist_mc.sh
# Each job runs 10 lambda values x SEEDS chains in parallel on one node.
# Rerunning the same job resumes from the checkpoints (--resume).
# Part of the SU2_Quantum project. Drafted with AI (LLM) assistance (Claude, Anthropic).
set -e
mkdir -p logs results
sub () {  # name Lx Lt stacks configs skip therm seeds walltime
  sbatch --job-name=$1 --time=$9 \
         --export=ALL,LX=$2,LT=$3,NS=$4,CONFIGS=$5,SKIP=$6,THERM=$7,SEEDS=$8 slurm/run_twist_case.sbatch
}
# Cross check against the Hamiltonian 2x2 torus: long time extent
sub tw_L2_T16   2 16 1 4000 2 500 4 01:00:00
sub tw_L2_T32   2 32 1 4000 2 500 4 01:00:00
# Control: two stacks must give dF = 0
sub tw_L8_n2    8  8 2 4000 5 500 4 02:00:00
# Volume trend in cubic boxes, the geometry of the L = 16 to 32 campaign
sub tw_L4       4  4 1 4000 5 500 4 01:00:00
sub tw_L8       8  8 1 4000 5 500 4 02:00:00
sub tw_L12     12 12 1 4000 5 500 4 03:00:00
sub tw_L16     16 16 1 4000 5 500 4 04:00:00
sub tw_L24     24 24 1 4000 5 500 4 08:00:00
sub tw_L32     32 32 1 4000 5 500 4 12:00:00
