#!/bin/bash -l
# Three twist mode test (loop covariance and colour by space modes) together with
# the vortex lock measurements, on every configuration. 128 chains, L = 24.
#   sbatch 12_twist_modes.sh 24     (about 1 h)
#SBATCH -A mXXXX                  # <-- your NERSC project
#SBATCH -C cpu
#SBATCH -q regular
#SBATCH -N 1
#SBATCH -t 03:00:00
#SBATCH -J su2_modes
#SBATCH -o %x_%j.out
L=${1:-24}
cd "$SLURM_SUBMIT_DIR/.."
source slurm/env_perlmutter.sh
srun -n 128 -c 2 --cpu-bind=cores "$PY" vortex_lock_production.py \
     --L $L --ntherm 500 --nmeas 60 --skip 10 --rmax 6 --modes_every 1 \
     --out runs/vlm$L --wall $(( 3*3600 - 900 ))
FIGSCALE=1.55 "$PY" twist_modes_analysis.py runs/vlm$L --outdir figures_modes_L$L
FIGSCALE=1.55 "$PY" vortex_lock_analysis.py runs/vlm$L --outdir figures_modes_L$L
