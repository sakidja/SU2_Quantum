#!/bin/bash -l
# String tension by one method at every coupling: multihit Wilson loops (su2_4d_potential.py).
#   sbatch slurm/24_4d_potential.sh 16 2.2
#   sbatch slurm/24_4d_potential.sh 16 2.3
#   sbatch slurm/24_4d_potential.sh 16 2.4
#   sbatch slurm/24_4d_potential.sh 20 2.5
# About 1 to 1.5 h at 16^4 and 3 h at 20^4. Resubmit the same line to resume.
#SBATCH -A mXXXX                  # <-- your NERSC project
#SBATCH -C cpu
#SBATCH -q regular
#SBATCH -N 1
#SBATCH -t 06:00:00
#SBATCH -J su2_4d_pot
#SBATCH -o %x_%j.out
L=${1:-16}; BETA=${2:-2.3}; NMEAS=${3:-100}
cd "$SLURM_SUBMIT_DIR/.."
source slurm/env_perlmutter.sh
srun -n 128 -c 2 --cpu-bind=cores "$PY" su2_4d_potential.py \
     --L $L --beta $BETA --ntherm 300 --nmeas $NMEAS --skip 10 \
     --out runs/pot_L${L}_b${BETA} --wall $(( 6*3600 - 1200 ))
