#!/usr/bin/env python3
"""
lock_profile.py
The strength of the topological quantum lock against the physical size of the loop (Figure S12).

Input: data/nersc_summaries/bscan_summary.json (jobs 13 and 14: W_odd/W_even for square R x R loops
at beta = 2.2 (L = 24) and beta = 3.0, 4.0, 5.0 (L = 32), 128 chains each).

The fraction of the Z_2 quantum held by a loop is L = (1 - W_odd/W_even)/2: 0 when the loop carries no
lock (W_odd/W_even = +1) and 1 when the phase is held at exactly -1. It is fitted at each coupling with
a Fermi (logistic) profile in the physical size x = R a g^2 = 4R/beta,

    L(x) = 1 / (1 + exp(-(x - x0)/w)),

where x0 is the size at which half the quantum is held and w is the width of the transition, the
analogue of a temperature. A Gaussian cumulative profile is fitted as a check of the form.

  python lock_profile.py            # prints the table, writes figures_lock_profile/FigS12_lock_profile.png
"""
import json
import os

import numpy as np
from scipy.optimize import curve_fit
from scipy.special import erf
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

FS = float(os.environ.get('FIGSCALE', '1'))
plt.rcParams.update({'font.size': 11 * FS, 'axes.spines.top': False, 'axes.spines.right': False})
COL = {2.2: '#2A6FB0', 3.0: '#C27A12', 4.0: '#B4457A', 5.0: '#2E9E6B'}
HERE = os.path.dirname(os.path.abspath(__file__))
DATA = os.path.join(HERE, '..', '..', 'data', 'nersc_summaries', 'bscan_summary.json')


def fermi(x, x0, w):
    return 1.0 / (1.0 + np.exp(-(x - x0) / w))


def gauss_cdf(x, x0, s):
    return 0.5 * (1 + erf((x - x0) / (np.sqrt(2) * s)))


def main():
    runs = json.load(open(DATA))['runs']
    out = os.path.join(HERE, 'figures_lock_profile'); os.makedirs(out, exist_ok=True)
    rows = []
    fig, ax = plt.subplots(1, 2, figsize=(13, 4.8))
    xx = np.linspace(0, 11, 300)
    for key, v in sorted(runs.items(), key=lambda kv: float(kv[0].split('_')[0][4:])):
        beta = float(key.split('_')[0][4:])
        W = np.array(v['w_odd_over_even']); R = np.arange(1, len(W) + 1); x = 4 * R / beta
        ok = W[:, 1] < 0.1
        L = (1 - W[ok, 0]) / 2; eL = W[ok, 1] / 2
        p, cv = curve_fit(fermi, x[ok], L, p0=[3, 1], sigma=eL + 1e-3, maxfev=20000)
        q, _ = curve_fit(gauss_cdf, x[ok], L, p0=[3, 1.5], sigma=eL + 1e-3, maxfev=20000)
        resid = np.abs(L - fermi(x[ok], *p)).max()
        rows.append(dict(beta=beta, x0=p[0], w=p[1], w_lattice=p[1] * beta / 4, x0_lattice=p[0] * beta / 4,
                         gauss_x0=q[0], gauss_s=q[1], max_resid=resid))
        ax[0].errorbar(x[ok], L, yerr=eL, fmt='o', color=COL[beta], capsize=2, label=rf'$\beta$ = {beta}')
        ax[0].plot(xx, fermi(xx, *p), '-', color=COL[beta], lw=1.2, alpha=0.8)
    ax[0].set_xlabel(r'physical loop size $R\,a\,g^2 = 4R/\beta$'); ax[0].set_ylabel('fraction of the quantum held')
    ax[0].set_title('(a) the lock profile at four couplings'); ax[0].legend(fontsize=9 * FS); ax[0].set_xlim(0, 11)
    a = np.array([4 / r['beta'] for r in rows])
    ax[1].plot(a, [r['w'] for r in rows], 'o-', color='#14213D', ms=8, label=r'width $w$, units of $1/g^2$')
    ax[1].plot(a, [r['w_lattice'] for r in rows], 's--', color='#8FA3C4', ms=7, label='width in lattice units')
    ax[1].plot(a, [r['x0'] for r in rows], '^-', color='#E8A33D', ms=8, label=r'half point $x_0$, units of $1/g^2$')
    ax[1].set_xlabel(r'lattice spacing $a\,g^2 = 4/\beta$'); ax[1].set_ylabel('fitted value')
    ax[1].set_title('(b) the width is fixed in physical units'); ax[1].legend(fontsize=9 * FS); ax[1].set_ylim(0, 4)
    fig.tight_layout(); fig.savefig(os.path.join(out, 'FigS12_lock_profile.png'), dpi=250, bbox_inches='tight')
    print(' beta   x0 (1/g^2)   w (1/g^2)   w (lattice)   Gaussian x0, sigma   max |residual|')
    for r in rows:
        print(f" {r['beta']:.1f}   {r['x0']:.3f}        {r['w']:.3f}       {r['w_lattice']:.3f}         "
              f"{r['gauss_x0']:.3f}, {r['gauss_s']:.3f}         {r['max_resid']:.3f}")
    ws = np.array([r['w'] for r in rows]); wl = np.array([r['w_lattice'] for r in rows])
    print(f'width in physical units: {ws.mean():.3f} +/- {ws.std(ddof=1):.3f} (spread {100*ws.std(ddof=1)/ws.mean():.1f} %); '
          f'in lattice units from {wl.min():.2f} to {wl.max():.2f}')
    json.dump(rows, open(os.path.join(out, 'lock_profile.json'), 'w'), indent=1)


if __name__ == '__main__':
    main()
