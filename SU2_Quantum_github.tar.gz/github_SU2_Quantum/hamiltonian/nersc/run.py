#!/usr/bin/env python3
"""
Driver for the v3 Hamiltonian campaign.

Part of the SU2_Quantum project (R. Sakidja, Missouri State University).
Code drafted with AI (LLM) assistance (Claude, Anthropic) and reviewed by the author.

Example:
    python run.py --system torus2x1 --jmax 2.5 --g2 1.0 1.5 1.818 2.5 3 5 \
                  --twist 1 1 --twist -1 1 --out results/torus2x1_j2.5.json

Each --twist gives one sign per plaquette (+1 untwisted, -1 center twisted).
Output JSON: one record per (twist, g2) with the lowest levels, the gap and,
per plaquette, <c0>, <c0^2> and sum_k Var(c_k) = 1 - <c0^2>.
"""
import argparse, json, os, time, platform
import numpy as np
from su2ham.systems import BUILDERS
from su2ham.systems2 import SPECS, build2
from su2ham.engine import apply_word_trace, inner


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--system", required=True, choices=sorted(BUILDERS))
    ap.add_argument("--engine", default="compact", choices=["compact", "original"],
                    help="compact (engine2, low memory) or original (engine.py); identical results")
    ap.add_argument("--jmax", type=float, required=True)
    ap.add_argument("--g2", type=float, nargs="+", required=True)
    ap.add_argument("--twist", type=int, nargs="+", action="append",
                    help="one sign per plaquette; repeat for several sectors")
    ap.add_argument("--levels", type=int, default=4)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    t0 = time.time()
    sysm = build2(a.system, a.jmax, verbose=True) if a.engine == "compact" else BUILDERS[a.system](a.jmax, verbose=True)
    t_build = time.time() - t0
    nplaq = len(sysm.plaquettes)
    twists = a.twist or [[1] * nplaq]
    for tw in twists:
        if len(tw) != nplaq:
            raise SystemExit(f"--twist needs {nplaq} signs for {a.system}")
    print(f"{a.system} jmax={a.jmax}: n={sysm.n}, build {t_build:.1f}s, "
          f"operator symmetry check {sysm.max_asymmetry:.1e}", flush=True)

    records = []
    os.makedirs(os.path.dirname(os.path.abspath(a.out)), exist_ok=True)
    meta = dict(system=a.system, engine=a.engine, jmax=a.jmax, n=sysm.n, build_seconds=t_build,
                operator_asymmetry=sysm.max_asymmetry, host=platform.node())

    def save():  # written after every record, so a job that hits its wall time keeps what it finished
        json.dump(dict(meta=meta, records=records), open(a.out, "w"), indent=1)

    for tw in twists:
        for g2 in a.g2:
            t1 = time.time()
            w, v = sysm.lowest(g2, signs=tw, k=min(a.levels, sysm.n))
            psi = sysm.state(v[:, 0])
            mom, imgs = sysm.plaquette_moments(psi)
            rec = dict(system=a.system, jmax=a.jmax, g2=g2, twist=tw, n=sysm.n,
                       E=[float(x) for x in w], gap=float(w[1] - w[0]) if len(w) > 1 else None,
                       plaquettes={nm: dict(c0=c0, c0sq=c0sq, sumVar=1.0 - c0sq)
                                   for nm, (c0, c0sq) in zip(sysm.names, mom)})
            # connected correlation of the effective plaquette variables u_p = s_p c0_p
            # (vortex localization test; exact, intermediate reps untruncated)
            if len(imgs) > 1:
                nP = len(imgs)
                M2 = np.array([[float(np.real(inner(imgs[p], imgs[q])).ravel()[0]) for q in range(nP)]
                               for p in range(nP)])
                c = np.array([m[0] for m in mom])
                s = np.array(tw, float)
                rec["K_u"] = (np.outer(s, s) * (M2 - np.outer(c, c))).tolist()
            if hasattr(sysm, "corr_word"):
                img = apply_word_trace(psi, sysm.corr_word)
                cc = float(np.real(inner(psi, img)).ravel()[0])
                c1c2 = float(np.real(inner(imgs[0], imgs[1])).ravel()[0])
                rec["T12"] = cc - c1c2
            rec["seconds"] = time.time() - t1
            records.append(rec)
            pl = "  ".join(f"{nm}: c0={d['c0']:+.5f} SV={d['sumVar']:.5f}" for nm, d in rec["plaquettes"].items())
            print(f"  twist={tw} g2={g2:.4f} E0={w[0]:.8f} gap={rec['gap']:.6f}  {pl}", flush=True)
            save()

    save()
    print(f"wrote {a.out} ({time.time()-t0:.1f}s total)")


if __name__ == "__main__":
    main()
