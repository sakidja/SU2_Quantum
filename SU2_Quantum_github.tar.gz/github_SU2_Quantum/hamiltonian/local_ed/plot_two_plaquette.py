import json, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
R = json.load(open("su2_two_plaquette_results.json"))
S1 = json.load(open("su2_plaquette_results.json"))["coupling_scan"]
C = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100"]
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.edgecolor": "#888", "axes.grid": True, "grid.color": "#e6e6e6", "grid.linewidth": 0.6})
op = [r for r in R["open_scan"]["4.0"] if r["g2"] >= 0.5]
tu = [r for r in R["torus_scan"]["4.0"] if r["g2"] >= 1.0]
tt = [r for r in R["torus_twist_scan"]["4.0"] if r["g2"] >= 1.0]
s1 = [r for r in S1 if 0.5 <= r["g2"] <= 20]
f = lambda L, k: np.array([r[k] for r in L])
fig, ax = plt.subplots(1, 4, figsize=(17, 4.0))
a = ax[0]
a.plot(f(s1, "g2"), f(s1, "sumVar_ck"), color=C[1], lw=2, label="single plaquette")
a.plot(f(op, "g2"), f(op, "sumVar_1"), color=C[0], lw=2, ls="--", label="2x1 lattice, each plaquette")
a.plot([4/2.2], [0.617], "D", ms=8, mfc="white", mec="#222", mew=1.5, label=r"Wilson ensemble, $\beta=2.2$")
a.axhline(0.75, color="#666", lw=1, ls=":")
a.set_xscale("log"); a.set_xlabel(r"$g^2$"); a.set_ylim(0.25, 0.8)
a.set_title(r"(a) Open lattice: $\Sigma_k\,\mathrm{Var}(c_k)$", loc="left", fontsize=10.5)
a.legend(fontsize=8.5, frameon=False, loc="lower right")
b = ax[1]
b.plot(f(op, "g2"), f(op, "T12"), color=C[0], lw=2)
b.axhline(0, color="#666", lw=1)
b.set_xscale("log"); b.set_xlabel(r"$g^2$")
b.set_title(r"(b) Neighbour twist correlation $\langle\Sigma_k c^1_k c^2_k\rangle$", loc="left", fontsize=10.5)
c = ax[2]
g = f(tu, "g2"); dE = np.array([t["E"][0] - u["E"][0] for t, u in zip(tt, tu)])
c.plot(g, dE, color=C[2], lw=2, label=r"$E_0^{\mathrm{twist}}-E_0$")
c.plot(g, 2 / g, color="#666", lw=1, ls="--", label=r"$2/g^2$")
c.set_xscale("log"); c.set_yscale("log"); c.set_xlabel(r"$g^2$")
c.set_title("(c) Periodic 1x1: center twist energy cost", loc="left", fontsize=10.5)
c.legend(fontsize=8.5, frameon=False, loc="upper right")
d = ax[3]
d.plot(g, f(tu, "sumVar"), color=C[0], lw=2, label="untwisted")
d.plot(g, f(tt, "sumVar"), color=C[2], lw=2, label="twisted")
d.plot(g, f(tu, "c0"), color=C[0], lw=1.5, ls="--", label=r"$\langle c_0\rangle$ untwisted")
d.plot(g, f(tt, "c0"), color=C[2], lw=1.5, ls="--", label=r"$\langle c_0\rangle$ twisted")
d.axhline(0, color="#666", lw=1)
d.set_xscale("log"); d.set_xlabel(r"$g^2$")
d.set_title(r"(d) Periodic 1x1: $\Sigma_k\,\mathrm{Var}(c_k)$ and $\langle c_0\rangle$", loc="left", fontsize=10.5)
d.legend(fontsize=8, frameon=False, loc="center left", bbox_to_anchor=(1.01, 0.5))
fig.tight_layout(); fig.savefig("su2_two_plaquette_v3.png", dpi=200)
