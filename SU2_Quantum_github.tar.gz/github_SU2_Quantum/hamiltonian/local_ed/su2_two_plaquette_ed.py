"""
Two plaquette SU(2) Kogut Susskind Hamiltonian (2x1 open lattice), gauge fixed
on a maximal tree, plus the twisted sector test, plus the 1x1 periodic lattice
where a center twist cannot be removed by a field redefinition.

Part of the SU2_Quantum project (R. Sakidja, Missouri State University).
Code drafted with AI (LLM) assistance (Claude, Anthropic) and reviewed by the author.

2x1 open lattice
----------------
Sites (x, y), x = 0,1,2, y = 0,1. Links: b1, b2 (bottom), t1, t2 (top), v0, v1, v2 (vertical).
Maximal tree {b1, b2, t1, t2, v0} set to 1. Dynamical links U1 = U_v1 (shared), U2 = U_v2.
Plaquette holonomies: P1 = U1, P2 = U2 U1^dagger.
Gauss law on the tree gives
    sum_links E^2 = C(U1) + 3 C(U2) + 3 (L1 + L2)^2
In the invariant basis |J, j2, j1>: J on the shared link, j2 on the three outer
links of plaquette 2, j1 on the three outer links of plaquette 1:
    H_E = (g^2/2) [ J(J+1) + 3 j2(j2+1) + 3 j1(j1+1) ]
    H_B = (4/g^2) sum_p (1 - s_p c0_p),   c0_p = (1/2) Tr P_p,  s_p = +1 (or -1 twisted)
Truncation: J, j2, j1 <= jmax (every link).

Observables per plaquette: <c0_p>, sum_k Var(c_k^p) = 1 - <c0_p^2> (exact, <c_k^p> = 0),
and the twist correlation between neighbours T12 = <sum_k c_k^1 c_k^2>
    = <(1/2) Tr(P1 P2^dagger)> - <c0_1 c0_2>   (parallel transport along the tree).

1x1 periodic lattice
--------------------
One site, links Ux, Uy, one plaquette P = Ux Uy Ux^dagger Uy^dagger.
    H = (g^2/2)(C(Ux) + C(Uy)) + (4/g^2)(1 - s c0),   s = -1 is the 't Hooft (center) twist.
"""
import numpy as np
import scipy.sparse as sp
import json, time
from su2_lattice_core import LinkSpace, invariant_basis_two_links, kron, jlist, mlist

H2 = [0.5, -0.5]


def build_open(jmax):
    jcut = jmax + 1.0
    L1s = LinkSpace(jcut)
    L2s = LinkSpace(jcut)
    B, labels = invariant_basis_two_links(L1s, L2s, jmax, j1max=jmax)
    I1 = sp.identity(L1s.dim, format="csr")
    I2 = sp.identity(L2s.dim, format="csr")
    c01 = kron(L1s.half_trace(), I2)
    c02 = sp.csr_matrix((L1s.dim * L2s.dim,) * 2)
    for a in H2:
        for b in H2:
            c02 = c02 + 0.5 * kron(L1s.Mdag(b, a), L2s.M(a, b))
    # (1/2) Tr(P1 P2^dag) = (1/2) Tr(U1 U1 U2^dag)
    corr = sp.csr_matrix((L1s.dim * L2s.dim,) * 2)
    for a in H2:
        for b in H2:
            for c in H2:
                corr = corr + 0.5 * kron(L1s.M(a, b) @ L1s.M(b, c), L2s.Mdag(c, a))
    EC = np.array([J * (J + 1) + 3 * j2 * (j2 + 1) + 3 * j1 * (j1 + 1) for (J, j2, j1) in labels])
    return dict(B=B, labels=labels, c01=c01, c02=c02, corr=corr, EC=EC, sp=(L1s, L2s))


def solve_open(S, g2, s1=1, s2=1, nlev=4):
    B = S["B"]
    C1 = (B.T @ (S["c01"] @ B)).toarray()
    C2 = (B.T @ (S["c02"] @ B)).toarray()
    n = B.shape[1]
    H = np.diag(0.5 * g2 * S["EC"]) + (4.0 / g2) * (2 * np.eye(n) - s1 * C1 - s2 * C2)
    w, v = np.linalg.eigh(H)
    psi = B @ v[:, 0]
    a1 = S["c01"] @ psi
    a2 = S["c02"] @ psi
    c01 = psi @ a1
    c02 = psi @ a2
    T12 = psi @ (S["corr"] @ psi) - a1 @ a2
    return dict(g2=g2, E=w[:nlev].tolist(), gap=w[1] - w[0], c0_1=c01, c0_2=c02,
                sumVar_1=1 - a1 @ a1, sumVar_2=1 - a2 @ a2, T12=T12,
                asym=float(np.max(np.abs(H - H.T))))


def build_torus(jmax):
    jcut = jmax + 1.0
    Xs = LinkSpace(jcut)
    Ys = LinkSpace(jcut)
    B, labels = invariant_basis_two_links(Xs, Ys, jmax, j1max=None)
    # (1/2) Tr(Ux Uy Ux^dag Uy^dag) = (1/2) sum Ux_ab Uy_bc (Ux^dag)_cd (Uy^dag)_da
    c0 = sp.csr_matrix((Xs.dim * Ys.dim,) * 2)
    for a in H2:
        for b in H2:
            for c in H2:
                for d in H2:
                    c0 = c0 + 0.5 * kron(Xs.M(a, b) @ Xs.Mdag(c, d), Ys.M(b, c) @ Ys.Mdag(d, a))
    EC = np.array([J * (J + 1) + j2 * (j2 + 1) for (J, j2, j1) in labels])
    return dict(B=B, labels=labels, c0=c0, EC=EC)


def solve_torus(S, g2, s=1, nlev=4):
    B = S["B"]
    C = (B.T @ (S["c0"] @ B)).toarray()
    n = B.shape[1]
    H = np.diag(0.5 * g2 * S["EC"]) + (4.0 / g2) * (np.eye(n) - s * C)
    w, v = np.linalg.eigh(H)
    psi = B @ v[:, 0]
    a = S["c0"] @ psi
    return dict(g2=g2, E=w[:nlev].tolist(), gap=w[1] - w[0], c0=psi @ a, sumVar=1 - a @ a,
                asym=float(np.max(np.abs(H - H.T))))


if __name__ == "__main__":
    out = {"open": {}, "open_twist": {}, "torus": {}, "torus_twist": {}}
    g2s = [0.5, 1.0, 4 / 2.2, 3.0, 5.0]
    for jmax in [0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 4.0]:
        t = time.time()
        So = build_open(jmax)
        out["open"][jmax] = [solve_open(So, g) for g in g2s]
        out["open_twist"][jmax] = [solve_open(So, g, s1=-1) for g in g2s]
        print(f"open jmax={jmax}: {So['B'].shape[1]} states, {time.time()-t:.1f}s", flush=True)
    for jmax in [0.5, 1.0, 1.5, 2.0, 2.5, 3.0, 4.0]:
        t = time.time()
        St = build_torus(jmax)
        out["torus"][jmax] = [solve_torus(St, g) for g in g2s]
        out["torus_twist"][jmax] = [solve_torus(St, g, s=-1) for g in g2s]
        print(f"torus jmax={jmax}: {St['B'].shape[1]} states, {time.time()-t:.1f}s", flush=True)
    # dense coupling scans at the converged truncation
    So = build_open(4.0); St = build_torus(4.0)
    gs = [float(x) for x in np.geomspace(0.1, 20.0, 50)]
    out["open_scan"] = {"4.0": [solve_open(So, g) for g in gs]}
    out["torus_scan"] = {"4.0": [solve_torus(St, g) for g in gs]}
    out["torus_twist_scan"] = {"4.0": [solve_torus(St, g, s=-1) for g in gs]}
    json.dump({k: {str(j): v for j, v in d.items()} for k, d in out.items()},
              open("su2_two_plaquette_results.json", "w"), indent=1)
