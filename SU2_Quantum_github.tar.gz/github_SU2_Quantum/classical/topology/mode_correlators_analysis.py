#!/usr/bin/env python3
"""
mode_correlators_analysis.py
Analysis of job 15 (mode_correlators.py). Login node, no MPI.

  python mode_correlators_analysis.py runs/mc32_b3.0 [--outdir figures_mcorr_L32_b3.0]

Figure T11, two panels per run:
  (a) normalized connected slice correlators C_i(t)/C_i(0) of the three modes (log scale)
      at the loop sizes with a significant signal at t = 1, against t a g^2 = 4t/beta;
  (b) the short distance decay rate m_i(0->1) = ln[C_i(0)/C_i(1)] in units of g^2, by mode.
  Redraw from a summary: python mode_correlators_analysis.py mcorr_summary_L32_b3.0.json --redraw
Errors: delete one chain jackknife. Summary JSON with C_i(t), m_i(t) and errors for every R.
"""
import argparse
import glob
import json
import os
import re
import warnings

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

warnings.simplefilter('ignore', RuntimeWarning)
COL = ['#2A6FB0', '#C27A12', '#B4457A']
FS = float(os.environ.get('FIGSCALE', '1'))
plt.rcParams.update({'font.size': 11 * FS, 'axes.spines.top': False, 'axes.spines.right': False})


def load(d):
    files = sorted(glob.glob(os.path.join(d, 'mcorr_L*_rank*.npz')),
                   key=lambda p: int(re.search(r'rank(\d+)', p).group(1)))
    ch, meta = [], None
    for p in files:
        z = np.load(p, allow_pickle=False)
        if len(z['slices']) == 0:
            continue
        meta = json.loads(str(z['meta']))
        ch.append((z['slices'], z['pops']))
    if len(ch) == 1:
        sl, po = ch[0]
        cut = np.array_split(np.arange(len(sl)), min(10, len(sl)))
        ch = [(sl[i], po[i]) for i in cut]
    return ch, meta


def sums(sl):
    """Per chain sums needed for the connected correlator: (sum_t0 O(t0) O(t0+t), sum O, count)."""
    L = sl.shape[-1]
    oo = np.zeros(sl.shape[1:4] + (L,))                       # (R, axis, mode, t)
    for t in range(L):
        oo[..., t] = (sl * np.roll(sl, -t, axis=-1)).sum((0, -1))
    return oo, sl.sum((0, -1)), sl.shape[0] * L


def corr(S):
    oo, o, n = S
    mean = o / n                                               # (R, axis, mode)
    c = oo / n - mean[..., None] ** 2
    return c.mean(1)                                          # average over the three axes -> (R, mode, t)


def draw(S, out):
    """Figure T11 from a summary dict: the signal lives at the shortest separations, so the figure
    shows (a) C_i(t)/C_i(0) for t = 0..4 at the loop sizes with a significant C(1), and (b) the
    short distance decay rate m_i(0->1)/g^2 of each mode, with errors, per loop size."""
    beta, L = S['beta'], S['L']
    C = np.array(S['C']); Ce = np.array(S['C_err'])
    m = np.array(S['meff_over_g2'], dtype=float); me = np.array(S['meff_over_g2_err'])
    good = [R for R in range(C.shape[0]) if np.all(C[R, :, 1] > 3 * Ce[R, :, 1])] or [0]
    fig, ax = plt.subplots(1, 2, figsize=(13, 5))
    ls = ['-', '--', ':', '-.']
    for k, R in enumerate(good):
        for i in range(3):
            t = np.arange(5); y = C[R, i, :5] / C[R, i, 0]; e = Ce[R, i, :5] / C[R, i, 0]
            ok = y > 2 * e; ok[0] = True
            ax[0].errorbar(4 * t[ok] / beta, y[ok], yerr=e[ok], fmt='o' + ls[k % 4], color=COL[i], capsize=3,
                           label=f'mode {i+1}, R = {R+1}')
    ax[0].set_yscale('log'); ax[0].set_xlabel(r'$t\,a\,g^2 = 4t/\beta$'); ax[0].set_ylabel(r'$C_i(t)/C_i(0)$')
    ax[0].set_title('(a) mode correlators (points above twice their error)'); ax[0].legend(fontsize=8 * FS, ncol=2)
    for k, R in enumerate(good):
        x = np.arange(3) + 0.12 * (k - (len(good) - 1) / 2)
        ax[1].errorbar(x, m[R, :, 0], yerr=me[R, :, 0], fmt='o' + ls[k % 4], color='0.3', capsize=4,
                       label=f'R = {R+1}')
        for i in range(3):
            ax[1].plot(x[i], m[R, i, 0], 'o', color=COL[i], ms=8)
    ax[1].set_xticks(range(3)); ax[1].set_xticklabels(['mode 1\n(0.692)', 'mode 2\n(0.266)', 'mode 3\n(0.041)'])
    ax[1].set_ylabel(r'$m_i(0 \to 1)/g^2$'); ax[1].set_title('(b) short distance decay rate by mode')
    ax[1].legend(fontsize=9 * FS)
    fig.suptitle(f'L = {L}, beta = {beta}')
    fig.tight_layout()
    fig.savefig(os.path.join(out, 'FigT11_mode_correlators.png'), dpi=250, bbox_inches='tight')
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('rundir', help='run directory, or a mcorr_summary_*.json with --redraw')
    ap.add_argument('--outdir', default=None)
    ap.add_argument('--redraw', action='store_true', help='redraw Figure T11 from a summary JSON')
    a = ap.parse_args()
    if a.redraw:
        S = json.load(open(a.rundir))
        out = a.outdir or f"figures_mcorr_L{S['L']}_b{S['beta']}"
        os.makedirs(out, exist_ok=True); draw(S, out); print('wrote', out); return
    ch, meta = load(a.rundir)
    if not ch:
        raise SystemExit('no measurements in ' + a.rundir)
    L, beta = meta['L'], meta['beta']
    out = a.outdir or f'figures_mcorr_L{L}_b{beta}'
    os.makedirs(out, exist_ok=True)
    per = [sums(sl) for sl, _ in ch]
    tot = tuple(sum(p[k] for p in per) for k in range(3))
    C = corr(tot)
    n = len(per)
    jk = np.array([corr(tuple(tot[k] - per[i][k] for k in range(3))) for i in range(n)])
    Ce = np.sqrt((n - 1) / n * ((jk - jk.mean(0)) ** 2).sum(0))
    T = L // 2
    with np.errstate(divide='ignore', invalid='ignore'):
        meff = np.log(C[..., :T] / C[..., 1:T + 1])
        jm = np.log(jk[..., :T] / jk[..., 1:T + 1])
    me = np.sqrt((n - 1) / n * np.nansum((jm - np.nanmean(jm, 0)) ** 2, 0))
    g2 = beta / 4.0                                            # m / g^2 = (m a) * beta / 4
    pops = np.concatenate([po for _, po in ch]).mean(0)
    nconf = sum(len(sl) for sl, _ in ch)
    print(f'L = {L}, beta = {beta}, {nconf} configurations, {n} chains; t a g^2 = 4t/beta')
    for R in range(C.shape[0]):
        print(f'\nR = {R+1}   populations {np.round(pops[R], 4)}')
        print('   t   t a g^2   C_i(t)/C_i(0) for modes 1, 2, 3        m_i(t)/g^2 for modes 1, 2, 3')
        for t in range(T):
            cn = C[R, :, t] / C[R, :, 0]
            print(f'  {t:2d}  {4*t/beta:6.2f}   {np.round(cn, 5)}   '
                  f'{np.round(meff[R, :, t] * g2, 3)} +/- {np.round(me[R, :, t] * g2, 3)}')
    S = dict(L=L, beta=beta, n_configs=nconf, n_chains=n, populations=pops.tolist(),
             C=C[..., :T + 1].tolist(), C_err=Ce[..., :T + 1].tolist(),
             meff_over_g2=(meff * g2).tolist(), meff_over_g2_err=(me * g2).tolist())
    json.dump(S, open(os.path.join(out, f'mcorr_summary_L{L}_b{beta}.json'), 'w'), indent=1)

    draw(S, out)
    print('\nwrote', out)


if __name__ == '__main__':
    main()
