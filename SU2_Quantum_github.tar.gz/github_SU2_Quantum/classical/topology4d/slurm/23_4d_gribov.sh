#!/bin/bash -l
# Gribov check: center vortices identified from the best of three random gauge starts.
# If W_odd/W_even and the vortex density match the gribov = 1 run (runs/L16_b2.3),
# the lock is not an artifact of the gauge copy the fixing found.
#   sbatch slurm/23_4d_gribov.sh            (16^4, beta = 2.3, about 3 to 4 h)
#SBATCH -A mXXXX                  # <-- your NERSC project
#SBATCH -C cpu
#SBATCH -q regular
#SBATCH -N 1
#SBATCH -t 06:00:00
#SBATCH -J su2_4d_gribov
#SBATCH -o %x_%j.out
L=${1:-16}; BETA=${2:-2.3}
cd "$SLURM_SUBMIT_DIR/.."
source slurm/env_perlmutter.sh
srun -n 128 -c 2 --cpu-bind=cores "$PY" su2_4d_production.py \
     --L $L --beta $BETA --ntherm 300 --nmeas 20 --skip 10 --rmax 8 --gribov 3 \
     --out runs/L${L}_b${BETA}_gribov3 --wall $(( 6*3600 - 1200 ))
FIGSCALE=1.55 "$PY" su2_4d_analysis.py runs/L${L}_b${BETA}_gribov3 --outdir figures_4d_L${L}_b${BETA}_gribov3
