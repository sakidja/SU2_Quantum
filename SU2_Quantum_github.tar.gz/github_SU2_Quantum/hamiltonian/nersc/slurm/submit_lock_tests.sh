#!/bin/bash
# Lock tests on Perlmutter: vortex localization, probe phase versus damping,
# and the plaquette angle distribution. Run from the package directory:
#   bash slurm/submit_lock_tests.sh
# Every output gets its own name, so nothing from earlier runs is overwritten.
# Part of the SU2_Quantum project. Drafted with AI (LLM) assistance (Claude, Anthropic).
set -e
mkdir -p logs results
G2="0.5 0.8 1.0 1.4 1.8181818 2.5 3.0 5.0"

# 1. Vortex localization: run.py now also records the connected correlation K_u
#    of u_p = s_p c0_p. Outputs: results/<system>_j<jmax>_lock.json
loc () {  # name system jmax walltime nproc twists
  sbatch --job-name=$1 --time=$4 \
         --export=ALL,SYSTEM=$2,JMAX=$3,NPROC=$5,TAG=_lock,TWISTS="$6" slurm/run_case.sbatch
}
loc lock_t21_j2.5 torus2x1 2.5 00:30:00 128 "--twist 1 1 --twist -1 1"
loc lock_t21_j3   torus2x1 3   01:00:00 128 "--twist 1 1 --twist -1 1"
loc lock_t21_j3.5 torus2x1 3.5 02:00:00 128 "--twist 1 1 --twist -1 1"
loc lock_t31_j1.5 torus3x1 1.5 00:30:00 128 "--twist 1 1 1 --twist -1 1 1"
# (the 3x1 jobs at jmax 2 and 2.5 from submit_3x1.sh also record K_u if they
#  start after this code update; otherwise resubmit them with TAG=_lock)

# 2. Probe phase versus damping. Outputs: results/probe_<case>.json
pr () {  # name walltime args
  sbatch --job-name=$1 --time=$2 \
         --export=ALL,NPROC=64,OMP=32,CMD="python probe_phase.py $3 --g2 $G2 --lam 0.1 0.5 1.0 2.0 --out results/$1.json" \
         slurm/run_script.sbatch
}
pr probe_single     00:30:00 "--system single --jmax 10"
pr probe_open2x1    00:30:00 "--system open2x1 --jmax 6"
pr probe_t11_untw   00:30:00 "--system torus1x1 --jmax 6 --twist 1"
pr probe_t11_tw     00:30:00 "--system torus1x1 --jmax 6 --twist -1"
pr probe_t21_untw   04:00:00 "--system torus2x1 --jmax 3 --twist 1 1"
pr probe_t21_tw     04:00:00 "--system torus2x1 --jmax 3 --twist -1 1"
pr probe_t31_untw   04:00:00 "--system torus3x1 --jmax 1.5 --twist 1 1 1"
pr probe_t31_tw     04:00:00 "--system torus3x1 --jmax 1.5 --twist -1 1 1"

# 3. Plaquette angle distribution, one job per lattice and coupling.
#    Outputs: results/angle_<system>_j<jmax>_g<g2>.npz and .json
for g in 0.8 1.0 1.4 1.8181818 2.5 3.0; do
  for spec in "torus1x1 5 1000000 02:00:00" "torus2x1 2.5 1000000 12:00:00" "torus3x1 1.5 500000 12:00:00"; do
    set -- $spec
    sbatch --job-name=angle_${1}_g$g --time=$4 \
           --export=ALL,NPROC=64,OMP=8,CMD="python angle_distribution.py --system $1 --jmax $2 --g2 $g --nsamp $3 --out results/angle_${1}_j${2}_g$g" \
           slurm/run_script.sbatch
  done
done
