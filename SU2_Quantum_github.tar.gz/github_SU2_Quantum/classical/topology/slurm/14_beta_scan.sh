#!/bin/bash -l
# Job 14: coupling scan of the three mode populations and the lock (Figure T10).
# Same measurement as job 13 at a finer lattice spacing. Larger beta means a longer
# correlation length in lattice units, so the loops reach further (rmax grows with beta).
# One beta per submission:
#   sbatch slurm/14_beta_scan.sh 3.0        (L = 32, rmax 9)
#   sbatch slurm/14_beta_scan.sh 4.0        (L = 32, rmax 11)
#   sbatch slurm/14_beta_scan.sh 5.0        (L = 32, rmax 13)
#   sbatch slurm/14_beta_scan.sh 4.0 40 12  (optional: L and rmax by hand)
# Resubmit the same line to resume if the time limit is hit.
# After all three: "$PY" beta_scan_summary.py   (login node, draws Figure T10)
#SBATCH -A mXXXX                  # <-- your NERSC project
#SBATCH -C cpu
#SBATCH -q regular
#SBATCH -N 1
#SBATCH -t 06:00:00
#SBATCH -J su2topo_bscan
#SBATCH -o %x_%j.out
BETA=${1:-4.0}
L=${2:-32}
case "$BETA" in
  2.2*) RDEF=7 ;;
  3.0*) RDEF=9 ;;
  4.0*) RDEF=11 ;;
  *)    RDEF=13 ;;
esac
RMAX=${3:-$RDEF}
cd "$SLURM_SUBMIT_DIR/.."
source slurm/env_perlmutter.sh
srun -n 128 -c 2 --cpu-bind=cores "$PY" locked_modes.py \
     --L $L --beta $BETA --ntherm 800 --nmeas 60 --skip 20 --rmax $RMAX \
     --out runs/lm${L}_b${BETA} --wall $(( 6*3600 - 1200 ))
FIGSCALE=1.55 "$PY" locked_modes_analysis.py runs/lm${L}_b${BETA} --outdir figures_lmodes_L${L}_b${BETA}
