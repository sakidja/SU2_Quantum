#!/usr/bin/env python3
"""
vortex_lock_production.py
Dedicated production run for paper Figure 21 (the center vortex sign flip) and
Figure T6 (the ground state counterpart of Figure 17: neutrino probe coherence
after n turns, sorted by vortex number). Built for NERSC Perlmutter.

Per configuration (3D SU(2), Wilson action, Creutz heat bath, beta = 2.2):
  1. all square Wilson loops R x R, R = 1..rmax, at every site and plane
     (full, gauge invariant 1/2 Tr W, i.e. cos psi);
  2. direct maximal center gauge (overrelaxed), optionally from several random
     gauge starts keeping the best objective (--gribov k), then center projection
     and P vortex plaquettes;
  3. for every loop, n_v = number of P vortex plaquettes on its flat surface
     (exact up to nv_max = 64, so parity is never lost);
  4. accumulators per (R, n_v): count, sum cos(n psi) for n = 1..6, and the
     holonomy angle histogram for even and odd n_v;
  5. hedgehog charge per cell, and P vortex faces on charged and neutral cells
     (panel c of Figure 21);
  6. (--modes) the three twist modes: for every square loop, the plaquette Pauli
     vectors on its flat surface are parallel transported to the loop's base point,
     their 3x3 covariance C_ij = Cov(c_i, c_j) is formed there (gauge covariant,
     so its eigenvalues are gauge invariant), and the sorted eigenvalues
     l1 <= l2 <= l3 are accumulated by vortex class. A null copy gives every
     transported vector a random direction with the same magnitude, which removes
     any alignment and measures the spread produced by finite sampling alone.
     Test of the 1 + 2 split proposed for the three neutrino mass states.

Every MPI rank is an independent Markov chain. Each rank keeps one npz file
    <out>/vlock_L{L}_rank{r}.npz
holding its chain state (links, rng, sweep count) and per configuration
accumulators, rewritten at every checkpoint. Rerunning the same command resumes.
Analysis and figures: vortex_lock_analysis.py (login node, no MPI).

Examples
  python vortex_lock_production.py --L 12 --ntherm 200 --nmeas 20 --out runs/vl12     # laptop test
  srun -n 128 -c 2 --cpu-bind=cores python vortex_lock_production.py \
       --L 32 --ntherm 500 --nmeas 100 --skip 10 --rmax 8 --out runs/vl32              # Perlmutter
"""
import argparse
import json
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from topo_measure import (qmul, qconj, shift, PLANES, plaquette, hedgehog_field,   # noqa: E402
                          wilson_loops, max_center_gauge, _box_sum_2d, line_products)
from su2_topology_heatbath import sweep, rng_state_json, rng_from_json             # noqa: E402

try:
    from mpi4py import MPI
    COMM = MPI.COMM_WORLD
    RANK, SIZE = COMM.Get_rank(), COMM.Get_size()
except Exception:
    COMM, RANK, SIZE = None, 0, 1

NMAX = 6          # turns n = 1..6
NVMAX = 64        # vortex count bins 0..64 (last bin collects >= 64)
NBINS = 36        # holonomy angle histogram bins on [0, pi]


NCLS = 6          # classes for the mode test: n_v = 0, 1, 2, 3, then even and odd (exact parity)
NQ = 6            # count, l1, l2, l3, trace, |mean c|^2


def twist_modes(links, P, pv, rmax, rng):
    """Accumulators modes[R-1, class, kind, q]: kind 0 real, 1 null (random directions)."""
    L = links.shape[1]
    lines = [line_products(links[mu], mu, rmax) for mu in range(3)]
    out = np.zeros((rmax, NCLS, 2, NQ))
    for p, (mu, nu) in enumerate(PLANES):
        nv_all = {R: np.rint(_box_sum_2d(pv[(mu, nu)].astype(float), mu, nu, R)).astype(int) for R in range(1, rmax + 1)}
        S1 = [np.zeros((L, L, L, 3)) for _ in range(2)]
        S2 = [np.zeros((L, L, L, 3, 3)) for _ in range(2)]
        added = set()
        for R in range(1, rmax + 1):
            for a in range(R):
                for b in range(R):
                    if (a, b) in added:
                        continue
                    added.add((a, b))
                    T = qmul(lines[mu][a], shift(lines[nu][b], mu, a))          # path x -> x + a mu + b nu
                    Py = shift(shift(P[p], mu, a), nu, b)
                    c = qmul(qmul(T, Py), qconj(T))[..., 1:]                    # transported Pauli vector
                    mag = np.linalg.norm(c, axis=-1, keepdims=True)
                    g = rng.normal(size=c.shape); g /= np.linalg.norm(g, axis=-1, keepdims=True)
                    for k, v in enumerate((c, mag * g)):
                        S1[k] += v
                        S2[k] += v[..., :, None] * v[..., None, :]
            N = R * R
            nv = nv_all[R]
            cls = [nv == 0, nv == 1, nv == 2, nv == 3, (nv % 2) == 0, (nv % 2) == 1]
            for k in range(2):
                m = S1[k] / N
                C = S2[k] / N - m[..., :, None] * m[..., None, :]
                lam = np.linalg.eigvalsh(C)                                      # ascending
                tr = lam.sum(-1)
                m2 = (m ** 2).sum(-1)
                for ci, sel in enumerate(cls):
                    if not sel.any():
                        continue
                    out[R - 1, ci, k, 0] += sel.sum()
                    out[R - 1, ci, k, 1:4] += lam[sel].sum(0)
                    out[R - 1, ci, k, 4] += tr[sel].sum()
                    out[R - 1, ci, k, 5] += m2[sel].sum()
    return out


NSV = 8           # color-space matrix: count, s1^2, s2^2, s3^2 (descending, as fractions of sum s^2, the variance shares), |det M| , sign(det)=+1 count, s1^2/sum, (s2-s3)/(s1-s3)


def color_space_modes(P, pv, rng):
    """Three twist modes at a site: M[a, i] = c_a of the plaquette dual to spatial direction i
    (planes (1,2), (0,2), (0,1) for i = 0, 1, 2). Singular values of M are invariant under gauge
    and spatial rotations. Classified by the number of P vortex plaquettes among the three.
    Null: the three plaquettes taken from three independent random sites."""
    L = P.shape[1]
    cols = [P[2][..., 1:], P[1][..., 1:], P[0][..., 1:]]           # dual to x, y, z
    M = np.stack(cols, axis=-1)                                     # (L,L,L,3 colour,3 space)
    nsite = (pv[(1, 2)].astype(int) + pv[(0, 2)].astype(int) + pv[(0, 1)].astype(int))
    out = np.zeros((2, 4, NSV))                                     # kind (real, null), class n_pv = 0..3
    flat = [c.reshape(-1, 3) for c in cols]
    n = flat[0].shape[0]
    perm = [rng.permutation(n) for _ in range(3)]
    Mn = np.stack([flat[i][perm[i]] for i in range(3)], axis=-1)
    nn = np.stack([pv[(1, 2)].ravel()[perm[0]], pv[(0, 2)].ravel()[perm[1]], pv[(0, 1)].ravel()[perm[2]]], 0).astype(int).sum(0)
    for k, (MM, cls) in enumerate(((M.reshape(-1, 3, 3), nsite.ravel()), (Mn, nn))):
        sv = np.linalg.svd(MM, compute_uv=False)                     # descending
        det = np.linalg.det(MM)
        sq = (sv ** 2) / ((sv ** 2).sum(-1, keepdims=True) + 1e-300)
        split = (sv[:, 1] - sv[:, 2]) / (sv[:, 0] - sv[:, 2] + 1e-300)
        for c in range(4):
            sel = cls == c
            if not sel.any():
                continue
            out[k, c, 0] += sel.sum()
            out[k, c, 1:4] += sq[sel].sum(0)
            out[k, c, 4] += np.abs(det[sel]).sum()
            out[k, c, 5] += (det[sel] > 0).sum()
            out[k, c, 6] += sq[sel, 0].sum()
            out[k, c, 7] += split[sel].sum()
    return out


def gauge_fix_best(links, gribov, rng):
    """Maximal center gauge; with gribov > 1, repeat from random gauge starts and keep the best."""
    best = None
    for k in range(max(1, gribov)):
        U, obj, nit = max_center_gauge(links, rng=(rng if k > 0 else None))
        if best is None or obj > best[1]:
            best = (U, obj, nit)
    return best


def measure(links, rmax, gribov, rng, modes=False):
    L = links.shape[1]
    P = np.stack([plaquette(links, m, n) for m, n in PLANES])
    Q = hedgehog_field(P)
    _, sq = wilson_loops(links, rmax)                      # sq[R]: (3, L, L, L) values of 1/2 Tr W
    Ug, obj, nit = gauge_fix_best(links, gribov, rng)
    z = np.sign(Ug[..., 0])
    pv = {}
    for mu, nu in PLANES:
        pv[(mu, nu)] = (z[mu] * shift(z[nu], mu) * shift(z[mu], nu) * z[nu]) < 0
    dens = float(np.mean([v.mean() for v in pv.values()]))
    # accumulators: acc[R-1, n_v, j] with j = 0 count, j = 1..6 sum cos(j psi)
    acc = np.zeros((rmax, NVMAX + 1, NMAX + 1))
    hist = np.zeros((rmax, 2, NBINS))
    edges = np.linspace(0, np.pi, NBINS + 1)
    for R in range(1, rmax + 1):
        w = sq[R]
        for p, (mu, nu) in enumerate(PLANES):
            nv = np.rint(_box_sum_2d(pv[(mu, nu)].astype(float), mu, nu, R)).astype(int).ravel()
            psi = np.arccos(np.clip(w[p].ravel(), -1, 1))
            nb = np.clip(nv, 0, NVMAX)
            acc[R - 1, :, 0] += np.bincount(nb, minlength=NVMAX + 1)
            for j in range(1, NMAX + 1):
                acc[R - 1, :, j] += np.bincount(nb, weights=np.cos(j * psi), minlength=NVMAX + 1)
            for par in (0, 1):
                hist[R - 1, par] += np.histogram(psi[(nv % 2) == par], bins=edges)[0]
    faces = 0
    for (mu, nu), v in pv.items():
        rho = 3 - mu - nu
        faces = faces + v.astype(int) + np.roll(v, -1, axis=rho).astype(int)
    ch = Q != 0
    extra = np.array([dens, obj, nit,
                      faces[ch].mean() if ch.any() else 0.0, faces[~ch].mean(),
                      float((Q ** 2).mean()), float(Q.sum()), float(P[..., 0].mean())])
    mode_acc = (twist_modes(links, P, pv, min(rmax, 6), rng), color_space_modes(P, pv, rng)) if modes else None
    return acc, hist, extra, mode_acc


EXTRA_NAMES = ['pvortex_density', 'mcg_objective', 'mcg_iters', 'faces_pv_charged',
               'faces_pv_neutral', 'Q_sq_per_cell', 'Q_total', 'mean_c0']


def save(path, links, rng, sweeps, accs, hists, extras, args, modes=None):
    tmp = path + '.tmp.npz'
    np.savez(tmp, links=links, rng=rng_state_json(rng), sweeps_done=sweeps,
             acc=np.array(accs) if accs else np.zeros((0, args.rmax, NVMAX + 1, NMAX + 1)),
             hist=np.array(hists) if hists else np.zeros((0, args.rmax, 2, NBINS)),
             extra=np.array(extras) if extras else np.zeros((0, len(EXTRA_NAMES))),
             modes=np.array([m[0] for m in modes]) if modes else np.zeros((0, min(args.rmax, 6), NCLS, 2, NQ)),
             csmodes=np.array([m[1] for m in modes]) if modes else np.zeros((0, 2, 4, NSV)),
             meta=json.dumps(dict(L=args.L, beta=args.beta, rmax=args.rmax, skip=args.skip,
                                  ntherm=args.ntherm, gribov=args.gribov, seed=args.seed,
                                  extra_names=EXTRA_NAMES, nmax=NMAX, nvmax=NVMAX, nbins=NBINS, cs_shares='squared')))
    os.replace(tmp, path)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--L', type=int, default=32)
    ap.add_argument('--beta', type=float, default=2.2)
    ap.add_argument('--ntherm', type=int, default=500)
    ap.add_argument('--nmeas', type=int, default=100)
    ap.add_argument('--skip', type=int, default=10)
    ap.add_argument('--rmax', type=int, default=8)
    ap.add_argument('--gribov', type=int, default=1, help='gauge fixing starts per configuration (best kept)')
    ap.add_argument('--modes_every', type=int, default=0,
                    help='three twist mode test on every Nth configuration (0: off)')
    ap.add_argument('--seed', type=int, default=20260924)
    ap.add_argument('--out', default='runs/vlock')
    ap.add_argument('--ckpt_every', type=int, default=5)
    ap.add_argument('--wall', type=float, default=0, help='stop cleanly after this many seconds')
    args = ap.parse_args()

    L = args.L
    os.makedirs(args.out, exist_ok=True)
    path = os.path.join(args.out, f'vlock_L{L}_rank{RANK}.npz')
    t0 = time.time()
    idx = np.indices((L, L, L)).sum(0) % 2
    if os.path.exists(path):
        z = np.load(path, allow_pickle=False)
        links = z['links'].copy(); rng = rng_from_json(str(z['rng'])); sweeps = int(z['sweeps_done'])
        accs = list(z['acc']); hists = list(z['hist']); extras = list(z['extra'])
        modes = list(zip(z['modes'], z['csmodes'])) if 'csmodes' in z.files else []
    else:
        rng = np.random.default_rng([args.seed, RANK])
        links = np.zeros((3, L, L, L, 4)); links[..., 0] = 1.0
        sweeps, accs, hists, extras, modes = 0, [], [], [], []
    grng = np.random.default_rng([args.seed, RANK, 99, len(accs)])
    if RANK == 0:
        print(f'[vortex lock] L={L} beta={args.beta} ranks={SIZE} rmax={args.rmax} '
              f'gribov={args.gribov} nmeas={args.nmeas} out={args.out}', flush=True)

    stopped = False
    while sweeps < args.ntherm:
        sweep(links, args.beta, rng, idx); sweeps += 1
        if sweeps % 50 == 0:
            save(path, links, rng, sweeps, accs, hists, extras, args, modes)
            if args.wall and time.time() - t0 > args.wall:
                stopped = True; break
    while not stopped and len(accs) < args.nmeas:
        for _ in range(args.skip):
            sweep(links, args.beta, rng, idx); sweeps += 1
        a, h, e, mo = measure(links, args.rmax, args.gribov, grng,
                              modes=args.modes_every > 0 and len(accs) % args.modes_every == 0)
        accs.append(a); hists.append(h); extras.append(e)
        if mo is not None:
            modes.append(mo)
        if len(accs) % args.ckpt_every == 0 or len(accs) == args.nmeas:
            save(path, links, rng, sweeps, accs, hists, extras, args, modes)
            if RANK == 0:
                print(f'  rank0 {len(accs)}/{args.nmeas}  vortex density {e[0]:.4f}  '
                      f'MCG obj {e[1]:.5f}  t={time.time()-t0:.0f}s', flush=True)
        if args.wall and time.time() - t0 > args.wall:
            stopped = True
    save(path, links, rng, sweeps, accs, hists, extras, args, modes)
    if COMM is not None:
        COMM.Barrier()
    if RANK == 0:
        print('stopped at wall limit; rerun the same command to resume' if stopped else 'done', flush=True)


if __name__ == '__main__':
    main()
