#!/bin/bash -l
# Floor and stiffness of the three twist modes in Euclidean time (su2_4d_mode_masses.py).
# Submit from inside slurm/:
#   sbatch 26_4d_mode_masses.sh 16 2.4        first look (about 2 to 3 h)
#   sbatch 26_4d_mode_masses.sh 16 2.3
# Resubmit the same line to resume. Afterwards, in physical units:
#   python su2_4d_mode_masses_analysis.py runs/mm_L16_b2.4 --asig <a sqrt(sigma) from job 25>
#SBATCH -A mXXXX                  # <-- your NERSC project
#SBATCH -C cpu
#SBATCH -q regular
#SBATCH -N 1
#SBATCH -t 06:00:00
#SBATCH -J su2_4d_mm
#SBATCH -o %x_%j.out
L=${1:-16}; BETA=${2:-2.4}; NMEAS=${3:-150}
cd "$SLURM_SUBMIT_DIR/.."
source slurm/env_perlmutter.sh
srun -n 128 -c 2 --cpu-bind=cores "$PY" su2_4d_mode_masses.py \
     --L $L --beta $BETA --ntherm 300 --nmeas $NMEAS --skip 10 --rlist 1,2,3,4 --ape 0,10,25 \
     --out runs/mm_L${L}_b${BETA} --wall $(( 6*3600 - 1200 ))
FIGSCALE=1.55 "$PY" su2_4d_mode_masses_analysis.py runs/mm_L${L}_b${BETA} --outdir figures_4d_mode_masses_L${L}_b${BETA}
