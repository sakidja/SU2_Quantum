#!/usr/bin/env python3
"""
beta_scan_summary.py
Collects the job 13 and job 14 summaries and draws Figure T10:
  (a) distance of the three mode populations from the SU(2) maximal variance fixed
      point 0.6925 / 0.2663 / 0.0412 (three independent Haar holonomies), against R;
  (b) the lock, W_odd / W_even, against R;
  (c) the lock against R a g^2 = 4 R / beta (3D: a g^2 = 4 / beta), the physical loop size;
one curve per beta. Points with error above 0.25 are not drawn in (b), (c). Login node, seconds.

  python beta_scan_summary.py                       # figures_lmodes_*/lmodes_summary_*.json
  python beta_scan_summary.py a.json b.json ...     # or explicit files
"""
import glob
import json
import os
import sys

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

FIXED = np.array([0.69235, 0.26642, 0.04122])   # 2e7 Haar samples, +/- 3e-5
COL = ['#2A6FB0', '#C27A12', '#2E9E6B', '#B4457A', '#555555', '#7A5CC2']
FS = float(os.environ.get('FIGSCALE', '1'))
plt.rcParams.update({'font.size': 11 * FS, 'axes.spines.top': False, 'axes.spines.right': False})


def main():
    files = sys.argv[1:] or sorted(glob.glob('figures_lmodes_*/lmodes_summary_*.json'))
    extra = os.path.join(os.path.dirname(os.path.abspath(__file__)), '..', '..', 'data',
                         'nersc_summaries', 'lmodes_summary_L24.json')
    if not sys.argv[1:] and os.path.exists(extra):
        files.append(extra)
    runs = {}
    for f in files:
        S = json.load(open(f))
        key = (S.get('beta') or 2.2, S['L'])
        runs[key] = S
    if not runs:
        raise SystemExit('no summaries found')
    fig, ax = plt.subplots(1, 3, figsize=(19, 5))
    out = {}
    print('beta   L   R where populations reach the fixed point (|d| < 1e-3)   R where W_odd/W_even < -0.95')
    for i, (key, S) in enumerate(sorted(runs.items())):
        beta, L = key
        sh = np.array(S['shares_real_all'])
        d = np.abs(sh - FIXED).max(1)
        w = np.array(S['w_odd_over_even'])
        R = np.arange(1, len(d) + 1)
        c = COL[i % len(COL)]
        ax[0].semilogy(R, np.maximum(d, 1e-6), 'o-', color=c, label=f'beta {beta}, L {L}')
        ok = w[:, 1] < 0.25
        ax[1].errorbar(R[ok], w[ok, 0], yerr=w[ok, 1], fmt='o-', color=c, capsize=3, label=f'beta {beta}, L {L}')
        ax[2].errorbar(4 * R[ok] / beta, w[ok, 0], yerr=w[ok, 1], fmt='o-', color=c, capsize=3, label=f'beta {beta}, L {L}')
        rf = next((int(r) for r, x in zip(R, d) if x < 1e-3), None)
        rl = next((int(r) for r, x in zip(R, w[:, 0]) if x < -0.95), None)
        print(f'{beta:4}  {L:3}   {rf}   {rl}   (physical: {4*rf/beta if rf else None}, {round(4*rl/beta,2) if rl else None})')
        out[f'beta{beta}_L{L}'] = dict(R_fixed=rf, R_lock=rl, dist=d.tolist(),
                                       shares_last=sh[-1].tolist(), w_odd_over_even=w.tolist())
    ax[0].axhline(1e-3, color='k', lw=0.8, ls='--')
    ax[0].set_xlabel('loop side R'); ax[0].set_ylabel('max |population - fixed point|')
    ax[0].set_title('(a) approach to the SU(2) fixed point'); ax[0].legend(fontsize=9 * FS)
    ax[1].axhline(-1, color='k', lw=0.8, ls='--'); ax[1].axhline(0, color='k', lw=0.5)
    ax[1].set_xlabel('loop side R'); ax[1].set_ylabel(r'$W_{odd}/W_{even}$')
    ax[1].set_title('(b) the lock, lattice units'); ax[1].legend(fontsize=9 * FS)
    ax[2].axhline(-1, color='k', lw=0.8, ls='--'); ax[2].axhline(0, color='k', lw=0.5)
    ax[2].set_xlabel(r'physical loop size $R\,a\,g^2 = 4R/\beta$'); ax[2].set_ylabel(r'$W_{odd}/W_{even}$')
    ax[2].set_title('(c) the lock, physical units'); ax[2].legend(fontsize=9 * FS)
    fig.tight_layout()
    os.makedirs('figures_bscan', exist_ok=True)
    fig.savefig('figures_bscan/FigT10_beta_scan.png', dpi=250, bbox_inches='tight')
    json.dump(dict(fixed_point=FIXED.tolist(), runs=out), open('figures_bscan/bscan_summary.json', 'w'), indent=1)
    print('wrote figures_bscan/')


if __name__ == '__main__':
    main()
