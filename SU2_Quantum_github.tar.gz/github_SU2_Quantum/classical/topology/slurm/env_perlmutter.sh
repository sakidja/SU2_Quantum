# Source this in every job (and once on a login node for the setup).
# NERSC Perlmutter, CPU nodes. The NERSC python module ships numpy, scipy,
# matplotlib and an mpi4py built against Cray MPICH.

# make the module command available even in a non login batch shell
if ! type module >/dev/null 2>&1; then
  [ -f /usr/share/lmod/lmod/init/bash ] && source /usr/share/lmod/lmod/init/bash
fi
module load python 2>/dev/null || module load cray-python 2>/dev/null

# optional: your own conda env, e.g.  export SU2_CONDA_ENV=su2topo
if [ -n "$SU2_CONDA_ENV" ]; then
  source "$(conda info --base)/etc/profile.d/conda.sh" && conda activate "$SU2_CONDA_ENV"
fi

# absolute path to the interpreter, passed to srun so compute nodes never search PATH
PY=$(command -v python || command -v python3)
if [ -z "$PY" ]; then
  echo "ERROR: no python found after 'module load python'. Run 'module avail python' and edit slurm/env_perlmutter.sh" >&2
  exit 1
fi
export PY
"$PY" -c "import numpy, scipy, matplotlib" || { echo "ERROR: $PY lacks numpy/scipy/matplotlib" >&2; exit 1; }
"$PY" -c "import mpi4py" 2>/dev/null || echo "WARNING: mpi4py not found in $PY; every rank would run as a separate serial job" >&2
echo "using $PY ($("$PY" --version 2>&1))"

export OMP_NUM_THREADS=1          # one chain per core; stop numpy from spawning threads
export OPENBLAS_NUM_THREADS=1
export MKL_NUM_THREADS=1
export PYTHONUNBUFFERED=1
# Own conda env instead of the module:
#   module load python
#   conda create -n su2topo python=3.11 numpy scipy matplotlib -y
#   conda activate su2topo
#   MPICC="cc -shared" pip install --force-reinstall --no-cache-dir --no-binary=mpi4py mpi4py
#   then:  export SU2_CONDA_ENV=su2topo  before sbatch
