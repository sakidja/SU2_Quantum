# SU(2) Quantum, version 3: the Hamiltonian vacuum

Code, Perlmutter job scripts, results and the Section 11 addendum for version 3 of
*SU(2) Quantum* (R. Sakidja, Missouri State University; Zenodo DOI 10.5281/zenodo.23111769).
Version 3 adds an exact Kogut Susskind Hamiltonian treatment of the SU(2) plaquette field
and ties it to the Monte Carlo campaign of version 2 (L = 16, 24, 32 at β = 2.2).

All production runs were made on NERSC Perlmutter (project m4675). Code drafted with
AI (LLM) assistance (Claude, Anthropic) and reviewed by the author.

## Layout

| folder | contents |
|---|---|
| `nersc/` | exact diagonalisation engine (`su2ham/`), the campaign scripts and their Slurm submitters |
| `nersc/results/`, `nersc/logs/` | JSON results and job logs of every Hamiltonian run reported in Section 11 |
| `twistmc/` | twisted boundary Monte Carlo (heat bath, same code as version 2), twist free energy and the vortex eye analysis |
| `twistmc/results/` | twist free energy per box (2 × 2 × 16 up to 32³) and the eye maps (L = 8 to 32) |
| `local_ed/` | the first small exact diagonalisations run before the Perlmutter campaign (single plaquette, two plaquettes, 2 × 1 torus) |
| `paper/` | the Section 11 addendum in markdown with its figures (Figures 29 to 34 of the paper) |

## What each script measures

| script | question | section |
|---|---|---|
| `nersc/run.py` | ground state, Σ Var(cₖ) = 1 − ⟨c₀²⟩, twist energy, convergence in jmax, for `single`, `open2x1`, `torus1x1`, `torus2x1`, `torus3x1`, `torus2x2` | 11.2, 11.4 |
| `nersc/probe_phase.py` | probe coupled to Σ cₖ²: energy shift, Lamb correction, coherence loss | 11.3 |
| `twistmc/su2_twist_free_energy.py` | twist free energy ΔF = 2β ∫dλ ⟨Σ c₀⟩ over the stack, volume trend of the twist cost | 11.4 |
| `twistmc/vortex_eye.py` | position of the imposed flux in saved configurations: core, pin distance, hop, radial profiles | 11.4 |
| `nersc/flux_quench.py` | real time release of the twist from one plaquette | 11.5 |
| `nersc/emergent_symmetry.py` | gauge fixed Hamiltonian with no singlet projection: lowest energy per total charge sector | 11.6 |
| `nersc/ungauged.py` | no gauge fixing, no constraint: ⟨Gₛ²⟩ at every site, explicit breaking term κ, susceptibility χ | 11.6 |
| `nersc/angle_distribution.py` | twist populations of the ground state against the Haar reference | 11.7 |

## Conventions

H = (g²/2) Σ_ℓ E(ℓ)² + (4/g²) Σ_p (1 − s_p c₀,p), with s_p = −1 on a twisted plaquette and
c₀ = ½ Tr U_p. The tree level matching g² = 4/β puts β = 2.2 at g² = 1.818. The electric basis
is truncated at j ≤ jmax on every link; each table in the paper states the jmax used and the
convergence check.

## Running on Perlmutter

```bash
cd nersc
bash slurm/setup_env.sh                 # once
module load python && source $SCRATCH/envs/su2ham/bin/activate
python validate.py                      # must print PASSED
bash slurm/submit_campaign.sh           # ground states and twist energies
bash slurm/submit_lock_tests.sh         # probe and lock tests
bash slurm/submit_emergent.sh           # charge sectors with no singlet projection
bash slurm/submit_ungauged.sh           # no gauge fixing, breaking term
bash slurm/submit_quench.sh             # real time release
cd ../twistmc && bash slurm/submit_twist_mc.sh && sbatch slurm/run_eye.sbatch
```

Memory rule for the large builds (2 × 2 at jmax 1.5, 3 × 1 at jmax 2.5 and above): peak
memory is about workers × SU2HAM_CHUNK × 8 copies × 8 bytes, so use `NPROC=16 SU2HAM_CHUNK=5e7`
(about 50 GB) rather than the defaults. See `nersc/README.md` and `twistmc/README.md` for
the options of each script.

## Status of the runs in this snapshot

Complete and reported: all ground states up to 3 × 1 at jmax 2 and 2 × 2 at jmax 1; probe on
every lattice; twist free energy from 2 × 2 × 16 to 32³; eye maps L = 8 to 32; quench on 2 × 1,
3 × 1 and 2 × 2 (jmax 1); charge sectors on 1 × 1, open 2 × 1, 2 × 1, 3 × 1, 2 × 2; ungauged
single plaquette and 2 × 1 at jmax 1 and 1.5, 1 × 1 at jmax 3 and 4.
Still running at the time of this snapshot: 2 × 2 at jmax 1.5, 3 × 1 at jmax 2.5 and 3,
and the 2 × 2 quench at jmax 1.5. Their results will be added when they land.
