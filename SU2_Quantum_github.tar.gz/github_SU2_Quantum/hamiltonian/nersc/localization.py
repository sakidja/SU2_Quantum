#!/usr/bin/env python3
"""
Vortex localization test on periodic lattices.

Part of the SU2_Quantum project (R. Sakidja, Missouri State University).
Code drafted with AI (LLM) assistance (Claude, Anthropic) and reviewed by the author.

In the twisted sector the center flux is shared among the plaquettes. Two
pictures give the same one plaquette averages:
  spread flux:      every plaquette sits partway toward pi,
  localized vortex: one plaquette sits at pi, the others near 0, in a
                    superposition over the vortex position.
They differ in the connected correlation of the effective plaquette variables
    u_p = s_p c0_p          (s_p = -1 on the plaquette carrying the twist sign),
    K_pq = <u_p u_q> - <u_p><u_q>.
A localized vortex makes K strongly negative between plaquettes; spread flux
makes it small. Computed exactly (intermediate representations untruncated).
"""
import argparse, json
import numpy as np
from su2ham.systems import BUILDERS
from su2ham.engine import apply_word_trace, inner


def correlations(S, g2, signs):
    w, v = S.lowest(g2, signs=signs)
    psi = S.state(v[:, 0])
    imgs = [apply_word_trace(psi, wd) for wd in S.plaquettes]
    P = len(imgs)
    mean = np.array([s * float(np.real(inner(psi, im)).ravel()[0]) for s, im in zip(signs, imgs)])
    M2 = np.array([[signs[p] * signs[q] * float(np.real(inner(imgs[p], imgs[q])).ravel()[0])
                    for q in range(P)] for p in range(P)])
    K = M2 - np.outer(mean, mean)
    return dict(E0=float(w[0]), gap=float(w[1] - w[0]), u=mean.tolist(), K=K.tolist(),
                var_u=np.diag(K).tolist())


if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--system", required=True)
    ap.add_argument("--jmax", type=float, nargs="+", required=True)
    ap.add_argument("--g2", type=float, nargs="+", default=[1.0, 1.4, 4 / 2.2, 2.5, 3.0])
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    recs = []
    for j in a.jmax:
        S = BUILDERS[a.system](j)
        nP = len(S.plaquettes)
        for g in a.g2:
            for name, signs in [("untwisted", [1] * nP), ("twisted", [-1] + [1] * (nP - 1))]:
                r = correlations(S, g, signs)
                r.update(system=a.system, jmax=j, g2=g, sector=name)
                recs.append(r)
                K = np.array(r["K"])
                off = K[np.triu_indices(nP, 1)]
                rho = off / np.sqrt(np.outer(np.diag(K), np.diag(K))[np.triu_indices(nP, 1)])
                print(f"{a.system} jmax={j} g2={g:.4f} {name:9s}: <u>={np.round(r['u'], 4).tolist()} "
                      f"Var(u)={np.round(np.diag(K), 4).tolist()} K_off={np.round(off, 4).tolist()} "
                      f"corr={np.round(rho, 3).tolist()}", flush=True)
    json.dump(recs, open(a.out, "w"), indent=1)
