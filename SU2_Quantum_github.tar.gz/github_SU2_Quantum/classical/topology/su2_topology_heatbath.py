#!/usr/bin/env python3
"""
su2_topology_heatbath.py
3D SU(2) Wilson gauge theory, Creutz heat bath (Kennedy Pendleton sampler)
in the quaternion representation, with the topology measurements of
topo_measure.py. Built for NERSC Perlmutter CPU nodes.

Parallel layout: every MPI rank runs its own independent Markov chain
(seed = seed + rank) on the full L^3 lattice. Nothing is exchanged during
the run, so the job scales perfectly and any subset of ranks is usable.
Each rank writes
    <out>/ckpt_topo_L{L}_rank{r}.npz     links + rng state + sweep count
    <out>/meas_topo_L{L}_rank{r}.jsonl   one JSON line per measured config
and rank 0 writes <out>/summary_topo_L{L}.json at the end
(the same summary can be rebuilt any time with aggregate_topology.py).

Resuming: rerun the identical command. Each rank reloads its checkpoint
and continues; measurement lines already written are kept.

Action: S = beta * sum_P (1 - 1/2 Tr P), same as the S6 production run.
At beta = 2.2 the S6 campaign gives <c0> = 0.4933, sum Var c_k = 0.6172,
<Q^2> per cell = 0.3747. Reproduce these first (slurm/00_smoke_debug.sh,
then L = 16), before trusting anything new.

Examples
  # laptop / login node smoke test (about a minute)
  python su2_topology_heatbath.py --L 8 --ntherm 100 --nmeas 20 --skip 5

  # Perlmutter, 1 CPU node, 128 chains, L = 16
  srun -n 128 -c 2 --cpu-bind=cores python su2_topology_heatbath.py \
       --L 16 --ntherm 500 --nmeas 200 --skip 10 --out runs/L16
"""

import argparse
import json
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from topo_measure import qmul, qconj, shift, measure  # noqa: E402

try:
    from mpi4py import MPI
    COMM = MPI.COMM_WORLD
    RANK, SIZE = COMM.Get_rank(), COMM.Get_size()
except Exception:                     # serial fallback
    COMM, RANK, SIZE = None, 0, 1


# ------------------------------------------------------------ heat bath
def staple_sum(links, mu):
    """Sum of the 4 staples A such that 1/2 Tr(U_mu(x) A) are the plaquettes."""
    A = 0.0
    for nu in range(3):
        if nu == mu:
            continue
        Um, Un = links[mu], links[nu]
        # upper: U_nu(x+mu) U_mu(x+nu)^+ U_nu(x)^+
        up = qmul(qmul(shift(Un, mu), qconj(shift(Um, nu))), qconj(Un))
        # lower: U_nu(x+mu-nu)^+ U_mu(x-nu)^+ U_nu(x-nu)
        Un_m = shift(Un, nu, -1)
        dn = qmul(qmul(qconj(shift(Un_m, mu)), qconj(shift(Um, nu, -1))), Un_m)
        A = A + up + dn
    return A


def kp_sample_x0(rng, bk):
    """Kennedy Pendleton: x0 with density sqrt(1-x0^2) exp(bk x0)."""
    x0 = np.empty_like(bk)
    todo = np.arange(bk.size)
    while todo.size:
        b = bk[todo]
        r1 = 1.0 - rng.random(todo.size)
        r2 = rng.random(todo.size)
        r3 = 1.0 - rng.random(todo.size)
        lam2 = -(np.log(r1) + np.cos(2 * np.pi * r2) ** 2 * np.log(r3)) / (2 * b)
        acc = rng.random(todo.size) ** 2 <= 1.0 - lam2
        x0[todo[acc]] = 1.0 - 2.0 * lam2[acc]
        todo = todo[~acc]
    return x0


def random_su2_with_x0(rng, x0):
    n = x0.size
    cost = 2 * rng.random(n) - 1
    phi = 2 * np.pi * rng.random(n)
    s = np.sqrt(np.clip(1 - x0 ** 2, 0, None))
    sint = np.sqrt(1 - cost ** 2)
    return np.stack([x0, s * sint * np.cos(phi), s * sint * np.sin(phi), s * cost], -1)


def sweep(links, beta, rng, parity, n_or=0):
    L = links.shape[1]
    for mu in range(3):
        for par in (0, 1):
            A = staple_sum(links, mu)
            k = np.linalg.norm(A, axis=-1)
            m = parity == par
            a_hat = A[m] / k[m][:, None]
            X = random_su2_with_x0(rng, kp_sample_x0(rng, beta * k[m]))
            links[mu][m] = qmul(X, qconj(a_hat))          # U = X a_hat^+
    for _ in range(n_or):                                   # optional overrelaxation
        for mu in range(3):
            for par in (0, 1):
                A = staple_sum(links, mu)
                m = parity == par
                a = A[m] / np.linalg.norm(A[m], axis=-1, keepdims=True)
                ab = qconj(a)
                links[mu][m] = qmul(qmul(ab, qconj(links[mu][m])), ab)
    # renormalize against round off drift
    links /= np.linalg.norm(links, axis=-1, keepdims=True)


# ------------------------------------------------------------ I/O helpers
def rng_state_json(rng):
    return json.dumps(rng.bit_generator.state)


def rng_from_json(s):
    rng = np.random.default_rng()
    rng.bit_generator.state = json.loads(s)
    return rng


def save_ckpt(path, links, rng, sweeps_done, n_meas, args):
    tmp = path + '.tmp.npz'
    np.savez(tmp, links=links, sweeps_done=sweeps_done, n_meas=n_meas,
             rng=rng_state_json(rng), beta=args.beta, L=args.L)
    os.replace(tmp, path)


def to_jsonable(o):
    if isinstance(o, dict):
        return {str(k): to_jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [to_jsonable(v) for v in o]
    if isinstance(o, np.generic):
        return o.item()
    return o


# ------------------------------------------------------------ main
def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--L', type=int, default=12)
    ap.add_argument('--beta', type=float, default=2.2)
    ap.add_argument('--ntherm', type=int, default=500, help='thermalization sweeps')
    ap.add_argument('--nmeas', type=int, default=200, help='measured configs per rank')
    ap.add_argument('--skip', type=int, default=10, help='sweeps between measurements')
    ap.add_argument('--nor', type=int, default=0, help='overrelaxation steps per sweep (production used 0)')
    ap.add_argument('--rmax', type=int, default=0, help='largest Wilson loop side (0: min(8, L/2))')
    ap.add_argument('--nmax', type=int, default=6, help='highest winding n in C_n')
    ap.add_argument('--slab', type=int, default=1, help='cell layers on each side of the loop surface')
    ap.add_argument('--vortex_every', type=int, default=1,
                    help='center vortex analysis on every Nth measurement (0: never)')
    ap.add_argument('--seed', type=int, default=20260923)
    ap.add_argument('--out', default='runs')
    ap.add_argument('--ckpt_every', type=int, default=10, help='checkpoint every N measurements')
    ap.add_argument('--wall', type=float, default=0, help='stop cleanly after this many seconds (0: no limit)')
    ap.add_argument('--hot', action='store_true', help='hot (Haar) start instead of cold')
    args = ap.parse_args()

    L = args.L
    os.makedirs(args.out, exist_ok=True)
    ck = os.path.join(args.out, f'ckpt_topo_L{L}_rank{RANK}.npz')
    mf = os.path.join(args.out, f'meas_topo_L{L}_rank{RANK}.jsonl')
    t0 = time.time()

    idx = np.indices((L, L, L)).sum(0) % 2
    if os.path.exists(ck):
        z = np.load(ck, allow_pickle=False)
        links = z['links'].copy()
        rng = rng_from_json(str(z['rng']))
        sweeps_done = int(z['sweeps_done'])
        n_meas = int(z['n_meas'])
        # drop measurement lines written after the checkpoint
        if os.path.exists(mf):
            with open(mf) as f:
                lines = f.readlines()[:n_meas]
            with open(mf, 'w') as f:
                f.writelines(lines)
    else:
        rng = np.random.default_rng([args.seed, RANK])
        links = np.zeros((3, L, L, L, 4)); links[..., 0] = 1.0
        if args.hot:
            g = rng.normal(size=links.shape)
            links = g / np.linalg.norm(g, axis=-1, keepdims=True)
        sweeps_done, n_meas = 0, 0
        open(mf, 'w').close()

    if RANK == 0:
        print(f'[L={L} beta={args.beta}] ranks={SIZE} therm={args.ntherm} '
              f'nmeas={args.nmeas} skip={args.skip} out={args.out}', flush=True)

    stopped = False
    while sweeps_done < args.ntherm:
        sweep(links, args.beta, rng, idx, args.nor)
        sweeps_done += 1
        if sweeps_done % 50 == 0:
            save_ckpt(ck, links, rng, sweeps_done, n_meas, args)
            if args.wall and time.time() - t0 > args.wall:
                stopped = True
                break

    mrng = np.random.default_rng([args.seed, RANK, 7])
    while not stopped and n_meas < args.nmeas:
        for _ in range(args.skip):
            sweep(links, args.beta, rng, idx, args.nor)
            sweeps_done += 1
        dov = args.vortex_every > 0 and n_meas % args.vortex_every == 0
        res = measure(links, rmax=args.rmax or None, nmax=args.nmax,
                      slab=args.slab, rng=mrng, vortex=dov)
        res['sweep'] = sweeps_done
        with open(mf, 'a') as f:
            f.write(json.dumps(to_jsonable(res)) + '\n')
        n_meas += 1
        if n_meas % args.ckpt_every == 0 or n_meas == args.nmeas:
            save_ckpt(ck, links, rng, sweeps_done, n_meas, args)
            if RANK == 0:
                print(f'  rank0 meas {n_meas}/{args.nmeas}  <c0>={res["mean_c0"]:.4f} '
                      f'Q2={res["Q_sq_per_cell"]:.4f}  t={time.time()-t0:.0f}s', flush=True)
        if args.wall and time.time() - t0 > args.wall:
            stopped = True
    save_ckpt(ck, links, rng, sweeps_done, n_meas, args)

    if COMM is not None:
        COMM.Barrier()
    if RANK == 0:
        if stopped:
            print('wall limit reached; rerun the same command to resume', flush=True)
        from aggregate_topology import aggregate
        summ = aggregate(args.out, L)
        summ.update(beta=args.beta, ranks=SIZE, ntherm=args.ntherm,
                    skip=args.skip, seed=args.seed, wall_seconds=time.time() - t0)
        with open(os.path.join(args.out, f'summary_topo_L{L}.json'), 'w') as f:
            json.dump(summ, f, indent=1)
        print(json.dumps({k: summ[k] for k in ('n_configs', 'mean_c0', 'sumvar_ck',
                                               'Q_sq_per_cell', 'Q_total_max_abs')}), flush=True)


if __name__ == '__main__':
    main()
