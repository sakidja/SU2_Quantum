# Topology of the thermal SU(2) vacuum (Stage 3, classical)

**Complete NERSC run list: see `RUN_ORDER.md`.**

Scripts that test the topological lock of Section 10.1 in real Wilson ensembles (3D SU(2), β = 2.2), not in hand built configurations. They are written for NERSC Perlmutter but also run on a laptop.

## Files

| File | Purpose |
|------|---------|
| `topo_measure.py` | All measurements on one configuration (pure numpy). |
| `su2_topology_heatbath.py` | Creutz heat bath (Kennedy Pendleton), one independent chain per MPI rank, checkpoint and resume, measurements written as JSON lines. |
| `measure_checkpoints.py` | The same measurements on existing configurations, such as the S6 production checkpoints `ckpt_cl_L32_rank*.npz`. |
| `aggregate_topology.py` | Combines all rank files into `summary_topo_L{L}.json`, with errors from the spread between independent chains. |
| `topology_figures.py` | Figures T1 to T5 from one or more summaries. |
| `slurm/` | Perlmutter job scripts. |

The link format is the production format: shape (3, L, L, L, 4), scalar first unit quaternions, with the same `qmul` convention as `analysis/twist_visualization.py`.

## What is measured

1. **Plaquette channel:** ⟨c0⟩, ⟨c0²⟩ and Σ Var(c_k).
2. **Hedgehog charge per cell, the definition of Section S6.** n̂ = c/|c| is built from the plaquette Pauli vector summed over the three planes at each site. Q is the degree of n̂ on the cell surface, computed from 12 triangles with signed solid angles. Every face is shared with the same diagonal, so the total Q is exactly zero on the torus.
3. **Charge correlator C_Q(r).** This includes the running sum S(R) and χ(k) at the smallest momenta. χ(0) = 0 identically.
4. **Wilson loops and the probe around a loop:**
   * Wilson loops W(R,T) and Creutz ratios.
   * For square loops: the holonomy angle ψ, the coherence C_n = ⟨cos nψ⟩, and the probe variance V_ν = 1 − ⟨(½ Tr W)²⟩.
5. **Loop against nearby hedgehogs.** The loop value is binned by the hedgehog count in the cells next to its surface, with a displaced charge field as the null.
6. **Center vortices (the lock itself).** The analysis runs in four steps:
   * direct maximal center gauge (overrelaxed, ω = 1.9);
   * center projection;
   * P vortex plaquettes;
   * binning every square loop by the number n_v of vortices piercing it.

   A Z₂ lock appears as W_{n_v}/W_0 → (−1)^{n_v}: every vortex adds a phase π to the transported probe.
   The probe coherence C_n = ⟨cos nψ⟩ after n = 1 to 6 turns is also recorded per vortex class (Figure T6, the ground state counterpart of paper Figure 20): odd turns change sign with vortex parity, even turns do not.

## Dedicated run for Figure 25 and Figure T6 (the vortex lock)

`vortex_lock_production.py` and `vortex_lock_analysis.py` keep only what these two figures need (loops up to R = 8, center gauge fixing, vortex count up to 64 so parity is exact, probe coherence after 1 to 6 turns, hedgehog faces), so the whole node budget goes into large loops. The analysis adds the even/odd statistic W_odd/W_even, which uses every loop and is far more precise than W_1/W_0 at large R, and jackknife errors over the independent chains.

```bash
sbatch slurm/09_vortex_smoke.sh        # 10 min debug check
sbatch slurm/10_vortex_lock.sh 32      # main run, about 1 h; figures in figures_vlock_L32/
sbatch slurm/11_gribov_check.sh        # optional: gauge fixing from 3 random starts per configuration
sbatch slurm/10_vortex_lock.sh 40      # optional: volume check
```

Local test (L = 12, 2 chains x 30 configurations): W_odd/W_even = -0.504(2), -0.952(10), -1.195(13) at R = 2, 3, 4.

## Three twist mode test (Figure T7)

`vortex_lock_production.py --modes_every 1` adds two constructions of three twist modes: (A) the covariance of the plaquette Pauli vectors on each loop surface, parallel transported to the base point (gauge invariant eigenvalues), and (B) the colour by space matrix at each site (singular values invariant under gauge and spatial rotations). Both are compared with nulls that keep magnitudes and remove alignment. `twist_modes_analysis.py` produces the tables and Figure T7. Local test (L = 12, 24 configurations): no difference from the nulls beyond about 0.002 in the normalized modes; the NERSC run decides. The fraction with det M > 0 is geometric (unchanged under reflection) and is kept only as a check.

## Three mode test at the scale of the lock (Figure T8, job 13)

Job 12 builds the modes from plaquettes, below the scale where the lock forms. Job 10 shows the lock complete from R = 4 on. `locked_modes.py` builds the three modes from the R x R loops themselves: at each site the three loops in the xy, xz and yz planes share the base point, so the singular values of the colour by space matrix of their Pauli vectors, and the mutual products of their axes, are gauge invariant. Both are sorted by vortex parity and compared with a null in which each plane's loop comes from an unrelated site (same magnitude and parity, relative orientation removed). `locked_modes_analysis.py` prints the tables and writes Figure T8.

```bash
sbatch slurm/13_locked_modes.sh        # L = 24; figures in figures_lmodes_L24/
```

Result (L = 24, beta = 2.2): from R = 2 on the populations sit at 0.6924 / 0.2664 / 0.0412, identical to the null. This is the value for three independent Haar random SU(2) holonomies, the state of maximal variance.

## Measured lepton mixing against the SU(2) fixed point (Figure T9, laptop)

`pmns_test.py` (about 1 minute, no NERSC) confirms the fixed point, checks on a small local lattice that real loops reproduce the full per sample distribution (not only its mean), and compares with NuFIT 6.0 (normal ordering):
T1, the electron row |U_e1|^2, |U_e2|^2, |U_e3|^2 against the per sample populations, with the anarchy baselines (Haar U(3) and O(3) rows);
T2, the three mixing angles read from the plane by mode rotation of the same SVD;
T3, the CP phase (a real SO(3) rotation gives 0 or 180 degrees).

```bash
python pmns_test.py                    # figures_pmns/FigT9_pmns_test.png, pmns_test_summary.json
```

## Coupling scan (Figure T10, job 14)

The job 13 measurement at beta = 3.0, 4.0, 5.0 on L = 32 (finer lattice spacing, longer loops). Tests that the populations reach the same fixed point and the lock forms at every coupling once the loops exceed the correlation length.

```bash
sbatch slurm/14_beta_scan.sh 3.0
sbatch slurm/14_beta_scan.sh 4.0
sbatch slurm/14_beta_scan.sh 5.0
"$PY" beta_scan_summary.py             # login node, figures_bscan/FigT10_beta_scan.png
```

## Running on Perlmutter

```bash
cd classical/topology
# 1. edit the account (-A mXXXX) in slurm/*.sh, and CKPT_DIR in 02_checkpoints.sh
sbatch slurm/00_smoke_debug.sh          # 10 min debug job, checks the setup
sbatch slurm/01_ensemble.sh 16          # validation volume, compare with S6
sbatch slurm/01_ensemble.sh 24
sbatch slurm/01_ensemble.sh 32
sbatch slurm/02_checkpoints.sh          # optional: the S6 L = 32 checkpoints
bash   slurm/03_figures.sh              # login node: summaries and figures
```

If a job reaches its time limit it stops cleanly; resubmitting the same line resumes every chain from its checkpoint.

Useful options for `su2_topology_heatbath.py`:
* `--vortex_every N`: center gauge fixing is the most expensive step, so it can run on every Nth configuration only.
* `--rmax`: the largest loop side.
* `--beta`: a β scan; larger β gives longer measurable loops.
* `--wall`: the seconds allowed before a clean stop.

## Laptop run

```bash
python su2_topology_heatbath.py --L 8 --ntherm 100 --nmeas 20 --skip 5 --out runs/L8
mpiexec -n 4 python su2_topology_heatbath.py --L 16 --ntherm 500 --nmeas 100 --skip 10 --out runs/L16
python topology_figures.py runs/L16/summary_topo_L16.json --outdir figures
```

Paper sized figures (larger text): `FIGSCALE=1.55 python topology_figures.py <summaries>`.

Requirements: numpy, scipy and matplotlib; mpi4py is optional (without it the code runs serially).

## Mode correlators (Figure T11, job 15)

The step from the three strata to three masses needs the stiffness of each mode. `mode_correlators.py` measures, for loop sizes R = 1 to 4, the gauge invariant amplitude of each mode (sorted squared singular values of the colour by plane matrix) summed over slices, and `mode_correlators_analysis.py` builds the connected slice correlators and effective masses in units of g^2. All three amplitudes are scalars under the lattice symmetry, so at large separation they are expected to decay with the same lightest scalar mass; differences between the modes are to be looked for within the lock scale, t a g^2 below about 7.

```bash
sbatch slurm/15_mode_correlators.sh 3.0
sbatch slurm/15_mode_correlators.sh 4.0
```

