"""SU(2) gauge fixed Hamiltonian engine for the SU2_Quantum v3 addendum."""
