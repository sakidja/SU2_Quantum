#!/usr/bin/env python3
"""
Quick validation before the campaign (about a minute on a login node).
Reproduces the reference numbers of the v3 runs of 18 Oct 2026 and checks the
exact symmetries. Exits nonzero on any failure.

Part of the SU2_Quantum project (R. Sakidja, Missouri State University).
Code drafted with AI (LLM) assistance (Claude, Anthropic) and reviewed by the author.
"""
import sys
import numpy as np
from su2ham.systems import BUILDERS

G = 4 / 2.2
fails = 0


def check(name, got, ref, tol=2e-5):
    global fails
    ok = abs(got - ref) <= tol
    fails += (not ok)
    print(f"  [{'ok' if ok else 'FAIL'}] {name}: {got:.6f} (reference {ref:.6f})")


def ground(sysm, g2, signs=None):
    w, v = sysm.lowest(g2, signs=signs)
    mom, _ = sysm.plaquette_moments(sysm.state(v[:, 0]))
    return w, mom


print("single plaquette, jmax 3 (independent check: angle grid solver)")
S = BUILDERS["single"](3.0)
w, m = ground(S, G)
check("sum Var(c_k) at beta 2.2", 1 - m[0][1], 0.695177)
check("gap at beta 2.2", w[1] - w[0], 3.274131)

print("open 2x1, jmax 2")
S = BUILDERS["open2x1"](2.0)
w, m = ground(S, G)
check("sum Var(c_k), plaquette 1", 1 - m[0][1], 0.694730)
check("reflection: plaquette 1 minus plaquette 2", m[0][0] - m[1][0], 0.0, 1e-12)
wt, _ = ground(S, G, [-1, 1])
check("open lattice twist cost (exactly zero)", wt[0] - w[0], 0.0, 1e-10)

print("periodic 1x1, jmax 2")
S = BUILDERS["torus1x1"](2.0)
w, _ = ground(S, G)
wt, _ = ground(S, G, [-1])
check("twist energy", wt[0] - w[0], 1.001843)

print("periodic 2x1, jmax 1.5")
S = BUILDERS["torus2x1"](1.5)
w, m = ground(S, G)
wa, _ = ground(S, G, [-1, 1])
wb, _ = ground(S, G, [1, -1])
wd, _ = ground(S, G, [-1, -1])
check("twist energy", wa[0] - w[0], 0.718450, 5e-5)
check("twist on A minus twist on B", wa[0] - wb[0], 0.0, 1e-10)
check("double twist minus untwisted", wd[0] - w[0], 0.0, 1e-10)
check("operator symmetry", S.max_asymmetry, 0.0, 1e-12)

print("periodic 3x1, jmax 1")
S = BUILDERS["torus3x1"](1.0)
w, m = ground(S, G)
w1, _ = ground(S, G, [-1, 1, 1]); w2, _ = ground(S, G, [1, -1, 1]); w3, _ = ground(S, G, [1, 1, -1])
wd, _ = ground(S, G, [-1, -1, 1])
check("translation: plaquette 0 minus plaquette 2", m[0][0] - m[2][0], 0.0, 1e-10)
check("twist on plaquette 0 minus plaquette 2", w1[0] - w3[0], 0.0, 1e-10)
check("double twist minus untwisted", wd[0] - w[0], 0.0, 1e-10)
check("twist energy", w1[0] - w[0], 0.638210, 5e-5)

print("compact engine (engine2) against the original engine")
from su2ham.systems2 import build2
for name, j, tw in [("torus2x1", 1.5, [-1, 1]), ("torus3x1", 1.0, [-1, 1, 1])]:
    wo, _ = BUILDERS[name](j).lowest(G, signs=tw)
    wn, _ = build2(name, j).lowest(G, signs=tw)
    check(f"{name} jmax {j} twisted E0, compact minus original", wn[0] - wo[0], 0.0, 1e-10)

print("periodic 2x2, jmax 0.5 (compact engine)")
S = build2("torus2x2", 0.5)
w, m = ground(S, G)
ws = [ground(S, G, [-1 if i == k else 1 for i in range(4)])[0][0] for k in range(4)]
wd, _ = ground(S, G, [-1, 1, 1, -1])
check("translation: plaquette 00 minus plaquette 11", m[0][0] - m[3][0], 0.0, 1e-10)
check("twist position spread", max(ws) - min(ws), 0.0, 1e-10)
check("double twist minus untwisted", wd[0] - w[0], 0.0, 1e-10)
check("twist energy", ws[0] - w[0], 0.051027, 5e-5)

print("PASSED" if fails == 0 else f"{fails} FAILED")
sys.exit(1 if fails else 0)
