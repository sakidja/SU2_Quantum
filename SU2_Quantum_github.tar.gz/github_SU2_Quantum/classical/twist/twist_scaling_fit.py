#!/usr/bin/env python3
"""
twist_scaling_fit.py

Cross-size analysis for the classical SU(2) twist campaign. Reads the
summary_cl_L{L}.json and results_cl_L{L}.npz files produced by
su2_classical_twist.py for several lattice sizes and produces:

  1. The susceptibility verdict: chi = <sum Q^2>/V against 1/L with the
     combined error bars, a weighted constant fit and a weighted linear
     fit in 1/L, each with its chi^2/dof, and a printed verdict.
  2. The floor table and figure: pooled site-level m*_CTC histograms per
     size on a log scale with the 0.1 percent and 1 percent quantile
     markers, answering whether the lower edge moves with volume.

Usage:
  python3 twist_scaling_fit.py --dirs run_cl_L16 run_cl_L24 run_cl_L32 \
      --out scaling
Outputs: scaling_chi_fit.png, scaling_floor.png, scaling_summary.json
"""

import argparse
import glob
import json
import os

import numpy as np


def load_size(d):
    js = glob.glob(os.path.join(d, "summary_cl_L*.json"))
    nz = glob.glob(os.path.join(d, "results_cl_L*.npz"))
    if not js or not nz:
        raise FileNotFoundError(f"no summary/results files in {d}")
    summary = json.load(open(js[0]))
    results = np.load(nz[0])
    return summary, results


def hist_quantile(counts, edges, q):
    cum = np.cumsum(counts) / max(counts.sum(), 1)
    idx = int(np.searchsorted(cum, q))
    return float(edges[min(idx + 1, len(edges) - 1)])


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--dirs", nargs="+", required=True)
    ap.add_argument("--out", default="scaling")
    args = ap.parse_args()

    sizes = []
    for d in args.dirs:
        s, r = load_size(d)
        sizes.append((s["L"], s, r))
    sizes.sort(key=lambda t: t[0])

    Ls = np.array([t[0] for t in sizes], dtype=float)
    chi = np.array([t[1]["Q_sq_per_cell"] for t in sizes])
    cerr = np.array([t[1]["chi_twist_err"] for t in sizes])
    x = 1.0 / Ls
    w = 1.0 / cerr**2

    # weighted constant fit
    c0 = float(np.sum(w * chi) / np.sum(w))
    chi2_const = float(np.sum(w * (chi - c0) ** 2) / max(len(Ls) - 1, 1))

    # weighted linear fit chi = a + b/L
    A = np.vstack([np.ones_like(x), x]).T
    W = np.diag(w)
    cov = np.linalg.inv(A.T @ W @ A)
    a, b = (cov @ (A.T @ W @ chi)).tolist()
    b_err = float(np.sqrt(cov[1, 1]))
    chi2_lin = float(np.sum(w * (chi - (a + b * x)) ** 2)
                     / max(len(Ls) - 2, 1))
    verdict = ("slope consistent with zero: volume-independent within errors"
               if abs(b) < 2 * b_err else
               "finite-size correction resolved at 2 sigma or better")

    # floor quantiles from pooled histograms
    floor = {}
    for L, s, r in sizes:
        counts, edges = r["mctc_hist_counts"], r["mctc_hist_edges"]
        floor[int(L)] = dict(
            sites=int(counts.sum()),
            q001=hist_quantile(counts, edges, 0.001),
            q01=hist_quantile(counts, edges, 0.01),
        )

    out = dict(
        L=[int(v) for v in Ls], chi=chi.tolist(), chi_err=cerr.tolist(),
        constant_fit=dict(value=c0, chi2_dof=chi2_const),
        linear_fit=dict(intercept=a, slope=b, slope_err=b_err,
                        chi2_dof=chi2_lin),
        verdict=verdict, floor_quantiles=floor,
    )
    with open(f"{args.out}_summary.json", "w") as f:
        json.dump(out, f, indent=2)

    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    # figure 1: chi verdict
    plt.figure(figsize=(6, 4.5))
    plt.errorbar(x, chi, yerr=cerr, fmt="o", capsize=3,
                 label="data (chains combined)")
    xs = np.linspace(0, x.max() * 1.05, 50)
    plt.axhline(c0, ls="--", color="gray",
                label=f"constant {c0:.4f}  (chi2/dof={chi2_const:.2f})")
    plt.plot(xs, a + b * xs, ls=":", color="crimson",
             label=f"linear, slope {b:.4f}+/-{b_err:.4f}  "
                   f"(chi2/dof={chi2_lin:.2f})")
    plt.xlabel("1 / L")
    plt.ylabel("<sum Q^2> / V")
    plt.title("hedgehog susceptibility: constant vs finite-size correction")
    plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(f"{args.out}_chi_fit.png", dpi=200)

    # figure 2: floor histograms
    plt.figure(figsize=(8, 5))
    cmap = plt.cm.viridis(np.linspace(0.1, 0.9, len(sizes)))
    for c, (L, s, r) in zip(cmap, sizes):
        counts, edges = r["mctc_hist_counts"], r["mctc_hist_edges"]
        centers = 0.5 * (edges[1:] + edges[:-1])
        f = floor[int(L)]
        plt.step(centers, np.maximum(counts / counts.sum(), 1e-12),
                 where="mid", color=c,
                 label=f"L={int(L)}  (q0.1%={f['q001']:.3f}, "
                       f"q1%={f['q01']:.3f})")
        plt.axvline(f["q001"], ls="--", color=c, alpha=0.6)
    plt.yscale("log")
    plt.xlim(0, 1.0)
    plt.xlabel("m*_CTC = theta / |div F| (per site)")
    plt.ylabel("fraction")
    plt.title("pooled site-level CTC mass: does the lower edge move "
              "with volume?")
    plt.legend(fontsize=8)
    plt.tight_layout()
    plt.savefig(f"{args.out}_floor.png", dpi=200)

    print(json.dumps(out, indent=2))


if __name__ == "__main__":
    main()
