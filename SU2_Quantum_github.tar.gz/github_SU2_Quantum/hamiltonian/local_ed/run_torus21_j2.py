import json, time
from su2_torus21_ed import build, solve
t=time.time(); S=build(2.0)
print(f"jmax=2: {S['n']} states, gauge {S['Kerr']:.1e}, Casimir {S['cas_err']:.1e}, {time.time()-t:.0f}s", flush=True)
g2s=[1.0,1.5,4/2.2,2.5,3.0,4.0,5.0,8.0]
R=json.load(open("su2_torus21_results.json"))
R["2.0"]={"untwisted":[solve(S,g) for g in g2s],"twisted":[solve(S,g,sA=-1) for g in g2s]}
json.dump(R,open("su2_torus21_results.json","w"),indent=1)
for u,tw in zip(R["2.0"]["untwisted"],R["2.0"]["twisted"]):
    print(f"g2={u['g2']:.3f} dE={tw['E'][0]-u['E'][0]:.5f} SVu={u['sumVar_A']:.4f} SVt={tw['sumVar_A']:.4f} c0u={u['c0_A']:.4f} c0t={tw['c0_B']:.4f}")
