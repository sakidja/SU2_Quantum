#!/usr/bin/env python3
"""
su2_classical_twist.py

Classical SU(2) lattice gauge theory on a 3D L x L x L periodic lattice,
standard Wilson action (real trace only), exact Creutz heat-bath in the
quaternion representation, with twist readout:

  1. CTC-style Frobenius twist density T(x): the transported plaquette
     mismatch, split exactly (SU(2) only) into a c0-gradient part and an
     orientation (twist) part.
  2. Hedgehog charge Q per unit cell: the discrete degree of the plaquette
     Pauli-vector field n_hat = c_vec/|c_vec| over each cell surface
     (solid-angle / Berg-Luscher construction), an integer per cell.
  3. Continuity observables matching the quantum campaign: mean c0,
     Var(c_k), m* = arcsin(|c|)/|c| per plaquette, Delta_weak, min m*.

The Wilson dynamics samples with the real-only weight; every link stores
the complete SU(2) element (unit quaternion). The twist estimators are
readout, not dynamics: same engine, new question.

Conventions match the quantum campaign scripts: argparse CLI, base seed
plus rank seeding under MPI (independent chains per rank), checkpoint
every --checkpoint-every measured configurations, --resume, and outputs
results_cl_L{L}.npz, summary_cl_L{L}.json, twist_cl_L{L}.png.

Example (serial):
  python3 su2_classical_twist.py --L 8 --beta 2.2 --configs 1000 \
      --therm 200 --skip 5 --seed 42 --outdir run_cl_L8

Example (Perlmutter, 32 ranks, independent chains):
  srun -n 32 python3 su2_classical_twist.py --L 24 --beta 2.2 \
      --configs 10000 --therm 500 --skip 10 --seed 42 --outdir run_cl_L24
"""

import argparse
import json
import os
import sys
import time

import numpy as np

# ----------------------------------------------------------------------
# Optional MPI (graceful serial fallback, as in su2_lattice_scaling.py)
# ----------------------------------------------------------------------
try:
    from mpi4py import MPI
    COMM = MPI.COMM_WORLD
    RANK = COMM.Get_rank()
    NRANKS = COMM.Get_size()
except Exception:
    COMM = None
    RANK = 0
    NRANKS = 1


# ----------------------------------------------------------------------
# Quaternion algebra for SU(2):  U = q0 * I + i (q1 sx + q2 sy + q3 sz)
# stored as float64 arrays of shape (..., 4) with q0^2 + |q_vec|^2 = 1.
# ----------------------------------------------------------------------
def qmul(a, b):
    """Quaternion (SU(2)) product, broadcasting over leading axes."""
    a0, av = a[..., 0], a[..., 1:]
    b0, bv = b[..., 0], b[..., 1:]
    out = np.empty(np.broadcast(a, b).shape[:-1] + (4,))
    out[..., 0] = a0 * b0 - np.sum(av * bv, axis=-1)
    out[..., 1:] = (a0[..., None] * bv + b0[..., None] * av
                    - np.cross(av, bv))
    return out


def qdag(a):
    """Hermitian conjugate: (q0, -q_vec)."""
    out = a.copy()
    out[..., 1:] *= -1.0
    return out


def qnorm(a):
    return np.sqrt(np.sum(a * a, axis=-1))


def transport(u, q):
    """Adjoint transport U q U^dagger (leaves q0 fixed, rotates q_vec)."""
    return qmul(u, qmul(q, qdag(u)))


# ----------------------------------------------------------------------
# Lattice: links[mu] has shape (L, L, L, 4), mu in {0,1,2} = x,y,z.
# Periodic boundaries via np.roll. Site parity checkerboard for the
# heat-bath (staples of U_mu(x) never involve same-direction links of
# the same parity).
# ----------------------------------------------------------------------
class SU2Lattice3D:
    def __init__(self, L, beta, rng):
        self.L = L
        self.beta = beta
        self.rng = rng
        self.links = np.zeros((3, L, L, L, 4))
        self.links[..., 0] = 1.0  # cold start: identity links
        xyz = np.indices((L, L, L)).sum(axis=0)
        self.parity = (xyz % 2).astype(bool)

    # -- geometry helpers ------------------------------------------------
    def shift(self, arr, mu, n=1):
        """arr(x) -> arr(x + n mu_hat) with periodic wrap."""
        return np.roll(arr, -n, axis=mu)

    def staples(self, mu):
        """Sum of the 4 staples for every link U_mu(x). Returns (L,L,L,4)."""
        U = self.links
        s = np.zeros((self.L, self.L, self.L, 4))
        for nu in range(3):
            if nu == mu:
                continue
            Unu = U[nu]
            Umu_xnu = self.shift(U[mu], nu)
            Unu_xmu = self.shift(U[nu], mu)
            # forward staple: U_nu(x+mu) U_mu(x+nu)^+ U_nu(x)^+
            s += qmul(Unu_xmu, qmul(qdag(Umu_xnu), qdag(Unu)))
            # backward staple: U_nu(x+mu-nu)^+ U_mu(x-nu)^+ U_nu(x-nu)
            Unu_b = self.shift(Unu, nu, -1)
            Umu_b = self.shift(U[mu], nu, -1)
            Unu_bm = self.shift(Unu_b, mu)
            s += qmul(qdag(Unu_bm), qmul(qdag(Umu_b), Unu_b))
        return s

    # -- exact Creutz heat-bath -----------------------------------------
    def _sample_w0(self, alpha):
        """Creutz sampling of w0 in [-1,1], P(w0) ~ sqrt(1-w0^2) e^{alpha w0}.
        alpha = beta * k > 0 elementwise. Vectorized accept/reject."""
        w0 = np.empty_like(alpha)
        todo = np.ones(alpha.shape, dtype=bool)
        lo = np.exp(-2.0 * alpha)
        while todo.any():
            a = alpha[todo]
            z = self.rng.uniform(lo[todo], 1.0)
            trial = 1.0 + np.log(z) / a
            acc = self.rng.uniform(size=a.shape) < np.sqrt(
                np.clip(1.0 - trial * trial, 0.0, 1.0))
            idx = np.flatnonzero(todo.ravel())
            keep = idx[acc]
            w0.ravel()[keep] = trial[acc]
            t = todo.ravel()
            t[keep] = False
            todo = t.reshape(alpha.shape)
        return w0

    def heatbath_sweep(self):
        """One full sweep: both parities, all three directions."""
        for mu in range(3):
            for par in (False, True):
                mask = self.parity == par
                R = self.staples(mu)
                k = qnorm(R)
                k = np.where(k < 1e-14, 1e-14, k)
                V = R / k[..., None]
                alpha = self.beta * k
                w0 = self._sample_w0(alpha[mask])
                # random direction on the 2-sphere for w_vec
                n = self.rng.normal(size=w0.shape + (3,))
                n /= np.linalg.norm(n, axis=-1, keepdims=True)
                w = np.empty(w0.shape + (4,))
                w[..., 0] = w0
                w[..., 1:] = np.sqrt(np.clip(1 - w0 * w0, 0, 1))[..., None] * n
                Unew = qmul(w, qdag(V[mask]))
                Unew /= qnorm(Unew)[..., None]  # renormalize drift
                self.links[mu][mask] = Unew

    # -- plaquettes ------------------------------------------------------
    def plaquettes(self):
        """All three plaquette orientations. Returns (3, L, L, L, 4):
        index p = 0,1,2 for planes (x,y), (y,z), (z,x)."""
        U = self.links
        planes = [(0, 1), (1, 2), (2, 0)]
        P = np.empty((3, self.L, self.L, self.L, 4))
        for p, (mu, nu) in enumerate(planes):
            a = U[mu]
            b = self.shift(U[nu], mu)
            c = qdag(self.shift(U[mu], nu))
            d = qdag(U[nu])
            P[p] = qmul(a, qmul(b, qmul(c, d)))
        return P

    # -- twist readout ---------------------------------------------------
    def twist_density(self, P):
        """CTC-style Frobenius transported mismatch, per site, summed over
        the 3 plaquette planes and the 3 transport directions rho:

          T(x) = sum_p sum_rho || P_p(x) - U_rho(x) P_p(x+rho) U_rho(x)^+ ||_F^2

        For SU(2) the chordal norm splits exactly:
          ||A - B||_F^2 = 2 [ (a0-b0)^2 + |a_vec - b_vec|^2 ].
        Returns (T_total, T_c0, T_orient), each of shape (L, L, L)."""
        T_c0 = np.zeros((self.L, self.L, self.L))
        T_or = np.zeros((self.L, self.L, self.L))
        for p in range(3):
            for rho in range(3):
                Pn = self.shift(P[p], rho)              # P_p(x + rho)
                Pt = transport(self.links[rho], Pn)     # transported back to x
                d0 = P[p][..., 0] - Pt[..., 0]
                dv = P[p][..., 1:] - Pt[..., 1:]
                T_c0 += 2.0 * d0 * d0
                T_or += 2.0 * np.sum(dv * dv, axis=-1)
        return T_c0 + T_or, T_c0, T_or

    def ctc_mass_field(self, P, eps=1e-12):
        """CTC mass estimator, local: m*_CTC(x) = theta(x) / |div F(x)|.

        theta(x): local curvature, summed over the 3 plaquette planes,
        theta_p = 2 arcsin(|c_vec_p|) (the SU(2) plaquette rotation angle).
        |div F(x)|: the SU(3) Paper I transport estimator verbatim,
        unsquared Frobenius norm of the transported plaquette mismatch,
          |div F(x)| = sum_p sum_rho || P_p(x) - U_rho(x) P_p(x+rho) U_rho^+(x) ||_F
        which for SU(2) is the chordal distance on S^3.
        Returns (theta, divF, m_ctc), each (L, L, L); m_ctc is inf where
        divF < eps (perfectly transported curvature)."""
        c0 = np.clip(P[..., 0], -1.0, 1.0)
        cabs = np.sqrt(np.clip(1.0 - c0 * c0, 0.0, 1.0))
        theta = np.sum(2.0 * np.arcsin(np.clip(cabs, 0.0, 1.0)), axis=0)
        divF = np.zeros_like(theta)
        for p in range(3):
            for rho in range(3):
                Pn = self.shift(P[p], rho)
                Pt = transport(self.links[rho], Pn)
                d = P[p] - Pt
                divF += np.sqrt(2.0 * np.sum(d * d, axis=-1))
        mask = divF > eps
        m_ctc = np.where(mask, theta / np.where(mask, divF, 1.0), np.inf)
        return theta, divF, m_ctc

    def hedgehog_charges(self, P, eps=1e-12):
        """Discrete degree of n_hat = c_vec/|c_vec| over each unit cell.

        Site Pauli vector: c_vec(x) = sum over the 3 plaquette planes of the
        plaquette Pauli vector at x (execution choice; see paper notes).
        Each unit cell surface (8 corner sites) is triangulated into 12
        triangles with outward orientation; the signed solid angle of each
        spherical triangle (n1, n2, n3) uses the Oosterom-Strackee formula
          tan(Omega/2) = n1.(n2 x n3) / (1 + n1.n2 + n2.n3 + n3.n1)
        and Q_cell = (sum Omega) / (4 pi), rounded to the nearest integer.
        Returns integer array of shape (L, L, L)."""
        cv = P[..., 1:].sum(axis=0)                     # (L,L,L,3)
        norm = np.linalg.norm(cv, axis=-1, keepdims=True)
        n = cv / np.where(norm < eps, eps, norm)

        # gather the 8 corners of every cell
        c = {}
        for dx in (0, 1):
            for dy in (0, 1):
                for dz in (0, 1):
                    c[(dx, dy, dz)] = np.roll(
                        np.roll(np.roll(n, -dx, 0), -dy, 1), -dz, 2)

        # 6 faces, each split into 2 triangles, outward-oriented
        faces = [
            # (corner indices), outward normal direction
            ([(1, 0, 0), (1, 1, 0), (1, 1, 1), (1, 0, 1)]),   # +x
            ([(0, 0, 0), (0, 0, 1), (0, 1, 1), (0, 1, 0)]),   # -x
            ([(0, 1, 0), (0, 1, 1), (1, 1, 1), (1, 1, 0)]),   # +y
            ([(0, 0, 0), (1, 0, 0), (1, 0, 1), (0, 0, 1)]),   # -y
            ([(0, 0, 1), (1, 0, 1), (1, 1, 1), (0, 1, 1)]),   # +z
            ([(0, 0, 0), (0, 1, 0), (1, 1, 0), (1, 0, 0)]),   # -z
        ]

        def solid_angle(n1, n2, n3):
            num = np.sum(n1 * np.cross(n2, n3), axis=-1)
            den = (1.0 + np.sum(n1 * n2, axis=-1)
                   + np.sum(n2 * n3, axis=-1)
                   + np.sum(n3 * n1, axis=-1))
            return 2.0 * np.arctan2(num, den)

        omega = np.zeros(n.shape[:-1])
        for quad in faces:
            v0, v1, v2, v3 = (c[q] for q in quad)
            omega += solid_angle(v0, v1, v2)
            omega += solid_angle(v0, v2, v3)
        return np.rint(omega / (4.0 * np.pi)).astype(np.int64)

    # -- continuity observables (match the quantum campaign) -------------
    @staticmethod
    def mass_estimator(P):
        """m* = arcsin(|c|)/|c| per plaquette, |c|^2 = 1 - c0^2."""
        c0 = np.clip(P[..., 0], -1.0, 1.0)
        cabs = np.sqrt(np.clip(1.0 - c0 * c0, 0.0, 1.0))
        small = cabs < 1e-8
        m = np.where(small, 1.0 + cabs * cabs / 6.0,
                     np.arcsin(np.clip(cabs, 0, 1)) / np.where(small, 1, cabs))
        return m


# ----------------------------------------------------------------------
# Measurement of one configuration -> dict of scalars
# ----------------------------------------------------------------------
def measure(lat, return_sites=False):
    P = lat.plaquettes()
    c0 = P[..., 0]
    ck = P[..., 1:]
    T, T_c0, T_or = lat.twist_density(P)
    Q = lat.hedgehog_charges(P)
    m = lat.mass_estimator(P)
    theta, divF, m_ctc = lat.ctc_mass_field(P)
    mc = m_ctc[np.isfinite(m_ctc)]
    out = dict(
        mean_c0=float(c0.mean()),
        var_ck=float(np.sum(ck.var(axis=(0, 1, 2, 3)))),
        c0_sq_mean=float((c0 * c0).mean()),
        delta_mean=float(m.mean()),
        delta_min=float(m.min()),
        T_mean=float(T.mean()),
        T_c0_mean=float(T_c0.mean()),
        T_orient_mean=float(T_or.mean()),
        Q_sq_sum=int(np.sum(Q * Q)),
        Q_abs_sum=int(np.sum(np.abs(Q))),
        n_charged=int(np.count_nonzero(Q)),
        theta_mean=float(theta.mean()),
        divF_mean=float(divF.mean()),
        m_ctc_mean=float(mc.mean()),
        m_ctc_median=float(np.median(mc)),
        m_ctc_min=float(mc.min()),
        m_ctc_q001=float(np.quantile(mc, 0.001)),
        m_ctc_q01=float(np.quantile(mc, 0.01)),
    )
    if return_sites:
        return out, mc
    return out


FIELDS = ["mean_c0", "var_ck", "c0_sq_mean", "delta_mean", "delta_min",
          "T_mean", "T_c0_mean", "T_orient_mean",
          "Q_sq_sum", "Q_abs_sum", "n_charged",
          "theta_mean", "divF_mean", "m_ctc_mean", "m_ctc_median",
          "m_ctc_min", "m_ctc_q001", "m_ctc_q01"]

HIST_EDGES = np.linspace(0.0, 2.0, 2001)  # pooled site-level m*_CTC histogram bins (fine, for tail quantiles)



def tau_int(series):
    """Integrated autocorrelation time (sum of rho(t) to first negative)."""
    x = np.asarray(series, dtype=float)
    x = x - x.mean()
    if x.size < 8 or x.std() == 0:
        return 1.0
    tau = 1.0
    var = np.mean(x * x)
    for t in range(1, x.size // 2):
        rho = np.mean(x[:-t] * x[t:]) / var
        if rho <= 0:
            break
        tau += 2.0 * rho
    return float(tau)


# ----------------------------------------------------------------------
# Checkpointing (per rank), mirroring the Perlmutter scripts
# ----------------------------------------------------------------------
def ckpt_path(outdir, L, rank):
    return os.path.join(outdir, f"ckpt_cl_L{L}_rank{rank}.npz")


def save_ckpt(outdir, L, rank, lat, rng, rows, sweeps_done, save_cfgs,
              cfgs, hist):
    state = rng.bit_generator.state
    np.savez_compressed(
        ckpt_path(outdir, L, rank),
        links=lat.links, rows=np.array(rows), sweeps_done=sweeps_done,
        rng_state=json.dumps(state), hist=hist,
        configs=np.array(cfgs) if save_cfgs and cfgs else np.zeros(0))


def load_ckpt(outdir, L, rank, lat, rng):
    p = ckpt_path(outdir, L, rank)
    if not os.path.exists(p):
        return None
    d = np.load(p, allow_pickle=False)
    lat.links = d["links"]
    rng.bit_generator.state = json.loads(str(d["rng_state"]))
    rows = [list(r) for r in d["rows"]] if d["rows"].size else []
    cfgs = [c for c in d["configs"]] if d["configs"].size else []
    hist = d["hist"] if "hist" in d.files else np.zeros(len(HIST_EDGES) - 1)
    return rows, int(d["sweeps_done"]), cfgs, hist


# ----------------------------------------------------------------------
# Main driver
# ----------------------------------------------------------------------
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--L", type=int, required=True)
    ap.add_argument("--beta", type=float, default=2.2)
    ap.add_argument("--configs", type=int, default=1000,
                    help="measured configurations (total across ranks)")
    ap.add_argument("--therm", type=int, default=200,
                    help="thermalization sweeps before first measurement")
    ap.add_argument("--skip", type=int, default=5,
                    help="sweeps between measurements")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--outdir", type=str, default="run_cl")
    ap.add_argument("--checkpoint-every", type=int, default=50)
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--save-configs", action="store_true",
                    help="store the full quaternion link fields per "
                         "measurement (large; enables re-reading later)")
    args = ap.parse_args()

    os.makedirs(args.outdir, exist_ok=True)
    my_configs = args.configs // NRANKS + (1 if RANK < args.configs % NRANKS
                                           else 0)
    rng = np.random.default_rng(args.seed + RANK)
    lat = SU2Lattice3D(args.L, args.beta, rng)

    rows, sweeps_done, cfgs = [], 0, []
    hist = np.zeros(len(HIST_EDGES) - 1)
    if args.resume:
        got = load_ckpt(args.outdir, args.L, RANK, lat, rng)
        if got is not None:
            rows, sweeps_done, cfgs, hist = got
            if RANK == 0:
                print(f"[resume] rank 0 restored at {len(rows)} configs",
                      flush=True)

    t0 = time.time()
    if sweeps_done == 0 and not rows:
        for _ in range(args.therm):
            lat.heatbath_sweep()
        sweeps_done = args.therm

    while len(rows) < my_configs:
        for _ in range(args.skip):
            lat.heatbath_sweep()
        sweeps_done += args.skip
        m, mc_sites = measure(lat, return_sites=True)
        rows.append([m[f] for f in FIELDS])
        hist += np.histogram(mc_sites, bins=HIST_EDGES)[0]
        if args.save_configs:
            cfgs.append(lat.links.copy())
        if len(rows) % args.checkpoint_every == 0:
            save_ckpt(args.outdir, args.L, RANK, lat, rng, rows,
                      sweeps_done, args.save_configs, cfgs, hist)
            if RANK == 0:
                print(f"[ckpt] {len(rows)}/{my_configs} configs, "
                      f"{time.time()-t0:.0f}s", flush=True)
    save_ckpt(args.outdir, args.L, RANK, lat, rng, rows, sweeps_done,
              args.save_configs, cfgs, hist)

    # ---- gather across ranks (each rank is an independent chain) ----
    local = np.array(rows)
    tau_q = tau_int([r[FIELDS.index("Q_sq_sum")] for r in rows])
    if COMM is not None and NRANKS > 1:
        total_hist = np.zeros_like(hist)
        COMM.Reduce(hist, total_hist, root=0)
        gathered = COMM.gather(local, root=0)
        taus = COMM.gather(tau_q, root=0)
        if RANK != 0:
            return
        data = np.concatenate(gathered, axis=0)
        hist = total_hist
        iq = FIELDS.index("Q_sq_sum")
        chain_chi_means = np.array([g[:, iq].mean() for g in gathered
                                    if g.shape[0] > 0])
    else:
        data = local
        taus = [tau_q]
        chain_chi_means = np.array([local[:, FIELDS.index("Q_sq_sum")].mean()])

    # ---- rank 0: write results, summary, figure ----
    cols = {f: data[:, i] for i, f in enumerate(FIELDS)}
    L = args.L
    ncells = L ** 3
    np.savez(os.path.join(args.outdir, f"results_cl_L{L}.npz"),
             mctc_hist_counts=hist, mctc_hist_edges=HIST_EDGES, **cols)

    def pooled_quantile(q):
        cum = np.cumsum(hist) / max(hist.sum(), 1)
        idx = int(np.searchsorted(cum, q))
        return float(HIST_EDGES[min(idx + 1, len(HIST_EDGES) - 1)])

    chi_twist = float(np.mean(cols["Q_sq_sum"]) / ncells)
    summary = dict(
        L=L, beta=args.beta, n_configs=int(data.shape[0]),
        therm=args.therm, skip=args.skip, seed=args.seed, ranks=NRANKS,
        action="Wilson real-trace only (heat-bath: exact Creutz)",
        mean_c0=[float(cols["mean_c0"].mean()), float(cols["mean_c0"].std())],
        var_ck=[float(cols["var_ck"].mean()), float(cols["var_ck"].std())],
        delta_weak=[float(cols["delta_mean"].mean()),
                    float(cols["delta_mean"].std())],
        delta_min=float(cols["delta_min"].min()),
        T_mean=[float(cols["T_mean"].mean()), float(cols["T_mean"].std())],
        T_orient_fraction=float(cols["T_orient_mean"].mean()
                                / max(cols["T_mean"].mean(), 1e-30)),
        Q_sq_per_cell=chi_twist,
        m_ctc_median=[float(cols["m_ctc_median"].mean()),
                      float(cols["m_ctc_median"].std())],
        m_ctc_min=float(cols["m_ctc_min"].min()),
        m_ctc_q001_pooled=pooled_quantile(0.001),
        m_ctc_q01_pooled=pooled_quantile(0.01),
        m_ctc_q001_perconfig=[float(cols["m_ctc_q001"].mean()),
                              float(cols["m_ctc_q001"].std())],
        chi_twist_err_internal=float(cols["Q_sq_sum"].std()
                                     / np.sqrt(max(data.shape[0], 1))) / ncells,
        chi_twist_err_external=(float(chain_chi_means.std(ddof=1)
                                      / np.sqrt(len(chain_chi_means))) / ncells
                                if len(chain_chi_means) > 1 else None),
        chi_twist_err=float(max(
            cols["Q_sq_sum"].std() / np.sqrt(max(data.shape[0], 1)),
            (chain_chi_means.std(ddof=1) / np.sqrt(len(chain_chi_means))
             if len(chain_chi_means) > 1 else 0.0))) / ncells,
        tau_int_Qsq_mean=float(np.mean(taus)),
        tau_int_Qsq_max=float(np.max(taus)),
        Q_abs_per_cell=float(np.mean(cols["Q_abs_sum"]) / ncells),
        charged_cell_fraction=float(np.mean(cols["n_charged"]) / ncells),
        wall_seconds=time.time() - t0,
    )
    with open(os.path.join(args.outdir, f"summary_cl_L{L}.json"), "w") as f:
        json.dump(summary, f, indent=2)

    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, ax = plt.subplots(2, 3, figsize=(15, 8.4))
        ax = ax.ravel()
        fig.suptitle(f"SU(2) classical Wilson sampling, L={L} (3D), "
                     f"beta={args.beta}, {data.shape[0]} configs")
        ax[0].hist(cols["T_orient_mean"], bins=40, color="#8e5572",
                   alpha=0.85)
        ax[0].set_title("orientation (twist) part of T(x), config mean")
        ax[0].set_xlabel("T_orient per site")
        ax[1].hist(cols["Q_sq_sum"] / ncells, bins=40, color="#4b7f9f",
                   alpha=0.85)
        ax[1].set_title("hedgehog charge density  sum Q^2 / V")
        ax[1].set_xlabel("Q^2 per cell")
        ax[2].hist(cols["delta_mean"], bins=40, color="#7a9f4b", alpha=0.85)
        ax[2].axvline(1.0, ls="--", color="k")
        ax[2].set_title("geometric floor  Delta_weak")
        ax[2].set_xlabel("m* (lattice units)")
        ax[3].hist(cols["m_ctc_median"], bins=40, color="#b8860b", alpha=0.85)
        ax[3].set_title("CTC mass  m*_CTC = theta / |div F|  (config median)")
        ax[3].set_xlabel("m*_CTC")
        centers = 0.5 * (HIST_EDGES[1:] + HIST_EDGES[:-1])
        ax[4].step(centers, np.maximum(hist, 0.5), where="mid",
                   color="#5b3a8e")
        ax[4].set_yscale("log")
        for q, ls in [(0.001, "--"), (0.01, ":")]:
            ax[4].axvline(pooled_quantile(q), ls=ls, color="k",
                          label=f"q={100*q:g}%")
        ax[4].legend()
        ax[4].set_title("pooled site-level m*_CTC (all sites, all configs)")
        ax[4].set_xlabel("m*_CTC")
        ax[5].axis("off")
        for a in ax[:5]:
            a.set_ylabel("frequency")
        fig.tight_layout()
        fig.savefig(os.path.join(args.outdir, f"twist_cl_L{L}.png"), dpi=200)
    except Exception as e:  # figure is best-effort on compute nodes
        print(f"[warn] figure not written: {e}", flush=True)

    print(json.dumps(summary, indent=2))


if __name__ == "__main__":
    main()
