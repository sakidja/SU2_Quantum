#!/bin/bash -l
# Finer coupling: 4D SU(2) at beta = 2.6 on a 32^4 lattice, 128 independent chains on 2 nodes.
# Memory: about 5.6 GB per chain at 32^4 with loops to R = 12, so 64 chains per node (about 360 GB of 512 GB).
# Submit from inside slurm/:
#   sbatch 27_4d_fine.sh                      (defaults: L = 32, beta = 2.6, RMAX = 12, NMEAS = 20)
# Expect several 6 h jobs; the run stops cleanly before the limit and resumes from its checkpoint,
# so resubmit the same line until check_status.py shows it complete.
#SBATCH -A mXXXX                  # <-- your NERSC project
#SBATCH -C cpu
#SBATCH -q regular
#SBATCH -N 2
#SBATCH -t 06:00:00
#SBATCH -J su2_4d_fine
#SBATCH -o %x_%j.out
L=${1:-32}; BETA=${2:-2.6}; RMAX=${3:-12}; NMEAS=${4:-20}
cd "$SLURM_SUBMIT_DIR/.."
source slurm/env_perlmutter.sh
srun -N 2 -n 128 --ntasks-per-node=64 -c 4 --cpu-bind=cores "$PY" su2_4d_production.py \
     --L $L --beta $BETA --ntherm 400 --nmeas $NMEAS --skip 10 --rmax $RMAX --rmodes 6 \
     --out runs/L${L}_b${BETA} --wall $(( 6*3600 - 5400 )) --ckpt_every 1
FIGSCALE=1.55 "$PY" su2_4d_analysis.py runs/L${L}_b${BETA} --outdir figures_4d_L${L}_b${BETA}
