#!/bin/bash
# Login node, after the potential runs (24) and the lock runs (21): one scale for every
# coupling, then the lock profile in units of 1/sqrt(sigma) with that scale.
#   bash slurm/25_4d_scale_and_profile.sh
cd "$(dirname "$0")/.."
source slurm/env_perlmutter.sh
FIGSCALE=1.55 "$PY" su2_4d_potential_analysis.py runs/pot_L16_b2.2 runs/pot_L16_b2.3 runs/pot_L16_b2.4 runs/pot_L20_b2.5 \
     --outdir figures_4d_potential | tee figures_4d_potential.log
ASIG=$(grep -- '--asig' figures_4d_potential.log | sed 's/.*--asig //')
echo "scale used: $ASIG"
FIGSCALE=1.55 "$PY" su2_4d_analysis.py runs/L16_b2.2 runs/L20_b2.3 runs/L16_b2.4 runs/L20_b2.5 \
     --asig $ASIG --outdir figures_4d_bscan_multihit
