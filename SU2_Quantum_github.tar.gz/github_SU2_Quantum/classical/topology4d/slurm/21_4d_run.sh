#!/bin/bash -l
# One 4D production run: 128 independent chains on one CPU node.
#   sbatch slurm/21_4d_run.sh L BETA RMAX NMEAS
#   sbatch slurm/21_4d_run.sh 16 2.3 8 60      main run            (about 2 h)
#   sbatch slurm/21_4d_run.sh 20 2.3 8 40      volume check        (about 3 h)
#   sbatch slurm/21_4d_run.sh 16 2.2 8 60      coupling scan       (about 2 h)
#   sbatch slurm/21_4d_run.sh 16 2.4 8 60      coupling scan       (about 2 h)
#   sbatch slurm/21_4d_run.sh 20 2.5 10 40     finest coupling     (about 3.5 h)
# The job stops cleanly before its time limit; resubmit the same line to resume.
#SBATCH -A mXXXX                  # <-- your NERSC project
#SBATCH -C cpu
#SBATCH -q regular
#SBATCH -N 1
#SBATCH -t 06:00:00
#SBATCH -J su2_4d
#SBATCH -o %x_%j.out
L=${1:-16}; BETA=${2:-2.3}; RMAX=${3:-8}; NMEAS=${4:-60}
cd "$SLURM_SUBMIT_DIR/.."
source slurm/env_perlmutter.sh
srun -n 128 -c 2 --cpu-bind=cores "$PY" su2_4d_production.py \
     --L $L --beta $BETA --ntherm 300 --nmeas $NMEAS --skip 10 --rmax $RMAX \
     --out runs/L${L}_b${BETA} --wall $(( 6*3600 - 1200 ))
FIGSCALE=1.55 "$PY" su2_4d_analysis.py runs/L${L}_b${BETA} --outdir figures_4d_L${L}_b${BETA}
