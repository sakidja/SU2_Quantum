#!/usr/bin/env python3
"""
su2_4d_mode_masses_analysis.py
Floor and stiffness of each twist mode from su2_4d_mode_masses.py runs.

  python su2_4d_mode_masses_analysis.py runs/mm_L16_b2.4 [--asig 0.289] [--tfit 1] [--level -1]

For every smearing level and loop side R, with jackknife errors over chains:
  floor       <e_i> (population) and <lam_i> (variance of mode i); the populations
              of the paper are the unsmeared level 0 values;
  correlator  C_i(dt) = <O_i(t) O_i(t+dt)> - <O_i>^2, the part that returns to the floor;
  mass        effective mass m_i(dt) from C_i(dt)/C_i(dt+1) (cosh form, periodic time),
              for lam1, lam2, lam3 and the plain loop w (reference 0++ channel);
  GEVP        eigen masses of the 4 x 4 correlator matrix {lam1, lam2, lam3, w}: whether
              the three modes carry distinct energies or one common one;
  harmonic    at dt = --tfit: m_i * e_i and m_i^2 * e_i across the three modes (constant
              product: omega proportional to 1/lambda, or kappa proportional to 1/lambda),
              and the splitting ratio (m3^2 - m1^2)/(m2^2 - m1^2), measured 33.

Writes mode_masses_summary.json and FigMM_mode_masses.png in --outdir.
"""
import argparse
import glob
import json
import os
import re
import warnings

import numpy as np
from scipy.linalg import eigh
from scipy.optimize import brentq
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

warnings.simplefilter('ignore', RuntimeWarning)
FS = float(os.environ.get('FIGSCALE', '1'))
plt.rcParams.update({'font.size': 11 * FS, 'axes.spines.top': False, 'axes.spines.right': False})
MODE_COL = ['#2a78d6', '#eb6834', '#1baf7a']
INK2 = '#52514e'
FIXED = [0.692, 0.266, 0.041]
BASIS = [0, 1, 2, 6]                  # lam1, lam2, lam3, w


def load(d):
    files = sorted(glob.glob(os.path.join(d, 'mm_L*_b*_rank*.npz')),
                   key=lambda p: int(re.search(r'rank(\d+)', p).group(1)))
    ch, meta = [], None
    for p in files:
        if p.endswith('.tmp.npz'):
            continue
        z = np.load(p, allow_pickle=False)
        if len(z['obs']) == 0:
            continue
        meta = json.loads(str(z['meta'])); ch.append(z['obs'])
    if len(ch) == 1:
        ch = [ch[0][i] for i in np.array_split(np.arange(len(ch[0])), min(10, len(ch[0])))]
    return ch, meta


def chain_sums(O, T):
    """O: (n, op, L). Sums over configs of means m_i and products c_ij(dt), dt = 0..T."""
    m = O.mean(-1)                                             # (n, op)
    c = np.stack([np.einsum('nit,njt->ij', O, np.roll(O, -dt, axis=-1)) / O.shape[-1] for dt in range(T + 1)])
    return m.sum(0), c, len(O)                                 # c: (T+1, op, op)


def corr(ms, cs, n):
    mean = ms / n
    C = cs / n - np.outer(mean, mean)[None]
    return mean, 0.5 * (C + np.transpose(C, (0, 2, 1)))


def meff_cosh(C, L):
    out = np.full(len(C) - 1, np.nan)
    for t in range(len(C) - 1):
        if C[t] <= 0 or C[t + 1] <= 0 or C[t] / C[t + 1] <= 1:
            continue
        r = C[t] / C[t + 1]
        f = lambda m: np.cosh(m * (L / 2 - t)) / np.cosh(m * (L / 2 - t - 1)) - r
        try:
            out[t] = brentq(f, 1e-8, 20)
        except ValueError:
            pass
    return out


def gevp_masses(C, t0=0):
    out = np.full((len(C) - 1, C.shape[1]), np.nan)
    try:
        lam = np.array([eigh(C[t], C[t0], eigvals_only=True)[::-1] for t in range(len(C))])
    except Exception:
        return out
    with np.errstate(invalid='ignore', divide='ignore'):
        out = np.log(lam[:-1] / lam[1:])
    return out


def analyse(ch, L, tfit):
    """Returns dict of estimates and jackknife errors for one (level, R) slice: ch list of (n, op, L)."""
    T = L // 2
    S = [chain_sums(O, T) for O in ch]
    tot = [sum(s[k] for s in S) for k in range(3)]

    def est(ms, cs, n):
        mean, C = corr(ms, cs, n)
        diag = np.stack([C[:, i, i] for i in range(C.shape[1])], 1)          # (T+1, op)
        me = np.stack([meff_cosh(diag[:, i], L) for i in range(diag.shape[1])], 1)
        Cb = C[:, BASIS][:, :, BASIS]
        g = gevp_masses(Cb)
        m_t = me[tfit, :3]; e = mean[3:6]
        with np.errstate(invalid='ignore'):
            ratio = (m_t[2] ** 2 - m_t[0] ** 2) / (m_t[1] ** 2 - m_t[0] ** 2)
        return dict(mean=mean, Cn=diag / diag[:1], meff=me, gevp=g,
                    prod1=m_t * e, prod2=m_t ** 2 * e, ratio=np.array([ratio]))

    full = est(*tot)
    nj = len(S)
    jk = [est(tot[0] - s[0], tot[1] - s[1], tot[2] - s[2]) for s in S]
    err = {k: np.sqrt((nj - 1) / nj * np.nansum((np.array([j[k] for j in jk]) - np.nanmean([j[k] for j in jk], 0)) ** 2, 0))
           for k in full}
    return full, err, int(tot[2])


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('rundir')
    ap.add_argument('--asig', type=float, default=0, help='a sqrt(sigma) for physical units')
    ap.add_argument('--tfit', type=int, default=1, help='time separation at which masses are read')
    ap.add_argument('--level', type=int, default=-1, help='smearing level index for masses (default: most smeared)')
    ap.add_argument('--outdir', default='')
    a = ap.parse_args()
    ch, meta = load(a.rundir)
    L, beta, rlist, ape = meta['L'], meta['beta'], meta['rlist'], meta['ape']
    outdir = a.outdir or f'figures_4d_mode_masses_L{L}_b{beta}'
    os.makedirs(outdir, exist_ok=True)
    lv = a.level % len(ape)
    res = dict(L=L, beta=beta, rlist=rlist, ape=ape, alpha=meta['alpha'], tfit=a.tfit, level_for_masses=ape[lv],
               asig=a.asig or None, n_chains=len(ch), results={})
    tab = {}
    for il in range(len(ape)):
        for k, R in enumerate(rlist):
            full, err, n = analyse([O[:, il, k] for O in ch], L, a.tfit)
            tab[(il, R)] = (full, err)
            res['n_configs'] = n
            res['results'][f'ape{ape[il]}_R{R}'] = {
                'populations': [[float(full['mean'][3 + i]), float(err['mean'][3 + i])] for i in range(3)],
                'lam': [[float(full['mean'][i]), float(err['mean'][i])] for i in range(3)],
                'meff': {OP: [[float(x), float(y)] for x, y in zip(full['meff'][:, j], err['meff'][:, j])]
                         for j, OP in enumerate(meta['ops'])},
                'gevp': [[[float(x), float(y)] for x, y in zip(full['gevp'][t], err['gevp'][t])]
                         for t in range(len(full['gevp']))],
                'm_times_e': [[float(x), float(y)] for x, y in zip(full['prod1'], err['prod1'])],
                'm2_times_e': [[float(x), float(y)] for x, y in zip(full['prod2'], err['prod2'])],
                'splitting_ratio': [float(full['ratio'][0]), float(err['ratio'][0])]}

    u = a.asig or 1.0
    unit = r'$/\sqrt{\sigma}$' if a.asig else ' (lattice units)'
    print(f'beta {beta}  L {L}  {res["n_configs"]} configs, {len(ch)} chains, masses at dt = {a.tfit}, '
          f'APE level {ape[lv]}' + (f', a sqrt(sigma) = {a.asig}' if a.asig else ''))
    for R in rlist:
        f0, e0 = tab[(0, R)]; f, e = tab[(lv, R)]
        print(f'\n R = {R}')
        print('  populations (unsmeared): ' + '  '.join(f'{f0["mean"][3+i]:.4f}({e0["mean"][3+i]:.4f})' for i in range(3)))
        for j, nm in enumerate(['mode 1', 'mode 2', 'mode 3', None, None, None, 'loop w']):
            if nm is None:
                continue
            print(f'  m_eff {nm}: ' + ' '.join(f'{f["meff"][t, j]/u:.3f}({e["meff"][t, j]/u:.3f})'
                                                   for t in range(min(4, len(f['meff'])))))
        print('  GEVP masses dt=' + str(a.tfit) + ': ' + ' '.join(f'{f["gevp"][a.tfit, n]/u:.3f}({e["gevp"][a.tfit, n]/u:.3f})'
                                                               for n in range(4)))
        print('  m_i e_i:   ' + ' '.join(f'{x:.4f}({y:.4f})' for x, y in zip(f['prod1'], e['prod1'])))
        print('  m_i^2 e_i: ' + ' '.join(f'{x:.4f}({y:.4f})' for x, y in zip(f['prod2'], e['prod2'])))
        print(f'  (m3^2 - m1^2)/(m2^2 - m1^2) = {f["ratio"][0]:.2f} +/- {e["ratio"][0]:.2f}   (measured 33)')

    # figure
    fig, ax = plt.subplots(2, 2, figsize=(13, 9.5))
    Rs = np.array(rlist)
    for i in range(3):
        y = [tab[(0, R)][0]['mean'][3 + i] for R in rlist]; ye = [tab[(0, R)][1]['mean'][3 + i] for R in rlist]
        ax[0, 0].errorbar(Rs, y, yerr=ye, fmt='o-', color=MODE_COL[i], capsize=3, label=f'mode {i+1}')
        ax[0, 0].axhline(FIXED[i], color=INK2, ls='--', lw=0.8)
    ax[0, 0].set_xlabel('loop side R'); ax[0, 0].set_ylabel('population (unsmeared)')
    ax[0, 0].set_title('(a) the floor: populations of the three modes'); ax[0, 0].legend(fontsize=9 * FS)
    Rsel = rlist[-1] if len(rlist) < 3 else rlist[len(rlist) // 2]
    f, e = tab[(lv, Rsel)]
    dt = np.arange(len(f['Cn']))
    for j, (nm, col) in enumerate([('mode 1', MODE_COL[0]), ('mode 2', MODE_COL[1]), ('mode 3', MODE_COL[2])] +
                                  [(None, None)] * 3 + [('loop w', INK2)]):
        if nm is None:
            continue
        ax[0, 1].errorbar(dt, f['Cn'][:, j], yerr=e['Cn'][:, j], fmt='o-', color=col, capsize=3, label=nm)
        ax[1, 0].errorbar(dt[:-1] + 0.06 * min(j, 3), f['meff'][:, j] / u, yerr=e['meff'][:, j] / u, fmt='s', color=col,
                          capsize=3, label=nm)
    for axx in (ax[0, 0], ax[1, 1]):
        axx.set_xticks(rlist)
    ax[1, 0].set_xticks(dt[:-1])
    ax[0, 1].set_yscale('log'); ax[0, 1].set_xlabel(r'time separation $\Delta t$')
    ax[0, 1].set_ylabel(r'$C(\Delta t)/C(0)$, connected')
    ax[0, 1].set_title(f'(b) return to the floor, R = {Rsel}, APE {ape[lv]}'); ax[0, 1].legend(fontsize=9 * FS)
    ax[1, 0].set_xlabel(r'$\Delta t$'); ax[1, 0].set_ylabel('effective mass' + unit)
    ax[1, 0].set_title(f'(c) effective masses, R = {Rsel}'); ax[1, 0].legend(fontsize=9 * FS)
    for i in range(3):
        y = [tab[(lv, R)][0]['meff'][a.tfit, i] / u for R in rlist]
        ye = [tab[(lv, R)][1]['meff'][a.tfit, i] / u for R in rlist]
        ax[1, 1].errorbar(Rs + 0.05 * i, y, yerr=ye, fmt='o-', color=MODE_COL[i], capsize=3, label=f'mode {i+1}')
    y = [tab[(lv, R)][0]['meff'][a.tfit, 6] / u for R in rlist]
    ye = [tab[(lv, R)][1]['meff'][a.tfit, 6] / u for R in rlist]
    ax[1, 1].errorbar(Rs + 0.15, y, yerr=ye, fmt='s--', color=INK2, capsize=3, label='loop w')
    ax[1, 1].set_xlabel('loop side R'); ax[1, 1].set_ylabel(rf'mass at $\Delta t$ = {a.tfit}' + unit)
    ax[1, 1].set_title('(d) stiffness of each mode'); ax[1, 1].legend(fontsize=9 * FS)
    fig.suptitle(rf'4D SU(2), $\beta$ = {beta}, $L$ = {L}: floor and stiffness of the three twist modes', fontsize=12 * FS)
    fig.tight_layout()
    fig.savefig(os.path.join(outdir, f'FigMM_mode_masses_L{L}_b{beta}.png'), dpi=200, bbox_inches='tight')
    json.dump(res, open(os.path.join(outdir, f'mode_masses_summary_L{L}_b{beta}.json'), 'w'), indent=1)
    print('\nwrote', outdir)


if __name__ == '__main__':
    main()
