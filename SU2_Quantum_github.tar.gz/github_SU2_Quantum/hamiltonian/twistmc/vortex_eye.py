#!/usr/bin/env python3
"""
vortex_eye.py: where does the imposed Z2 center flux sit, and what does the
field look like around it? Reads the configurations saved by
su2_twist_free_energy.py at lambda = 1 (twisted) and lambda = 0 (untwisted,
the control).

    python3 vortex_eye.py results/L16_T16_n1            # one box
    python3 vortex_eye.py results/L*_T*_n1 --block 2    # several boxes, one summary

Part of the SU2_Quantum project (R. Sakidja, Missouri State University).
Code drafted with AI (LLM) assistance (Claude, Anthropic) and reviewed by the author.

Readout (no smoothing of the links)
-----------------------------------
For every xy plane (one per time slice t) the action density of each xy
plaquette is d(x, y) = 1 - w_p c0_p, with w_p = -1 on the twist stack at
lambda = 1, so d is exactly what the action sees. The flux of the twisted
ensemble has to cross every xy plane once. Its core in a plane is taken as the
b x b block (default b = 2, i.e. the 2 x 2 Wilson loop area) with the largest
summed d. The same rule applied to the untwisted control just finds the
largest vacuum fluctuation, so every twisted number is quoted against it.

1. Eye profile: d(r) and |c|^2(r) = 1 - c0^2 (the per plaquette sum of c_k^2,
   whose mean is sum_k Var(c_k)) against periodic distance r from the core.
2. Pinning: distance of the core from the stack position (x0, y0); a flux tube
   that stays where it was imposed sits at r ~ 0, a free one is spread over the
   whole plane.
3. Line coherence: distance between the cores of neighbouring time slices; a
   coherent vortex line moves little from slice to slice, a dissolved flux
   jumps by about L/2.
4. Figures: one xy plane of d and of |c|^2 (twisted and untwisted side by
   side, core and stack marked), the core track through t, and the profiles.
"""
import argparse
import glob
import json
import os

import numpy as np

from su2_classical_twist import qmul, qdag


def shift(a, axis, s=1):
    return np.roll(a, -s, axis=axis)


def xy_plaquettes(U):
    """xy plaquette quaternions, shape (Lx, Ly, Lt, 4); U: (3, Lx, Ly, Lt, 4)."""
    Ux, Uy = U[0], U[1]
    return qmul(Ux, qmul(shift(Uy, 0), qmul(qdag(shift(Ux, 1)), qdag(Uy))))


def periodic_dist(L):
    d = np.minimum(np.arange(L), L - np.arange(L))
    return np.sqrt(d[:, None] ** 2 + d[None, :] ** 2)


def analyse(cfgfile, block):
    z = np.load(cfgfile)
    links = z["links"].astype(np.float64)
    W = z["W"][0]                       # xy plane weights, (Lx, Ly, Lt)
    Lx, Lt = int(z["Lx"]), int(z["Lt"])
    stack = tuple(int(v) for v in z["stacks"][0])
    rgrid = periodic_dist(Lx)
    rbins = np.arange(0, rgrid.max() + 2.0)
    prof_d = np.zeros(len(rbins)); prof_c = np.zeros(len(rbins)); cnt = np.zeros(len(rbins))
    pin, hop, example = [], [], None
    for k, U in enumerate(links):
        P = xy_plaquettes(U)
        c0 = P[..., 0]
        d = 1.0 - W * c0                    # action density per xy plaquette
        csq = 1.0 - c0 ** 2                 # sum_k c_k^2 per plaquette
        D = sum(np.roll(np.roll(d, -i, 0), -j, 1) for i in range(block) for j in range(block))
        cores = []
        off = (block - 1) / 2.0             # core = centre of the b x b block
        xs = np.arange(Lx)
        for t in range(Lt):
            ix = np.unravel_index(np.argmax(D[:, :, t]), (Lx, Lx))
            cx, cy = (ix[0] + off) % Lx, (ix[1] + off) % Lx
            cores.append((cx, cy))
            ddx = np.abs(xs - cx); ddx = np.minimum(ddx, Lx - ddx)
            ddy = np.abs(xs - cy); ddy = np.minimum(ddy, Lx - ddy)
            r = np.sqrt(ddx[:, None] ** 2 + ddy[None, :] ** 2)
            rb = np.rint(r).astype(int)
            np.add.at(prof_d, rb, d[:, :, t]); np.add.at(prof_c, rb, csq[:, :, t]); np.add.at(cnt, rb, 1)
            sx = abs(cx - stack[0]); sx = min(sx, Lx - sx)
            sy = abs(cy - stack[1]); sy = min(sy, Lx - sy)
            pin.append(np.hypot(sx, sy))
        for t in range(Lt):
            a, b = cores[t], cores[(t + 1) % Lt]
            hx = abs(a[0] - b[0]); hx = min(hx, Lx - hx)
            hy = abs(a[1] - b[1]); hy = min(hy, Lx - hy)
            hop.append(np.hypot(hx, hy))
        if example is None:
            example = dict(d=d[:, :, 0], csq=csq[:, :, 0], core=cores[0], cores=np.array(cores))
    ok = cnt > 0
    rand = rgrid.mean()                     # mean distance of a uniformly placed point
    return dict(Lx=Lx, Lt=Lt, lam=float(z["lam"]), stack=stack, n_configs=len(links),
                r=rbins[ok].tolist(), d_r=(prof_d[ok] / cnt[ok]).tolist(), csq_r=(prof_c[ok] / cnt[ok]).tolist(),
                pin_mean=float(np.mean(pin)), pin_err=float(np.std(pin) / np.sqrt(len(pin))),
                hop_mean=float(np.mean(hop)), hop_err=float(np.std(hop) / np.sqrt(len(hop))),
                uniform_mean_distance=float(rand)), example


def figure(folder, res, ex, block):
    import matplotlib
    matplotlib.use("Agg")
    import matplotlib.pyplot as plt
    L = res["twisted"]["Lx"]
    fig, ax = plt.subplots(2, 3, figsize=(13, 8))
    for row, sec in enumerate(["twisted", "untwisted"]):
        e = ex[sec]
        for col, (key, lab, cm) in enumerate([("d", "action density 1 - w c0", "magma"),
                                              ("csq", "sum_k c_k^2 = 1 - c0^2", "viridis")]):
            a = ax[row, col]
            im = a.imshow(e[key].T, origin="lower", cmap=cm, vmin=0, vmax=2 if key == "d" else 1)
            a.plot(*e["core"], "c+", ms=14, mew=2, label="core")
            if sec == "twisted":
                a.plot(*res[sec]["stack"], "wx", ms=10, mew=2, label="stack")
            a.set_title(f"{sec}, t = 0: {lab}")
            a.legend(loc="upper left", bbox_to_anchor=(0.0, -0.08), ncol=2, fontsize=7, frameon=False)
            plt.colorbar(im, ax=a, fraction=0.046)
        a = ax[row, 2]
        cores = e["cores"]
        a.scatter(cores[:, 0] + 0.15 * np.random.default_rng(0).normal(size=len(cores)),
                  cores[:, 1] + 0.15 * np.random.default_rng(1).normal(size=len(cores)),
                  c=np.arange(len(cores)), cmap="plasma", s=18)
        a.plot(cores[:, 0], cores[:, 1], "-", lw=0.4, color="gray")
        a.set_xlim(-0.5, L - 0.5); a.set_ylim(-0.5, L - 0.5); a.set_aspect("equal")
        a.set_title(f"{sec}: core position through t (colour = t)")
    fig.suptitle(f"L = {L}, Lt = {res['twisted']['Lt']}, beta = 2.2, core block {block}x{block}")
    fig.tight_layout()
    fig.savefig(os.path.join(folder, "vortex_eye_maps.png"), dpi=130)
    plt.close(fig)

    fig, ax = plt.subplots(1, 2, figsize=(11, 4))
    for sec, st in [("twisted", "o-"), ("untwisted", "s--")]:
        r = res[sec]
        ax[0].plot(r["r"], r["d_r"], st, label=sec)
        ax[1].plot(r["r"], r["csq_r"], st, label=sec)
    ax[0].set_xlabel("distance from core"); ax[0].set_ylabel("<1 - w c0>"); ax[0].set_title("eye profile: action density")
    ax[1].set_xlabel("distance from core"); ax[1].set_ylabel("<sum_k c_k^2>"); ax[1].set_title("eye profile: variance")
    for a in ax:
        a.legend()
    fig.tight_layout()
    fig.savefig(os.path.join(folder, "vortex_eye_profile.png"), dpi=130)
    plt.close(fig)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("folders", nargs="+")
    ap.add_argument("--block", type=int, default=2)
    a = ap.parse_args()
    summary = []
    for folder in a.folders:
        files = {}
        for f in glob.glob(os.path.join(folder, "*_configs.npz")):
            lam = float(np.load(f)["lam"])
            if lam in (0.0, 1.0):
                files.setdefault("twisted" if lam == 1.0 else "untwisted", []).append(f)
        if set(files) != {"twisted", "untwisted"}:
            print(f"{folder}: saved configurations at lambda 0 and 1 not found, skipped")
            continue
        res, ex = {}, {}
        for sec, fl in files.items():
            parts = [analyse(f, a.block) for f in sorted(fl)]
            r0 = parts[0][0]
            n = sum(p[0]["n_configs"] for p in parts)
            comb = dict(r0)
            for key in ("d_r", "csq_r", "pin_mean", "hop_mean"):
                comb[key] = (np.sum([np.array(p[0][key]) * p[0]["n_configs"] for p in parts], axis=0) / n).tolist()
            comb["pin_err"] = float(np.sqrt(np.sum([p[0]["pin_err"] ** 2 for p in parts])) / len(parts))
            comb["hop_err"] = float(np.sqrt(np.sum([p[0]["hop_err"] ** 2 for p in parts])) / len(parts))
            comb["n_configs"] = n
            res[sec], ex[sec] = comb, parts[0][1]
        t, u = res["twisted"], res["untwisted"]
        line = (f"L={t['Lx']} Lt={t['Lt']}: core distance from stack {t['pin_mean']:.2f}+-{t['pin_err']:.2f} "
                f"(uniform {t['uniform_mean_distance']:.2f}); slice to slice hop twisted {t['hop_mean']:.2f}+-{t['hop_err']:.2f} "
                f"untwisted {u['hop_mean']:.2f}+-{u['hop_err']:.2f}; core d twisted {t['d_r'][0]:.3f} untwisted {u['d_r'][0]:.3f}; "
                f"core sum c_k^2 twisted {t['csq_r'][0]:.3f} untwisted {u['csq_r'][0]:.3f}")
        print(line)
        json.dump(dict(block=a.block, **res), open(os.path.join(folder, "vortex_eye.json"), "w"), indent=1)
        try:
            figure(folder, res, ex, a.block)
        except Exception as e:  # figures are optional
            print(f"  [warn] figures not written: {e}")
        summary.append(dict(folder=folder, twisted=t, untwisted=u))
    if len(summary) > 1:
        json.dump(summary, open("vortex_eye_summary.json", "w"), indent=1)


if __name__ == "__main__":
    main()
