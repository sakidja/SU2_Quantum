#!/usr/bin/env python3
"""
su2_4d_production.py
4D SU(2) Wilson gauge theory, Creutz heat bath (Kennedy Pendleton sampler), the
four dimensional counterpart of the 3D campaign in ../topology. Built for NERSC
Perlmutter CPU nodes: every MPI rank is an independent Markov chain.

Per measured configuration:
  1. plaquette channel: <1/2 Tr P> (all six planes, and spatial / temporal
     separately), sum_k Var(c_k) of the plaquette Pauli vector;
  2. Wilson loops W(R, T), R, T = 1..rmax, averaged over sites and the six planes
     (Creutz ratios chi(R) give the string tension a^2 sigma, which sets the
     physical scale in 4D, as in Creutz 1980);
  3. center vortices: direct maximal center gauge (optionally best of several
     random gauge starts, --gribov k), center projection, P vortex plaquettes;
     every square R x R loop in every plane is classified by the number n_v of
     P vortex plaquettes on its flat surface; accumulated per (plane type, R, n_v):
     count and sum cos(j psi), j = 1..6, with cos psi = 1/2 Tr W (full, gauge
     invariant loop); holonomy angle histograms for even and odd n_v;
  4. three twist modes at the lock scale, option A: at every site the three square
     R x R loops in the three SPATIAL planes (xy, xz, yz) of its time slice share
     a base point, so the 3 x 3 colour by space matrix of their Pauli vectors has
     gauge invariant singular values s1 >= s2 >= s3 (populations s_i^2 / sum s^2),
     and the axes have gauge invariant mutual products. Classified by the number of
     the three loops with odd n_v. Null: each plane's loop from an independent
     random site (keeps every loop's own magnitude and vortex parity, removes only
     the relative orientation). Identical to ../topology/locked_modes.py on each
     time slice.

Resumable: one npz per rank, <out>/su2_4d_L{L}_b{beta}_rank{r}.npz. Rerun the same
command to continue. Analysis: su2_4d_analysis.py (login node, no MPI).

  python su2_4d_production.py --L 6 --beta 2.3 --ntherm 100 --nmeas 10 --rmax 3 --out runs/t6   # laptop
  srun -n 128 -c 2 --cpu-bind=cores python su2_4d_production.py --L 16 --beta 2.3 --rmax 6 --out runs/L16_b2.3
"""
import argparse
import json
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from su2_4d_core import (ND, PLANES, SPATIAL, qmul, qconj, shift, plaquette, checkerboard,   # noqa: E402
                         sweep, line_products, rect_loop, box_sum_2d, gauge_fix_best, p_vortices)

try:
    from mpi4py import MPI
    COMM = MPI.COMM_WORLD
    RANK, SIZE = COMM.Get_rank(), COMM.Get_size()
except Exception:
    COMM, RANK, SIZE = None, 0, 1

NMAX = 6        # cos(j psi), j = 1..6
NVMAX = 64      # vortex count bins 0..64
NBINS = 36      # holonomy angle histogram on [0, pi]
NSV = 8         # count, s1, s2, s3 (sum normalized), e1, e2, e3 (squared shares), split
NSH = 20        # split histogram bins
NPR = 4         # count, dot, |dot|, dot^2
EXTRA_NAMES = ['plaq_all', 'plaq_spatial', 'plaq_temporal', 'sumvar_ck', 'pvortex_density',
               'pvortex_density_spatial', 'pvortex_density_temporal', 'mcg_objective', 'mcg_iters']


def rng_state_json(rng):
    return json.dumps(rng.bit_generator.state)


def rng_from_json(s):
    rng = np.random.default_rng()
    rng.bit_generator.state = json.loads(s)
    return rng


def accumulate_modes(W, par, sv, sh, pr):
    """W: (3, N, 4) spatial loops at the same base points, par: (3, N) vortex parity."""
    w = W[..., 1:]
    M = np.transpose(w, (1, 2, 0))                              # (N, 3 colour, 3 plane)
    s = np.linalg.svd(M, compute_uv=False)
    sn = s / (s.sum(-1, keepdims=True) + 1e-300)
    e = s ** 2 / ((s ** 2).sum(-1, keepdims=True) + 1e-300)
    split = (s[:, 1] - s[:, 2]) / (s[:, 0] - s[:, 2] + 1e-300)
    nodd = par.sum(0)
    for c in range(4):
        sel = nodd == c
        if not sel.any():
            continue
        sv[c, 0] += sel.sum()
        sv[c, 1:4] += sn[sel].sum(0)
        sv[c, 4:7] += e[sel].sum(0)
        sv[c, 7] += split[sel].sum()
        sh[c] += np.histogram(split[sel], bins=NSH, range=(0, 1))[0]
    m = w / (np.linalg.norm(w, axis=-1, keepdims=True) + 1e-300)
    for p, q in ((0, 1), (0, 2), (1, 2)):
        d = (m[p] * m[q]).sum(-1)
        pc = par[p] + par[q]
        for c in range(3):
            sel = pc == c
            if not sel.any():
                continue
            pr[c, 0] += sel.sum()
            pr[c, 1] += d[sel].sum()
            pr[c, 2] += np.abs(d[sel]).sum()
            pr[c, 3] += (d[sel] ** 2).sum()


def measure(links, rmax, rmodes, gribov, rng):
    L = links.shape[1]
    n = L ** ND
    # 1. plaquettes
    P = np.stack([plaquette(links, m, nu) for m, nu in PLANES])       # (6, L^4, 4)
    c0 = P[..., 0]
    ck = P[..., 1:].reshape(-1, 3)
    sumvar = float(ck.var(0).sum())
    # 2. Wilson loops W(R, T)
    lines = [line_products(links[mu], mu, rmax) for mu in range(ND)]
    WRT = np.zeros((rmax + 1, rmax + 1))
    sqW = {}
    for p, (mu, nu) in enumerate(PLANES):
        for R in range(1, rmax + 1):
            for T in range(1, rmax + 1):
                w = rect_loop(lines, mu, nu, R, T)
                WRT[R, T] += w[..., 0].mean() / len(PLANES)
                if R == T:
                    sqW.setdefault(R, [None] * len(PLANES))[p] = w
    # 3. center vortices
    Ug, obj, nit = gauge_fix_best(links, gribov, rng)
    pv = p_vortices(Ug)
    dens = [float(np.mean([pv[pl].mean() for pl in sel])) for sel in (PLANES, PLANES[:3], PLANES[3:])]
    acc = np.zeros((2, rmax, NVMAX + 1, NMAX + 1))            # plane type 0 spatial, 1 temporal
    hist = np.zeros((rmax, 2, NBINS))
    edges = np.linspace(0, np.pi, NBINS + 1)
    nvbox = {}
    for R in range(1, rmax + 1):
        for p, (mu, nu) in enumerate(PLANES):
            nv = np.rint(box_sum_2d(pv[(mu, nu)].astype(float), mu, nu, R)).astype(int)
            nvbox[(R, p)] = nv
            nvr = nv.ravel()
            psi = np.arccos(np.clip(sqW[R][p][..., 0].ravel(), -1, 1))
            nb = np.clip(nvr, 0, NVMAX)
            t = 0 if p in SPATIAL else 1
            acc[t, R - 1, :, 0] += np.bincount(nb, minlength=NVMAX + 1)
            for j in range(1, NMAX + 1):
                acc[t, R - 1, :, j] += np.bincount(nb, weights=np.cos(j * psi), minlength=NVMAX + 1)
            for par in (0, 1):
                hist[R - 1, par] += np.histogram(psi[(nvr % 2) == par], bins=edges)[0]
    # 4. three twist modes, spatial planes (option A), real and null
    sv = np.zeros((rmodes, 2, 4, NSV)); sh = np.zeros((rmodes, 2, 4, NSH)); pr = np.zeros((rmodes, 2, 3, NPR))
    for R in range(1, rmodes + 1):
        W = np.stack([sqW[R][p] for p in SPATIAL]).reshape(3, n, 4)
        par = np.stack([nvbox[(R, p)].ravel() % 2 for p in SPATIAL])
        accumulate_modes(W, par, sv[R - 1, 0], sh[R - 1, 0], pr[R - 1, 0])
        perm = [np.arange(n)] + [rng.permutation(n) for _ in range(2)]
        accumulate_modes(np.stack([W[p][perm[p]] for p in range(3)]),
                         np.stack([par[p][perm[p]] for p in range(3)]),
                         sv[R - 1, 1], sh[R - 1, 1], pr[R - 1, 1])
    extra = np.array([c0.mean(), c0[:3].mean(), c0[3:].mean(), sumvar, *dens, obj, nit])
    return dict(wrt=WRT, acc=acc, hist=hist, sv=sv, sh=sh, pr=pr, extra=extra)


KEYS = ['wrt', 'acc', 'hist', 'sv', 'sh', 'pr', 'extra']


def save(path, links, rng, sweeps, res, args):
    tmp = path + '.tmp.npz'
    arrs = {k: np.array([r[k] for r in res]) for k in KEYS} if res else {}
    np.savez(tmp, links=links, rng=rng_state_json(rng), sweeps_done=sweeps, **arrs,
             meta=json.dumps(dict(L=args.L, beta=args.beta, rmax=args.rmax, rmodes=args.rmodes, skip=args.skip,
                                  ntherm=args.ntherm, gribov=args.gribov, seed=args.seed, nd=ND,
                                  extra_names=EXTRA_NAMES, nmax=NMAX, nvmax=NVMAX, nbins=NBINS)))
    os.replace(tmp, path)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--L', type=int, default=16)
    ap.add_argument('--beta', type=float, default=2.3)
    ap.add_argument('--ntherm', type=int, default=300)
    ap.add_argument('--nmeas', type=int, default=100)
    ap.add_argument('--skip', type=int, default=10)
    ap.add_argument('--rmax', type=int, default=6, help='largest loop side (keep <= L/2)')
    ap.add_argument('--rmodes', type=int, default=0, help='largest loop side for the mode test (0: rmax)')
    ap.add_argument('--gribov', type=int, default=1)
    ap.add_argument('--seed', type=int, default=20260930)
    ap.add_argument('--out', default='runs/4d')
    ap.add_argument('--ckpt_every', type=int, default=5)
    ap.add_argument('--wall', type=float, default=0, help='stop cleanly after this many seconds')
    ap.add_argument('--hot', action='store_true', help='hot (Haar) start instead of cold')
    args = ap.parse_args()
    args.rmodes = args.rmodes or args.rmax
    if 2 * args.rmax > args.L:
        raise SystemExit('rmax must be <= L/2')

    L = args.L
    os.makedirs(args.out, exist_ok=True)
    path = os.path.join(args.out, f'su2_4d_L{L}_b{args.beta}_rank{RANK}.npz')
    t0 = time.time()
    idx = checkerboard(L)
    if os.path.exists(path):
        z = np.load(path, allow_pickle=False)
        links = z['links'].copy(); rng = rng_from_json(str(z['rng'])); sweeps = int(z['sweeps_done'])
        res = [{k: z[k][i] for k in KEYS} for i in range(len(z['extra']))] if 'extra' in z.files else []
    else:
        rng = np.random.default_rng([args.seed, RANK])
        links = np.zeros((ND,) + (L,) * ND + (4,)); links[..., 0] = 1.0
        if args.hot:
            g = rng.normal(size=links.shape); links = g / np.linalg.norm(g, axis=-1, keepdims=True)
        sweeps, res = 0, []
    grng = np.random.default_rng([args.seed, RANK, 4, len(res)])
    if RANK == 0:
        print(f'[su2 4d] L={L} beta={args.beta} ranks={SIZE} rmax={args.rmax} rmodes={args.rmodes} '
              f'therm={args.ntherm} nmeas={args.nmeas} skip={args.skip} out={args.out}', flush=True)

    stopped = False
    while sweeps < args.ntherm:
        sweep(links, args.beta, rng, idx); sweeps += 1
        if sweeps % 25 == 0:
            save(path, links, rng, sweeps, res, args)
            if RANK == 0:
                pl = float(np.mean([plaquette(links, m, nu)[..., 0].mean() for m, nu in PLANES]))
                print(f'  therm {sweeps}/{args.ntherm}  plaq {pl:.5f}  t={time.time()-t0:.0f}s', flush=True)
            if args.wall and time.time() - t0 > args.wall:
                stopped = True; break
    while not stopped and len(res) < args.nmeas:
        for _ in range(args.skip):
            sweep(links, args.beta, rng, idx); sweeps += 1
        r = measure(links, args.rmax, args.rmodes, args.gribov, grng)
        res.append(r)
        if len(res) % args.ckpt_every == 0 or len(res) == args.nmeas:
            save(path, links, rng, sweeps, res, args)
            if RANK == 0:
                e = r['extra']
                print(f'  meas {len(res)}/{args.nmeas}  plaq {e[0]:.5f}  vortex density {e[4]:.4f}  '
                      f'MCG iters {int(e[8])}  t={time.time()-t0:.0f}s', flush=True)
        if args.wall and time.time() - t0 > args.wall:
            stopped = True
    save(path, links, rng, sweeps, res, args)
    if COMM is not None:
        COMM.Barrier()
    if RANK == 0:
        print('stopped at wall limit; rerun the same command to resume' if stopped else 'done', flush=True)


if __name__ == '__main__':
    main()
