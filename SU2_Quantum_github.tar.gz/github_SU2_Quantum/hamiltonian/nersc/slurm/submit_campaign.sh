#!/bin/bash
# Submit the whole v3 convergence campaign from the package directory:
#   cd /pscratch/sd/r/rsakidja/quantum/su2_v3_hamiltonian && bash slurm/submit_campaign.sh
# Check progress with sacct (not squeue) and with the files in logs/ and results/:
#   sacct -u rsakidja --starttime today --format=JobID,JobName%28,State,Elapsed,MaxRSS
# Part of the SU2_Quantum project. Drafted with AI (LLM) assistance (Claude, Anthropic).
set -e
mkdir -p logs results
sub () {  # name system jmax walltime twists...
  local name=$1 sys=$2 j=$3 t=$4; shift 4
  sbatch --job-name=$name --time=$t \
         --export=ALL,SYSTEM=$sys,JMAX=$j,TWISTS="$*" slurm/run_case.sbatch
}
# single plaquette (reference, seconds)
sub su2_single_j10   single   10  00:15:00 "--twist 1"
# open 2x1 (untwisted plus the open lattice twist control)
for j in 3 4 5 6; do
  sub su2_open_j$j   open2x1  $j  00:30:00 "--twist 1 1 --twist -1 1"
done
# periodic 1x1
for j in 3 4 5 6; do
  sub su2_t11_j$j    torus1x1 $j  00:30:00 "--twist 1 --twist -1"
done
# periodic 2x1: the size comparison; cost grows about 7x per half step in jmax
sub su2_t21_j2.5     torus2x1 2.5 00:30:00 "--twist 1 1 --twist -1 1"
sub su2_t21_j3       torus2x1 3   01:00:00 "--twist 1 1 --twist -1 1"
sub su2_t21_j3.5     torus2x1 3.5 03:00:00 "--twist 1 1 --twist -1 1"
sub su2_t21_j4       torus2x1 4   12:00:00 "--twist 1 1 --twist -1 1"
