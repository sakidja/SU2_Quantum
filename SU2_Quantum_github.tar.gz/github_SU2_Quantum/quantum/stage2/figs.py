import numpy as np, json, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
B="#2A6FB0"; A="#C27A12"; INK="#1F2937"; MUT="#6B7280"; GRID="#E5E7EB"
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":11,"axes.edgecolor":MUT,"axes.labelcolor":INK,"xtick.color":MUT,"ytick.color":MUT,"axes.spines.top":False,"axes.spines.right":False,"axes.grid":True,"grid.color":GRID,"grid.linewidth":0.6,"axes.axisbelow":True})
R=json.load(open("results.json"))  # from su2_haar_check.py
# Fig 1: means and variances, 2D and 3D
fig,ax=plt.subplots(figsize=(7.5,4.2))
lab=["c₁","c₂","c₃"]; x=np.arange(3); w=0.36
for off,key,col,name in [(-w/2,"A_2D",B,"3×3 lattice (18,000 plaquettes)"),(w/2,"A_3D",A,"2×2×2 lattice (24,000 plaquettes)")]:
    r=R[key]
    ax.bar(x+off,r["Var c_k"],w*0.94,color=col,label=name)
    ax.bar(x+3.4+off,r["mean c_k"],w*0.94,color=col)
ax.axhline(0.25,color=INK,lw=1,ls="--"); ax.text(2.55,0.258,"Haar value 1/4",color=INK,fontsize=10)
ax.axhline(0,color=MUT,lw=0.8)
ax.set_xticks(list(x)+list(x+3.4)); ax.set_xticklabels([f"Var({l})" for l in lab]+[f"⟨{l}⟩" for l in lab])
ax.set_ylim(-0.03,0.3); ax.set_ylabel("value")
ax.set_title(f"Zero means, finite variances:  Σ Var(cₖ) = {R['A_2D']['sum Var c_k']} ± {R['A_2D']['sum Var c_k err']} (2D),  {R['A_3D']['sum Var c_k']} ± {R['A_3D']['sum Var c_k err']} (3D)",fontsize=10.5,color=INK,loc="left")
ax.legend(frameon=False,loc="center right"); fig.tight_layout(); fig.savefig("Fig_N1_ck_means_variances.png",dpi=300)
# Fig 2: c0 distribution vs Haar
C=np.load("c_2d.npy"); fig,ax=plt.subplots(figsize=(6.5,4))
ax.hist(C[:,0],bins=60,density=True,color=B,alpha=0.85,edgecolor="white",linewidth=0.4,label="sampled plaquettes (3×3)")
xx=np.linspace(-1,1,400); ax.plot(xx,2/np.pi*np.sqrt(1-xx**2),color=A,lw=2,label="Haar density (2/π)√(1 − c₀²)")
ax.set_xlabel("c₀ = ½ Tr P"); ax.set_ylabel("probability density"); ax.legend(frameon=False,loc="lower center")
ax.set_title(f"Plaquettes are uniform on SU(2):  ⟨c₀²⟩ = {R['A_2D']['<c0^2>']} (exact 1/4)",fontsize=10.5,color=INK,loc="left")
fig.tight_layout(); fig.savefig("Fig_N2_c0_haar.png",dpi=300)
# Fig 3: qubit readout vs exact
E=np.load("b_exact.npy"); M=np.load("b_meas.npy"); fig,ax=plt.subplots(figsize=(5.2,5))
ax.plot([-1,1],[-1,1],color=MUT,lw=1)
ax.scatter(E[:,1:].ravel(),M[:,1:].ravel(),s=10,color=B,alpha=0.6,label="c₁, c₂, c₃")
ax.scatter(E[:,0],M[:,0],s=10,color=A,alpha=0.6,label="c₀")
ax.set_xlabel("exact coefficient"); ax.set_ylabel("measured on qubits (2,000 shots)"); ax.set_aspect("equal")
ax.legend(frameon=False,loc="upper left"); ax.set_title(f"Hadamard test readout, rms error {R['B']['rms |circuit - c| (shots)']:.3f}",fontsize=10.5,color=INK,loc="left")
fig.tight_layout(); fig.savefig("Fig_N3_qubit_readout.png",dpi=300)
# Fig 4: neutrino probe
rows=R["C"]["field on"]; S=np.array([r["sum Var c_k"] for r in rows]); V=np.array([r["V_nu"] for r in rows]); Ve=np.array([r["V_nu err"] for r in rows])
o=np.argsort(S); fig,ax=plt.subplots(figsize=(6.5,4.2))
ss=np.linspace(0,0.8,200); ax.plot(ss,1-(1-2*ss/3)**8,color=MUT,lw=1.5,label="1 − (1 − 2S/3)⁸")
ax.errorbar(S[o],V[o],yerr=Ve[o],fmt="o",ms=7,color=A,mec="white",mew=1.5,label="simulation, field on")
ax.plot([0],[R["C"]["field off V_nu"]],"s",ms=8,color=B,mec="white",mew=1.5,label="field off")
ax.set_xlabel("gauge field variance  S = Σ Var(cₖ)"); ax.set_ylabel("neutrino variance  1 − ⟨X₀⟩² − ⟨Y₀⟩²")
ax.annotate("field off: exactly 0",xy=(0,0),xytext=(0.08,0.05),color=INK,fontsize=10,arrowprops=dict(arrowstyle="->",color=MUT)); ax.set_ylim(-0.03,1.05); ax.legend(frameon=False,loc="lower right")
ax.set_title("Neutrino probe qubit responds to the gauge variance",fontsize=10.5,color=INK,loc="left")
fig.tight_layout(); fig.savefig("Fig_N4_neutrino_probe.png",dpi=300)
print("ok")
