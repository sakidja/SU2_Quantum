#!/usr/bin/env python3
"""
locked_modes.py
Job 13: the three mode test at the scale of the lock (Figure T8).

Job 12 built the three twist modes from single plaquettes (R = 1) and from averaged
plaquette vectors, i.e. below the scale where the Z2 lock forms. Job 10 showed that
the lock is complete from R = 4 on (W_odd/W_even = -1.00). This script builds the
three modes from the large loops themselves.

At every site x and for every loop side R, the three R x R Wilson loops based at x in
the planes (xy, xz, yz) give three holonomies W_p = cos psi_p + i w_p . sigma. All three
are based at the same point, so under a gauge transformation their Pauli vectors w_p
rotate together: the 3x3 colour by space matrix M[a, p] = w_p^a has gauge invariant
singular values s1 >= s2 >= s3, and the axes m_p = w_p / |w_p| have gauge invariant
mutual products m_p . m_q.

Measured per configuration, per R and per vortex class
  * mode shares: s_i / sum s and s_i^2 / sum s^2 (the populations of the three modes),
    and the split ratio (s2 - s3) / (s1 - s3) with its histogram (0: one mode on top of
    a degenerate pair, 1: a degenerate pair on top of one mode);
    classes: number of the three loops pierced by an odd number of P vortices (0..3);
  * axis alignment between the three planes: <m_p . m_q>, <|m_p . m_q|>, <(m_p . m_q)^2>,
    classes: number of odd loops in the pair (0, 1, 2). Random axes give 0, 1/2, 1/3.
  * null: each plane's loop taken from an independent random site, which keeps every
    loop's own magnitude and vortex parity and removes only the relative orientation.
A lock that distinguishes one axis shows up as real minus null differences that stay
(or grow) at R >= 4, where the lock is complete.

Every MPI rank is an independent chain; resumable npz per rank:
    <out>/lmodes_L{L}_rank{r}.npz
Analysis: locked_modes_analysis.py

  python locked_modes.py --L 12 --ntherm 200 --nmeas 10 --rmax 5 --out runs/lm12     # laptop
  srun -n 128 -c 2 --cpu-bind=cores python locked_modes.py --L 24 --rmax 7 --out runs/lm24
"""
import argparse
import json
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from topo_measure import qmul, qconj, shift, PLANES, line_products, _box_sum_2d      # noqa: E402
from su2_topology_heatbath import sweep, rng_state_json, rng_from_json               # noqa: E402
from vortex_lock_production import gauge_fix_best                                    # noqa: E402

try:
    from mpi4py import MPI
    COMM = MPI.COMM_WORLD
    RANK, SIZE = COMM.Get_rank(), COMM.Get_size()
except Exception:
    COMM, RANK, SIZE = None, 0, 1

NSV = 8        # count, s1, s2, s3 (sum normalized), e1, e2, e3 (square shares), split
NSH = 20       # split histogram bins on [0, 1]
NPR = 4        # count, dot, |dot|, dot^2


def square_loops(links, R, lines):
    """Full quaternion W_p(x) for R x R loops in the three planes, all based at x."""
    out = []
    for mu, nu in PLANES:
        a, b = lines[mu][R], lines[nu][R]
        out.append(qmul(qmul(a, shift(b, mu, R)), qmul(qconj(shift(a, nu, R)), qconj(b))))
    return np.stack(out)                                        # (3, L, L, L, 4)


def accumulate(W, par, sv, sh, pr):
    """W: (3, N, 4) loops, par: (3, N) vortex parity. Adds into sv (4, NSV), sh (4, NSH), pr (3, NPR)."""
    w = W[..., 1:]                                              # (3, N, 3) Pauli vectors
    M = np.transpose(w, (1, 2, 0))                              # (N, 3 colour, 3 plane)
    s = np.linalg.svd(M, compute_uv=False)                      # descending
    sn = s / (s.sum(-1, keepdims=True) + 1e-300)
    e = s ** 2 / ((s ** 2).sum(-1, keepdims=True) + 1e-300)
    split = (s[:, 1] - s[:, 2]) / (s[:, 0] - s[:, 2] + 1e-300)
    nodd = par.sum(0)
    for c in range(4):
        sel = nodd == c
        if not sel.any():
            continue
        sv[c, 0] += sel.sum()
        sv[c, 1:4] += sn[sel].sum(0)
        sv[c, 4:7] += e[sel].sum(0)
        sv[c, 7] += split[sel].sum()
        sh[c] += np.histogram(split[sel], bins=NSH, range=(0, 1))[0]
    m = w / (np.linalg.norm(w, axis=-1, keepdims=True) + 1e-300)
    for p, q in ((0, 1), (0, 2), (1, 2)):
        d = (m[p] * m[q]).sum(-1)
        pc = par[p] + par[q]
        for c in range(3):
            sel = pc == c
            if not sel.any():
                continue
            pr[c, 0] += sel.sum()
            pr[c, 1] += d[sel].sum()
            pr[c, 2] += np.abs(d[sel]).sum()
            pr[c, 3] += (d[sel] ** 2).sum()


def measure(links, rmax, gribov, rng):
    L = links.shape[1]
    Ug, obj, _ = gauge_fix_best(links, gribov, rng)
    z = np.sign(Ug[..., 0])
    pv = {}
    for mu, nu in PLANES:
        pv[(mu, nu)] = ((z[mu] * shift(z[nu], mu) * shift(z[mu], nu) * z[nu]) < 0).astype(float)
    dens = float(np.mean([v.mean() for v in pv.values()]))
    lines = [line_products(links[mu], mu, rmax) for mu in range(3)]
    sv = np.zeros((rmax, 2, 4, NSV)); sh = np.zeros((rmax, 2, 4, NSH)); pr = np.zeros((rmax, 2, 3, NPR))
    wodd = np.zeros((rmax, 2))                                  # sum of 1/2 Tr W over even and odd loops (check)
    n = L ** 3
    for R in range(1, rmax + 1):
        W = square_loops(links, R, lines).reshape(3, n, 4)
        par = np.stack([np.rint(_box_sum_2d(pv[(mu, nu)], mu, nu, R)).astype(int).ravel() % 2
                        for mu, nu in PLANES])
        for k in (0, 1):
            wodd[R - 1, k] = W[..., 0][par == k].sum() / max(1, (par == k).sum())
        accumulate(W, par, sv[R - 1, 0], sh[R - 1, 0], pr[R - 1, 0])
        perm = [np.arange(n)] + [rng.permutation(n) for _ in range(2)]
        Wn = np.stack([W[p][perm[p]] for p in range(3)])
        parn = np.stack([par[p][perm[p]] for p in range(3)])
        accumulate(Wn, parn, sv[R - 1, 1], sh[R - 1, 1], pr[R - 1, 1])
    return sv, sh, pr, np.array([dens, obj]), wodd


def save(path, links, rng, sweeps, res, args):
    tmp = path + '.tmp.npz'
    cols = list(zip(*res)) if res else [[] for _ in range(5)]
    shapes = [(args.rmax, 2, 4, NSV), (args.rmax, 2, 4, NSH), (args.rmax, 2, 3, NPR), (2,), (args.rmax, 2)]
    arrs = [np.array(c) if len(c) else np.zeros((0,) + s) for c, s in zip(cols, shapes)]
    np.savez(tmp, links=links, rng=rng_state_json(rng), sweeps_done=sweeps,
             sv=arrs[0], sh=arrs[1], pr=arrs[2], extra=arrs[3], wparity=arrs[4],
             meta=json.dumps(dict(L=args.L, beta=args.beta, rmax=args.rmax, skip=args.skip,
                                  ntherm=args.ntherm, gribov=args.gribov, seed=args.seed)))
    os.replace(tmp, path)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--L', type=int, default=24)
    ap.add_argument('--beta', type=float, default=2.2)
    ap.add_argument('--ntherm', type=int, default=500)
    ap.add_argument('--nmeas', type=int, default=100)
    ap.add_argument('--skip', type=int, default=10)
    ap.add_argument('--rmax', type=int, default=7)
    ap.add_argument('--gribov', type=int, default=1)
    ap.add_argument('--seed', type=int, default=20260925)
    ap.add_argument('--out', default='runs/lmodes')
    ap.add_argument('--ckpt_every', type=int, default=5)
    ap.add_argument('--wall', type=float, default=0)
    args = ap.parse_args()

    L = args.L
    os.makedirs(args.out, exist_ok=True)
    path = os.path.join(args.out, f'lmodes_L{L}_rank{RANK}.npz')
    t0 = time.time()
    idx = np.indices((L, L, L)).sum(0) % 2
    if os.path.exists(path):
        z = np.load(path, allow_pickle=False)
        links = z['links'].copy(); rng = rng_from_json(str(z['rng'])); sweeps = int(z['sweeps_done'])
        res = list(zip(z['sv'], z['sh'], z['pr'], z['extra'], z['wparity']))
    else:
        rng = np.random.default_rng([args.seed, RANK])
        links = np.zeros((3, L, L, L, 4)); links[..., 0] = 1.0
        sweeps, res = 0, []
    grng = np.random.default_rng([args.seed, RANK, 77, len(res)])
    if RANK == 0:
        print(f'[locked modes] L={L} beta={args.beta} ranks={SIZE} rmax={args.rmax} '
              f'nmeas={args.nmeas} out={args.out}', flush=True)
    stopped = False
    while sweeps < args.ntherm:
        sweep(links, args.beta, rng, idx); sweeps += 1
        if sweeps % 50 == 0:
            save(path, links, rng, sweeps, res, args)
            if args.wall and time.time() - t0 > args.wall:
                stopped = True; break
    while not stopped and len(res) < args.nmeas:
        for _ in range(args.skip):
            sweep(links, args.beta, rng, idx); sweeps += 1
        res.append(measure(links, args.rmax, args.gribov, grng))
        if len(res) % args.ckpt_every == 0 or len(res) == args.nmeas:
            save(path, links, rng, sweeps, res, args)
            if RANK == 0:
                print(f'  rank0 {len(res)}/{args.nmeas}  vortex density {res[-1][3][0]:.4f}  '
                      f't={time.time()-t0:.0f}s', flush=True)
        if args.wall and time.time() - t0 > args.wall:
            stopped = True
    save(path, links, rng, sweeps, res, args)
    if COMM is not None:
        COMM.Barrier()
    if RANK == 0:
        print('stopped at wall limit; rerun the same command to resume' if stopped else 'done', flush=True)


if __name__ == '__main__':
    main()
