"""
Holonomy test of vortex aggregation (2D lattice of plaquettes, Z2 center vortices).
Each plaquette carries vortex charge q in {-1, 0, +1}. A Wilson loop around a region picks up
(-1)^(number of enclosed vortices): the neutrino probe transported around the loop reads
W = product of the enclosed signs. Two ensembles with the SAME zero mode susceptibility
chi(k=0) = <Q^2>/V but different spatial correlation:
  A  independent vortices, density rho_A, random orientation            chi_A = rho_A
  B  screened: tightly bound dipoles (+1,-1 on neighboring plaquettes)   plus independent
     singles at density rho_A, so chi_B = rho_A as well (dipoles carry no net charge)
"""
import numpy as np, json
L=128; NCFG=300; rhoA=0.02; rho_pair=0.04   # dipole density (pairs per plaquette)
def ens_A(rng):
    q=np.zeros((L,L),int); m=rng.random((L,L))<rhoA; q[m]=rng.choice([-1,1],m.sum()); return q
def ens_B(rng):
    q=ens_A(rng)
    npair=rng.binomial(L*L,rho_pair)
    xs=rng.integers(0,L,npair); ys=rng.integers(0,L,npair); d=rng.integers(0,2,npair)
    s=rng.choice([-1,1],npair)
    for x,y,dd,ss in zip(xs,ys,d,s):
        x2,y2=((x+1)%L,y) if dd==0 else (x,(y+1)%L)
        if q[x,y]==0 and q[x2,y2]==0: q[x,y]=ss; q[x2,y2]=-ss
    return q
def loops(q,Rs):
    occ=(q!=0).astype(int); P=np.pad(occ.cumsum(0).cumsum(1),((1,0),(1,0)))
    out=[]
    for R in Rs:
        n=P[R:,R:]-P[:-R,R:]-P[R:,:-R]+P[:-R,:-R]   # vortices enclosed in every R x R loop
        out.append(np.mean((-1.0)**n))
    return np.array(out)
def corr(q,rmax=6):
    V=q.size; f=np.fft.fft2(q); C=np.real(np.fft.ifft2(f*np.conj(f)))/V
    return np.array([C[r,0] for r in range(rmax+1)])
Rs=np.arange(1,21)
res={}
for name,fn,seed in [("A_independent",ens_A,1),("B_screened",ens_B,2)]:
    rng=np.random.default_rng(seed); W=[]; C=[]; chi=[]; dens=[]
    for _ in range(NCFG):
        q=fn(rng); W.append(loops(q,Rs)); C.append(corr(q)); chi.append(q.sum()**2/q.size); dens.append((q!=0).mean())
    W=np.array(W); C=np.array(C)
    res[name]={"loop_R":Rs.tolist(),"W":W.mean(0).tolist(),"W_err":(W.std(0)/np.sqrt(NCFG)).tolist(),
               "C_r":C.mean(0).tolist(),"chi_zero_mode":float(np.mean(chi)),"chi_err":float(np.std(chi)/np.sqrt(NCFG)),
               "vortex_density":float(np.mean(dens))}
json.dump(res,open("holonomy_results.json","w"),indent=1)
for k,v in res.items():
    print(k,"chi(k=0)=%.4f±%.4f"%(v["chi_zero_mode"],v["chi_err"]),"density=%.4f"%v["vortex_density"],
          "C(r=0..3)=",np.round(v["C_r"][:4],4),"W(R=2,5,10,15)=",np.round([v["W"][1],v["W"][4],v["W"][9],v["W"][14]],4))
