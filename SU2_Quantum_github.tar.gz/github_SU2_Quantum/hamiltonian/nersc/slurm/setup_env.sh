#!/bin/bash
# One time setup on a Perlmutter login node. The environment lives in $SCRATCH
# because the home quota fills up.
# Part of the SU2_Quantum project. Drafted with AI (LLM) assistance (Claude, Anthropic).
set -e
module load python
python -m venv $SCRATCH/envs/su2ham
source $SCRATCH/envs/su2ham/bin/activate
pip install --upgrade pip
pip install numpy scipy sympy matplotlib
echo "environment ready: $SCRATCH/envs/su2ham"
