#!/bin/bash -l
# String tension at the finer coupling, same multihit method as job 24 (Parisi, Petronzio and Rapuano):
# 24^4 at beta = 2.6, loops to R = 8 in space and T = 12 in time, so the potential can be read at its
# plateau in time (T0 about 9 to 10 at this coupling; T0 = 7 was needed at beta = 2.5).
# Submit from inside slurm/:
#   sbatch 28_4d_potential_fine.sh            (defaults: L = 24, beta = 2.6, NMEAS = 40, RMAX = 8, TMAX = 12)
# Resubmit the same line to resume. Then read the scale at the plateau:
#   for t in 7 8 9 10 11; do python su2_4d_potential_analysis.py runs/pot_L24_b2.6_T12 --t0 $t --outdir figures_4d_potential_b2.6_t$t | grep "a sqrt"; done
#SBATCH -A mXXXX                  # <-- your NERSC project
#SBATCH -C cpu
#SBATCH -q regular
#SBATCH -N 1
#SBATCH -t 06:00:00
#SBATCH -J su2_4d_pot
#SBATCH -o %x_%j.out
L=${1:-24}; BETA=${2:-2.6}; NMEAS=${3:-40}; RMAX=${4:-8}; TMAX=${5:-12}
cd "$SLURM_SUBMIT_DIR/.."
source slurm/env_perlmutter.sh
srun -n 128 -c 2 --cpu-bind=cores "$PY" su2_4d_potential.py \
     --L $L --beta $BETA --ntherm 400 --nmeas $NMEAS --skip 10 --rmax $RMAX --tmax $TMAX \
     --out runs/pot_L${L}_b${BETA}_T${TMAX} --wall $(( 6*3600 - 1800 ))
