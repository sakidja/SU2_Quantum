import numpy as np, json, warnings; warnings.filterwarnings("ignore")
from lock_sim import *
import pennylane as qml
# 1) PennyLane cross check of the loop interferometer
dev=qml.device("default.qubit",wires=3)
@qml.qnode(dev)
def probe(links,n):
    qml.Hadamard(0); qml.Hadamard(1); qml.CNOT([1,2])      # neutrino in |+>, target-reference Bell pair
    for _ in range(n):
        for U in links[::-1]: qml.ControlledQubitUnitary(U, wires=[0,1])   # operator product U_1 U_2 ... U_N
    return qml.expval(qml.PauliX(0)), qml.expval(qml.PauliY(0))
rng=np.random.default_rng(7); md=0
for kind in ["random","locked"]:
    for _ in range(20):
        L=config(rng,8,kind,np.pi/3,0.0); W=holonomy(L); Wn=I2.copy()
        for n in range(5):
            x,y=probe(L,n); md=max(md,abs(float(x)-np.real(np.trace(Wn))/2),abs(float(y)))
            Wn=Wn@W
print("PennyLane vs holonomy formula, max deviation:",md)
# 2) Parallel (local) probe cannot see the winding
def parallel_V(links,rng):
    coh=1+0j
    for U in links:
        v=rng.normal(size=2)+1j*rng.normal(size=2); v/=np.linalg.norm(v)
        coh*=v.conj()@U@v
    return 1-abs(coh)**2
res={}
for kind in ["random","locked"]:
    rng=np.random.default_rng(11); V=[parallel_V(config(rng,8,kind,np.pi),rng) for _ in range(4000)]
    res[kind]=(float(np.mean(V)),float(np.std(V)/np.sqrt(len(V))))
print("Parallel probe V_nu: random %.4f ± %.4f, locked %.4f ± %.4f"%(*res["random"],*res["locked"]))
json.dump({"pennylane_max_dev":md,"parallel_probe":res},open("lock_checks.json","w"),indent=1)
