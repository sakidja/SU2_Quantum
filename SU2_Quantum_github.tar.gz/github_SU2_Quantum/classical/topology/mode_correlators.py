#!/usr/bin/env python3
"""
mode_correlators.py
Job 15: correlations of the three twist modes in space (Figure T11).

Jobs 13 and 14 fix the three mode populations (0.692 / 0.266 / 0.041) and show that the
lock forms at a fixed physical size, about 7/g^2. The step from strata to masses needs the
stiffness of each mode. This job measures how the fluctuation of each mode is correlated in
space, the lattice route to a mass: a correlation that dies off as exp(-m r) defines m.

At every site and for every loop side R the three R x R loops based at x in the planes
(xy, xz, yz) give a gauge invariant 3 x 3 colour by plane matrix; its sorted squared singular
values s_1^2 >= s_2^2 >= s_3^2 are the mode amplitudes at x (R acts as a smearing size).
For each mode and each axis the amplitudes are summed over the planes perpendicular to the
axis (zero momentum slices). The analysis builds the connected slice correlator
    C_i(t) = < O_i(t0 + t) O_i(t0) > - < O_i >^2
and the effective mass m_i(t) = ln[C_i(t) / C_i(t + 1)], also in units of g^2 (a g^2 = 4/beta).

Expected behaviour, stated in advance: all three sorted singular values are scalars under
the lattice symmetry, so at large t their correlators generically decay with the same
lightest scalar mass. Differences between the modes, if any, are to be looked for at
distances within the lock scale, t a g^2 below about 7. The job reports both.

Every MPI rank is an independent chain; resumable npz per rank:
    <out>/mcorr_L{L}_rank{r}.npz
Analysis: mode_correlators_analysis.py

  python mode_correlators.py --L 12 --beta 3.0 --ntherm 100 --nmeas 10 --rmax 3 --out runs/mc12   # laptop
  srun -n 128 -c 2 --cpu-bind=cores python mode_correlators.py --L 32 --beta 3.0 --out runs/mc32_b3.0
"""
import argparse
import json
import os
import sys
import time

import numpy as np

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from topo_measure import line_products                                  # noqa: E402
from su2_topology_heatbath import sweep, rng_state_json, rng_from_json  # noqa: E402
from locked_modes import square_loops                                   # noqa: E402

try:
    from mpi4py import MPI
    COMM = MPI.COMM_WORLD
    RANK, SIZE = COMM.Get_rank(), COMM.Get_size()
except Exception:
    COMM, RANK, SIZE = None, 0, 1


def measure(links, rmax):
    """Returns slices (rmax, 3 axes, 3 modes, L): mode amplitudes s_i^2 summed over planes
    perpendicular to each axis, and pops (rmax, 3): mean populations s_i^2 / sum s^2 (check)."""
    L = links.shape[1]
    lines = [line_products(links[mu], mu, rmax) for mu in range(3)]
    sl = np.zeros((rmax, 3, 3, L))
    pops = np.zeros((rmax, 3))
    for R in range(1, rmax + 1):
        W = square_loops(links, R, lines)                          # (3 planes, L, L, L, 4)
        M = np.moveaxis(W[..., 1:], 0, -1)                          # (L, L, L, 3 colour, 3 plane)
        s = np.linalg.svd(M.reshape(-1, 3, 3), compute_uv=False)    # descending
        a = (s ** 2).reshape(L, L, L, 3)                            # mode amplitudes per site
        pops[R - 1] = (a / a.sum(-1, keepdims=True)).mean((0, 1, 2))
        for ax in range(3):
            other = tuple(d for d in range(3) if d != ax)
            sl[R - 1, ax] = a.sum(other).T                          # (3 modes, L)
    return sl, pops


def save(path, links, rng, sweeps, res, args):
    tmp = path + '.tmp.npz'
    sl = np.array([r[0] for r in res]) if res else np.zeros((0, args.rmax, 3, 3, args.L))
    po = np.array([r[1] for r in res]) if res else np.zeros((0, args.rmax, 3))
    np.savez(tmp, links=links, rng=rng_state_json(rng), sweeps_done=sweeps, slices=sl, pops=po,
             meta=json.dumps(dict(L=args.L, beta=args.beta, rmax=args.rmax, skip=args.skip,
                                  ntherm=args.ntherm, seed=args.seed)))
    os.replace(tmp, path)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--L', type=int, default=32)
    ap.add_argument('--beta', type=float, default=3.0)
    ap.add_argument('--ntherm', type=int, default=800)
    ap.add_argument('--nmeas', type=int, default=200)
    ap.add_argument('--skip', type=int, default=10)
    ap.add_argument('--rmax', type=int, default=4)
    ap.add_argument('--seed', type=int, default=20260926)
    ap.add_argument('--out', default='runs/mcorr')
    ap.add_argument('--ckpt_every', type=int, default=10)
    ap.add_argument('--wall', type=float, default=0)
    args = ap.parse_args()

    L = args.L
    os.makedirs(args.out, exist_ok=True)
    path = os.path.join(args.out, f'mcorr_L{L}_rank{RANK}.npz')
    t0 = time.time()
    idx = np.indices((L, L, L)).sum(0) % 2
    if os.path.exists(path):
        z = np.load(path, allow_pickle=False)
        links = z['links'].copy(); rng = rng_from_json(str(z['rng'])); sweeps = int(z['sweeps_done'])
        res = list(zip(z['slices'], z['pops']))
    else:
        rng = np.random.default_rng([args.seed, RANK])
        links = np.zeros((3, L, L, L, 4)); links[..., 0] = 1.0
        sweeps, res = 0, []
    if RANK == 0:
        print(f'[mode correlators] L={L} beta={args.beta} ranks={SIZE} rmax={args.rmax} '
              f'nmeas={args.nmeas} out={args.out}', flush=True)
    stopped = False
    while sweeps < args.ntherm:
        sweep(links, args.beta, rng, idx); sweeps += 1
        if sweeps % 50 == 0:
            save(path, links, rng, sweeps, res, args)
            if args.wall and time.time() - t0 > args.wall:
                stopped = True; break
    while not stopped and len(res) < args.nmeas:
        for _ in range(args.skip):
            sweep(links, args.beta, rng, idx); sweeps += 1
        res.append(measure(links, args.rmax))
        if len(res) % args.ckpt_every == 0 or len(res) == args.nmeas:
            save(path, links, rng, sweeps, res, args)
            if RANK == 0:
                print(f'  rank0 {len(res)}/{args.nmeas}  populations R={args.rmax}: '
                      f'{np.round(res[-1][1][-1], 4)}  t={time.time()-t0:.0f}s', flush=True)
        if args.wall and time.time() - t0 > args.wall:
            stopped = True
    save(path, links, rng, sweeps, res, args)
    if COMM is not None:
        COMM.Barrier()
    if RANK == 0:
        print('stopped at wall limit; rerun the same command to resume' if stopped else 'done', flush=True)


if __name__ == '__main__':
    main()
