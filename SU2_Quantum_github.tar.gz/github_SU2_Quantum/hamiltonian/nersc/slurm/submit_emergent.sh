#!/bin/bash
# Emergent global symmetry: the Hamiltonian is solved without the singlet
# restriction; the vacuum's charge sector is read off.
#   bash slurm/submit_emergent.sh        (from the nersc folder)
# Outputs: results/emergent_<case>.json
# Part of the SU2_Quantum project. Drafted with AI (LLM) assistance (Claude, Anthropic).
set -e
mkdir -p logs results
e () {  # name walltime args
  sbatch --job-name=$1 --time=$2 \
         --export=ALL,NPROC=1,OMP=64,CMD="python emergent_symmetry.py $3 --out results/$1" \
         slurm/run_script.sbatch
}
e emergent_t11_j2     00:30:00 "--system torus1x1 --jmax 2"
e emergent_t11_j3     01:00:00 "--system torus1x1 --jmax 3"
e emergent_open21_j2  01:00:00 "--system open2x1  --jmax 2"
e emergent_t21_j1     00:30:00 "--system torus2x1 --jmax 1"
e emergent_t21_j1.5   02:00:00 "--system torus2x1 --jmax 1.5"
e emergent_t31_j1     04:00:00 "--system torus3x1 --jmax 1"
e emergent_t22_j0.5   01:00:00 "--system torus2x2 --jmax 0.5"
