#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
su2_lattice_scaling.py
SU(2) random sampling on an L x L planar lattice - HPC version for
NERSC Perlmutter. Generalizes the 3x3 (9-qubit) simulation to arbitrary
lattice size for finite-size scaling of the variance locking and the
geometric floor Delta_weak.

Physics is identical to the corrected v4 notebooks:
  - neutrino qubit at the origin (node 0), gauge qubits on all other nodes
  - random single-qubit SU(2) rotations on every gauge qubit
  - entanglement along the true lattice links (gauge-gauge links),
    one parameter per link
  - neutrino coupling: RY rotation, then gauge-controlled CNOTs from the
    neutrino's lattice neighbors
  - no optimization of any kind; parameters uniform on [-pi, pi]
  - observables: <Z^(x)N>, Var(Z^(x)N), c_k averages over gauge qubits,
    m* = arccos(c0)/|c| per sample
  - fixed base seed for reproducibility (per-rank offset under MPI)

Usage (single node, serial):
    python3 su2_lattice_scaling.py --L 4 --samples 10000 --outdir run_L4

Usage (MPI across ranks, samples split automatically):
    srun -n 32 python3 su2_lattice_scaling.py --L 5 --samples 10000 \\
         --outdir run_L5 --device lightning.qubit

Memory guide (statevector, complex128): L=3: 8 KB, L=4: 1 MB,
L=5: 512 MB per rank. L=5 with 32 ranks/node needs ~16 GB + overhead;
reduce ranks-per-node or use --device lightning.gpu on GPU nodes.

Author: Ridwan Sakidja (HPC adaptation)
"""
import argparse, json, os, sys, time, glob
import numpy as np

# ---------------------------------------------------------------- MPI (optional)
try:
    from mpi4py import MPI
    COMM = MPI.COMM_WORLD
    RANK, NPROCS = COMM.Get_rank(), COMM.Get_size()
except ImportError:
    COMM, RANK, NPROCS = None, 0, 1

def log(msg):
    if RANK == 0:
        print(msg, flush=True)

# ---------------------------------------------------------------- lattice
class SU2_Lattice_LxL:
    """L x L planar lattice. Node 0 = neutrino at origin (0,0);
    all other nodes are gauge qubits. Links along +x and +y."""
    def __init__(self, L):
        self.L = L
        self.n_qubits = L * L
        self.n_gauge = self.n_qubits - 1
        self.node_positions = {y * L + x: (x, y)
                               for y in range(L) for x in range(L)}
        self.links = []
        for y in range(L):
            for x in range(L):
                i = y * L + x
                if x + 1 < L: self.links.append((i, i + 1))
                if y + 1 < L: self.links.append((i, i + L))
        self.neutrino_index = 0
        self.gauge_links = [(a, b) for (a, b) in self.links
                            if a != 0 and b != 0]
        self.neutrino_neighbors = sorted({b for (a, b) in self.links
                                          if a == 0}
                                         | {a for (a, b) in self.links
                                            if b == 0})

# ---------------------------------------------------------------- circuit
class SU2_Lattice_LLL:
    """L x L x L cubic lattice: neutrino at the origin, gauge qubits on
    every other site, links along all three axes with periodic wrap for
    L > 2 handled by nearest-neighbor pairs (open boundaries; the 2x2x2
    published control used the same convention)."""
    def __init__(self, L):
        self.L = L
        self.n_qubits = L ** 3
        idx = lambda x, y, z: (z * L + y) * L + x
        self.links = []
        for z in range(L):
            for y in range(L):
                for x in range(L):
                    i = idx(x, y, z)
                    if x + 1 < L: self.links.append((i, idx(x + 1, y, z)))
                    if y + 1 < L: self.links.append((i, idx(x, y + 1, z)))
                    if z + 1 < L: self.links.append((i, idx(x, y, z + 1)))
        self.n_gauge = self.n_qubits - 1
        self.neutrino_index = 0
        self.gauge_links = [(a, b) for (a, b) in self.links if a and b]
        self.neutrino_neighbors = sorted({b for (a, b) in self.links
                                          if a == 0}
                                         | {a for (a, b) in self.links
                                            if b == 0})

def build_circuit(lat, device_name):
    import pennylane as qml
    n = lat.n_qubits
    dev = qml.device(device_name, wires=n)
    n_rot = 3 * lat.n_gauge
    n_link = len(lat.gauge_links)

    @qml.qnode(dev)
    def circuit(params):
        # random SU(2) rotations on gauge qubits (nodes 1..n-1)
        for i in range(lat.n_gauge):
            g = i + 1
            qml.RY(params[3 * i], wires=g)
            qml.RZ(params[3 * i + 1], wires=g)
            qml.RX(params[3 * i + 2], wires=g)
        # entanglement along the true lattice links (gauge-gauge)
        for m, (a, b) in enumerate(lat.gauge_links):
            qml.CNOT(wires=[a, b])
            qml.RZ(params[n_rot + m], wires=b)
            qml.CNOT(wires=[a, b])
        # neutrino coupling: rotate, then entangle with lattice neighbors
        qml.RY(params[n_rot + n_link], wires=0)
        for nb in lat.neutrino_neighbors:
            qml.CNOT(wires=[nb, 0])
        return qml.state()

    n_params = n_rot + n_link + 1
    return circuit, n_params

# ---------------------------------------------------------------- estimators
class FastEstimators:
    """<psi|A|psi> by direct statevector contraction. Identical to the
    dense-operator definitions Tr[rho A] to machine precision; scales to
    lattice sizes where dense operators are impossible."""
    def __init__(self, n_qubits):
        self.n = n_qubits
        self.n_gauge = n_qubits - 1
        self.sx = np.array([[0, 1], [1, 0]], dtype=complex)
        self.sy = np.array([[0, -1j], [1j, 0]], dtype=complex)
        self.sz = np.array([[1, 0], [0, -1]], dtype=complex)
        # parity of set bits -> diagonal of Z^(x)n, vectorized
        idx = np.arange(2 ** n_qubits, dtype=np.uint64)
        par = idx.copy()
        shift = 1
        while shift < n_qubits:
            par ^= par >> np.uint64(shift)
            shift *= 2
        self.z_diag = (1.0 - 2.0 * (par & np.uint64(1))).astype(np.float32)
        del idx, par

    def _expval_1q(self, psi_t, sigma, q):
        phi = np.tensordot(sigma, psi_t, axes=([1], [q]))
        phi = np.moveaxis(phi, 0, q)
        return float(np.real(np.vdot(psi_t, phi)))

    def measure(self, psi):
        """Memory-lean single-pass estimators (validated identical to the
        dense-operator definitions; complex64 contractions, error ~1e-7)."""
        psi = np.asarray(psi).astype(np.complex64)
        probs = psi.real ** 2 + psi.imag ** 2
        mean = float(self.z_diag @ probs)
        var = 1.0 - mean * mean              # (Z^N)^2 = identity, exact
        c = np.zeros(3)
        for q in range(1, self.n):
            A, B = 2 ** q, 2 ** (self.n - q - 1)
            pt = psi.reshape(A, 2, B)
            r01 = np.einsum("ab,ab->", pt[:, 0, :], pt[:, 1, :].conj())
            pz = probs.reshape(A, 2, B)
            sz = float(pz[:, 0, :].sum() - pz[:, 1, :].sum())
            c[0] += 2 * r01.real
            c[1] += -2 * r01.imag
            c[2] += sz
        c /= self.n_gauge
        c0 = np.sqrt(max(0.0, 1 - float((c ** 2).sum())))
        theta = np.arccos(np.clip(c0, -1, 1))
        div = float(np.linalg.norm(c)) + 1e-8
        return mean, var, theta / div, c0

# ---------------------------------------------------------------- main
def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--L", type=int, default=5, help="lattice side (qubits=L^2)")
    ap.add_argument("--samples", type=int, default=10000,
                    help="total samples across all ranks")
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--device", default="lightning.qubit",
                    help="lightning.qubit | lightning.gpu | default.qubit")
    ap.add_argument("--outdir", default="run_out")
    ap.add_argument("--checkpoint-every", type=int, default=50)
    ap.add_argument("--resume", action="store_true",
                    help="resume from ckpt_rank*.npz in --outdir: reload "
                         "partial results, realign the random stream, "
                         "and continue")
    ap.add_argument("--cubic", action="store_true",
                    help="use an L x L x L cubic lattice (L**3 qubits) "
                         "instead of the planar L x L lattice")
    ap.add_argument("--alpha", type=float, default=1.0,
                    help="excitation amplitude: parameters sampled uniformly "
                         "from [-alpha*pi, alpha*pi]; 1.0 = fully driven "
                         "(saturated) ensemble, smaller = weaker driving. "
                         "Still pure random sampling; no optimization.")
    ap.add_argument("--merge-checkpoints", action="store_true",
                    help="assemble results from ckpt_rank*.npz in --outdir "
                         "(recover a timed-out run) and exit")
    args = ap.parse_args()
    if args.merge_checkpoints:
        import glob as _g
        files = sorted(_g.glob(os.path.join(args.outdir, "ckpt_rank*.npz")))
        if not files:
            log("no checkpoint files found"); sys.exit(1)
        data = {k: np.concatenate([np.load(f)[k] for f in files])
                for k in ["means", "variances", "deltas", "c0"]}
        np.savez(os.path.join(args.outdir, f"results_L{args.L}_recovered.npz"),
                 **data)
        m = data["deltas"]
        log(f"recovered {len(m)} samples from {len(files)} rank checkpoints")
        log(f"Var        = {data['variances'].mean():.6f} +/- "
            f"{data['variances'].std():.6f}")
        log(f"Delta_weak = {m.mean():.6f} +/- {m.std():.6f}   "
            f"min m* = {m.min():.6f}   below 1.0: {(m < 1.0).sum()}")
        sys.exit(0)

    lat = (SU2_Lattice_LLL(args.L) if args.cubic else SU2_Lattice_LxL(args.L))
    n = lat.n_qubits
    log("=" * 64)
    log(f"SU(2) random sampling, {args.L}x{args.L}" + ("x" + str(args.L) if args.cubic else "") + f" lattice ({n} qubits), "
        f"{args.samples} samples, {NPROCS} rank(s), device={args.device}")
    log("No optimization: parameters uniform on [-pi, pi]; seed "
        f"{args.seed} (+rank offset).")
    log("=" * 64)

    try:
        circuit, n_params = build_circuit(lat, args.device)
    except Exception as e:
        log(f"device {args.device} unavailable ({e}); falling back to "
            "default.qubit")
        circuit, n_params = build_circuit(lat, "default.qubit")

    est = FastEstimators(n)
    rng = np.random.default_rng(args.seed + RANK)

    my_n = args.samples // NPROCS + (1 if RANK < args.samples % NPROCS else 0)
    means, variances, deltas, c0s = [], [], [], []
    os.makedirs(args.outdir, exist_ok=True)
    start = 0
    if args.resume:
        _ck = os.path.join(args.outdir, f"ckpt_rank{RANK}.npz")
        if os.path.exists(_ck):
            _z = np.load(_ck)
            means, variances, deltas, c0s = (list(_z["means"]),
                list(_z["variances"]), list(_z["deltas"]), list(_z["c0"]))
            start = len(means)
            for _ in range(start):
                rng.uniform(-args.alpha * np.pi, args.alpha * np.pi,
                            n_params)          # burn to realign the stream
            print(f"[rank {RANK}] resuming at sample {start}/{my_n}",
                  flush=True)
    t0 = time.time()
    for s in range(start, my_n):
        params = rng.uniform(-args.alpha * np.pi, args.alpha * np.pi, n_params)
        psi = circuit(params)
        m, v, d, c0 = est.measure(np.array(psi))
        means.append(m); variances.append(v); deltas.append(d); c0s.append(c0)
        if RANK == 0 and s % 500 == 0:
            print(f"  rank0 sample {s:6d}/{my_n}  <Z>={m:+.4f}  Var={v:.4f}"
                  f"  m*={d:.4f}  ({time.time()-t0:.0f}s)", flush=True)
        if s and s % args.checkpoint_every == 0:
            np.savez(os.path.join(args.outdir, f"ckpt_rank{RANK}.npz"),
                     means=means, variances=variances, deltas=deltas, c0=c0s)

    data = {k: np.array(v) for k, v in
            [("means", means), ("variances", variances),
             ("deltas", deltas), ("c0", c0s)]}

    if COMM is not None and NPROCS > 1:
        gathered = COMM.gather(data, root=0)
        if RANK == 0:
            data = {k: np.concatenate([g[k] for g in gathered])
                    for k in data}
    if RANK != 0:
        return

    np.savez(os.path.join(args.outdir, f"results_L{args.L}.npz"), **data)
    summary = {
        "L": args.L, "cubic": bool(args.cubic), "n_qubits": n, "n_samples": int(len(data["means"])),
        "seed": args.seed, "device": args.device, "alpha": args.alpha,
        "mean": [float(np.mean(data["means"])), float(np.std(data["means"]))],
        "variance": [float(np.mean(data["variances"])),
                     float(np.std(data["variances"]))],
        "delta_weak": [float(np.mean(data["deltas"])),
                       float(np.std(data["deltas"]))],
        "delta_min": float(np.min(data["deltas"])),
        "c0_sq_mean": float(np.mean(data["c0"] ** 2)),
        "wall_seconds": time.time() - t0,
    }
    with open(os.path.join(args.outdir, f"summary_L{args.L}.json"), "w") as f:
        json.dump(summary, f, indent=2)
    log("-" * 64)
    log(f"L={args.L} ({n} qubits), {summary['n_samples']} samples, "
        f"{summary['wall_seconds']:.0f}s")
    log(f"  <Z^(x){n}>  = {summary['mean'][0]:+.4f} +/- {summary['mean'][1]:.4f}")
    log(f"  Var        = {summary['variance'][0]:.4f} +/- "
        f"{summary['variance'][1]:.4f}")
    log(f"  Delta_weak = {summary['delta_weak'][0]:.4f} +/- "
        f"{summary['delta_weak'][1]:.4f}   (min m* = {summary['delta_min']:.4f})")
    log(f"  <c0^2>     = {summary['c0_sq_mean']:.4f}")
    log("-" * 64)

    # headless figures
    try:
        import matplotlib
        matplotlib.use("Agg")
        import matplotlib.pyplot as plt
        fig, (a1, a2) = plt.subplots(1, 2, figsize=(13, 5))
        a1.hist(data["variances"], bins=60, color="#2E86AB", alpha=0.75,
                edgecolor="black", linewidth=0.4)
        a1.axvline(1, color="black", lw=1.4, label="SU(2) bound (Var=1)")
        a1.axvline(summary["variance"][0], color="red", ls="--", lw=1.6,
                   label=f"mean {summary['variance'][0]:.4f}")
        a1.set_xlabel(f"Var(Z^(x){n})"); a1.set_ylabel("frequency")
        a1.set_title(f"{args.L}x{args.L}: variance locking"); a1.legend()
        a2.hist(data["deltas"], bins=60, color="#A23B72", alpha=0.75,
                edgecolor="black", linewidth=0.4)
        a2.axvline(summary["delta_weak"][0], color="red", ls="--", lw=1.6,
                   label=f"mean {summary['delta_weak'][0]:.4f}")
        a2.set_xlabel("m* (lattice units)"); a2.set_ylabel("frequency")
        a2.set_title(f"{args.L}x{args.L}: geometric floor"); a2.legend()
        fig.suptitle(f"SU(2) random sampling, L={args.L} ({n} qubits), "
                     f"{summary['n_samples']} samples", fontweight="bold")
        fig.tight_layout()
        fig.savefig(os.path.join(args.outdir, f"locking_L{args.L}.png"),
                    dpi=200)
    except Exception as e:
        log(f"(figure generation skipped: {e})")

if __name__ == "__main__":
    main()
