#!/usr/bin/env python3
"""
combine_twist.py: twist free energy from the per lambda runs of
su2_twist_free_energy.py.

    python3 combine_twist.py run_tw            # every *.json in the folder
    python3 combine_twist.py run_tw --nodes 8  # check that each case has the 8 Gauss Legendre nodes

For each (Lx, Lt, beta, nstacks) the runs at each lambda (several seeds are
pooled, chain to chain spread used for the error when there are several) are
integrated with Gauss Legendre weights:
    dF = 2 beta * n_stack_plaquettes * sum_i w_i <c0_stack>(lambda_i)
Writes twist_free_energy.json and prints dF, dF/Lt and, at lambda 0 and 1,
the full readout (mean c0, sum_k Var(c_k), hedgehog density).

Part of the SU2_Quantum project (R. Sakidja, Missouri State University).
Code drafted with AI (LLM) assistance (Claude, Anthropic) and reviewed by the author.
"""
import sys, os, glob, json, argparse
from collections import defaultdict
import numpy as np


def gl_nodes(n):
    x, w = np.polynomial.legendre.leggauss(n)
    return (x + 1) / 2, w / 2


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("folder")
    ap.add_argument("--nodes", type=int, default=8)
    a = ap.parse_args()
    lam_nodes, lam_w = gl_nodes(a.nodes)
    runs = [json.load(open(f)) for f in sorted(glob.glob(os.path.join(a.folder, "*.json")))
            if not f.endswith("twist_free_energy.json")]
    groups = defaultdict(lambda: defaultdict(list))
    for r in runs:
        if not r.get("n_configs"):
            continue
        key = (r["Lx"], r["Lt"], round(r["beta"], 6), r["nstacks"])
        groups[key][round(r["lam"], 10)].append(r)
    out = []
    for key in sorted(groups):
        Lx, Lt, beta, ns = key
        byl = groups[key]
        vals, errs, missing = [], [], []
        for lam in lam_nodes:
            k = min(byl, key=lambda l: abs(l - lam)) if byl else None
            if k is None or abs(k - lam) > 1e-6:
                missing.append(round(float(lam), 6)); vals.append(np.nan); errs.append(np.nan); continue
            rs = byl[k]
            m = np.array([r["stack_c0_mean"] for r in rs])
            e_int = np.sqrt(np.sum(np.array([r["stack_c0_err"] for r in rs]) ** 2)) / len(rs)
            e_ext = m.std(ddof=1) / np.sqrt(len(m)) if len(m) > 1 else 0.0
            vals.append(m.mean()); errs.append(max(e_int, e_ext))
        vals, errs = np.array(vals), np.array(errs)
        nplaq = ns * Lt
        rec = dict(Lx=Lx, Lt=Lt, beta=beta, nstacks=ns, nodes=a.nodes, missing_nodes=missing)
        if not missing:
            dF = 2 * beta * nplaq * float(np.sum(lam_w * vals))
            dF_err = 2 * beta * nplaq * float(np.sqrt(np.sum((lam_w * errs) ** 2)))
            rec.update(dF=dF, dF_err=dF_err, dF_per_Lt=dF / Lt, dF_per_Lt_err=dF_err / Lt,
                       lam=lam_nodes.tolist(), stack_c0=vals.tolist(), stack_c0_err=errs.tolist())
        for end in (0.0, 1.0):
            if end in byl and "full" in byl[end][0]:
                f = byl[end][0]["full"]
                rec[f"lambda{int(end)}"] = dict(mean_c0=f["mean_c0"], var_ck=f["var_ck"],
                                                Q_sq_per_cell=f["Q_sq_per_cell"])
        out.append(rec)
        line = f"Lx={Lx} Lt={Lt} beta={beta} stacks={ns}: "
        line += (f"dF = {rec['dF']:.4f} +- {rec['dF_err']:.4f}   dF/Lt = {rec['dF_per_Lt']:.5f} +- {rec['dF_per_Lt_err']:.5f}"
                 if not missing else f"missing lambda nodes {missing}")
        for end in ("lambda0", "lambda1"):
            if end in rec:
                q = rec[end]
                line += (f"\n    {end}: <c0> {q['mean_c0'][0]:.4f}  sum Var(c_k) {q['var_ck'][0]:.4f}  "
                         f"hedgehog sum Q^2/V {q['Q_sq_per_cell'][0]:.4f} +- {q['Q_sq_per_cell'][1]:.4f}")
        print(line)
    json.dump(out, open(os.path.join(a.folder, "twist_free_energy.json"), "w"), indent=1)


if __name__ == "__main__":
    main()
