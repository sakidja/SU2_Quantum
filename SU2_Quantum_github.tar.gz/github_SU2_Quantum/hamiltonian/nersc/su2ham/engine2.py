"""
Compact engine for gauge fixed SU(2) Hamiltonians on larger lattices.

Part of the SU2_Quantum project (R. Sakidja, Missouri State University).
Code drafted with AI (LLM) assistance (Claude, Anthropic) and reviewed by the author.

Why
---
engine.py stores every gauge invariant basis vector as a full Peter Weyl tensor
(prod_l (2 j_l + 1)^2 numbers per vector). On the 2x2 torus at jmax 1.5 that is
about 230 GB. Here only the gauge invariant content is stored, and each basis
vector exists in full only while its matrix elements are being computed, in
small batches. The physics, basis and truncation are identical to engine.py,
so the two engines give the same numbers (checked to machine precision).

Representation
--------------
In a block js = (j_1, ..., j_N), a coefficient tensor is a d x d matrix Psi
(rows m_1..m_N, columns n_1..n_N, d = prod (2 j_l + 1)). Gauge invariant states
have the form
    Psi = B^T Z B,   Z = (+)_J  X_J (x) 1_{2J+1} / sqrt(2J+1),
with B the orthogonal change to the coupled basis (coupling chains of the j_l
to total J). The coordinates x = (X_J) are the coefficients on engine.py's
orthonormal invariant basis. Truncated fields on the gauge fixed tree links
are handled as in engine.py: per block, the subspace with every such field at
j <= jmax is kept (columns of V), and the electric energy is block diagonal.
"""
import itertools
import os
import multiprocessing as mp
import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla
from .engine import (jvals, dim, coupling_paths, apply_word_trace, apply_field_casimir, inner)

CHUNK_ENTRIES = float(os.environ.get("SU2HAM_CHUNK", "2e8"))   # batch size in matrix entries


def to_tensor(Psi, js):
    """(c, d, d) matrices -> engine tensors (c, m1, n1, m2, n2, ...)."""
    dims = [dim(j) for j in js]
    N = len(js)
    T = Psi.reshape((Psi.shape[0],) + tuple(dims + dims))
    order = [0] + [x + 1 for l in range(N) for x in (l, N + l)]
    return np.transpose(T, order)


def to_matrix(T, js):
    """engine tensors (c, m1, n1, ...) -> (c, d, d)."""
    N = len(js)
    order = [0] + [2 * l + 1 for l in range(N)] + [2 * l + 2 for l in range(N)]
    d = int(np.prod([dim(j) for j in js]))
    return np.transpose(T, order).reshape(T.shape[0], d, d)


class Block:
    def __init__(self, js):
        self.js = js
        self.d = int(np.prod([dim(j) for j in js]))
        rows, self.sectors = [], []
        byJ = {}
        for path, J, A in coupling_paths(js):
            byJ.setdefault(round(2 * J), []).append(A.reshape(A.shape[0], -1))
        off = 0
        for J2 in sorted(byJ):
            mats = byJ[J2]
            self.sectors.append((J2 / 2, len(mats), off))
            for A in mats:
                rows.append(A)
                off += A.shape[0]
        self.B = np.vstack(rows)
        self.nx = sum(m * m for (_, m, _) in self.sectors)
        self.V = None

    def x_to_psi(self, X):
        """(c, nx) coordinates -> (c, d, d) matrices."""
        c = X.shape[0]
        Z = np.zeros((c, self.d, self.d))
        k = 0
        for (J, m, off) in self.sectors:
            g = int(round(2 * J + 1))
            Xs = X[:, k:k + m * m].reshape(c, m, m) / np.sqrt(g)
            k += m * m
            for M in range(g):
                Z[:, off + M:off + m * g:g, off + M:off + m * g:g] = Xs
        return np.matmul(np.matmul(self.B.T[None], Z), self.B[None])

    def psi_to_x(self, Psi):
        """(c, d, d) matrices -> (c, nx) coordinates (projection onto invariant states)."""
        Y = np.matmul(np.matmul(self.B[None], Psi), self.B.T[None])
        out = []
        for (J, m, off) in self.sectors:
            g = int(round(2 * J + 1))
            acc = 0
            for M in range(g):
                acc = acc + Y[:, off + M:off + m * g:g, off + M:off + m * g:g]
            out.append((acc / np.sqrt(g)).reshape(Y.shape[0], -1))
        return np.concatenate(out, axis=1)

    def chunks(self, ncols):
        step = max(1, int(CHUNK_ENTRIES // max(1, self.d * self.d)))
        return [(s, min(ncols, s + step)) for s in range(0, ncols, step)]

    def basis_psi(self, s, e):
        """Kept basis vectors s..e-1 (columns of V) as (c, d, d) matrices."""
        return self.x_to_psi(self.V[:, s:e].T)


_G = {}


def _build_block(args):
    js, jcap, constraints, energy = args
    b = Block(js)
    if b.nx == 0:
        return js, None, None
    b.V = np.eye(b.nx)

    def field_matrix(pieces):
        nk = b.V.shape[1]
        M = np.zeros((nk, nk))
        for s, e in b.chunks(nk):
            Psi = b.basis_psi(s, e)
            Ct = apply_field_casimir({js: to_tensor(Psi, js)}, pieces)[js]
            X = b.psi_to_x(np.real(to_matrix(Ct, js)))
            M[:, s:e] = (X @ b.V).T
        return 0.5 * (M + M.T)

    for pieces in constraints:
        C = field_matrix(pieces)
        w, U = np.linalg.eigh(C)
        keep = w <= jcap
        if not keep.any():
            return js, None, None
        b.V = b.V @ U[:, keep]
    nk = b.V.shape[1]
    E = np.zeros((nk, nk))
    for coef, kind, data in energy:
        if kind == "cas":
            j = js[data]
            E += coef * j * (j + 1) * np.eye(nk)
        else:
            E += coef * field_matrix(data)
    return js, b, E


def _operator_block(js):
    blocks, index, word = _G["blocks"], _G["index"], _G["word"]
    b = blocks[js]
    o_s, n_s = index[js]
    rows, cols, vals = [], [], []
    for s, e in b.chunks(n_s):
        img = apply_word_trace({js: to_tensor(b.basis_psi(s, e), js)}, word)
        for key, T in img.items():
            if key not in blocks:
                continue
            bt = blocks[key]
            o_t, n_t = index[key]
            M = (bt.psi_to_x(to_matrix(T, key)) @ bt.V).T        # (n_t, e - s)
            r, c = np.nonzero(np.abs(M) > 1e-14)
            rows.append(o_t + r); cols.append(o_s + s + c); vals.append(M[r, c])
    if not rows:
        return np.zeros(0, int), np.zeros(0, int), np.zeros(0)
    return np.concatenate(rows), np.concatenate(cols), np.concatenate(vals)


class CompactSystem:
    """Same interface as engine.GaugeFixedSystem."""

    def __init__(self, N, jmax, plaquettes, energy, constraints=(), verbose=False):
        self.N, self.jmax, self.plaquettes = N, jmax, plaquettes
        jcap = jmax * (jmax + 1) + 1e-8
        tasks = [(js, jcap, list(constraints), list(energy))
                 for js in itertools.product(jvals(jmax), repeat=N)]
        tasks.sort(key=lambda t: -int(np.prod([dim(j) for j in t[0]])))
        nproc = int(os.environ.get("SU2HAM_NPROC", "1"))
        if nproc > 1:
            with mp.get_context("fork").Pool(nproc) as pool:
                built = pool.map(_build_block, tasks, chunksize=1)
        else:
            built = [_build_block(t) for t in tasks]
        built.sort(key=lambda r: r[0])
        self.blocks, self.index, Ediag = {}, {}, []
        off = 0
        for js, b, E in built:
            if b is None:
                continue
            self.blocks[js] = b
            self.index[js] = (off, b.V.shape[1])
            Ediag.append(E)
            off += b.V.shape[1]
        self.n = off
        self.Eel = sp.block_diag(Ediag, format="csr")
        self.max_asymmetry = 0.0
        self.Cp = [self._operator(w) for w in plaquettes]
        if verbose:
            mem = sum(b.B.nbytes + b.V.nbytes for b in self.blocks.values()) / 1e9
            print(f"  {self.n} invariant states in {len(self.blocks)} blocks, stored bases {mem:.2f} GB", flush=True)

    def _operator(self, word):
        _G.update(blocks=self.blocks, index=self.index, word=word)
        keys = sorted(self.blocks, key=lambda k: -self.blocks[k].d)
        nproc = int(os.environ.get("SU2HAM_NPROC", "1"))
        if nproc > 1:
            with mp.get_context("fork").Pool(nproc) as pool:
                parts = pool.map(_operator_block, keys, chunksize=1)
        else:
            parts = [_operator_block(k) for k in keys]
        rows = np.concatenate([p[0] for p in parts]); cols = np.concatenate([p[1] for p in parts])
        vals = np.concatenate([p[2] for p in parts])
        A = sp.csr_matrix((vals, (rows, cols)), shape=(self.n, self.n))
        asym = abs(A - A.T).max() if A.nnz else 0.0
        self.max_asymmetry = max(self.max_asymmetry, float(asym))
        return 0.5 * (A + A.T)

    def hamiltonian(self, g2, signs=None):
        signs = signs or [1] * len(self.Cp)
        H = 0.5 * g2 * self.Eel
        for s, C in zip(signs, self.Cp):
            H = H + (4.0 / g2) * (sp.identity(self.n) - s * C)
        return H.tocsr()

    def lowest(self, g2, signs=None, k=4):
        H = self.hamiltonian(g2, signs)
        if self.n <= 1500:
            w, v = np.linalg.eigh(H.toarray())
            return w[:k], v[:, :k]
        w, v = spla.eigsh(H, k=k, which="SA", tol=1e-11)
        o = np.argsort(w)
        return w[o], v[:, o]

    def state(self, coeffs):
        st = {}
        for js, b in self.blocks.items():
            o, n = self.index[js]
            c = coeffs[o:o + n]
            if np.any(c):
                st[js] = to_tensor(b.x_to_psi((b.V @ c)[None]), js)
        return st

    def plaquette_moments(self, psi_state):
        res, imgs = [], []
        for w in self.plaquettes:
            img = apply_word_trace(psi_state, w)
            res.append((float(np.real(inner(psi_state, img)).ravel()[0]),
                        float(np.real(inner(img, img)).ravel()[0])))
            imgs.append(img)
        return res, imgs
