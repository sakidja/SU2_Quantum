# 4D SU(2): the lock and the three twist modes in four dimensions

The 3D campaign in `../topology` is repeated in four dimensions, the setting of
Creutz, Phys. Rev. D 21, 2308 (1980). Same action (Wilson), same update (Creutz heat
bath with the Kennedy Pendleton sampler, quaternion links U = a0 + i a.sigma), same
center vortex and mode measurements. Only the dimension changes.

## What is measured (one pass per configuration, su2_4d_production.py)

1. Plaquette <1/2 Tr P> in all six planes, and sum_k Var(c_k).
2. Wilson loops W(R, T): Creutz ratios and the static potential, which give the string
   tension a^2 sigma. In 4D the coupling is dimensionless, so the physical scale is set
   by the string tension (as Creutz did), not by g^2 as in 3D. Loop sizes are quoted as
   x = R a sqrt(sigma).
3. Center vortices: direct maximal center gauge, center projection, P vortex plaquettes.
   Every square loop in all six planes is sorted by the number n_v of vortices on its
   surface: W_nv/W_0 and W_odd/W_even, for spatial and temporal planes separately.
4. Three twist modes, option A: on every time slice, the three square loops in the
   spatial planes (xy, xz, yz) based at the same site, exactly as in 3D
   (locked_modes.py). Populations s_i^2/sum s^2, split ratio, axis products, and the
   null that removes only the relative orientation.

## Local validation (8^4, 40 configurations, before any NERSC time)

| | beta = 2.3 | beta = 2.5 | standard 4D SU(2) value |
|---|---|---|---|
| plaquette | 0.6024(8) | 0.6525(4) | about 0.602 and 0.652 |
| populations, R >= 3 | 0.6924, 0.2663, 0.0412 | 0.6924, 0.2663, 0.0413 | 3D: 0.6924, 0.2664, 0.0412 |
| W_odd/W_even at R = 4 | -0.45(4) | +0.16(4) | lock forms at larger R when a is smaller |

beta = 2.4 at 10^4 gave 0.6315(5) (standard value about 0.630).
8^4 is too small for the string tension at beta = 2.5 and for the complete lock; that is
what the 16^4 and 20^4 runs are for.

## Neutrino probe in the ground state

The analysis also writes `FigT6_4D_L{L}_b{beta}.png`, the 4D counterpart of Figure T6:
the coherence C_n = <cos n psi> of the probe carried n = 1..6 times around a loop, by
vortex number and by vortex parity, for spatial and temporal planes separately. A loop
in a temporal plane is the worldline of a static source, the probe sitting in the medium
while Euclidean time passes. No extra production cost: the production script already
stores cos(j psi), j = 1..6, per loop class.

## Run order on Perlmutter

Submit every job from inside `slurm/`: the scripts change to the parent folder
(`cd "$SLURM_SUBMIT_DIR/.."`), so `cd slurm` first and then `sbatch 21_4d_run.sh ...`.
On Perlmutter `sacct` reports job states reliably; `squeue` and `sqs` can hang.

Put your NERSC project name (as shown in Iris, for example m1234) in place of mXXXX in the
#SBATCH -A lines of every script in slurm/.

| Step | Command | Purpose | Time (1 CPU node, 128 chains) |
|---|---|---|---|
| 0 | `sbatch 20_4d_smoke.sh` | setup check | 10 min, debug queue |
| 1 | `sbatch 21_4d_run.sh 16 2.3 8 60` | main run | about 2 h |
| 2 | `sbatch 21_4d_run.sh 20 2.3 8 40` | volume check | about 3 h |
| 3 | `sbatch 21_4d_run.sh 16 2.2 8 60` | coupling scan | about 2 h |
| 4 | `sbatch 21_4d_run.sh 16 2.4 8 60` | coupling scan | about 2 h |
| 5 | `sbatch 21_4d_run.sh 20 2.5 10 40` | finest coupling, loops to R = 10 | about 3.5 h |
| 6 | `bash 22_4d_analysis.sh` | login node: summaries, lock profile | minutes |

Steps 1 to 5 are independent and can be queued together once step 0 passes. Every job
stops cleanly before its limit; resubmit the same line to resume. Times are estimates
from local profiling (gauge fixing is about 90 percent of the cost).

## Further checks (queue together)

| Step | Command | Objection it answers | Time |
|---|---|---|---|
| 7 | `sbatch 21_4d_run.sh 20 2.3 8 40` (resubmit) | finish the volume check | remaining ~2 h |
| 8 | `sbatch 21_4d_run.sh 20 2.4 8 40` | box size at beta = 2.4, where the lock needs R ~ 8 | about 3 to 4 h |
| 9 | `sbatch 23_4d_gribov.sh` | vortices depend on the gauge copy (best of three random starts) | about 3 to 4 h |
| 10 | `sbatch 24_4d_potential.sh 16 2.2`, `16 2.3`, `16 2.4`, `20 2.5` | one method for the string tension at every coupling (multihit loops; noise on V(R) about 3x lower at R = 4 in the local test) | 1 to 3 h each |
| 11 | `bash 25_4d_scale_and_profile.sh` | login node: the multihit scale and the lock profile with it | minutes |
| 12 | `sbatch 26_4d_mode_masses.sh 16 2.4` | time correlators of the three twist modes (su2_4d_mode_masses.py) | about 2.5 h |
| 13 | `sbatch 27_4d_fine.sh` | fifth coupling, beta = 2.6 on 32^4 (2 nodes; one measurement takes about 70 min, saved after each) | several 6 h jobs |
| 14 | `sbatch 28_4d_potential_fine.sh` | string tension at beta = 2.6 on 24^4 with T up to 12, to reach the plateau in time | several 6 h jobs |

The scale in the paper is read where the potential has reached its plateau in time:
`python su2_4d_potential_analysis.py runs/pot_L16_b2.3 --t0 5` and so on (T = 4, 5, 5, 7 at
beta = 2.2, 2.3, 2.4, 2.5).

## Outputs to send back

`figures_4d_L16_b2.3/`, `figures_4d_L20_b2.3/`, `figures_4d_bscan/`,
`figures_4d_bscan_litscale/` (each has the figures and summary JSON files).

## The questions the runs answer

* Does the Z2 sign rule reach W_odd/W_even = -1 in 4D, in spatial and temporal planes?
* Is the lock volume independent (16^4 against 20^4 at beta = 2.3)?
* Are the three populations 0.6924, 0.2664, 0.0412 in 4D as in 3D, real and null?
* Is the lock width fixed in physical units, 1/sqrt(sigma), while it changes in lattice
  units, as the width 1.20/g^2 is in 3D?

## Scale cross check

`22_4d_analysis.sh` also runs the analysis with approximate literature values of
a sqrt(sigma) (about 0.369, 0.266 and 0.188 at beta = 2.3, 2.4 and 2.5, from published
4D SU(2) string tension studies) through `--asig`. The measured scale from the runs
themselves is the primary one; the literature values are only a check.
