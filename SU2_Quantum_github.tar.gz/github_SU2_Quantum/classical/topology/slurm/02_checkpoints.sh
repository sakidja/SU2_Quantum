#!/bin/bash -l
# Same measurements on the existing S6 production checkpoints (L = 32),
# plus 20 further heat bath configurations from each, 10 sweeps apart.
#SBATCH -A mXXXX                  # <-- your NERSC project
#SBATCH -C cpu
#SBATCH -q regular
#SBATCH -N 1
#SBATCH -t 02:00:00
#SBATCH -J su2topo_ckpt
#SBATCH -o %x_%j.out
cd "$SLURM_SUBMIT_DIR/.."
source slurm/env_perlmutter.sh
CKPT_DIR=/path/to/your/checkpoints   # <-- folder holding ckpt_cl_L32_rank*.npz
srun -n 32 -c 8 --cpu-bind=cores "$PY" measure_checkpoints.py \
     --glob "$CKPT_DIR/ckpt_cl_L32_rank*.npz" --extra 20 --skip 10 --vortex_every 2 --out runs/ckpt32
"$PY" topology_figures.py runs/ckpt32/summary_topo_L32.json --outdir figures_ckpt32
