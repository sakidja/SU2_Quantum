"""
SU(2) gauge variance: Haar sampling on real lattices, quantum readout of c_k,
and a neutrino probe qubit coupled to the gauge field.
R. Sakidja, Missouri State University. Runs on Google Colab (pip install pennylane).

Part A  Haar random links on a 3x3 (2D) and 2x2x2 (3D) periodic lattice.
        Plaquettes P = U1 U2 U3^dag U4^dag, decomposed as P = c0 I + i sum_k c_k sigma_k.
Part B  Quantum readout: each c_k measured on qubits with a Hadamard test
        (ancilla + target + reference Bell pair), checked against the exact values.
Part C  Neutrino probe: qubit 0 in |+>, controlled SU(2) gates onto 8 gauge qubits,
        field on versus field off, neutrino variance V = 1 - <X>^2 - <Y>^2.
"""
import numpy as np, json, warnings
warnings.filterwarnings("ignore")

I2 = np.eye(2, dtype=complex)
SX = np.array([[0, 1], [1, 0]], complex)
SY = np.array([[0, -1j], [1j, 0]], complex)
SZ = np.array([[1, 0], [0, -1]], complex)
PAULI = [SX, SY, SZ]

def su2_from_c(c):
    return c[0] * I2 + 1j * (c[1] * SX + c[2] * SY + c[3] * SZ)

def haar_c(rng, size):
    """Uniform (Haar) points on S^3: four Gaussians, normalized."""
    x = rng.normal(size=(size, 4))
    return x / np.linalg.norm(x, axis=1, keepdims=True)

def c_from_su2(P):
    """P = c0 I + i sum c_k sigma_k  ->  c0 = Tr P / 2,  c_k = Tr(sigma_k P) / (2i)."""
    c0 = np.real(np.trace(P)) / 2
    ck = [np.real(np.trace(s @ P) / 2j) for s in PAULI]
    return np.array([c0, *ck])

# ---------------------------------------------------------------- Part A
def lattice_plaquettes(dims, rng):
    """All plaquettes of a periodic lattice with Haar random links."""
    D = len(dims)
    sites = list(np.ndindex(*dims))
    links = {}
    for s in sites:
        for mu in range(D):
            links[(s, mu)] = su2_from_c(haar_c(rng, 1)[0])
    def shift(s, mu):
        t = list(s); t[mu] = (t[mu] + 1) % dims[mu]; return tuple(t)
    out = []
    for s in sites:
        for mu in range(D):
            for nu in range(mu + 1, D):
                P = links[(s, mu)] @ links[(shift(s, mu), nu)] @ links[(shift(s, nu), mu)].conj().T @ links[(s, nu)].conj().T
                out.append(c_from_su2(P))
    return np.array(out)

def part_a(dims, n_cfg, seed):
    rng = np.random.default_rng(seed)
    C = np.concatenate([lattice_plaquettes(dims, rng) for _ in range(n_cfg)])
    unit = np.abs((C ** 2).sum(1) - 1).max()
    # block error bars over 20 blocks
    blocks = np.array_split(C, 20)
    sv = np.array([b[:, 1:].var(0).sum() for b in blocks])
    res = {
        "lattice": "x".join(map(str, dims)),
        "configurations": n_cfg,
        "plaquettes": len(C),
        "max |sum c^2 - 1|": float(unit),
        "mean c_k": C[:, 1:].mean(0).round(4).tolist(),
        "Var c_k": C[:, 1:].var(0).round(4).tolist(),
        "sum Var c_k": round(float(C[:, 1:].var(0).sum()), 4),
        "sum Var c_k err": round(float(sv.std(ddof=1) / np.sqrt(len(sv))), 4),
        "<c0^2>": round(float((C[:, 0] ** 2).mean()), 4),
        "<c0>": round(float(C[:, 0].mean()), 4),
    }
    return res, C

# ---------------------------------------------------------------- Part B
def hadamard_test_values(U, shots=None, seed=0):
    """Measure c0..c3 of a one qubit SU(2) gate U on 3 qubits with PennyLane.
    Wire 0: ancilla. Wires 1,2: Bell pair (target, reference) so the test returns Tr(V)/2.
    For V = U:          <X_anc> = Re Tr(U)/2 = c0
    For V = sigma_k U:  Tr(sigma_k U)/2 = i c_k, and the S^dag rotation gives <Z_anc> = Im Tr(V)/2 = c_k."""
    import pennylane as qml
    dev = qml.device("default.qubit", wires=3, shots=shots, seed=seed) if shots else qml.device("default.qubit", wires=3)
    @qml.qnode(dev)
    def circ(V, basis):
        qml.Hadamard(1); qml.CNOT([1, 2])          # Bell pair: target maximally mixed
        qml.Hadamard(0)
        qml.ControlledQubitUnitary(V, wires=[0, 1])
        if basis == "Y":
            qml.adjoint(qml.S)(0)
        qml.Hadamard(0)
        return qml.expval(qml.PauliZ(0))
    c0 = circ(U, "X")
    ck = [circ(s @ U, "Y") for s in PAULI]
    return np.array([float(c0), *[float(v) for v in ck]])

def part_b(n, shots, seed):
    rng = np.random.default_rng(seed)
    C = haar_c(rng, n)
    exact, meas = [], []
    for i, c in enumerate(C):
        U = su2_from_c(c)
        exact.append(hadamard_test_values(U))                  # statevector
        meas.append(hadamard_test_values(U, shots=shots, seed=i))  # finite shots
    exact, meas = np.array(exact), np.array(meas)
    return {
        "configurations": n, "shots per observable": shots,
        "max |circuit - c| (statevector)": float(np.abs(exact - C).max()),
        "rms |circuit - c| (shots)": float(np.sqrt(((meas - C) ** 2).mean())),
        "mean c_k (circuit, shots)": meas[:, 1:].mean(0).round(4).tolist(),
        "sum Var c_k (circuit, shots)": round(float(meas[:, 1:].var(0).sum()), 4),
        "sum Var c_k (exact)": round(float(C[:, 1:].var(0).sum()), 4),
    }, C, meas

# ---------------------------------------------------------------- Part C
def neutrino_probe(rng, field_on, spread, n_gauge=8):
    """Qubit 0 = neutrino in |+>; gauge qubits in random pure states;
    controlled U_j from the neutrino onto each gauge qubit. Returns V and the c's used."""
    N = n_gauge + 1
    psi = np.array([1, 1], complex) / np.sqrt(2)
    for _ in range(n_gauge):
        v = rng.normal(size=2) + 1j * rng.normal(size=2); psi = np.kron(psi, v / np.linalg.norm(v))
    psi = psi.reshape([2] * N)
    cs = []
    for j in range(n_gauge):
        if spread == "haar":
            c = haar_c(rng, 1)[0]
        else:
            v = np.concatenate([[1.0], spread * rng.normal(size=3)]); c = v / np.linalg.norm(v)
        cs.append(c)
        if field_on:
            sub = np.moveaxis(np.tensordot(su2_from_c(c), psi[1], axes=([1], [j])), 0, j)
            psi = np.stack([psi[0], sub])
    a = psi.reshape(2, -1); rho = a @ a.conj().T
    x = np.real(np.trace(rho @ SX)); y = np.real(np.trace(rho @ SY))
    return 1 - x * x - y * y, np.array(cs)

def part_c(n, seed):
    rng = np.random.default_rng(seed)
    rows = []
    for spread in [0.0, 0.1, 0.2, 0.35, 0.5, 0.75, 1.0, 1.5, "haar"]:
        V, C = [], []
        for _ in range(n):
            v, cs = neutrino_probe(rng, True, spread); V.append(v); C.append(cs)
        C = np.concatenate(C); S = float(C[:, 1:].var(0).sum())
        rows.append({"spread": str(spread), "sum Var c_k": round(S, 4),
                     "V_nu": round(float(np.mean(V)), 4), "V_nu err": round(float(np.std(V) / np.sqrt(n)), 4),
                     "theory 1-(1-2S/3)^8": round(1 - (1 - 2 * S / 3) ** 8, 4)})
    off = float(np.mean([neutrino_probe(rng, False, "haar")[0] for _ in range(500)]))
    return {"field off V_nu": round(off, 6), "field on": rows}

if __name__ == "__main__":
    out = {}
    out["A_2D"], C2 = part_a((3, 3), 2000, 1)
    out["A_3D"], C3 = part_a((2, 2, 2), 1000, 2)
    for dims, n in [((4, 4), 1000), ((5, 5), 800), ((3, 3, 3), 400)]:
        r, _ = part_a(dims, n, 11); out["A_" + r["lattice"]] = r
    out["B"], Cb, Mb = part_b(300, 2000, 3)
    out["C"] = part_c(3000, 4)
    np.save("c_2d.npy", C2); np.save("c_3d.npy", C3); np.save("b_exact.npy", Cb); np.save("b_meas.npy", Mb)
    json.dump(out, open("results.json", "w"), indent=1)
    print(json.dumps(out, indent=1))
