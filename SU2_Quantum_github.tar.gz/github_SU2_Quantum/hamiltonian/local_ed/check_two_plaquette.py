"""Consistency checks for the two plaquette machinery."""
import numpy as np
import scipy.sparse as sp
from su2_lattice_core import LinkSpace, invariant_basis_two_links, kron, jlist, mlist
from su2_two_plaquette_ed import build_open, solve_open, build_torus, solve_torus
from su2_plaquette_ed import observables as single_ed

print("1) Single plaquette through the new machinery vs the earlier code")
jmax = 3.0
Ls = LinkSpace(jmax + 1)
cols = []
for J in jlist(jmax):
    v = np.zeros(Ls.dim)
    for m in mlist(J):
        v[Ls.idx[(J, m, m)]] = 1.0
    cols.append(v / np.linalg.norm(v))
Bc = np.array(cols).T
ht = Ls.half_trace()
C = Bc.T @ (ht @ Bc)
EC = np.array([J * (J + 1) for J in jlist(jmax)])
for g2 in [0.5, 4 / 2.2, 5.0]:
    H = np.diag(2 * g2 * EC) + (4 / g2) * (np.eye(len(EC)) - C)
    w, v = np.linalg.eigh(H)
    psi = Bc @ v[:, 0]
    a = ht @ psi
    r = single_ed(g2, 20.0)
    print(f"   g2={g2:.3f}: new sumVar={1 - a @ a:.6f} gap={w[1]-w[0]:.6f} | old sumVar={r['sumVar_ck']:.6f} gap={r['gap']:.6f}")

print("2) Gauge invariance, orthonormality, j1 Casimir on the 2x1 basis")
S = build_open(1.5)
B = S["B"]
L1s, L2s = S["sp"]
La, Ka = L1s.generators()
Lb, Kb = L2s.generators()
I1 = sp.identity(L1s.dim); I2 = sp.identity(L2s.dim)
Kmax = max(abs(kron(Ka[a], I2) @ B + kron(I1, Kb[a]) @ B).max() for a in range(3))
print(f"   max |K B| = {Kmax:.2e}")
print(f"   max |B^T B - 1| = {abs((B.T @ B).toarray() - np.eye(B.shape[1])).max():.2e}")
Lsum = [kron(La[a], I2) + kron(I1, Lb[a]) for a in range(3)]
cas = sum(Lsum[a] @ (Lsum[a] @ B) for a in range(3))
j1 = np.array([l[2] for l in S["labels"]])
err = abs(cas - B @ sp.diags(j1 * (j1 + 1))).max()
print(f"   max |(L1+L2)^2 B - j1(j1+1) B| = {err:.2e}")

print("3) Reflection symmetry <c0_1> = <c0_2>, and 4) open lattice twist")
S = build_open(2.0)
for g2 in [0.5, 4 / 2.2, 5.0]:
    r = solve_open(S, g2)
    t = solve_open(S, g2, s1=-1)
    print(f"   g2={g2:.3f}: c0_1={r['c0_1']:.6f} c0_2={r['c0_2']:.6f} | E(untw)={r['E'][0]:.8f} E(tw)={t['E'][0]:.8f}"
          f"  max|dE|={max(abs(np.array(r['E'])-np.array(t['E']))):.1e}")

print("5) Strong coupling limit (g2 = 50): sumVar per plaquette -> 3/4")
r = solve_open(S, 50.0)
print(f"   sumVar_1={r['sumVar_1']:.5f} sumVar_2={r['sumVar_2']:.5f} T12={r['T12']:.2e}")
St = build_torus(1.5)
r = solve_torus(St, 50.0)
print(f"   torus sumVar={r['sumVar']:.5f}")
