#!/bin/bash -l
# Gribov copy check: the same measurement with the gauge fixing repeated from
# 3 random gauge starts (best objective kept). If Figure 21 and T6 agree with
# the main run within errors, the vortex identification is not an artifact of
# which gauge copy was found. 32 chains, 30 configurations each.
#SBATCH -A mXXXX                  # <-- your NERSC project
#SBATCH -C cpu
#SBATCH -q regular
#SBATCH -N 1
#SBATCH -t 02:00:00
#SBATCH -J su2_vlock_gribov
#SBATCH -o %x_%j.out
cd "$SLURM_SUBMIT_DIR/.."
source slurm/env_perlmutter.sh
srun -n 32 -c 8 --cpu-bind=cores "$PY" vortex_lock_production.py \
     --L 32 --ntherm 500 --nmeas 30 --skip 10 --rmax 8 --gribov 3 --seed 777 \
     --out runs/vl32_gribov3 --wall $(( 2*3600 - 900 ))
FIGSCALE=1.55 "$PY" vortex_lock_analysis.py runs/vl32_gribov3 --outdir figures_vlock_L32_gribov3
