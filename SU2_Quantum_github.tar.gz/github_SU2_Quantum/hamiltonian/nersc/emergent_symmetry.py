#!/usr/bin/env python3
"""
emergent_symmetry.py: is the global SU(2) singlet imposed, or chosen by the
vacuum? The gauge fixed Hamiltonian is solved WITHOUT restricting to singlets
at the root: every state of the gauge fixed Hilbert space is kept (all
Peter Weyl components, every total charge K). The lowest energy is then found
in each charge sector K, and the ground state's K is read off.

    python emergent_symmetry.py --system torus2x1 --jmax 1.5 --out results/emergent_t21_j1.5

Part of the SU2_Quantum project (R. Sakidja, Missouri State University).
Code drafted with AI (LLM) assistance (Claude, Anthropic) and reviewed by the author.

What is and is not assumed
--------------------------
* Same Kogut Susskind Hamiltonian, same maximal tree gauge fixing and the same
  truncation of the tree link fields (j <= jmax) as run.py, so the K = 0
  sector must reproduce run.py's ground state energy (validation).
* No singlet projection. The global rotation U_l -> g U_l g^dagger acts on all
  links at once (generators L + R on every link). Its Casimir Q^2 = K(K+1)
  commutes with H, so H splits into sectors K = 0, 1, 2, ... but nothing
  selects one: all are kept and solved.
* Result: E_0(K) for each K, the ground state's K, and the gaps E_0(K) - E_0(0).
  If the overall ground state has K = 0 with a gap to every K > 0, the global
  symmetry of the vacuum is emergent (energetically chosen), not imposed.
  K > 0 sectors are states carrying net color charge at the root.
Full Hilbert space dimension per block is d^2 (d = prod (2 j_l + 1)), so this
is limited to small truncations (see slurm/submit_emergent.sh).
"""
import argparse
import itertools
import json
import time

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

from su2ham.engine import jvals, dim, apply_word_trace, apply_field_casimir
from su2ham.systems2 import SPECS


def unit_batch(js):
    d = int(np.prod([dim(j) for j in js]))
    D = d * d
    shape = tuple(x for j in js for x in (dim(j), dim(j)))
    return D, np.eye(D).reshape((D,) + shape)


def as_real(T, what):
    T = np.asarray(T)
    if np.iscomplexobj(T):
        im = np.abs(T.imag).max() if T.size else 0.0
        if im > 1e-10:
            raise SystemExit(f"{what}: imaginary part {im:.2e}")
        T = T.real
    return T


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--system", required=True)
    ap.add_argument("--jmax", type=float, required=True)
    ap.add_argument("--g2", type=float, nargs="+", default=[1.0, 1.4, 1.8181818, 2.5, 3.0])
    ap.add_argument("--kmax", type=float, default=3.0, help="largest charge sector solved")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    t0 = time.time()
    s = SPECS[a.system]
    N, words, energy, fields = s["N"], s["plaquettes"], s["energy"], s["fields"]
    jcap = a.jmax * (a.jmax + 1) + 1e-8
    blocks = list(itertools.product(jvals(a.jmax), repeat=N))
    offs, Ds, off = {}, {}, 0
    for js in blocks:
        D = int(np.prod([dim(j) for j in js])) ** 2
        offs[js], Ds[js] = off, D
        off += D
    ntot = off
    print(f"{a.system} jmax={a.jmax}: full gauge fixed space {ntot} states in {len(blocks)} blocks", flush=True)

    # per block: truncation subspace V (tree link fields <= jmax), electric energy, charge Casimir
    Vb, Eb, Qb = {}, {}, {}
    glob = [(l, "K") for l in range(N)]
    for js in blocks:
        D, U = unit_batch(js)
        V = np.eye(D)

        def fmat(pieces):
            T = as_real(apply_field_casimir({js: U}, pieces)[js], "field").reshape(D, D)
            F = T.T                                   # F[out, in]
            return 0.5 * (F + F.T)

        for pieces in fields:
            F = V.T @ fmat(pieces) @ V
            w, R = np.linalg.eigh(F)
            V = V @ R[:, w <= jcap]
            if V.shape[1] == 0:
                break
        if V.shape[1] == 0:
            continue
        E = np.zeros((D, D))
        for coef, kind, data in energy:
            E += coef * (js[data] * (js[data] + 1) * np.eye(D) if kind == "cas" else fmat(data))
        Vb[js], Eb[js], Qb[js] = V, V.T @ E @ V, V.T @ fmat(glob) @ V

    # kept basis: within each block, split by charge K (eigenvectors of Q^2)
    sectors = {}                                     # K -> list of (js, W) with W in block coords
    for js, V in Vb.items():
        w, R = np.linalg.eigh(0.5 * (Qb[js] + Qb[js].T))
        K = np.rint((-1 + np.sqrt(1 + 4 * np.maximum(w, 0))) * 0.5 * 2) / 2   # K(K+1) = w
        for k in np.unique(K):
            if k <= a.kmax + 1e-9:
                sectors.setdefault(float(k), []).append((js, V @ R[:, K == k]))
    dims = {k: sum(W.shape[1] for _, W in L) for k, L in sectors.items()}
    print("  charge sectors (K: kept states): " + "  ".join(f"{k:g}: {n}" for k, n in sorted(dims.items())), flush=True)

    # plaquette operators in the full block space, then restricted to each sector
    def plaq_full(word):
        rows, cols, vals = [], [], []
        for js in Vb:
            D, U = unit_batch(js)
            img = apply_word_trace({js: U}, word)
            for key, T in img.items():
                if key not in offs:
                    continue
                M = as_real(T, "plaquette").reshape(D, -1).T          # [out, in]
                r, c = np.nonzero(np.abs(M) > 1e-14)
                rows.append(offs[key] + r); cols.append(offs[js] + c); vals.append(M[r, c])
        A = sp.csr_matrix((np.concatenate(vals), (np.concatenate(rows), np.concatenate(cols))), shape=(ntot, ntot))
        return 0.5 * (A + A.T)

    Cfull = [plaq_full(w) for w in words]
    secs = {}
    for k, L in sorted(sectors.items()):
        W = sp.lil_matrix((ntot, dims[k]))
        c = 0
        for js, Wb in L:
            n = Wb.shape[1]
            W[offs[js]:offs[js] + Ds[js], c:c + n] = Wb
            c += n
        W = W.tocsr()
        # electric energy restricted to the sector: E is block diagonal, use V coordinates
        Eblocks = []
        for js, Wb in L:
            Rk = Vb[js].T @ Wb                       # sector vectors in V coordinates
            Eblocks.append(Rk.T @ Eb[js] @ Rk)
        secs[k] = dict(W=W, E=sp.block_diag(Eblocks, format="csr"), C=[(W.T @ C @ W).tocsr() for C in Cfull])
    print(f"  operators built ({time.time()-t0:.1f}s)", flush=True)

    nP = len(words)
    records = []
    for twist in ([1] * nP, [-1] + [1] * (nP - 1)):
        for g2 in a.g2:
            Ek = {}
            for k, S in secs.items():
                H = 0.5 * g2 * S["E"]
                n = H.shape[0]
                for sg, C in zip(twist, S["C"]):
                    H = H + (4.0 / g2) * (sp.identity(n) - sg * C)
                if n <= 1500:
                    e0 = float(np.linalg.eigvalsh(H.toarray())[0])
                else:
                    e0 = float(spla.eigsh(H.tocsr(), k=1, which="SA", tol=1e-11)[0][0])
                Ek[k] = e0
            kg = min(Ek, key=Ek.get)
            rec = dict(system=a.system, jmax=a.jmax, g2=g2, twist=twist, E_by_K={f"{k:g}": v for k, v in Ek.items()},
                       ground_K=kg, gap_to_charged=min(v for k, v in Ek.items() if k != 0) - Ek[0] if len(Ek) > 1 else None,
                       sector_dims={f"{k:g}": n for k, n in dims.items()})
            records.append(rec)
            print(f"  twist={twist} g2={g2:.4f}: ground state K={kg:g}  "
                  + "  ".join(f"E0(K={k:g})={v:.6f}" for k, v in sorted(Ek.items()))
                  + f"   gap to lowest charged sector {rec['gap_to_charged']:.4f}", flush=True)
            json.dump(records, open(a.out + ".json", "w"), indent=1)
    print(f"wrote {a.out}.json ({time.time()-t0:.1f}s)")


if __name__ == "__main__":
    main()
