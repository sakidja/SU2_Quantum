# NERSC Perlmutter run order (classical/topology)

Before anything: put your project in place of `mXXXX` in every `slurm/*.sh`, and for job 02 set `CKPT_DIR`.
All jobs run from `classical/topology/`. Every job stops cleanly at its time limit; resubmit the same line to resume.

| Step | Command | Purpose | Paper | Time (1 CPU node) |
|---|---|---|---|---|
| 0 | `sbatch slurm/00_smoke_debug.sh` | setup check, general measurements | | 10 min, debug queue |
| 1 | `sbatch slurm/09_vortex_smoke.sh` | setup check, vortex lock and mode scripts | | 10 min, debug queue |
| 2 | `sbatch slurm/01_ensemble.sh 16` | validation against S6 (c0, Var c_k, Q^2) and ground state figures | Figs 19, 20 | about 20 min |
| 3 | `sbatch slurm/01_ensemble.sh 24` | second volume | Figs 19, 20 | about 1 h |
| 4 | `sbatch slurm/01_ensemble.sh 32` | third volume | Figs 19, 20 | about 2 h |
| 5 | `sbatch slurm/10_vortex_lock.sh 32` | **main run**: vortex sign flip to large loops, ground state coherence | Fig 21, Fig T6 | about 1 h |
| 6 | `sbatch slurm/12_twist_modes.sh 24` | **three mode test**: loop covariance and colour by space modes against nulls | Fig T7 | about 1 h |
| 7 | `sbatch slurm/11_gribov_check.sh` | vortex identification not a gauge copy artifact | check for Fig 21 | about 1.5 h |
| 8 | `sbatch slurm/10_vortex_lock.sh 40` | volume check of the lock | check for Fig 21 | about 2 h |
| 8b | `sbatch slurm/13_locked_modes.sh` | **three mode test at the lock scale**: colour by space modes and axis alignment of the R x R loops (R up to 7) against a null, by vortex parity | Fig T8 | about 1 h |
| 8c | `sbatch slurm/14_beta_scan.sh 3.0`, then `4.0`, then `5.0` | **coupling scan**: the same test as 8b at finer lattice spacing; populations reach the SU(2) fixed point and the lock forms at every beta | Fig T10 | about 3 to 6 h each |
| 8d | `sbatch slurm/15_mode_correlators.sh 3.0`, then `4.0` | **mode correlators**: correlation of each of the three modes in space, effective masses within and beyond the lock scale | Fig T11 | about 1 to 2 h each |
| 9 | `sbatch slurm/02_checkpoints.sh` | the same measurements on the S6 production checkpoints (optional) | cross check | about 1 h |
| 10 | `bash slurm/03_figures.sh` | login node: summaries and figures of steps 2 to 4 | Figs 19, 20 | minutes |
| 11 | `"$PY" beta_scan_summary.py` | login node, after 8c: Figure T10 from all job 13 and 14 summaries | Fig T10 | seconds |

Steps 2 to 9 are independent and can be queued together after the two smoke tests pass.

Outputs to send back for the paper: `figures/`, `figures_vlock_L32/`, `figures_modes_L24/`, `figures_vlock_L32_gribov3/`, `figures_vlock_L40/`, `figures_lmodes_L24/`, `figures_lmodes_L32_b3.0/`, `figures_lmodes_L32_b4.0/`, `figures_lmodes_L32_b5.0/`, `figures_bscan/`, `figures_mcorr_L32_b3.0/`, `figures_mcorr_L32_b4.0/` (each holds the figures and a summary JSON).

Runs on a laptop instead (not NERSC): `python pmns_test.py` (Figure T9, about 1 minute: measured lepton mixing against the SU(2) populations and rotation, with a small local lattice cross check), `quantum/stage3/lock_sim.py`, `lock_checks.py`, `su3_lock_sim.py` (Figures 17 to 19).
