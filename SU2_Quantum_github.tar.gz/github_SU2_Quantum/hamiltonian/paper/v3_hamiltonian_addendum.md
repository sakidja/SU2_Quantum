---
title: "Version 3 addendum: The Hamiltonian Vacuum"
subtitle: "New Section 11 for *Dynamical Generation of Neutrino Mass from Local SU(2) Gauge Variance* (Zenodo DOI 10.5281/zenodo.23111769). Sections 11 and 12 of v2 become 12 and 13."
author: "Ridwan Sakidja, Department of Physics, Astronomy and Materials Science, Missouri State University"
---

# Proposed additions to the Abstract

*Insert after "...the mixing angles become outputs of the group geometry rather than inputs."*

Version 3 adds an exact quantum treatment of the same field. The Kogut Susskind Hamiltonian of SU(2) is diagonalised on small periodic lattices, with the electric basis truncated at j ≤ jmax and convergence shown in jmax, and the results are tied to the Monte Carlo campaign on lattices up to 32³ through a twist free energy built from the same heat bath code. The exact ground state carries Σ Var(cₖ) = 0.614 at the Monte Carlo coupling, against 0.617 from sampling, and a probe coupled to Σ cₖ² acquires a phase at the rate λ Σ Var(cₖ) with coherence loss below one percent: the variance acts on the probe as an energy, the Lamb shift structure, not as noise. The centre twist is a protected sector on every closed lattice, costs 0.1275 per unit time when confined to a 2 × 2 cross section, and costs nothing from 4 × 4 up to 32³, so the lock has a core of about 7/g², the scale at which the Wilson loop analysis saw it complete, and beyond that core the twist is carried by the vacuum for free. Released from one plaquette in real time, the twist delocalises over the loop in about one lattice time unit while the variance moves with the energy. Finally, with the Gauss law constraint removed from the Hamiltonian, and then with no gauge fixing at all, the vacuum selects the gauge invariant sector on its own, on every lattice and coupling, with a gap of 0.5 to 1.1 to any charged state; an explicit breaking term of strength κ induces a charge χκ² with χ × gap² constant. The gauge symmetry of the vacuum is an outcome of the dynamics, with a measured stiffness, not a constraint imposed on it.

# 11. The Hamiltonian Vacuum: An Exact Quantum Treatment

## 11.1 Why a Hamiltonian

Sections 3 to 10 establish the variance identity and the lock in two settings: quantum circuits in which the qubits carry the probe and the gauge field enters as a sampled environment, and classical Wilson ensembles at L = 16, 24 and 32 in which every link is sampled and the full plaquette matrix is read. Neither setting gives the vacuum itself. The circuits quantise the probe, not the medium; the Monte Carlo gives expectation values in the vacuum, never the vacuum as a state, and energies only through the decay of Euclidean correlators. Three questions therefore remained open: whether the identity Σ Var(cₖ) = 1 − ⟨c₀²⟩ holds in the exact quantum ground state of the gauge field; whether the variance acts on a probe as an energy (a coherent phase) or as noise (damping), which is the MSW question of Section 10.3 in quantum form; and whether the lock is a sector of the quantum theory with a definite energy, and what that energy does as the lattice grows.

The Kogut Susskind Hamiltonian [KS] answers all three. It is the same lattice theory the Monte Carlo samples, written with continuous time:

> **H = (g²/2) Σ_links E² + (4/g²) Σ_p (1 − sₚ c₀,ₚ),   g² = 4/β,**

with E(ℓ) the colour electric field on link ℓ (the generator of the link's gauge rotation) and c₀,ₚ = ½ Tr Uₚ the plaquette scalar. The sign sₚ = ±1 inserts a centre (Z₂) flux through plaquette p; on a closed lattice this flux is a protected sector, on an open one it is removable by a change of variables. The tree level matching g² = 4/β places the Monte Carlo coupling β = 2.2 at g² = 1.818. Every Hamiltonian result below is quoted at that coupling unless stated.

**The identity in operator form.** Since Uₚ ∈ SU(2), c₀² + Σₖ cₖ² = 1 on every plaquette, so Σₖ cₖ² = 1 − c₀² as operators and

> **Σₖ Var(cₖ) = 1 − ⟨c₀²⟩,   ⟨cₖ⟩ = 0,**

in any state invariant under the global colour rotation at the root. The magnetic term rewrites exactly as

> **(4/g²)(1 − c₀) = (4/g²) Σₖ cₖ² / (1 + c₀),**

so the magnetic energy of a plaquette is its Pauli vector squared, weighted by 1/(1 + c₀). The components the Wilson readout discards are the magnetic energy density, operator by operator. These two lines are algebra; the rest of the section is what the ground state does with them.

**Frame dependence is not a criterion for discarding a field.** The standard objection to the cₖ is that they rotate under a local colour transformation and, by Elitzur's theorem [Elitzur], average to zero. The same two facts hold for the electric and magnetic fields of electrodynamics: E and B are frame dependent components of F_μν mixed by Lorentz boosts, and in the vacuum ⟨E⟩ = ⟨B⟩ = 0. Electrodynamics measures them in each frame and builds its invariants from them, E² − B², E·B and the Poynting flux E × B, and the Lamb shift is a field with zero mean and finite variance shifting a measurable level. The cₖ stand to the colour frame as E and B stand to the Lorentz frame: components mixed by a rotation, with Σₖ cₖ² the invariant. Keeping only Tr Uₚ = 2c₀ is the analogue of keeping one scalar of electrodynamics and calling the fields bookkeeping.

**Method.** The Hamiltonian is diagonalised in the Peter Weyl basis eʲₘₙ(U) = √(2j+1) Dʲₘₙ(U), truncated at j ≤ jmax on every link, in a maximal tree gauge in which the tree links are set to the identity and their electric fields are eliminated through Gauss law at the sites they lead to [Bauer basis, KS]. The states kept are singlets under the residual global rotation at the root. The lattices are the single plaquette, an open 2 × 1 pair, and the periodic 1 × 1, 2 × 1, 3 × 1 and 2 × 2 tori, with 3 762 invariant states on 3 × 1 at jmax 1.5, 20 647 at jmax 2, and about 10⁵ at jmax 2.5. Two independent engines, one storing full Peter Weyl tensors and one storing only gauge invariant content, agree to 10⁻¹⁵. Section 11.6 removes the gauge fixing and the singlet restriction altogether. All runs were performed on NERSC Perlmutter; the scripts are in the public repository.

## 11.2 The Ground State and the Monte Carlo

Table 11.1 gives the converged ground state values at β = 2.2.

| Lattice | jmax | Σ Var(cₖ) | ⟨c₀⟩ | Twist energy ΔE |
|---|---|---|---|---|
| Single plaquette | 10 | 0.6952 | 0.342 | 0 (no closed cycle) |
| Open 2 × 1 | 6 | 0.6947 | 0.343 | 0 (gauge trivial) |
| Periodic 1 × 1 | 6 | 0.5080 | 0.591 | 1.0017 |
| Periodic 2 × 1 | 4 | 0.6055 | 0.520 | 0.7113 |
| Periodic 3 × 1 | 2 | 0.6044 | 0.5295 | 0.7378 |
| Periodic 2 × 2 | 1 | 0.698 | 0.350 | 0.085 (rough) |

*Table 11.1. Ground state values at g² = 1.818. ΔE is the energy of the twisted sector above the untwisted one. The 2 × 2 row is at a truncation too coarse for its ⟨c₀⟩ to be compared with the others; its twist energy is discussed in Section 11.4.*

**Convergence.** On 2 × 1, jmax 2.5 and 3 give ΔE = 0.71137 and 0.71129; jmax 3, 3.5 and 4 agree at every coupling down to g² = 0.5 (ΔE = 1.9918, 2.0521, 1.9925, the half integer truncation overshooting slightly). On 1 × 1, jmax 5 and 6 agree to 0.0006 at g² = 0.5. On 3 × 1, jmax 1.5 to 2 shifts ΔE by 0.006 and ⟨c₀⟩ by 0.009; the jmax 2.5 run is in progress. The weak coupling end, g² ≤ 0.9, is resolved on 1 × 1 and 2 × 1 and is reported there only.

**Agreement with the Monte Carlo.** The Monte Carlo campaign at L = 12 to 32 gives ⟨c₀⟩ = 0.4933 and Σ Var(cₖ) = 0.6172 (Table 11.3). The 3 × 1 ground state at g² = 1.818 gives 0.5295 and 0.6044; at the coupling g² ≈ 1.93 where its ⟨c₀⟩ matches the Monte Carlo value 0.493, it gives Σ Var(cₖ) = 0.625. The exact quantum vacuum and the sampled vacuum agree on the energy density to about one percent, and ⟨c₀⟩, the quantity the standard readout keeps, is the one that depends on lattice size; the variance settles by 2 × 1 (0.6055 against 0.6044 on 3 × 1).

## 11.3 The Probe: Phase, Not Damping

Section 10.3 read the neutrino's interaction with the gauge variance as a matter effect. The quantum test is to couple a probe to the variance operator, W = Σₚ Σₖ cₖ,ₚ², with strength λ, and ask whether the probe's energy shifts (a phase that grows with time, as in the MSW effect and the Lamb shift) or its coherence decays (noise). The exact spectrum gives both: the energy shift ΔE between the ground states of H and H + λW, and the overlap Z = |⟨0'|0⟩|² whose deficit 1 − Z is the weight spread into excited states, the incoherent part of the probe's response.

| Lattice | Σ Var(cₖ) | ΔE / (λ Σ Var) at λ = 0.5 | Lamb correction | Coherence loss 1 − Z at λ = 0.5 | at λ = 2 |
|---|---|---|---|---|---|
| Single plaquette | 0.695 | 0.991 | −0.9 % | 6.7 × 10⁻⁴ | 1.2 × 10⁻² |
| Open 2 × 1 | 0.695 | 0.991 | −0.9 % | 6.8 × 10⁻⁴ | 1.2 × 10⁻² |
| 1 × 1 untwisted | 0.508 | 0.973 | −2.7 % | 2.7 × 10⁻³ | 4.8 × 10⁻² |
| 1 × 1 twisted | 0.711 | 0.993 | −0.7 % | 3.3 × 10⁻⁴ | 9.3 × 10⁻³ |
| 2 × 1 untwisted | 0.605 | 0.983 | −1.7 % | 2.1 × 10⁻³ | 1.9 × 10⁻² |
| 2 × 1 twisted | 0.715 | 0.991 | −0.9 % | 7.6 × 10⁻⁴ | 1.2 × 10⁻² |
| 3 × 1 untwisted | 0.614 | 0.988 | −1.2 % | 1.5 × 10⁻³ | 2.1 × 10⁻² |
| 3 × 1 twisted | 0.719 | 0.993 | −0.7 % | 1.1 × 10⁻³ | 2.1 × 10⁻² |

*Table 11.2. Probe response at g² = 1.818. The first order prediction is ΔE = λ Σ Var(cₖ); the Lamb correction is the second order shift. Coherence loss is the weight outside the shifted ground state.*

![](figs/fig_probe.png)

*Figure 11.1. Probe energy shift against λ Σ Var(cₖ) on every lattice and in both twist sectors at β = 2.2, with the first order line. The deviations are the Lamb corrections of Table 11.2.*

On every lattice the probe's phase rate is λ Σ Var(cₖ) to within one to three percent, the deficit being the second order Lamb correction, and the coherence loss stays below 0.3 percent at λ = 0.5 and below 5 percent at λ = 2, the largest coupling tried. The variance shifts the probe's energy and barely dephases it. This is the structure of the Lamb shift reproduced inside SU(2): a field whose components average to zero and whose variance moves a level. For the neutrino it answers the question of Section 10.3 in the quantum theory: a probe coupled to the gauge variance propagates coherently with a shifted phase, as through a medium, and the twisted sector, which carries more variance, gives a faster phase by 18 percent on 2 × 1 and 3 × 1 (43 percent on 1 × 1, the most finite size affected lattice).

## 11.4 The Lock as a Sector: Cost, Core and Condensate

**Protection.** On every closed lattice the twisted and untwisted Hamiltonians have different spectra, Table 11.1, and no local change of the links connects them: the centre flux through a cycle of the torus is a quantum number. On the open 2 × 1 pair the two spectra coincide exactly, because a boundary link belongs to one plaquette only and the sign can be moved off it. The lock of Section 10 is a protected sector of the quantum theory precisely when, and only when, the loop it threads is closed.

**Cost along a strip.** The twist energy does not fall with length: 1.00 on 1 × 1, 0.711 on 2 × 1, 0.738 on 3 × 1, a 3 × 1 to 2 × 1 ratio of 1.04 at β = 2.2 (1.24 at g² = 1.4, 0.93 at 2.0, 0.45 at 3.0; the ratio crosses one near the Monte Carlo coupling).

**Cost against cross section, from the Monte Carlo.** The Hamiltonian cannot reach a cross section wider than two. The classical heat bath can, and the twist free energy connects the two. In the same code as the production campaign, the xy plaquettes of one stack (one per time slice, at a fixed (x₀, y₀)) are given weight 1 − 2λ in the action, so λ = 0 is the untwisted theory and λ = 1 the Z₂ twisted one, and

> **F_twist − F = 2β ∫₀¹ dλ ⟨Σ_stack c₀⟩_λ ,**

evaluated with eight Gauss Legendre nodes, four chains of 4 000 configurations each. With a long time extent, (F_twist − F)/Lₜ is the Hamiltonian twist energy of the spatial cross section. The untwisted limit reproduces the production code bit for bit, and two stacks, whose fluxes cancel, give −0.004 ± 0.004 on 8³.

| Box | ΔF / Lₜ | Σ Var(cₖ), untwisted | twisted | Hedgehog ⟨ΣQ²⟩/V, untwisted | twisted |
|---|---|---|---|---|---|
| 2 × 2 × 16 | 0.1271 ± 0.0022 | 0.6088 | 0.6188 | 0.3733 | 0.3771 |
| 2 × 2 × 32 | 0.1276 ± 0.0013 | 0.6108 | 0.6199 | 0.3765 | 0.3722 |
| 4³ | 0.0021 ± 0.0035 | 0.6147 | 0.6143 | 0.3749 | 0.3745 |
| 8³ | 0.0010 ± 0.0028 | 0.6168 | 0.6168 | 0.3756 | 0.3750 |
| 12³ | −0.0015 ± 0.0020 | 0.6172 | 0.6172 | 0.3747 | 0.3750 |
| 16³ | −0.0003 ± 0.0017 | 0.6172 | 0.6172 | 0.3749 | 0.3750 |
| 24³ | 0.0015 ± 0.0015 | 0.6173 | 0.6172 | 0.3752 | 0.3750 |
| 32³ | −0.0003 ± 0.0013 | 0.6172 | 0.6172 | 0.3750 | 0.3749 |

*Table 11.3. Twist free energy per unit time at β = 2.2 against box size, with the full readout of the untwisted (λ = 0) and twisted (λ = 1) ensembles.*

![](figs/fig_twist_cost.png)

*Figure 11.2. Twist cost per unit time against cross section. The dashed line is 7/g² = 3.85 lattice units, where Figure 30 of Section 10 found the lock complete.*

Three results. First, the cost through a 2 × 2 cross section is an energy: ΔF/Lₜ is the same at Lₜ = 8, 16 and 32, 0.1275 ± 0.0011 combined, and it is the same order as the Hamiltonian 2 × 2 value 0.085 at its rough truncation (the jmax 1.5 run is in progress). Second, the cost vanishes between a cross section of 2 and 4 and stays zero to 32³, through the boxes of the production campaign. Third, in the 2 × 2 column the twisted ensemble carries more variance (+0.010, the same direction as every Hamiltonian lattice) while from 4³ up the two ensembles are identical in Σ Var(cₖ) and in hedgehog density to four digits.

The lock therefore has a core. Squeezed below a cross section of about 7/g² ≈ 3.85 lattice units, the centre flux costs energy and raises the variance around it; given more room than that, it costs nothing and the vacuum carries it. This is the scale at which Section 10.2 saw W_odd/W_even reach −1 at four couplings, now measured by a different observable. A twist whose free energy vanishes in a large box is 't Hooft's criterion for a vacuum in which centre flux is already present and free to spread ['t Hooft 1979]: the twisted and untwisted vacua are degenerate, and the ground state already carries the twist.

**The eye of the storm.** The configurations saved at λ = 0 and λ = 1 in the 8³ to 32³ boxes locate the imposed flux directly, with no smoothing: in each xy plane the 2 × 2 block of largest action density is taken as the core, and its distance from the imposed stack, its displacement between neighbouring time slices, and the action and Σ cₖ² at and around it are compared between the two ensembles (Figure 11.3). In every box the core sits at the uniform random distance from the stack (12.1 ± 0.1 against 12.25 expected on 32³), it moves by about L/2 between slices in both ensembles alike, and the radial profiles of action and variance around it coincide between twisted and untwisted to the third decimal. The imposed flux has no location. It has dissolved into a vacuum that is already full of such flux: a condensate, in the sense of the dual superconductor picture [tHooft78, Mandelstam] with the centre vortex as the condensing object. The only place the eye exists is the 2 × 2 column, where the flux is squeezed below the core.

![](figs/fig_eye_L16.png)

*Figure 11.3. One time slice of the 16³ box at β = 2.2: action density 1 − w c₀ (left) and Σ cₖ² (centre) in the twisted (top) and untwisted (bottom) ensembles, with the core (+) and the imposed stack (×), and the core's position through time (right). The two ensembles are statistically identical; the flux has no footprint.*

**The bag as the missing fence.** The one established model that gives a hadron a size makes explicit what the lock supplies. The MIT bag [Chodos] is free QCD multiplied by a step function, L = [ψ̄(iγ·∂ − m)ψ − ¼F² − B] θ_V(x), with θ_V one inside the bag and zero outside: confinement is θ_V, a boundary with no degree of freedom, no energy and no mass, and B, fitted to the hadron spectrum at B^(1/4) ≈ 145 MeV [DeGrand], is the energy density by which the true vacuum exceeds a field free region. The model records the vacuum energy as a wall and assumes the holding. The lock holds without a wall: the flux is protected by topology, the cost is set by the stiffness of the vacuum, and the core is where that stiffness balances the energy of the circulation, as it is for an Abrikosov vortex [Abrikosov]. The same stiffness opens the gap to the charged sectors in Section 11.6.

## 11.5 Real Time: The Twist Released

The Hamiltonian has real time. A centre flux is pinned on one plaquette by making the other plaquettes stiff during the preparation (their magnetic couplings multiplied by 4) and then released into the uniform Hamiltonian; the untwisted sector with the same protocol is the control, so the difference isolates the flux. On 3 × 1 at jmax 2 the pinned plaquette starts with excess magnetic energy 2.0 over the control, loses half of it by t = 0.9 lattice time units, falls below its neighbours at t = 1.2, and thereafter the excess sloshes among the three plaquettes with means 0.61, 0.46, 0.46 (the two neighbours identical by the reflection symmetry of the ring) and total 1.53, the twist energy. On the 2 × 2 torus the late time excess is the same on all four plaquettes: two directions suffice to erase the memory of where the flux started. The release time is 0.4 to 0.9 lattice units on every lattice and coupling tried, and the motion is undamped (energy conserved to 10⁻¹²), an exact unitary evolution of a closed system.

![](figs/fig_quench_3x1.png)

*Figure 11.4. The twist released on the 3 × 1 ring at β = 2.2, jmax 2: excess magnetic energy per plaquette over the untwisted control (left), excess Σ cₖ² (centre), and the magnetic energy of each plaquette in the twisted sector (right).*

The centre panel is the identity of Section 11.1 seen in time. The excess variance on each plaquette rises and falls with its excess magnetic energy, peak for peak, with a correlation of 0.82 to 0.95 over the full series on every run. The energy that moves around the loop is the variance moving around the loop; there is no energy sloshing while the variance stays put, which is what a reading of the cₖ as noise would require.

## 11.6 The Symmetry as an Outcome

Gauss law, Gₓᵃ ψ = 0 at every site, enters the Hamiltonian theory as a constraint: in temporal gauge the Lagrange multiplier A₀ that would enforce it is set to zero, and the constraint is put back by hand on the states, the singlet condition of Section 11.1. The same practice underlies the standard reading of the cₖ: once only gauge invariant states and operators are admitted, a gauge variant component is unphysical by definition, and its vanishing mean is read as its absence. Whether the constraint is necessary can be tested. The Hamiltonian is solved with the constraint removed, first at the root of the tree and then with no gauge fixing at all, every link dynamical and every charge sector kept, and the vacuum is asked which sector it occupies.

**The total charge.** With the singlet restriction lifted at the root, the lowest energy in each sector of total charge K is found separately. On 1 × 1, open 2 × 1, 2 × 1, 3 × 1 and 2 × 2, at g² = 1.0 to 3.0 and in both twist sectors, the ground state has K = 0, and the energies of the K = 0 sector reproduce the constrained engine to 10⁻⁹. The gap to the lowest charged sector at β = 2.2 is 0.840 on 1 × 1 (jmax 3), 0.960 on 2 × 1 (jmax 1.5), 1.058 on 3 × 1 and 2.838 on open 2 × 1; it is converged to about one percent in jmax, grows with coupling, and is smaller in the twisted sector (0.518, 0.578 and 0.661 on 1 × 1, 2 × 1 and 3 × 1): colour charge costs less on top of the twisted vacuum. Figure 11.5 (left) shows E₀(K).

**Every site, with no gauge fixing.** The single plaquette (four sites, four links), the 1 × 1 torus (two links) and the 2 × 1 torus (two sites, four links) are solved in the full Peter Weyl space of all links, with no tree, no singlet projection and no constraint anywhere; the Gauss operators Gₓ² at every site commute with the Hamiltonian to 10⁻¹⁴. The ground state energies equal the gauge fixed values exactly (1.793449 on the single plaquette, 1.222069 on 1 × 1, 3.115142 on 2 × 1 at jmax 1.5), and ⟨Gₓ²⟩ is zero at every site to 10⁻¹⁷ or better, with a gap of 0.64 (single plaquette), 0.84 (1 × 1) and 0.66 (2 × 1) to the first level carrying charge at any site. The local Gauss law holds in the vacuum because the vacuum chooses it.

**Breaking the symmetry on purpose.** To measure how firmly, a term κ Σ_ℓ (1 − ½ Tr U(ℓ)) is added. Tr U(ℓ) changes under a rotation at either end of the link, so for κ > 0 the dynamics itself no longer respects the local symmetry, and ⟨Gₓ²⟩ in the ground state measures the charge the vacuum carries when its own equations are tilted against the symmetry. The result (Figure 11.5, right) is

> **⟨Gₓ²⟩ = χ κ²,**

with the exponent 2.00 fitted over κ = 0.01 to 0.1 on every lattice and truncation, holding to κ ≈ 0.3 (about 15 percent of the magnetic scale 4/g²) and saturating beyond. There is no linear response: the symmetric vacuum is a minimum, not a point the dynamics passes through. At β = 2.2, χ = 0.87 (0.89 at jmax 1.5) on the single plaquette and 0.68 (0.86) on 2 × 1. Table 11.5 gives the full scan. Across g² = 1.0 to 3.0 χ falls by an order of magnitude while the gap rises, and χ × gap² stays at 0.36 to 0.37 on every lattice, sector and truncation where the quadratic range is resolved: the susceptibility is set by the gap, as second order perturbation theory requires. The product is the converged quantity. On the single plaquette at g² = 1.0 the truncation moves the gap from 0.43 to 0.32 and χ from 1.83 to 3.43 between jmax 1 and 1.5, and χ × gap² moves from 0.35 to 0.36; in the twisted sector of 2 × 1 the jmax 1 product is not constant (0.07 to 0.34 across the scan, the coarse truncation distorting the twisted vacuum) and at jmax 1.5 it is (0.33 to 0.36). The stiffness that selects the symmetry, the energy it costs to leave the symmetric sector, and the resistance to a force that breaks it are one quantity measured three ways. (On the 1 × 1 torus both links begin and end at the single site, so Tr U(ℓ) is a Polyakov loop and the added term is gauge invariant; ⟨G²⟩ stays zero at all κ there and the gap grows. That lattice does not test breaking.)

| jmax 1.5 | g² = 1.0 | 1.4 | 1.818 | 2.5 | 3.0 |
|---|---|---|---|---|---|
| Single plaquette: gap | 0.325 | 0.470 | 0.641 | 0.916 | 1.112 |
| χ | 3.43 | 1.64 | 0.894 | 0.443 | 0.302 |
| χ × gap² | 0.362 | 0.364 | 0.367 | 0.372 | 0.373 |
| 2 × 1 untwisted: gap | 0.357 | 0.506 | 0.658 | 0.917 | 1.110 |
| χ | 2.90 | 1.45 | 0.855 | 0.443 | 0.303 |
| χ × gap² | 0.369 | 0.370 | 0.371 | 0.372 | 0.373 |
| 2 × 1 twisted: gap | 0.132 | 0.380 | 0.578 | 0.886 | 1.093 |
| χ | 19.1 | 2.40 | 0.996 | 0.452 | 0.305 |
| χ × gap² | 0.332 | 0.346 | 0.332 | 0.354 | 0.364 |

*Table 11.5. The breaking susceptibility χ in ⟨Gₓ²⟩ = χ κ², the gap to the first charged level at κ = 0, and their product, with no gauge fixing, at jmax 1.5. The exponent fitted over κ = 0.01 to 0.1 is 1.98 to 2.01 everywhere except the twisted 2 × 1 point at g² = 1.0 (1.83), where the gap of 0.13 puts κ = 0.1 already past the quadratic range.*

![](figs/fig_emergence.png)

*Figure 11.5. Left: lowest energy in each total charge sector, measured from the singlet, with no constraint imposed, at β = 2.2. Right: charge induced at a site by an explicit breaking term of strength κ, with the quadratic law.*

**Reading.** The three results together say that the gauge symmetry of the vacuum is an outcome of the dynamics. Nothing in the Hamiltonian selects the singlet; the energetics do, at every site, with a gap, and with a measured stiffness against breaking. Imposing the constraint changes no number for the vacuum, which is why the results of Sections 11.2 to 11.5 stand; what it changes is what the theory allows itself to call physical. The vacuum is symmetric in the sense a crystal is: in its averages and in its lowest energy state, while every configuration, and the exact ground state's own samples (Section 11.7), carry a definite local structure. The charged sectors exist above the gap as real states of the theory; higher energy opens them rather than restoring a larger symmetry. In this reading the twist, the variance and the components that carry them were never unphysical. They were defined away by a constraint the vacuum did not need.

## 11.7 The Twist Populations in the Ground State

The populations of Section 10.5 are the sorted eigenvalues of MᵀM over its trace, with M the matrix of Pauli vectors of three loops. The exact ground state can be sampled: links are drawn Haar uniformly and weighted by |ψ|², the weighted ⟨c₀⟩ and ⟨c₀²⟩ reproduce the exact values (a check passed on every run), and the populations are formed from the three plaquettes of the 3 × 1 ring. The Haar reference on this geometry, where the three plaquettes lie in one plane and share every link, is 0.6965 / 0.2575 / 0.0460, already displaced from the independent loop fixed point 0.6923 / 0.2664 / 0.0412 of Section 10.5.

| β = 2.2 | p₁ | p₂ | p₃ |
|---|---|---|---|
| Haar reference, 3 × 1 | 0.6965 | 0.2575 | 0.0460 |
| Untwisted ground state, jmax 1.5 | 0.7274 ± 0.0011 | 0.2349 ± 0.0010 | 0.0377 ± 0.0004 |
| Untwisted ground state, jmax 2 | 0.7283 ± 0.0019 | 0.2344 ± 0.0017 | 0.0373 ± 0.0007 |
| Twisted ground state, jmax 1.5 | 0.7043 ± 0.0003 | 0.2525 ± 0.0002 | 0.0432 ± 0.0001 |
| Twisted ground state, jmax 2 | 0.7053 ± 0.0005 | 0.2520 ± 0.0004 | 0.0427 ± 0.0002 |
| Electron row, NuFIT 6.0 | 0.677 | 0.301 | 0.022 |

*Table 11.4. Twist populations of the 3 × 1 ground state.*

Three facts are converged. The quantum vacuum is more anisotropic than Haar, not less: p₁ rises and p₂, p₃ fall, and the anisotropy grows toward weak coupling (p₁ = 0.746 at g² = 0.8, 0.701 at 3.0). The twisted sector is closer to Haar than the untwisted one at every coupling. And the ground state populations on this geometry do not reproduce the electron row: p₃ moves toward it (0.046 → 0.037) while p₁ and p₂ move away. The 3 × 1 ring cannot host the observable as Section 10.5 defines it, three independent loops with room between them, so the comparison with the mixing matrix belongs to the Monte Carlo of Section 10.5 and is left there. What the Hamiltonian adds is that the exact ground state is locally anisotropic, each sample carrying a definite twist ellipsoid, while its expectation values are isotropic: the statistical form of the result of Section 11.6.

![](figs/fig_populations.png)

*Figure 11.6. Twist populations of the 3 × 1 ground state against coupling, untwisted and twisted sectors, with the Haar reference of the same geometry.*

## 11.8 Scope

The Hamiltonian lattices are small, 3 × 1 and 2 × 2 at most, because the gauge invariant Hilbert space grows with the product of the link dimensions; this is the normal reach of exact nonabelian Hamiltonian work and the reason the Monte Carlo carries the volume here. The two methods agree wherever they overlap: on Σ Var(cₖ), on the sign and size of the sector effects, and on the twist cost at the 2 × 2 cross section. The Hamiltonian uses continuous time and the Monte Carlo a time spacing equal to the spatial one, which accounts for part of the difference between 0.085 and 0.1275 there; the 2 × 2 run at jmax 1.5 will fix the rest. The populations are a geometry limited result, stated as such. The weak coupling region is reported only where it is converged in jmax. The sizes of the ungauged runs are the single plaquette, 1 × 1 and 2 × 1; the size dependence of the gap comes from the root emergence runs on 3 × 1 and 2 × 2. Bases that remain efficient at weak coupling and scale polynomially with volume exist [Bauer basis, Grabowska], and two plaquettes have been evolved on IBM hardware in such a basis [Froland]; the probe of Section 11.3, on the open 2 × 1 pair, is a direct candidate for that machinery.

## 11.9 Summary of the Section

1. The identity Σ Var(cₖ) = 1 − ⟨c₀²⟩ holds in the exact quantum vacuum, which agrees with the sampled vacuum on the energy density to one percent.
2. A probe coupled to the variance acquires a phase at the rate λ Σ Var(cₖ) with coherence loss below one percent: the variance acts as an energy, as in the Lamb shift, and the twisted sector gives a faster phase.
3. The centre twist is a protected sector on every closed lattice, costs 0.1275 per unit time through a 2 × 2 cross section, and costs nothing from 4³ to 32³; the core is the 7/g² scale of Section 10, and beyond it the vacuum carries the twist as a condensate, with no footprint in the configurations.
4. Released in real time, the twist delocalises over the loop in about one lattice time unit, and the variance moves with the energy.
5. With no constraint and no gauge fixing, the vacuum selects the gauge invariant sector at every site, with a gap of 0.5 to 1.1, and resists an explicit breaking term quadratically with χ × gap² constant. The symmetry is an outcome with a measured stiffness.
6. The exact ground state is locally anisotropic and isotropic only in its averages; on the 3 × 1 ring its populations do not match the electron row, and the mixing comparison stays with the Monte Carlo.

# Proposed additions to Section 13 (formerly 12), Summary and Outlook

*Insert in 13.1 after the lock findings:*

The Hamiltonian treatment of Section 11 reproduces the variance identity in the exact quantum vacuum, shows the variance acting on a probe as a coherent energy shift, measures the lock as a protected sector with a core of about 7/g² beyond which the vacuum carries the twist for free, and finds that the gauge symmetry of the vacuum is selected by the dynamics, at every site and with a measured stiffness, when no constraint is imposed.

*Insert in 13.4, Future Directions:*

Three extensions follow directly. A scan of the twist cost against cross section at β = 2.2, 3.0 and 4.0 tests whether the core stays at 7/g² in physical units toward the continuum. The compact U(1) Hamiltonian, the photon's own field, admits the same emergence test on a three dimensional torus, and connects the result to the expectation value symmetry of disordered wave systems. And the probe of Section 11.3 on the open 2 × 1 pair fits within the two plaquette encodings already run on superconducting hardware, where the phase against coupling and the twisted against untwisted shift are each a few QPU minutes.

# New references

- [KS] J. Kogut and L. Susskind, Hamiltonian formulation of Wilson's lattice gauge theories, Phys. Rev. D 11, 395 (1975).
- [Elitzur] S. Elitzur, Impossibility of spontaneously breaking local symmetries, Phys. Rev. D 12, 3978 (1975). (Already [71] in v2.)
- ['t Hooft 1979] G. 't Hooft, A property of electric and magnetic flux in non Abelian gauge theories, Nucl. Phys. B 153, 141 (1979).
- [tHooft78] G. 't Hooft, On the phase transition towards permanent quark confinement, Nucl. Phys. B 138, 1 (1978); S. Mandelstam, Vortices and quark confinement in non Abelian gauge theories, Phys. Rep. 23, 245 (1976).
- [Chodos] A. Chodos, R. L. Jaffe, K. Johnson, C. B. Thorn and V. F. Weisskopf, New extended model of hadrons, Phys. Rev. D 9, 3471 (1974).
- [DeGrand] T. DeGrand, R. L. Jaffe, K. Johnson and J. Kiskis, Masses and other parameters of the light hadrons, Phys. Rev. D 12, 2060 (1975).
- [Abrikosov] A. A. Abrikosov, Sov. Phys. JETP 5, 1174 (1957). (Already [24] in v2.)
- [Bauer basis] C. W. Bauer, I. D'Andrea, M. Freytsis and D. M. Grabowska, A new basis for Hamiltonian SU(2) simulations, arXiv:2307.11829.
- [Grabowska] D. M. Grabowska, C. F. Kane and C. W. Bauer, A fully gauge fixed SU(2) Hamiltonian for quantum simulations, arXiv:2409.10610.
- [Froland] H. Froland, D. M. Grabowska and Z. Li, Simulating fully gauge fixed SU(2) Hamiltonian dynamics on digital quantum computers, arXiv:2512.22782.

# Code and data

The Hamiltonian engines (`su2ham`), the drivers (`run.py`, `probe_phase.py`, `angle_distribution.py`, `flux_quench.py`, `emergent_symmetry.py`, `ungauged.py`), the twisted boundary extension of the production heat bath (`su2_twist_free_energy.py`, `combine_twist.py`, `vortex_eye.py`) and the Slurm scripts of every run are added to the public repository. All runs were performed on NERSC Perlmutter. The code was drafted with AI (LLM) assistance (Claude, Anthropic) and reviewed by the author, as stated in each file; the author alone is responsible for the formulation, interpretation and presentation of the results.
