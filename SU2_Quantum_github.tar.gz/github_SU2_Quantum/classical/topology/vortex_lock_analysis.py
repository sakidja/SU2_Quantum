#!/usr/bin/env python3
"""
vortex_lock_analysis.py
Analysis and paper figures for vortex_lock_production.py (login node, no MPI).

  python vortex_lock_analysis.py runs/vl32 [--outdir figures_vlock] [--rsel 3]
  FIGSCALE=1.55 python vortex_lock_analysis.py runs/vl32      # paper sized text

Errors: delete one chain jackknife over the independent MPI chains (with a single
chain, consecutive blocks of configurations are used instead).

Outputs
  vlock_summary_L{L}.json
  Fig25_vortex_lock.png   (a) W_nv/W_0 against n_v for each loop size
                          (b) approach to the Z2 lock with loop size: W_1/W_0 and W_odd/W_even
                          (c) holonomy angle for even and odd n_v, with the Haar density
                          (d) P vortex faces on charged and neutral hedgehog cells
  FigT6_ground_state_coherence.png
                          (a) C_n = <cos n psi> after n = 1..6 turns, for n_v = 0, 1, 2
                          (b) odd turns (n = 1, 3) against loop size, even vs odd n_v
"""
import argparse
import glob
import warnings
import json
import os
import re

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

warnings.simplefilter('ignore', RuntimeWarning)
COL = ['#2A6FB0', '#C27A12', '#2E9E6B', '#B4457A', '#555555']
FS = float(os.environ.get('FIGSCALE', '1'))
plt.rcParams.update({'font.size': 11 * FS, 'axes.spines.top': False, 'axes.spines.right': False})


def load(d):
    files = sorted(glob.glob(os.path.join(d, 'vlock_L*_rank*.npz')),
                   key=lambda p: int(re.search(r'rank(\d+)', p).group(1)))
    chains, meta = [], None
    for p in files:
        z = np.load(p, allow_pickle=False)
        if len(z['acc']) == 0:
            continue
        meta = json.loads(str(z['meta']))
        chains.append(dict(acc=z['acc'], hist=z['hist'], extra=z['extra']))
    if len(chains) == 1:                       # block a single chain
        c = chains[0]; n = len(c['acc']); nb = min(10, n)
        cut = np.array_split(np.arange(n), nb)
        chains = [dict(acc=c['acc'][i], hist=c['hist'][i], extra=c['extra'][i]) for i in cut]
    return chains, meta


def jack(chains, fn):
    """fn(summed acc, summed hist, stacked extra) -> array. Returns value, jackknife error."""
    A = [c['acc'].sum(0) for c in chains]; H = [c['hist'].sum(0) for c in chains]
    E = [c['extra'] for c in chains]
    full = np.asarray(fn(sum(A), sum(H), np.concatenate(E)), float)
    n = len(chains)
    if n < 2:
        return full, np.zeros_like(full)
    sA, sH = sum(A), sum(H)
    jk = np.array([np.asarray(fn(sA - A[i], sH - H[i], np.concatenate(E[:i] + E[i + 1:])), float)
                   for i in range(n)])
    with np.errstate(invalid='ignore'):
        err = np.sqrt((n - 1) / n * np.nansum((jk - np.nanmean(jk, 0)) ** 2, 0))
    return full, err


def ratio_nv(A, H, E):              # W_{n_v}/W_0 for every R and n_v (n = 1 turn)
    with np.errstate(invalid='ignore', divide='ignore'):
        W = A[:, :, 1] / A[:, :, 0]
        return W / W[:, :1]


def cn_nv(A, H, E):                 # C_n per (R, n_v, n)
    with np.errstate(invalid='ignore', divide='ignore'):
        return A[:, :, 1:] / A[:, :, :1]


def parity(A, H, E):                # C_n for even / odd n_v: (R, 2, n)
    ev = A[:, 0::2, :].sum(1); od = A[:, 1::2, :].sum(1)
    with np.errstate(invalid='ignore', divide='ignore'):
        return np.stack([ev[:, 1:] / ev[:, :1], od[:, 1:] / od[:, :1]], 1)


def odd_over_even(A, H, E):
    p = parity(A, H, E)
    with np.errstate(invalid='ignore', divide='ignore'):
        return p[:, 1, 0] / p[:, 0, 0]


def extras(A, H, E):
    return E.mean(0)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('rundir')
    ap.add_argument('--outdir', default='figures_vlock')
    ap.add_argument('--rsel', type=int, default=3, help='loop size for panel (a) of Figure T6')
    ap.add_argument('--min_count', type=float, default=2000, help='minimum loops in a class to plot it')
    ap.add_argument('--max_err', type=float, default=0.15, help='largest error of a plotted ratio')
    a = ap.parse_args()
    chains, meta = load(a.rundir)
    if not chains:
        raise SystemExit('no measurements found in ' + a.rundir)
    os.makedirs(a.outdir, exist_ok=True)
    L, rmax = meta['L'], meta['rmax']
    A = sum(c['acc'].sum(0) for c in chains)
    H = sum(c['hist'].sum(0) for c in chains)
    cnt = A[:, :, 0]
    nconf = sum(len(c['acc']) for c in chains)

    rn, rne = jack(chains, ratio_nv)
    cn, cne = jack(chains, cn_nv)
    pa, pae = jack(chains, parity)
    oe, oee = jack(chains, odd_over_even)
    ex, exe = jack(chains, extras)

    S = dict(L=L, beta=meta['beta'], rmax=rmax, n_configs=nconf, n_chains=len(chains), gribov=meta['gribov'],
             extras={k: [float(ex[i]), float(exe[i])] for i, k in enumerate(meta['extra_names'])}, loops={})
    for R in range(1, rmax + 1):
        S['loops'][R] = dict(count=cnt[R - 1, :9].astype(int).tolist(),
                             W_ratio=np.nan_to_num(rn[R - 1, :9]).tolist(),
                             W_ratio_err=np.nan_to_num(rne[R - 1, :9]).tolist(),
                             odd_over_even=[float(np.nan_to_num(oe[R - 1])), float(np.nan_to_num(oee[R - 1]))],
                             C_n_by_nv=np.nan_to_num(cn[R - 1, :3]).tolist(),
                             C_n_by_nv_err=np.nan_to_num(cne[R - 1, :3]).tolist(),
                             C_n_even_odd=np.nan_to_num(pa[R - 1]).tolist(),
                             C_n_even_odd_err=np.nan_to_num(pae[R - 1]).tolist())
    with open(os.path.join(a.outdir, f'vlock_summary_L{L}.json'), 'w') as f:
        json.dump(S, f, indent=1)

    print(f'L = {L}, {nconf} configurations, {len(chains)} chains, gribov = {meta["gribov"]}')
    print(f'P vortex density {ex[0]:.4f} +/- {exe[0]:.4f}')
    print(' R   W1/W0              W2/W0              W_odd/W_even       C1 even   C1 odd')
    for R in range(2, rmax + 1):
        print(f'{R:2d}  {rn[R-1,1]:+.3f} +/- {rne[R-1,1]:.3f}   {rn[R-1,2]:+.3f} +/- {rne[R-1,2]:.3f}   '
              f'{oe[R-1]:+.3f} +/- {oee[R-1]:.3f}   {pa[R-1,0,0]:+.4f}   {pa[R-1,1,0]:+.4f}')

    # a class is plotted only if its ratio is resolved: enough loops, a small error, and a value
    # at least 3 errors from zero (at large R the vortex free loop W_0 is itself lost in noise)
    ok = lambda R, k: (cnt[R - 1, k] > a.min_count and cnt[R - 1, 0] > a.min_count and rne[R - 1, k] < a.max_err
                       and abs(rn[R - 1, k]) > 3 * rne[R - 1, k])
    Rs = [R for R in range(2, rmax + 1) if sum(ok(R, k) for k in range(1, 5)) >= 2][:5]

    # ---------------------------------------------------------------- Figure 21 (file name kept as Fig25 for continuity)
    fig, ax = plt.subplots(2, 2, figsize=(13, 10.5))
    a0, a1, a2, a3 = ax.ravel()
    for i, R in enumerate(Rs):
        ks = [k for k in range(0, 6) if k == 0 or ok(R, k)]
        a0.errorbar(np.array(ks) + 0.05 * (i - 2), rn[R - 1, ks], yerr=rne[R - 1, ks], fmt='o-',
                    color=COL[i % len(COL)], ms=5 * FS ** 0.5, capsize=3, label=f'R = {R}')
    k = np.arange(6)
    a0.plot(k, (-1.0) ** k, 'kx', ms=9, mew=2, label=r'Z$_2$ lock $(-1)^{n_v}$')
    a0.axhline(0, color='k', lw=0.6); a0.set_xticks(k)
    a0.set_xlabel(r'vortices piercing the loop, $n_v$'); a0.set_ylabel(r'$W_{n_v}/W_0$')
    a0.set_title('(a) sign per vortex')
    a0.legend(fontsize=8.5 * FS, ncol=3, loc='upper center', bbox_to_anchor=(0.5, -0.16))

    Rg = [R for R in range(2, rmax + 1) if cnt[R - 1, 0] > a.min_count and rne[R - 1, 1] < a.max_err]
    a1.errorbar(Rg, rn[np.array(Rg) - 1, 1], yerr=rne[np.array(Rg) - 1, 1], fmt='o-', color=COL[3],
                ms=6 * FS ** 0.5, capsize=3, label=r'$W_1/W_0$')
    Ro = [R for R in range(2, rmax + 1) if oee[R - 1] < a.max_err]
    a1.errorbar(np.array(Ro) + 0.08, oe[np.array(Ro) - 1], yerr=oee[np.array(Ro) - 1], fmt='s--', color=COL[0],
                ms=6 * FS ** 0.5, capsize=3, label=r'$W_{odd}/W_{even}$')
    a1.axhline(-1, color='k', ls=':', lw=1.2, label=r'Z$_2$ lock, $-1$')
    a1.axhline(0, color='k', lw=0.6)
    a1.set_xlabel('loop side R'); a1.set_ylabel('ratio'); a1.set_ylim(-1.3, 0.3)
    a1.set_title('(b) approach to the lock with loop size'); a1.legend(fontsize=9 * FS)

    nb = H.shape[-1]; e = np.linspace(0, np.pi, nb + 1); c = 0.5 * (e[1:] + e[:-1]); dw = e[1] - e[0]
    for i, R in enumerate([2, 3]):
        if R > rmax:
            continue
        he, ho = H[R - 1, 0], H[R - 1, 1]
        a2.plot(c, he / he.sum() / dw, '-', color=COL[i], lw=1.8, label=rf'R = {R}, even $n_v$')
        a2.plot(c, ho / ho.sum() / dw, '--', color=COL[i], lw=1.8, label=rf'R = {R}, odd $n_v$')
    a2.plot(c, 2 / np.pi * np.sin(c) ** 2, 'k:', lw=1.2, label='Haar')
    a2.set_xlabel(r'holonomy angle $\psi$'); a2.set_ylabel('density')
    a2.set_title(r'(c) even vs odd $n_v$'); a2.legend(fontsize=8.5 * FS)

    names = meta['extra_names']
    iC, iN = names.index('faces_pv_charged'), names.index('faces_pv_neutral')
    a3.bar([0, 1], [ex[iC], ex[iN]], yerr=[exe[iC], exe[iN]], color=[COL[3], COL[4]], capsize=4, width=0.6)
    a3.set_xticks([0, 1]); a3.set_xticklabels([r'$Q \neq 0$', r'$Q = 0$'])
    a3.set_ylabel('vortex faces per cell'); a3.set_title('(d) hedgehogs and vortices')
    if FS == 1:
        fig.suptitle(f'center vortex lock, L = {L}, {nconf} configurations, {len(chains)} chains', y=1.01)
    fig.tight_layout(); fig.savefig(os.path.join(a.outdir, 'Fig25_vortex_lock.png'), dpi=250, bbox_inches='tight')
    plt.close(fig)

    # ---------------------------------------------------------------- Figure T6
    fig, ax = plt.subplots(1, 2, figsize=(13, 4.8))
    R = min(a.rsel, rmax)
    n = np.arange(1, cn.shape[-1] + 1)
    for nv, col in zip(range(3), [COL[0], COL[3], COL[2]]):
        ax[0].errorbar(n + 0.06 * (nv - 1), cn[R - 1, nv], yerr=cne[R - 1, nv], fmt='o-', color=col,
                       ms=6 * FS ** 0.5, capsize=3, label=rf'$n_v$ = {nv} ({"odd" if nv % 2 else "even"})')
    ax[0].plot(n, [-0.5 if k == 2 else 0.0 for k in n], 'kx', ms=9, mew=2, label='Haar, no lock')
    ax[0].axhline(0, color='k', lw=0.6); ax[0].set_xticks(n)
    ax[0].set_xlabel('number of turns n around the loop'); ax[0].set_ylabel(r'$C_n=\langle\cos n\psi\rangle$')
    ax[0].set_title(f'(a) coherence after n turns, R = {R}'); ax[0].legend(fontsize=9 * FS)
    Rp = [r for r in range(2, rmax + 1) if max(pae[r - 1, :, 0]) < 0.05]
    for kk, (nt, mk, ls) in enumerate([(1, 'o', '-'), (3, 's', '--')]):
        for par, col in zip((0, 1), (COL[0], COL[3])):
            ax[1].errorbar(np.array(Rp) + 0.05 * (2 * kk - 1), pa[np.array(Rp) - 1, par, nt - 1],
                           yerr=pae[np.array(Rp) - 1, par, nt - 1], fmt=mk + ls, color=col, ms=6 * FS ** 0.5,
                           capsize=3, label=f'n = {nt}, {"odd" if par else "even"} ' + r'$n_v$')
    ax[1].axhline(0, color='k', lw=0.6); ax[1].set_xticks(Rp)
    ax[1].set_xlabel('loop side R'); ax[1].set_ylabel(r'$C_n$')
    ax[1].set_title('(b) odd turns: sign set by vortex parity'); ax[1].legend(fontsize=9 * FS, ncol=2)
    if FS == 1:
        fig.suptitle(f'ground state lock, L = {L}, {nconf} configurations', y=1.02)
    fig.tight_layout(); fig.savefig(os.path.join(a.outdir, 'FigT6_ground_state_coherence.png'), dpi=250,
                                    bbox_inches='tight')
    plt.close(fig)
    print('wrote', a.outdir)


if __name__ == '__main__':
    main()
