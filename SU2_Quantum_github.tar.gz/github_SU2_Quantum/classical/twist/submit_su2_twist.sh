#!/bin/bash
#SBATCH --job-name=su2_twist
#SBATCH --account=mXXXX        # <-- your NERSC project
#SBATCH --constraint=cpu
#SBATCH --qos=regular                 # use --qos=debug (max 30 min) for a test pass
#SBATCH --nodes=1
#SBATCH --ntasks=32                   # 32 MPI ranks = 32 independent chains
#SBATCH --cpus-per-task=4
#SBATCH --time=01:00:00
#SBATCH --output=su2_twist_%j.out
#SBATCH --error=su2_twist_%j.err

# ----------------------------------------------------------------------
# Classical SU(2) twist campaign on Perlmutter (CPU node).
#
# Runs the volume scan L = 16, 24, 32 at beta = 2.2, 2000 measured
# configurations per size split across 32 independent chains (one per
# rank, seeded base+rank), then the cross-size scaling analysis.
#
# Each rank checkpoints every 50 configurations. If the job is cut by
# the wall clock, resubmit this same script with RESUME=1:
#     sbatch --export=ALL,RESUME=1 submit_su2_twist.sh
# or chain a resume companion at submission time:
#     jid=$(sbatch --parsable submit_su2_twist.sh)
#     sbatch --dependency=afterany:$jid --export=ALL,RESUME=1 submit_su2_twist.sh
# Resumption is bit-identical to an uninterrupted run.
#
# Timing guidance: at these parameters the whole scan is minutes-scale
# per size on one CPU node, so a single one-hour wall covers all three
# sizes with a wide margin. Statistics can be raised cheaply: at 10,000
# configurations per size the scan still fits comfortably in one hour.
# ----------------------------------------------------------------------

module load python

export OMP_NUM_THREADS=${SLURM_CPUS_PER_TASK}
export HDF5_USE_FILE_LOCKING=FALSE

BETA=2.2
CONFIGS=2000
THERM=500
SKIP=10
SEED=42
SIZES="16 24 32"
RESUME_FLAG=""
if [ "${RESUME:-0}" = "1" ]; then
    RESUME_FLAG="--resume"
    echo "[submit] resume mode: reloading rank checkpoints"
fi

for L in ${SIZES}; do
    echo "[submit] starting L=${L} at $(date)"
    srun -n ${SLURM_NTASKS} python3 su2_classical_twist.py \
        --L ${L} --beta ${BETA} \
        --configs ${CONFIGS} --therm ${THERM} --skip ${SKIP} \
        --seed ${SEED} --checkpoint-every 50 ${RESUME_FLAG} \
        --outdir run_cl_L${L}
    echo "[submit] finished L=${L} at $(date)"
done

# ---- cross-size verdict: chi fit, floor quantiles, figures ----
echo "[submit] running scaling analysis"
srun -n 1 python3 twist_scaling_fit.py \
    --dirs run_cl_L16 run_cl_L24 run_cl_L32 \
    --out scaling
echo "[submit] done at $(date)"

# Outputs per size : run_cl_L{L}/results_cl_L{L}.npz, summary_cl_L{L}.json,
#                    twist_cl_L{L}.png
# Cross-size       : scaling_summary.json, scaling_chi_fit.png,
#                    scaling_floor.png
