#!/bin/bash
#SBATCH -A mXXXX                  # <-- your NERSC project
#SBATCH -C cpu
#SBATCH -q regular
#SBATCH -N 1
#SBATCH -n 32
#SBATCH -c 8
#SBATCH -t 04:00:00
#SBATCH -J su2_scaling
#SBATCH -o su2_scaling_%j.out

# SU(2) lattice finite-size scaling on Perlmutter (CPU).
# One srun per lattice size; samples split across MPI ranks.
#
# Setup (once):
#   module load python
#   pip install --user pennylane pennylane-lightning mpi4py
#
# For L=5 (25 qubits): each rank holds a 512 MB statevector.
# 32 ranks/node * 512 MB = 16 GB state memory, well within the
# 512 GB CPU node. For GPU nodes use -C gpu and
# --device lightning.gpu (pip install --user pennylane-lightning-gpu).

module load python

for L in 3 4 5; do
    srun -n 32 python3 su2_lattice_scaling.py \
        --L ${L} --samples 10000 --seed 42 \
        --device lightning.qubit \
        --outdir run_L${L}
done

# After completion, each run_L* contains:
#   results_L*.npz   raw per-sample arrays (means, variances, deltas, c0)
#   summary_L*.json  statistics for the scaling plot
#   locking_L*.png   variance-locking and geometric-floor histograms
