#!/usr/bin/env python3
"""
su2_4d_core.py
Core of the 4D SU(2) Wilson gauge theory used by su2_4d_production.py.

Same conventions as the 3D code in ../topology (topo_measure.py and
su2_topology_heatbath.py), extended from 3 to 4 dimensions:
    links : float64 array, shape (4, L, L, L, L, 4)
            scalar first unit quaternions, links[mu][x] = U_mu(x)
            U = a0 + i a.sigma, the parametrization of Creutz, Phys. Rev. D 21, 2308 (1980)
    site axes 0, 1, 2 are spatial, axis 3 is Euclidean time
    action   S = beta * sum_P (1 - 1/2 Tr P)  (Wilson), 6 planes per site
    update   Creutz heat bath with the Kennedy Pendleton sampler, checkerboard

Nothing here depends on the number of dimensions except ND and PLANES; the
3D functions of topo_measure.py are the special case ND = 3.
"""
import numpy as np

ND = 4
PLANES = [(0, 1), (0, 2), (1, 2), (0, 3), (1, 3), (2, 3)]      # 3 spatial, then 3 temporal
SPATIAL = [0, 1, 2]                                          # indices into PLANES: xy, xz, yz


# ------------------------------------------------------------ quaternions
def qmul(p, q):
    a0, av = p[..., 0], p[..., 1:]
    b0, bv = q[..., 0], q[..., 1:]
    c0 = a0 * b0 - (av * bv).sum(-1)
    cv = a0[..., None] * bv + b0[..., None] * av + np.cross(av, bv)
    return np.concatenate([c0[..., None], cv], axis=-1)


def qconj(q):
    out = q.copy()
    out[..., 1:] *= -1
    return out


def shift(a, mu, n=1):
    """a(x + n*mu) on the periodic lattice (site axes 0..3)."""
    return np.roll(a, -n, axis=mu)


def plaquette(links, mu, nu):
    Um, Un = links[mu], links[nu]
    return qmul(qmul(Um, shift(Un, mu)), qmul(qconj(shift(Um, nu)), qconj(Un)))


def checkerboard(L):
    return np.indices((L,) * ND).sum(0) % 2


# ------------------------------------------------------------ heat bath
def staple_sum(links, mu):
    """Sum of the 2*(ND-1) = 6 staples A such that 1/2 Tr(U_mu(x) A) are the plaquettes."""
    A = 0.0
    for nu in range(ND):
        if nu == mu:
            continue
        Um, Un = links[mu], links[nu]
        up = qmul(qmul(shift(Un, mu), qconj(shift(Um, nu))), qconj(Un))
        Un_m = shift(Un, nu, -1)
        dn = qmul(qmul(qconj(shift(Un_m, mu)), qconj(shift(Um, nu, -1))), Un_m)
        A = A + up + dn
    return A


def kp_sample_x0(rng, bk):
    """Kennedy Pendleton: x0 with density sqrt(1-x0^2) exp(bk x0)."""
    x0 = np.empty_like(bk)
    todo = np.arange(bk.size)
    while todo.size:
        b = bk[todo]
        r1 = 1.0 - rng.random(todo.size)
        r2 = rng.random(todo.size)
        r3 = 1.0 - rng.random(todo.size)
        lam2 = -(np.log(r1) + np.cos(2 * np.pi * r2) ** 2 * np.log(r3)) / (2 * b)
        acc = rng.random(todo.size) ** 2 <= 1.0 - lam2
        x0[todo[acc]] = 1.0 - 2.0 * lam2[acc]
        todo = todo[~acc]
    return x0


def random_su2_with_x0(rng, x0):
    n = x0.size
    cost = 2 * rng.random(n) - 1
    phi = 2 * np.pi * rng.random(n)
    s = np.sqrt(np.clip(1 - x0 ** 2, 0, None))
    sint = np.sqrt(1 - cost ** 2)
    return np.stack([x0, s * sint * np.cos(phi), s * sint * np.sin(phi), s * cost], -1)


def sweep(links, beta, rng, parity, n_or=0):
    """One heat bath sweep (every link once), optional overrelaxation steps."""
    for mu in range(ND):
        for par in (0, 1):
            A = staple_sum(links, mu)
            k = np.linalg.norm(A, axis=-1)
            m = parity == par
            a_hat = A[m] / k[m][:, None]
            X = random_su2_with_x0(rng, kp_sample_x0(rng, beta * k[m]))
            links[mu][m] = qmul(X, qconj(a_hat))          # U = X a_hat^+
    for _ in range(n_or):
        for mu in range(ND):
            for par in (0, 1):
                A = staple_sum(links, mu)
                m = parity == par
                a = A[m] / np.linalg.norm(A[m], axis=-1, keepdims=True)
                ab = qconj(a)
                links[mu][m] = qmul(qmul(ab, qconj(links[mu][m])), ab)
    links /= np.linalg.norm(links, axis=-1, keepdims=True)


# ------------------------------------------------------------ loops
def line_products(U, mu, rmax):
    """lines[r](x) = U_mu(x) U_mu(x+mu) ... U_mu(x+(r-1)mu), r = 0..rmax."""
    one = np.zeros_like(U); one[..., 0] = 1.0
    out = [one, U.copy()]
    for r in range(2, rmax + 1):
        out.append(qmul(out[-1], shift(U, mu, r - 1)))
    return out


def rect_loop(lines, mu, nu, R, T):
    """Full quaternion of the R x T loop in plane (mu, nu), based at x."""
    a, b = lines[mu][R], lines[nu][T]
    return qmul(qmul(a, shift(b, mu, R)), qmul(qconj(shift(a, nu, T)), qconj(b)))


def box_sum_2d(A, ax1, ax2, R):
    """sum_{i,j=0}^{R-1} A(x + i*ax1 + j*ax2), periodic."""
    s = np.zeros_like(A)
    for i in range(R):
        s += np.roll(A, -i, axis=ax1)
    t = np.zeros_like(A)
    for j in range(R):
        t += np.roll(s, -j, axis=ax2)
    return t


# ------------------------------------------------------------ center vortices
def max_center_gauge(links, iters=1000, tol=1e-7, rng=None, omega=1.9):
    """Direct maximal center gauge in 4D: maximize sum_links U0^2 (the 3D routine with ND = 4).
    Returns (gauge transformed links, objective, iterations)."""
    U = links.copy()
    L = U.shape[1]
    par = checkerboard(L)
    if rng is not None:                       # random gauge start (Gribov copies)
        g = rng.normal(size=(L,) * ND + (4,)); g /= np.linalg.norm(g, axis=-1, keepdims=True)
        for mu in range(ND):
            U[mu] = qmul(qmul(g, U[mu]), qconj(shift(g, mu)))
    last = -1.0
    for it in range(iters):
        for p in (0, 1):
            m = par == p
            M = np.zeros((int(m.sum()), 4, 4))
            for mu in range(ND):
                u = U[mu][m].copy(); u[:, 1:] *= -1
                v = shift(U[mu], mu, -1)[m]
                M += u[:, :, None] * u[:, None, :] + v[:, :, None] * v[:, None, :]
            w, vec = np.linalg.eigh(M)
            h = vec[:, :, -1]
            h = h * np.sign(h[:, :1] + 1e-300)
            if omega != 1.0:
                th = np.arccos(np.clip(h[:, 0], -1, 1))
                nv = h[:, 1:] / np.maximum(np.sin(th), 1e-12)[:, None]
                h = np.concatenate([np.cos(omega * th)[:, None],
                                    nv * np.sin(omega * th)[:, None]], axis=1)
            H = np.zeros((L,) * ND + (4,)); H[..., 0] = 1.0; H[m] = h
            for mu in range(ND):
                U[mu] = qmul(qmul(H, U[mu]), qconj(shift(H, mu)))
        obj = float((U[..., 0] ** 2).mean())
        if abs(obj - last) < tol:
            break
        last = obj
    U /= np.linalg.norm(U, axis=-1, keepdims=True)
    return U, obj, it + 1


def gauge_fix_best(links, gribov, rng):
    best = None
    for k in range(max(1, gribov)):
        U, obj, nit = max_center_gauge(links, rng=(rng if k > 0 else None))
        if best is None or obj > best[1]:
            best = (U, obj, nit)
    return best


def p_vortices(Ug):
    """P vortex plaquettes after center projection: dict plane -> bool array (L^4)."""
    z = np.sign(Ug[..., 0])
    return {(mu, nu): (z[mu] * shift(z[nu], mu) * shift(z[mu], nu) * z[nu]) < 0 for mu, nu in PLANES}
