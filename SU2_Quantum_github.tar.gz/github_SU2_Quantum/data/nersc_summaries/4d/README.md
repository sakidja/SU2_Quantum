# 4D summary JSONs

Written by `classical/topology4d/su2_4d_analysis.py` (one per run, `summary_4d_L{L}_b{beta}.json`).

| File | Run | Configurations |
|---|---|---|
| `summary_4d_L16_b2.2.json` | 16^4, beta = 2.2 | 7,680 |
| `summary_4d_L16_b2.4.json` | 16^4, beta = 2.4 | 7,680 |
| `summary_4d_L20_b2.3.json` | 20^4, beta = 2.3 | 5,120 |

To add the remaining runs from Perlmutter (from `classical/topology4d/`):

    cp figures_4d_*/summary_4d_*.json figures_4d_*/*.json <repo>/data/nersc_summaries/4d/
