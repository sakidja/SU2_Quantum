"""Independent check: solve the same Hamiltonian on the class angle theta in (0, pi).
Class functions on SU(2) = S^3; with u = sin(theta) f, E^2 u = (-u'' - u)/4.
H u = 2 g^2 (-u'' - u)/4 + (4/g^2)(1 - cos theta) u, u(0) = u(pi) = 0."""
import numpy as np
from scipy.linalg import eigh_tridiagonal
from su2_plaquette_ed import observables
N = 20000
th = np.linspace(0, np.pi, N + 2)[1:-1]; h = th[1] - th[0]
for g2 in [0.5, 1.0, 4/2.2, 3.0, 5.0]:
    kin = 2*g2/4
    d = kin*(2/h**2 - 1) + (4/g2)*(1 - np.cos(th))
    e = -kin/h**2*np.ones(N-1)
    w, v = eigh_tridiagonal(d, e, select='i', select_range=(0, 1))
    u = v[:, 0]; u /= np.sqrt(np.sum(u**2))
    c0 = np.sum(u**2*np.cos(th)); c0sq = np.sum(u**2*np.cos(th)**2)
    r = observables(g2, 20.0)
    print(f"g2={g2:6.3f}  grid: c0={c0:.5f} sumVar={1-c0sq:.5f} gap={w[1]-w[0]:.5f} | ED: c0={r['c0']:.5f} sumVar={r['sumVar_ck']:.5f} gap={r['gap']:.5f}")
