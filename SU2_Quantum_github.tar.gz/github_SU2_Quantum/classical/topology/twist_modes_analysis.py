#!/usr/bin/env python3
"""
twist_modes_analysis.py
Analysis of the three twist mode test (vortex_lock_production.py --modes_every N).
Login node, no MPI.

  python twist_modes_analysis.py runs/vl24m [--outdir figures_modes]
  FIGSCALE=1.55 python twist_modes_analysis.py runs/vl24m       # paper sized text

Two constructions of three twist modes are tested against nulls:

A. Loop covariance. For every square loop the plaquette Pauli vectors on its surface
   are parallel transported to the base point; the eigenvalues l1 <= l2 <= l3 of their
   3x3 covariance are gauge invariant. Null: same magnitudes, random directions.
   A lock specific 1 + 2 split shows up as real minus null eigenvalue differences that
   depend on vortex parity.

B. Colour by space matrix. At every site M[a, i] = c_a of the plaquette dual to spatial
   direction i; singular values s1 >= s2 >= s3 are invariant under gauge and spatial
   rotations. Null: the three plaquettes from three unrelated sites.
   Note: sign(det M) is recorded but is NOT a handedness test. With the three
   plaquettes sharing a corner, det M is unchanged under a lattice reflection
   (checked directly on mirrored configurations), so its excess over 1/2 is geometric,
   and its alternation with the number of P vortex plaquettes is the center sign
   algebra (a vortex plaquette flips its twist vector). It is kept only as a check.

Errors: delete one chain jackknife (blocks of configurations for a single chain).
"""
import argparse
import glob
import json
import os
import re
import warnings

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

warnings.simplefilter('ignore', RuntimeWarning)
COL = ['#2A6FB0', '#C27A12', '#2E9E6B', '#B4457A', '#555555']
FS = float(os.environ.get('FIGSCALE', '1'))
plt.rcParams.update({'font.size': 11 * FS, 'axes.spines.top': False, 'axes.spines.right': False})


def load(d):
    files = sorted(glob.glob(os.path.join(d, 'vlock_L*_rank*.npz')),
                   key=lambda p: int(re.search(r'rank(\d+)', p).group(1)))
    chains, meta = [], None
    for p in files:
        z = np.load(p, allow_pickle=False)
        if 'csmodes' not in z.files or len(z['csmodes']) == 0:
            continue
        meta = json.loads(str(z['meta']))
        chains.append(dict(modes=z['modes'], cs=z['csmodes']))
    if len(chains) == 1:
        c = chains[0]; n = len(c['cs']); cut = np.array_split(np.arange(n), min(10, n))
        chains = [dict(modes=c['modes'][i], cs=c['cs'][i]) for i in cut]
    return chains, meta


def jack(chains, fn):
    A = [c['modes'].sum(0) for c in chains]; B = [c['cs'].sum(0) for c in chains]
    full = np.asarray(fn(sum(A), sum(B)), float)
    n = len(chains)
    if n < 2:
        return full, np.zeros_like(full)
    sA, sB = sum(A), sum(B)
    jk = np.array([np.asarray(fn(sA - A[i], sB - B[i]), float) for i in range(n)])
    return full, np.sqrt((n - 1) / n * np.nansum((jk - np.nanmean(jk, 0)) ** 2, 0))


def loop_eigs(A, B):            # (R, class, kind, 3): normalized eigenvalues l_i / trace
    return A[..., 1:4] / A[..., 4:5]


def loop_diff(A, B):            # real minus null, (R, class, 3)
    e = A[..., 1:4] / A[..., 4:5]
    return e[:, :, 0] - e[:, :, 1]


def cs_sv(A, B):                # (kind, class, 3)
    return B[..., 1:4] / B[..., :1]


def cs_det(A, B):               # fraction det > 0, (kind, class)
    return B[..., 5] / B[..., 0]


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('rundir')
    ap.add_argument('--outdir', default='figures_modes')
    a = ap.parse_args()
    chains, meta = load(a.rundir)
    if not chains:
        raise SystemExit('no mode measurements in ' + a.rundir + ' (run with --modes_every 1)')
    os.makedirs(a.outdir, exist_ok=True)
    nconf = sum(len(c['cs']) for c in chains)
    le, lee = jack(chains, loop_eigs)
    ld, lde = jack(chains, loop_diff)
    sv, sve = jack(chains, cs_sv)
    dt, dte = jack(chains, cs_det)

    # per configuration handedness, pooled over classes, against the binomial width
    per = np.concatenate([c['cs'][:, 0, :, :].sum(1) for c in chains])       # real kind, summed over classes
    frac = per[:, 5] / per[:, 0]
    binom = np.sqrt(0.25 / per[:, 0].mean())
    pern = np.concatenate([c['cs'][:, 1, :, :].sum(1) for c in chains])
    fracn = pern[:, 5] / pern[:, 0]

    Rn = le.shape[0]
    S = dict(L=meta['L'], cs_shares=meta.get('cs_shares', 'linear'), n_configs=nconf, n_chains=len(chains),
             loop_eigs_even=[le[R, 4, 0].tolist() for R in range(Rn)],
             loop_eigs_odd=[le[R, 5, 0].tolist() for R in range(Rn)],
             loop_eigs_null_even=[le[R, 4, 1].tolist() for R in range(Rn)],
             loop_diff_even=[[ld[R, 4].tolist(), lde[R, 4].tolist()] for R in range(Rn)],
             loop_diff_odd=[[ld[R, 5].tolist(), lde[R, 5].tolist()] for R in range(Rn)],
             cs_sv_real=[[sv[0, c].tolist(), sve[0, c].tolist()] for c in range(4)],
             cs_sv_null=[[sv[1, c].tolist(), sve[1, c].tolist()] for c in range(4)],
             det_pos_real=[[float(dt[0, c]), float(dte[0, c])] for c in range(4)],
             det_pos_null=[[float(dt[1, c]), float(dte[1, c])] for c in range(4)],
             handedness_per_config=dict(mean=float(frac.mean()), std=float(frac.std(ddof=1)),
                                        binomial_std=float(binom), null_std=float(fracn.std(ddof=1))))
    with open(os.path.join(a.outdir, f"modes_summary_L{meta['L']}.json"), 'w') as f:
        json.dump(S, f, indent=1)

    print(f"L = {meta['L']}, {nconf} configurations, {len(chains)} chains")
    print('A. loop covariance, real minus null (x1000) of l1/tr, l2/tr, l3/tr:')
    for R in range(1, Rn):
        print(f'  R={R+1}  even {np.round(1e3*ld[R,4],2)} +/- {np.round(1e3*lde[R,4],2)}'
              f'   odd {np.round(1e3*ld[R,5],2)} +/- {np.round(1e3*lde[R,5],2)}')
    sq = meta.get('cs_shares') == 'squared'
    print('B. colour by space mode shares ' + ('s_i^2/sum s^2 (variance fractions)' if sq else 's_i/sum s (runs made before v2.3: linear shares)')
          + ' by vortex plaquettes at the site (det M > 0 fraction: geometric check only):')
    for c in range(4):
        print(f'  n_pv={c}  real {np.round(sv[0,c],4)}  null {np.round(sv[1,c],4)}   '
              f'det>0 real {dt[0,c]:.4f} +/- {dte[0,c]:.4f}  null {dt[1,c]:.4f} +/- {dte[1,c]:.4f}')
    print(f'  per configuration handedness: mean {frac.mean():.4f}, spread {frac.std(ddof=1):.4f}, '
          f'binomial {binom:.4f}, null spread {fracn.std(ddof=1):.4f}')

    fig, ax = plt.subplots(1, 2, figsize=(13, 4.8))
    Rs = np.arange(2, Rn + 1)
    for i, (ci, lab, col) in enumerate([(4, r'even $n_v$', COL[0]), (5, r'odd $n_v$', COL[3])]):
        for j, mk in enumerate(['o', 's', '^']):
            ax[0].errorbar(Rs + 0.06 * (i - 0.5), 1e3 * ld[1:, ci, j], yerr=1e3 * lde[1:, ci, j], fmt=mk + '-',
                           color=col, ms=5 * FS ** 0.5, capsize=3,
                           label=(f'{lab}' if j == 0 else None))
    ax[0].axhline(0, color='k', lw=0.8)
    ax[0].set_xlabel('loop side R'); ax[0].set_ylabel(r'$10^3\,[(\lambda_i/\mathrm{tr})_{real} - (\lambda_i/\mathrm{tr})_{null}]$')
    ax[0].set_title(r'(a) loop covariance: $\lambda_1$ (o), $\lambda_2$ (s), $\lambda_3$ (^)')
    ax[0].legend(fontsize=9 * FS)
    x = np.arange(4)
    for j in range(3):
        ax[1].errorbar(x - 0.08, sv[0, :, j], yerr=sve[0, :, j], fmt='o', color=COL[j], ms=6 * FS ** 0.5, capsize=3,
                       label=(f'$s_{j+1}^2$ real' if sq else f'$s_{j+1}$ real'))
        ax[1].plot(x + 0.08, sv[1, :, j], 'x', color=COL[j], ms=7, label=(f'$s_{j+1}^2$ null' if sq else f'$s_{j+1}$ null'))
    ax[1].set_xticks(x); ax[1].set_xlabel('P vortex plaquettes at the site')
    ax[1].set_ylabel(r'$s_i^2/\sum s^2$' if sq else r'$s_i/\sum s$ (linear, runs before v2.3)'); ax[1].set_title('(b) colour by space modes')
    ax[1].legend(fontsize=8 * FS, ncol=3)
    fig.tight_layout(); fig.savefig(os.path.join(a.outdir, 'FigT7_twist_modes.png'), dpi=250, bbox_inches='tight')
    plt.close(fig)
    print('wrote', a.outdir)


if __name__ == '__main__':
    main()
