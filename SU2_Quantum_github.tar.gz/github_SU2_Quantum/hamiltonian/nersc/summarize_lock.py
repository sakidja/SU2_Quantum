#!/usr/bin/env python3
"""
Summaries and figures for the lock tests, from the files in results/.

    python summarize_lock.py results
writes lock_localization.csv, lock_probe.csv, lock_angles.csv and
lock_localization.png, lock_probe.png, lock_angles.png.

Part of the SU2_Quantum project (R. Sakidja, Missouri State University).
Code drafted with AI (LLM) assistance (Claude, Anthropic) and reviewed by the author.
"""
import sys, os, glob, json, csv
import numpy as np
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt

d = sys.argv[1] if len(sys.argv) > 1 else "results"
C = ["#2a78d6", "#eb6834", "#1baf7a", "#eda100", "#e87ba4", "#6250d6"]
plt.rcParams.update({"font.size": 10, "axes.spines.top": False, "axes.spines.right": False,
                     "axes.edgecolor": "#888", "axes.grid": True, "grid.color": "#e6e6e6", "grid.linewidth": 0.6})


def write_csv(name, rows):
    if not rows:
        return
    with open(name, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader(); w.writerows(rows)


# ------------------------------------------------------------ localization
loc = []
for f in sorted(glob.glob(os.path.join(d, "*.json"))):
    try:
        recs = json.load(open(f)).get("records", [])
    except Exception:
        continue
    for r in recs:
        if "K_u" not in r:
            continue
        K = np.array(r["K_u"]); n = len(K)
        iu = np.triu_indices(n, 1)
        rho = K[iu] / np.sqrt(np.outer(np.diag(K), np.diag(K))[iu])
        loc.append(dict(system=r["system"], jmax=r["jmax"], g2=r["g2"],
                        sector="twisted" if -1 in r["twist"] else "untwisted",
                        mean_corr=float(rho.mean()), min_corr=float(rho.min()), max_corr=float(rho.max()),
                        mean_var_u=float(np.diag(K).mean())))
write_csv("lock_localization.csv", loc)
if loc:
    fig, ax = plt.subplots(figsize=(7, 4.3))
    keys = sorted({(r["system"], r["jmax"]) for r in loc})
    best = {}
    for s, j in keys:
        best[s] = max(best.get(s, 0), j)
    for i, s in enumerate(sorted(best)):
        for sec, ls in [("untwisted", "--"), ("twisted", "-")]:
            rr = sorted([r for r in loc if r["system"] == s and r["jmax"] == best[s] and r["sector"] == sec],
                        key=lambda r: r["g2"])
            ax.plot([r["g2"] for r in rr], [r["mean_corr"] for r in rr], ls, marker="o", ms=5, mec="white",
                    color=C[i], lw=2, label=f"{s} jmax {best[s]}, {sec}")
    ax.axhline(0, color="#666", lw=1); ax.set_xscale("log"); ax.set_xlabel(r"$g^2$")
    ax.set_title("Connected correlation of neighbouring plaquettes", loc="left", fontsize=10.5)
    ax.legend(frameon=False, fontsize=8); fig.tight_layout(); fig.savefig("lock_localization.png", dpi=200)

# ------------------------------------------------------------ probe
pro = []
for f in sorted(glob.glob(os.path.join(d, "probe_*.json"))):
    for r in json.load(open(f)):
        pro.append(dict(file=os.path.basename(f), system=r["system"], jmax=r["jmax"], twist=str(r["twist"]),
                        g2=r["g2"], lam=r["lam"], sumVar=r["sumVar"], dE=r["dE"], first_order=r["first_order"],
                        lamb_pt=r["lamb_pt"], coherence_loss=r["coherence_loss"],
                        coherence_loss_pt=r["coherence_loss_pt"], min_visibility=r["min_visibility"]))
write_csv("lock_probe.csv", pro)
if pro:
    fig, ax = plt.subplots(1, 2, figsize=(12, 4.3))
    files = sorted({p["file"] for p in pro})
    for i, fn in enumerate(files):
        rr = sorted([p for p in pro if p["file"] == fn and abs(p["lam"] - 1.0) < 1e-9], key=lambda p: p["g2"])
        if not rr:
            continue
        lab = fn.replace("probe_", "").replace(".json", "")
        ax[0].plot([p["g2"] for p in rr], [p["dE"] for p in rr], "-o", ms=5, mec="white", color=C[i % 6], lw=2, label=lab)
        ax[1].plot([p["g2"] for p in rr], [p["coherence_loss"] for p in rr], "-o", ms=5, mec="white", color=C[i % 6], lw=2, label=lab)
    for a_ in ax:
        a_.set_xscale("log"); a_.set_xlabel(r"$g^2$")
    ax[1].set_yscale("log")
    ax[0].set_title(r"(a) Probe phase rate $\Delta E$ at $\lambda=1$", loc="left", fontsize=10.5)
    ax[1].set_title(r"(b) Coherence lost, $1-|\langle 0'|0\rangle|^2$", loc="left", fontsize=10.5)
    ax[0].legend(frameon=False, fontsize=8); fig.tight_layout(); fig.savefig("lock_probe.png", dpi=200)

# ------------------------------------------------------------ angles
ang = []
hists = {}
for f in sorted(glob.glob(os.path.join(d, "angle_*.json"))):
    meta = json.load(open(f))
    npz = np.load(f.replace(".json", ".npz"))
    for m in meta:
        key = f"{m['sector']}_g{m['g2']:.4f}"
        if key + "_W" not in npz:
            continue
        W, C0 = npz[key + "_W"], npz[key + "_C0"]
        th = np.arccos(np.clip(C0, -1, 1))
        bins = np.linspace(0, np.pi, 37)
        h, _ = np.histogram(th[:, 0], bins=bins, weights=W, density=True)
        hists[(m["system"], m["jmax"], round(m["g2"], 4), m["sector"])] = (bins, h, th, W)
        near_pi = float(W[th[:, 0] > 0.75 * np.pi].sum() / W.sum())
        ang.append(dict(system=m["system"], jmax=m["jmax"], g2=m["g2"], sector=m["sector"], ess=m["ess"],
                        mean_weight=m["mean_weight"], exact_c0=m["exact"][0][0], sampled_c0=m["sampled"][0][0],
                        exact_c0sq=m["exact"][0][1], sampled_c0sq=m["sampled"][0][1],
                        prob_theta_above_0p75pi=near_pi))
write_csv("lock_angles.csv", ang)
if hists:
    systems = sorted({k[0] for k in hists})
    g2s = sorted({k[2] for k in hists})
    fig, ax = plt.subplots(len(systems), len(g2s), figsize=(3.2 * len(g2s), 2.8 * len(systems)), squeeze=False)
    haar = lambda t: (2 / np.pi) * np.sin(t) ** 2
    for i, s in enumerate(systems):
        for k, g in enumerate(g2s):
            a_ = ax[i][k]
            for sec, col in [("untwisted", C[0]), ("twisted", C[1])]:
                for key, (bins, h, th, W) in hists.items():
                    if key[0] == s and key[2] == g and key[3] == sec:
                        mid = 0.5 * (bins[1:] + bins[:-1])
                        a_.plot(mid / np.pi, h, color=col, lw=2, label=sec)
            tt = np.linspace(0, np.pi, 200)
            a_.plot(tt / np.pi, haar(tt), color="#888", lw=1, ls=":", label="Haar")
            a_.set_title(f"{s}, g² = {g:.3g}", fontsize=9, loc="left")
            a_.set_xlabel(r"$\theta/\pi$ (plaquette 0)", fontsize=8)
            if i == 0 and k == 0:
                a_.legend(frameon=False, fontsize=7)
    fig.tight_layout(); fig.savefig("lock_angles.png", dpi=170)
print(f"localization records {len(loc)}, probe records {len(pro)}, angle cases {len(ang)}")
