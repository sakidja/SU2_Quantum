"""
Lattice geometries for the v3 Hamiltonian addendum. Each builder returns a
GaugeFixedSystem; the gauge fixing tree and the Gauss law fields are written out.

Part of the SU2_Quantum project (R. Sakidja, Missouri State University).
Code drafted with AI (LLM) assistance (Claude, Anthropic) and reviewed by the author.
"""
from .engine import GaugeFixedSystem

F, T = False, True


def single_plaquette(jmax, verbose=False):
    """Open single plaquette. Tree: 3 links = 1. Dynamical U = P.
    Gauss law: all four links carry the same j, so sum E^2 = 4 C(U)."""
    sysm = GaugeFixedSystem(1, jmax, plaquettes=[[(0, F)]],
                            energy=[(4.0, "cas", 0)], verbose=verbose)
    sysm.names = ["P"]
    return sysm


def open_2x1(jmax, verbose=False):
    """Open 2x1. Tree {b1, b2, t1, t2, v0} = 1. Dynamical U1 = v1 (shared), U2 = v2.
    P1 = U1, P2 = U2 U1^dag. sum E^2 = C(U1) + 3 C(U2) + 3 (L1 + L2)^2.
    The field (L1 + L2) lives on the outer links of plaquette 1 and is truncated too."""
    j1 = [(0, "L"), (1, "L")]
    sysm = GaugeFixedSystem(2, jmax,
                            plaquettes=[[(0, F)], [(1, F), (0, T)]],
                            energy=[(1.0, "cas", 0), (3.0, "cas", 1), (3.0, "field", j1)],
                            constraints=[j1], verbose=verbose)
    sysm.names = ["P1", "P2"]
    # (1/2) Tr(P1 P2^dag) = (1/2) Tr(U1 U1 U2^dag): neighbour twist correlation
    sysm.corr_word = [(0, F), (0, F), (1, T)]
    return sysm


def torus_1x1(jmax, verbose=False):
    """Periodic 1x1: one site, links Ux, Uy, P = Ux Uy Ux^dag Uy^dag.
    sum E^2 = C(Ux) + C(Uy)."""
    sysm = GaugeFixedSystem(2, jmax,
                            plaquettes=[[(0, F), (1, F), (0, T), (1, T)]],
                            energy=[(1.0, "cas", 0), (1.0, "cas", 1)], verbose=verbose)
    sysm.names = ["P"]
    return sysm


def torus_2x1(jmax, verbose=False):
    """Periodic 2x1 (Lx = 2, Ly = 1). Sites A, B. Tree: xA = 1.
    Dynamical X = xB, YA = yA, YB = yB.
    P_A = YB YA^dag, P_B = X YA X^dag YB^dag.
    Gauss law at A: E_xA = -(R_X + K_YA); sum E^2 = C(X) + C(YA) + C(YB) + (R_X + K_YA)^2."""
    exa = [(0, "R"), (1, "K")]
    sysm = GaugeFixedSystem(3, jmax,
                            plaquettes=[[(2, F), (1, T)], [(0, F), (1, F), (0, T), (2, T)]],
                            energy=[(1.0, "cas", 0), (1.0, "cas", 1), (1.0, "cas", 2), (1.0, "field", exa)],
                            constraints=[exa], verbose=verbose)
    sysm.names = ["P_A", "P_B"]
    return sysm


def torus_3x1(jmax, verbose=False):
    """Periodic 3x1 (Lx = 3, Ly = 1). Sites 0, 1, 2. Links x_s: s -> s+1 (mod 3), y_s: s -> s.
    Plaquette at site s: P_s = x_s y_{s+1} x_s^dag y_s^dag.
    Tree: x0 = x1 = 1. Dynamical X = x2, Y0, Y1, Y2 (engine links 0, 1, 2, 3):
        P_0 = Y1 Y0^dag,   P_1 = Y2 Y1^dag,   P_2 = X Y0 X^dag Y2^dag.
    Gauss law: E_x0 = -(R_X + K_Y0), E_x1 = -(R_X + K_Y0 + K_Y1), so
        sum E^2 = C(X) + C(Y0) + C(Y1) + C(Y2) + (R_X + K_Y0)^2 + (R_X + K_Y0 + K_Y1)^2.
    Both gauge fixed fields are truncated at jmax as well (their Casimirs commute)."""
    ex0 = [(0, "R"), (1, "K")]
    ex1 = [(0, "R"), (1, "K"), (2, "K")]
    sysm = GaugeFixedSystem(4, jmax,
                            plaquettes=[[(2, F), (1, T)], [(3, F), (2, T)], [(0, F), (1, F), (0, T), (3, T)]],
                            energy=[(1.0, "cas", 0), (1.0, "cas", 1), (1.0, "cas", 2), (1.0, "cas", 3),
                                    (1.0, "field", ex0), (1.0, "field", ex1)],
                            constraints=[ex0, ex1], verbose=verbose)
    sysm.names = ["P_0", "P_1", "P_2"]
    return sysm


def torus_2x2(jmax, verbose=False):
    """Periodic 2x2. Sites (x, y), x, y in {0, 1}. Links X_xy: (x,y) -> (x+1,y), Y_xy: (x,y) -> (x,y+1).
    Plaquette P_xy = X_xy Y_(x+1)y X_x(y+1)^dag Y_xy^dag.
    Tree {X00, Y00, X01} = 1. Dynamical (engine links): 0 = X10, 1 = X11, 2 = Y10, 3 = Y01, 4 = Y11.
        P00 = Y10,  P10 = X10 X11^dag Y10^dag,  P01 = Y11 Y01^dag,  P11 = X11 Y01 X10^dag Y11^dag.
    Gauss law (L at a link's start, R at its end):
        E_X00 = -(L0 + L2 + R4),  E_X01 = -(L1 + L4 + R2),  E_Y00 = -(K1 + L3 + L4 + R2),
    so sum E^2 = sum_dyn C + (L0+L2+R4)^2 + (L1+L4+R2)^2 + (K1+L3+L4+R2)^2.
    The three gauge fixed fields are truncated at jmax too; their Casimirs commute."""
    ex00 = [(0, "L"), (2, "L"), (4, "R")]
    ex01 = [(1, "L"), (4, "L"), (2, "R")]
    ey00 = [(1, "K"), (3, "L"), (4, "L"), (2, "R")]
    sysm = GaugeFixedSystem(5, jmax,
                            plaquettes=[[(2, F)], [(0, F), (1, T), (2, T)], [(4, F), (3, T)],
                                        [(1, F), (3, F), (0, T), (4, T)]],
                            energy=[(1.0, "cas", l) for l in range(5)] +
                                   [(1.0, "field", ex00), (1.0, "field", ex01), (1.0, "field", ey00)],
                            constraints=[ex00, ex01, ey00], verbose=verbose)
    sysm.names = ["P00", "P10", "P01", "P11"]
    return sysm


BUILDERS = {"single": single_plaquette, "open2x1": open_2x1, "torus1x1": torus_1x1,
            "torus2x1": torus_2x1, "torus3x1": torus_3x1, "torus2x2": torus_2x2}
