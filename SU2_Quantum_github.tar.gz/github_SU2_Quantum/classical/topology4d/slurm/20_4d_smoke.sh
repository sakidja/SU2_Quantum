#!/bin/bash -l
# 10 minute debug check of the 4D scripts before any production run.
#   sbatch slurm/20_4d_smoke.sh
#SBATCH -A mXXXX                  # <-- your NERSC project
#SBATCH -C cpu
#SBATCH -q debug
#SBATCH -N 1
#SBATCH -t 00:10:00
#SBATCH -J su2_4d_smoke
#SBATCH -o %x_%j.out
cd "$SLURM_SUBMIT_DIR/.."
source slurm/env_perlmutter.sh
srun -n 16 -c 2 --cpu-bind=cores "$PY" su2_4d_production.py \
     --L 8 --beta 2.3 --ntherm 100 --nmeas 5 --skip 5 --rmax 4 --out runs/smoke_L8_b2.3
"$PY" su2_4d_analysis.py runs/smoke_L8_b2.3 --outdir figures_4d_smoke
