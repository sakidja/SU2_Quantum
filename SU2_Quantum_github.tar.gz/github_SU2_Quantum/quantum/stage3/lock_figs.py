import numpy as np, json, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
B="#2A6FB0"; A="#C27A12"; G="#2E9E6B"; M="#B4457A"; INK="#1F2937"; MUT="#6B7280"; GRID="#E5E7EB"
plt.rcParams.update({"font.family":"DejaVu Sans","font.size":11,"axes.edgecolor":MUT,"axes.labelcolor":INK,"xtick.color":MUT,"ytick.color":MUT,"axes.spines.top":False,"axes.spines.right":False,"axes.grid":True,"grid.color":GRID,"grid.linewidth":0.6,"axes.axisbelow":True})
R=json.load(open("lock_results.json")); K=json.load(open("lock_checks.json"))
n=np.arange(len(R["random"]["C_mean"]))
# Figure 17: coherence vs number of loops
fig,ax=plt.subplots(figsize=(7.5,5.0))
for key,col,mk,lab in [("locked_pi",B,"o","locked, ψ = π (center vortex)"),("locked_pi2",A,"s","locked, ψ = π/2"),("locked_pi3",G,"^","locked, ψ = π/3"),("random",M,"D","random, same link statistics")]:
    ax.plot(n,R[key]["C_mean"],marker=mk,ms=6,lw=1.6 if key!="random" else 2.2,color=col,label=lab,mec="white",mew=1)
ax.axhline(0,color=MUT,lw=0.8)
ax.set_xlabel("number of loops n (coupling time)"); ax.set_ylabel("neutrino coherence  ½ Tr Wⁿ")
ax.set_ylim(-1.15,1.15); ax.legend(frameon=False,loc="upper center",bbox_to_anchor=(0.5,-0.16),fontsize=9.5,ncol=2)
ax.set_title("Locked loops keep a steady phase nψ; random loops lose it",fontsize=11,color=INK,loc="left")
fig.tight_layout(); fig.savefig("Fig_N5_lock_coherence.png",dpi=300)
# Figure 16: robustness to noise, signed coherence for psi = pi
fig,ax=plt.subplots(figsize=(7.5,5.0))
sgn=(-1.0)**n
ax.plot(n,np.array(R["locked_pi"]["C_mean"])*sgn,marker="o",ms=6,color=B,lw=1.8,label="locked ψ = π, no noise",mec="white",mew=1)
for eta,col,mk in [(0.05,G,"^"),(0.1,A,"s"),(0.2,M,"D")]:
    ax.plot(n,np.array(R[f"locked_pi_noise{eta}"]["C_mean"])*sgn,marker=mk,ms=5.5,color=col,lw=1.5,label=f"locked ψ = π, link noise η = {eta}",mec="white",mew=1)
ax.plot(n,np.array(R["random"]["C_mean"])*sgn,marker="x",ms=6,color=MUT,lw=1.2,label="random links")
ax.axhline(0,color=MUT,lw=0.8)
ax.set_xlabel("number of loops n"); ax.set_ylabel("(−1)ⁿ × neutrino coherence")
ax.set_ylim(-0.7,1.1); ax.legend(frameon=False,loc="upper center",bbox_to_anchor=(0.5,-0.16),fontsize=9.5,ncol=2)
ax.set_title("The locked phase survives weak link noise and decays gradually",fontsize=11,color=INK,loc="left")
fig.tight_layout(); fig.savefig("Fig_N6_lock_noise.png",dpi=300)
# Figure 18: identical local statistics
fig,axs=plt.subplots(1,2,figsize=(8.5,3.8))
lab=["random","locked ψ = π"]
sv=[R["random"]["sumvar_ck"],R["locked_pi"]["sumvar_ck"]]; pv=[K["parallel_probe"]["random"][0],K["parallel_probe"]["locked"][0]]
axs[0].bar(lab,sv,color=[M,B],width=0.55); axs[0].axhline(0.75,color=INK,ls="--",lw=1); axs[0].set_ylim(0,0.9)
for i,v in enumerate(sv): axs[0].text(i,v+0.02,f"{v:.4f}",ha="center",color=INK,fontsize=10)
axs[0].set_title("Σ Var(cₖ) per link (3/4 dashed)",fontsize=10.5,color=INK,loc="left")
axs[1].bar(lab,pv,color=[M,B],width=0.55); axs[1].set_ylim(0,1.1)
for i,v in enumerate(pv): axs[1].text(i,v+0.02,f"{v:.4f}",ha="center",color=INK,fontsize=10)
axs[1].set_title("local (parallel) probe variance",fontsize=10.5,color=INK,loc="left")
fig.suptitle("Local measurements cannot tell the two ensembles apart",fontsize=11,color=INK,x=0.02,ha="left")
fig.tight_layout(); fig.savefig("Fig_N7_lock_local_stats.png",dpi=300)
print("ok")
