#!/usr/bin/env python3
"""
su2_4d_analysis.py
Analysis of su2_4d_production.py runs (login node, no MPI).

  python su2_4d_analysis.py runs/L16_b2.3                       # one run
  python su2_4d_analysis.py runs/L16_b2.2 runs/L16_b2.3 runs/L16_b2.4 runs/L16_b2.5 --outdir figures_4d_bscan
  FIGSCALE=1.55 python su2_4d_analysis.py ...                   # paper sized text

Errors: delete one chain jackknife over the independent MPI chains (a single chain
is cut into blocks of consecutive configurations).

Per run (summary_4d_L{L}_b{beta}.json and Fig4D_L{L}_b{beta}.png):
  * plaquette <1/2 Tr P> (compare Creutz 1980), sum_k Var(c_k), P vortex density;
  * Creutz ratios chi(R) = -ln[W(R,R) W(R-1,R-1) / (W(R,R-1) W(R-1,R))] -> a^2 sigma;
    the string tension sets the physical scale, a sqrt(sigma);
  * the Z2 sign rule: W_{n_v}/W_0 and W_odd/W_even against R, for spatial and
    temporal planes separately and together;
  * the three twist modes (spatial planes, option A): populations s_i^2/sum s^2
    against R, real and null, with the 3D values 0.6924, 0.2664, 0.0412.
  * the neutrino probe in the ground state (FigT6_4D_L{L}_b{beta}.png, as Figure T6 in 3D):
    coherence C_n = <cos n psi> after n = 1..6 turns around a loop, by n_v and by vortex
    parity, for spatial and temporal planes separately (a temporal loop is the worldline
    of a static source, the probe sitting in the medium while Euclidean time passes).
With two or more couplings (FigS12_4D_lock_profile.png, lock_profile_4d.json):
  * the fraction of the Z2 quantum held, (1 - W_odd/W_even)/2, against the physical
    loop size x = R a sqrt(sigma), with a Fermi profile 1/(1 + exp(-(x - x0)/w)) fitted
    at each coupling; in 4D the width w is quoted in units of 1/sqrt(sigma).
"""
import argparse
import glob
import json
import os
import re
import warnings

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

warnings.simplefilter('ignore', RuntimeWarning)
FS = float(os.environ.get('FIGSCALE', '1'))
plt.rcParams.update({'font.size': 11 * FS, 'axes.spines.top': False, 'axes.spines.right': False})
COL = ['#2A6FB0', '#C27A12', '#2E9E6B', '#B4457A', '#555555', '#14213D']
POP3D = [0.6924, 0.2664, 0.0412]
KEYS = ['wrt', 'acc', 'hist', 'sv', 'sh', 'pr', 'extra']
EXT_ASIG = {}      # beta -> a sqrt(sigma) given on the command line (--asig)


def load(d):
    files = sorted(glob.glob(os.path.join(d, 'su2_4d_L*_b*_rank*.npz')),
                   key=lambda p: int(re.search(r'rank(\d+)', p).group(1)))
    chains, meta = [], None
    for p in files:
        z = np.load(p, allow_pickle=False)
        if 'extra' not in z.files or len(z['extra']) == 0:
            continue
        meta = json.loads(str(z['meta']))
        chains.append({k: z[k] for k in KEYS})
    if len(chains) == 1:
        c = chains[0]; n = len(c['extra']); cut = np.array_split(np.arange(n), min(10, n))
        chains = [{k: c[k][i] for k in KEYS} for i in cut]
    return chains, meta


def jack(chains, fn):
    """fn(dict of summed arrays, stacked extra) -> array; returns value and jackknife error."""
    S = [{k: c[k].sum(0) for k in KEYS if k != 'extra'} for c in chains]
    E = [c['extra'] for c in chains]
    tot = {k: sum(s[k] for s in S) for k in S[0]}
    full = np.asarray(fn(tot, np.concatenate(E)), float)
    n = len(chains)
    if n < 2:
        return full, np.zeros_like(full)
    jk = np.array([np.asarray(fn({k: tot[k] - S[i][k] for k in tot}, np.concatenate(E[:i] + E[i + 1:])), float)
                   for i in range(n)])
    err = np.sqrt((n - 1) / n * np.nansum((jk - np.nanmean(jk, 0)) ** 2, 0))
    return full, err


def f_extra(T, E):
    return E.mean(0)


def f_creutz(T, E):
    W = T['wrt'] / 1.0
    out = [np.nan, np.nan]
    for R in range(2, W.shape[0]):
        out.append(-np.log(W[R, R] * W[R - 1, R - 1] / (W[R, R - 1] * W[R - 1, R])))
    return np.array(out)                      # index R


def f_potential(T, E):
    """V(R) = ln[W(R, T0) / W(R, T0 + 1)] at the largest T0 with W(R, T0 + 1) resolved (T0 = rmax - 1)."""
    W = T['wrt']
    t0 = W.shape[0] - 2
    return np.array([np.nan] + [np.log(W[R, t0] / W[R, t0 + 1]) for R in range(1, W.shape[0])])


def cornell_fit(V, Ve, rmin=1):
    """Fit V(R) = V0 + sigma R - e/R; returns (sigma, err, e, V0) or None."""
    from scipy.optimize import curve_fit
    R = np.arange(len(V)); ok = np.isfinite(V) & np.isfinite(Ve) & (R >= rmin) & (Ve > 0) & (Ve < 0.5)
    if ok.sum() < 4:
        return None
    try:
        p, cv = curve_fit(lambda r, v0, s, e: v0 + s * r - e / r, R[ok], V[ok], p0=[0.5, 0.1, 0.25],
                          sigma=Ve[ok], absolute_sigma=True, maxfev=20000)
        return float(p[1]), float(np.sqrt(cv[1, 1])), float(p[2]), float(p[0])
    except Exception:
        return None


def f_oe(T, E):
    """W_odd/W_even per R for [spatial, temporal, all]."""
    A = T['acc']                              # (2, rmax, nv, j)
    out = []
    for sel in (A[0], A[1], A[0] + A[1]):
        ev = sel[:, 0::2, :].sum(1); od = sel[:, 1::2, :].sum(1)
        out.append((od[:, 1] / od[:, 0]) / (ev[:, 1] / ev[:, 0]))
    return np.array(out)


def f_nv(T, E):
    A = T['acc'][0] + T['acc'][1]
    W = A[:, :, 1] / A[:, :, 0]
    return W / W[:, :1]


def f_pop(T, E):
    """populations (squared shares) per R, real and null, all classes: (rmodes, 2, 3); and split ratio."""
    sv = T['sv'].sum(2)                        # (rmodes, 2, NSV)
    pop = sv[..., 4:7] / sv[..., :1]
    split = sv[..., 7] / sv[..., 0]
    return np.concatenate([pop, split[..., None]], -1)


def _types(A):
    return (A[0], A[1], A[0] + A[1])            # spatial, temporal, all planes


def f_cn_nv(T, E):
    """probe coherence C_n = <cos n psi> per (plane type, R, n_v = 0..2, n = 1..6)."""
    return np.array([a[:, :3, 1:] / a[:, :3, :1] for a in _types(T['acc'])])


def f_cn_par(T, E):
    """C_n per (plane type, R, parity even/odd, n = 1..6)."""
    out = []
    for a in _types(T['acc']):
        ev = a[:, 0::2, :].sum(1); od = a[:, 1::2, :].sum(1)
        out.append(np.stack([ev[:, 1:] / ev[:, :1], od[:, 1:] / od[:, :1]], 1))
    return np.array(out)


def f_cn_ratio(T, E):
    """C_n(odd n_v) / C_n(even n_v) per (plane type, R, n): -1 when the probe's phase is locked at pi."""
    p = f_cn_par(T, E)
    return p[:, :, 1, :] / p[:, :, 0, :]


def coherence_figure(cn, cne, cp, cpe, rsel, rmax, L, beta, nconf, outdir, tag, cr=None, cre=None):
    """Figure T6 in 4D: the probe carried n times around a loop in the ground state."""
    fig, ax = plt.subplots(2, 3, figsize=(19, 10))
    a0, a1, a4, a2, a3, a5 = ax.ravel()
    R = min(rsel, rmax); n = np.arange(1, cn.shape[-1] + 1)
    for nv, col in zip(range(3), [COL[0], COL[3], COL[2]]):
        a0.errorbar(n + 0.06 * (nv - 1), cn[2, R - 1, nv], yerr=cne[2, R - 1, nv], fmt='o-', color=col,
                    capsize=3, label=rf'$n_v$ = {nv} ({"odd" if nv % 2 else "even"})')
    a0.plot(n, [-0.5 if k == 2 else 0.0 for k in n], 'kx', ms=9, mew=2, label='Haar, no lock')
    a0.axhline(0, color='k', lw=0.6); a0.set_xticks(n)
    a0.set_xlabel('number of turns n around the loop'); a0.set_ylabel(r'$C_n=\langle\cos n\psi\rangle$')
    a0.set_title(f'(a) coherence after n turns, R = {R}, all planes'); a0.legend(fontsize=9 * FS)
    Rp = [r for r in range(2, rmax + 1) if np.nanmax(cpe[2, r - 1, :, 0]) < 0.05]
    for kk, (nt, mk, ls) in enumerate([(1, 'o', '-'), (3, 's', '--')]):
        for par, col in zip((0, 1), (COL[0], COL[3])):
            a1.errorbar(np.array(Rp) + 0.05 * (2 * kk - 1), cp[2, np.array(Rp) - 1, par, nt - 1],
                        yerr=cpe[2, np.array(Rp) - 1, par, nt - 1], fmt=mk + ls, color=col, capsize=3,
                        label=f'n = {nt}, {"odd" if par else "even"} ' + r'$n_v$')
    a1.axhline(0, color='k', lw=0.6); a1.set_xticks(Rp)
    a1.set_xlabel('loop side R'); a1.set_ylabel(r'$C_n$'); a1.set_title('(b) odd turns: sign set by vortex parity')
    a1.legend(fontsize=9 * FS, ncol=2)
    for axx, nt, lab in ((a2, 1, '(c)'), (a3, 3, '(d)')):
        for ti, (tn, mk) in enumerate([('spatial', 'o-'), ('temporal', 's--')]):
            for par, col in zip((0, 1), (COL[0], COL[3])):
                axx.errorbar(np.array(Rp) + 0.05 * (2 * ti - 1), cp[ti, np.array(Rp) - 1, par, nt - 1],
                             yerr=cpe[ti, np.array(Rp) - 1, par, nt - 1], fmt=mk, color=col, capsize=3,
                             alpha=1.0 if ti == 0 else 0.75,
                             label=f'{tn}, {"odd" if par else "even"} ' + r'$n_v$')
        axx.axhline(0, color='k', lw=0.6); axx.set_xticks(Rp)
        axx.set_xlabel('loop side R'); axx.set_ylabel(rf'$C_{nt}$')
        axx.set_title(f'{lab} n = {nt}: spatial against temporal planes'); axx.legend(fontsize=8.5 * FS, ncol=2)
    # (e), (f): the mirror as a ratio, C_n(odd)/C_n(even); for n = 1 this is W_odd/W_even itself
    Rr = np.arange(1, rmax + 1)
    for k, (nt, mk) in enumerate([(1, 'o-'), (3, 's--'), (5, '^:')]):
        ok = (cre[2, :, nt - 1] < 0.3) & (Rr >= 2)
        a4.errorbar(Rr[ok] + 0.05 * (k - 1), cr[2, ok, nt - 1], yerr=cre[2, ok, nt - 1], fmt=mk, color=COL[k],
                    capsize=3, label=f'n = {nt}' + (r'  (= $W_{odd}/W_{even}$)' if nt == 1 else ''))
    for axx in (a4, a5):
        axx.axhline(-1, color='k', ls=':', lw=1.2, label='locked phase, $-1$'); axx.axhline(0, color='k', lw=0.6)
        axx.set_xlabel('loop side R'); axx.set_ylabel(r'$C_n(\mathrm{odd}\ n_v)\,/\,C_n(\mathrm{even}\ n_v)$')
        axx.set_ylim(-1.5, 1.2)
    a4.set_title('(e) the mirror as a ratio, all planes'); a4.legend(fontsize=9 * FS)
    for ti, (tn, mk) in enumerate([('spatial', 'o-'), ('temporal', 's--')]):
        ok = (cre[ti, :, 2] < 0.3) & (Rr >= 2)
        a5.errorbar(Rr[ok] + 0.06 * (2 * ti - 1), cr[ti, ok, 2], yerr=cre[ti, ok, 2], fmt=mk, color=COL[ti],
                    capsize=3, label=f'n = 3, {tn} planes')
    a5.set_title('(f) three turns: spatial against temporal'); a5.legend(fontsize=9 * FS)
    if FS == 1:
        fig.suptitle(f'ground state probe coherence, 4D, L = {L}, beta = {beta}, {nconf} configurations', y=1.01)
    fig.tight_layout(); fig.savefig(os.path.join(outdir, f'FigT6_4D_{tag}.png'), dpi=200, bbox_inches='tight')
    plt.close(fig)


def analyse(d, outdir, rsel=3):
    chains, meta = load(d)
    if not chains:
        raise SystemExit('no measurements in ' + d)
    L, beta, rmax, rmodes = meta['L'], meta['beta'], meta['rmax'], meta['rmodes']
    nconf = sum(len(c['extra']) for c in chains)
    ex, exe = jack(chains, f_extra)
    cr, cre = jack(chains, f_creutz)
    oe, oee = jack(chains, f_oe)
    rn, rne = jack(chains, f_nv)
    pp, ppe = jack(chains, f_pop)
    cn, cne = jack(chains, f_cn_nv)
    cp, cpe = jack(chains, f_cn_par)
    cnt = sum(c['acc'].sum(0) for c in chains).sum(0)[:, :, 0]       # (rmax, nv)

    # a^2 sigma, three estimates: (i) Cornell fit to the static potential, (ii) the largest resolved
    # Creutz ratio (biased high at small R by the Coulomb term), (iii) an external value (--asig)
    vp, vpe = jack(chains, f_potential)
    cf = cornell_fit(vp, vpe)
    good = [R for R in range(2, rmax + 1) if np.isfinite(cr[R]) and cr[R] > 0 and cre[R] < 0.15 * cr[R]]
    Rs = max(good) if good else None
    a2s_cr = (float(cr[Rs]), float(cre[Rs])) if Rs else (np.nan, np.nan)
    if EXT_ASIG.get(beta):
        asig = (EXT_ASIG[beta], 0.0); scale_src = 'external (--asig)'
        a2s = (asig[0] ** 2, 0.0)
    elif cf and cf[0] > 0 and cf[1] < 0.3 * cf[0]:
        a2s = (cf[0], cf[1]); asig = (np.sqrt(cf[0]), 0.5 * cf[1] / np.sqrt(cf[0])); scale_src = 'Cornell fit'
    elif Rs:
        a2s = a2s_cr; asig = (np.sqrt(a2s[0]), 0.5 * a2s[1] / np.sqrt(a2s[0])); scale_src = f'Creutz ratio R = {Rs}'
    else:
        a2s = asig = (np.nan, np.nan); scale_src = 'none'

    names = meta['extra_names']
    S = dict(L=L, beta=beta, nd=meta['nd'], rmax=rmax, rmodes=rmodes, n_configs=nconf, n_chains=len(chains),
             gribov=meta['gribov'], extras={k: [float(ex[i]), float(exe[i])] for i, k in enumerate(names)},
             creutz_ratio={R: [float(cr[R]), float(cre[R])] for R in range(2, rmax + 1)},
             a2_sigma=[float(a2s[0]), float(a2s[1])], a_sqrt_sigma=[float(asig[0]), float(asig[1])], scale_source=scale_src,
             a2_sigma_creutz=[a2s_cr[0], a2s_cr[1], Rs],
             cornell_fit=dict(sigma=cf[0], sigma_err=cf[1], e=cf[2], V0=cf[3]) if cf else None,
             potential={R: [float(vp[R]), float(vpe[R])] for R in range(1, rmax + 1)},
             w_odd_over_even={k: [[float(oe[i, R - 1]), float(oee[i, R - 1])] for R in range(1, rmax + 1)]
                              for i, k in enumerate(['spatial', 'temporal', 'all'])},
             w_nv_over_w0={R: dict(count=cnt[R - 1, :6].astype(int).tolist(),
                                   ratio=np.nan_to_num(rn[R - 1, :6]).tolist(),
                                   err=np.nan_to_num(rne[R - 1, :6]).tolist()) for R in range(1, rmax + 1)},
             populations={R: dict(real=pp[R - 1, 0, :3].tolist(), real_err=ppe[R - 1, 0, :3].tolist(),
                                  null=pp[R - 1, 1, :3].tolist(), null_err=ppe[R - 1, 1, :3].tolist(),
                                  split_real=[float(pp[R - 1, 0, 3]), float(ppe[R - 1, 0, 3])],
                                  split_null=[float(pp[R - 1, 1, 3]), float(ppe[R - 1, 1, 3])])
                          for R in range(1, rmodes + 1)},
             populations_3d_reference=POP3D,
             probe_coherence={tn: {R: dict(C_n_by_nv=np.nan_to_num(cn[i, R - 1]).tolist(),
                                          C_n_by_nv_err=np.nan_to_num(cne[i, R - 1]).tolist(),
                                          C_n_even_odd=np.nan_to_num(cp[i, R - 1]).tolist(),
                                          C_n_even_odd_err=np.nan_to_num(cpe[i, R - 1]).tolist())
                                 for R in range(1, rmax + 1)}
                             for i, tn in enumerate(['spatial', 'temporal', 'all'])})
    os.makedirs(outdir, exist_ok=True)
    tag = f'L{L}_b{beta}'
    json.dump(S, open(os.path.join(outdir, f'summary_4d_{tag}.json'), 'w'), indent=1)

    print(f'\n4D SU(2)  L = {L}  beta = {beta}  {nconf} configurations, {len(chains)} chains')
    print(f'  plaquette <1/2 Tr P> = {ex[0]:.5f} +/- {exe[0]:.5f}  (spatial {ex[1]:.5f}, temporal {ex[2]:.5f})')
    print(f'  sum Var c_k = {ex[3]:.4f} +/- {exe[3]:.4f}   P vortex density = {ex[4]:.4f} +/- {exe[4]:.4f}')
    print('  Creutz ratios chi(R): ' + ', '.join(f'R={R}: {cr[R]:.4f}({cre[R]:.4f})' for R in range(2, rmax + 1)))
    print('  potential V(R): ' + ', '.join(f'{vp[R]:.4f}({vpe[R]:.4f})' for R in range(1, rmax + 1)))
    if cf:
        print(f'  Cornell fit: a^2 sigma = {cf[0]:.4f} +/- {cf[1]:.4f}, e = {cf[2]:.3f}')
    print(f'  largest resolved Creutz ratio: {a2s_cr[0]:.4f} +/- {a2s_cr[1]:.4f} (R = {Rs})')
    print(f'  scale used: a sqrt(sigma) = {asig[0]:.4f} +/- {asig[1]:.4f}  [{scale_src}]')
    print('   R   W_odd/W_even: spatial          temporal           all            populations (real)        null')
    for R in range(1, rmax + 1):
        pr = f'{pp[R-1,0,0]:.4f} {pp[R-1,0,1]:.4f} {pp[R-1,0,2]:.4f}   {pp[R-1,1,0]:.4f} {pp[R-1,1,1]:.4f} {pp[R-1,1,2]:.4f}' \
            if R <= rmodes else ''
        print(f'  {R:2d}   {oe[0,R-1]:+.4f} +/- {oee[0,R-1]:.4f}   {oe[1,R-1]:+.4f} +/- {oee[1,R-1]:.4f}   '
              f'{oe[2,R-1]:+.4f} +/- {oee[2,R-1]:.4f}   {pr}')

    # ---------------------------------------------------------------- per run figure
    fig, ax = plt.subplots(2, 2, figsize=(13, 10))
    a0, a1, a2, a3 = ax.ravel()
    k = np.arange(6)
    for i, R in enumerate([R for R in range(2, rmax + 1) if cnt[R - 1, 0] > 1000][:5]):
        ks = [kk for kk in k if cnt[R - 1, kk] > 1000 and (kk == 0 or rne[R - 1, kk] < 0.2)]
        a0.errorbar(np.array(ks) + 0.05 * (i - 2), rn[R - 1, ks], yerr=rne[R - 1, ks], fmt='o-',
                    color=COL[i], capsize=3, label=f'R = {R}')
    a0.plot(k, (-1.0) ** k, 'kx', ms=9, mew=2, label=r'Z$_2$ lock $(-1)^{n_v}$')
    a0.axhline(0, color='k', lw=0.6); a0.set_xticks(k)
    a0.set_xlabel(r'vortices piercing the loop, $n_v$'); a0.set_ylabel(r'$W_{n_v}/W_0$')
    a0.set_title('(a) sign per vortex, all six planes'); a0.legend(fontsize=8.5 * FS, ncol=2)
    Rr = np.arange(1, rmax + 1)
    for i, (lab, mk) in enumerate([('spatial planes', 'o-'), ('temporal planes', 's--'), ('all planes', '^:')]):
        ok = oee[i] < 0.3
        a1.errorbar(Rr[ok] + 0.06 * (i - 1), oe[i][ok], yerr=oee[i][ok], fmt=mk, color=COL[i], capsize=3, label=lab)
    a1.axhline(-1, color='k', ls=':', lw=1.2, label=r'Z$_2$ lock, $-1$'); a1.axhline(0, color='k', lw=0.6)
    a1.set_xlabel('loop side R'); a1.set_ylabel(r'$W_{odd}/W_{even}$'); a1.set_ylim(-1.35, 0.8)
    a1.set_title('(b) approach to the lock'); a1.legend(fontsize=9 * FS)
    Rc = [R for R in range(2, rmax + 1) if np.isfinite(cr[R]) and cre[R] < 0.5]
    a2.errorbar(Rc, [cr[R] for R in Rc], yerr=[cre[R] for R in Rc], fmt='o-', color=COL[5], capsize=3)
    if np.isfinite(a2s[0]):
        a2.axhline(a2s[0], color=COL[1], ls='--', label=rf'$a^2\sigma$ = {a2s[0]:.3f}({a2s[1]:.3f}), {scale_src}')
        a2.legend(fontsize=9 * FS)
    a2.set_xlabel('R'); a2.set_ylabel(r'Creutz ratio $\chi(R)$'); a2.set_title('(c) string tension')
    Rm = np.arange(1, rmodes + 1)
    for j in range(3):
        a3.errorbar(Rm, pp[:, 0, j], yerr=ppe[:, 0, j], fmt='o-', color=COL[j], capsize=3, label=f'mode {j+1}')
        a3.plot(Rm, pp[:, 1, j], 'x:', color=COL[j], ms=7, label=f'null {j+1}' if j == 0 else None)
        a3.axhline(POP3D[j], color=COL[j], lw=0.8, ls='--')
    a3.set_xlabel('loop side R'); a3.set_ylabel(r'population $s_i^2/\sum s^2$')
    a3.set_title('(d) three twist modes, spatial planes (dashed: 3D values)'); a3.legend(fontsize=8.5 * FS, ncol=2)
    if FS == 1:
        fig.suptitle(f'4D SU(2), L = {L}, beta = {beta}, {nconf} configurations, {len(chains)} chains', y=1.01)
    fig.tight_layout(); fig.savefig(os.path.join(outdir, f'Fig4D_{tag}.png'), dpi=200, bbox_inches='tight')
    plt.close(fig)
    rr, rre = jack(chains, f_cn_ratio)
    for i, tn in enumerate(['spatial', 'temporal', 'all']):
        for R in range(1, rmax + 1):
            S['probe_coherence'][tn][R]['C_n_odd_over_even'] = np.nan_to_num(rr[i, R - 1]).tolist()
            S['probe_coherence'][tn][R]['C_n_odd_over_even_err'] = np.nan_to_num(rre[i, R - 1]).tolist()
    json.dump(S, open(os.path.join(outdir, f'summary_4d_{tag}.json'), 'w'), indent=1)
    coherence_figure(cn, cne, cp, cpe, rsel, rmax, L, beta, nconf, outdir, tag, rr, rre)
    print('  probe C_n(odd)/C_n(even), all planes, n = 1, 3, 5: ' + ', '.join(
        f'R={R}: {rr[2,R-1,0]:+.3f}({rre[2,R-1,0]:.3f}) {rr[2,R-1,2]:+.3f}({rre[2,R-1,2]:.3f}) {rr[2,R-1,4]:+.3f}({rre[2,R-1,4]:.3f})'
        for R in range(2, rmax + 1)))
    print('  probe C_1 (even, odd n_v), all planes: ' + ', '.join(
        f'R={R}: {cp[2,R-1,0,0]:+.4f}/{cp[2,R-1,1,0]:+.4f}' for R in range(2, rmax + 1)))
    return S


def fermi(x, x0, w):
    return 1.0 / (1.0 + np.exp(-(x - x0) / w))


def profile(summaries, outdir):
    from scipy.optimize import curve_fit
    rows = []
    fig, ax = plt.subplots(1, 2, figsize=(13, 4.8))
    xx = np.linspace(0, 4, 300)
    for i, S in enumerate(sorted(summaries, key=lambda s: s['beta'])):
        asg = S['a_sqrt_sigma'][0]
        if not np.isfinite(asg):
            print(f"beta {S['beta']}: string tension not resolved, skipped in the profile"); continue
        W = np.array(S['w_odd_over_even']['all']); R = np.arange(1, len(W) + 1); x = R * asg
        ok = W[:, 1] < 0.1
        Lq = (1 - W[ok, 0]) / 2; eL = W[ok, 1] / 2
        ax[0].errorbar(x[ok], Lq, yerr=eL, fmt='o', color=COL[i % len(COL)], capsize=2, label=rf"$\beta$ = {S['beta']}")
        row = dict(beta=S['beta'], L=S['L'], a_sqrt_sigma=asg, x=x[ok].tolist(), held=Lq.tolist())
        if ok.sum() >= 3:
            try:
                p, _ = curve_fit(fermi, x[ok], Lq, p0=[x[ok].mean(), 0.2], sigma=eL + 1e-3, maxfev=20000)
                ax[0].plot(xx, fermi(xx, *p), '-', color=COL[i % len(COL)], lw=1.2, alpha=0.8)
                row.update(x0=float(p[0]), w=float(p[1]), w_lattice=float(p[1] / asg),
                           max_resid=float(np.abs(Lq - fermi(x[ok], *p)).max()))
            except Exception as e:                                 # too few points in the transition
                row.update(fit_error=str(e))
        rows.append(row)
    ax[0].set_xlabel(r'physical loop size $R\,a\sqrt{\sigma}$'); ax[0].set_ylabel('fraction of the quantum held')
    ax[0].set_title('(a) the lock profile, 4D'); ax[0].legend(fontsize=9 * FS)
    fit = [r for r in rows if 'w' in r]
    if fit:
        a = [r['a_sqrt_sigma'] for r in fit]
        ax[1].plot(a, [r['w'] for r in fit], 'o-', color='#14213D', ms=8, label=r'width $w$, units of $1/\sqrt{\sigma}$')
        ax[1].plot(a, [r['w_lattice'] for r in fit], 's--', color='#8FA3C4', ms=7, label='width in lattice units')
        ax[1].plot(a, [r['x0'] for r in fit], '^-', color='#E8A33D', ms=8, label=r'half point $x_0$')
        ax[1].legend(fontsize=9 * FS)
    ax[1].set_xlabel(r'lattice spacing $a\sqrt{\sigma}$'); ax[1].set_ylabel('fitted value')
    ax[1].set_title('(b) is the width fixed in physical units?')
    fig.tight_layout(); fig.savefig(os.path.join(outdir, 'FigS12_4D_lock_profile.png'), dpi=200, bbox_inches='tight')
    json.dump(rows, open(os.path.join(outdir, 'lock_profile_4d.json'), 'w'), indent=1)
    print('\n beta   a sqrt(sigma)   x0          w (1/sqrt sigma)   w (lattice)')
    for r in rows:
        print(f" {r['beta']:.2f}   {r['a_sqrt_sigma']:.4f}        " +
              (f"{r['x0']:.3f}      {r['w']:.3f}              {r['w_lattice']:.3f}" if 'w' in r else 'no fit'))
    if len(fit) >= 2:
        ws = np.array([r['w'] for r in fit]); wl = np.array([r['w_lattice'] for r in fit])
        print(f'width in physical units: {ws.mean():.3f} +/- {ws.std(ddof=1):.3f} '
              f'(spread {100 * ws.std(ddof=1) / ws.mean():.1f} %); in lattice units {wl.min():.2f} to {wl.max():.2f}')


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('rundirs', nargs='+')
    ap.add_argument('--outdir', default=None)
    ap.add_argument('--rsel', type=int, default=3, help='loop size for panel (a) of FigT6_4D')
    ap.add_argument('--asig', nargs='*', default=[], metavar='BETA=VALUE',
                    help='use an external a sqrt(sigma) for a coupling, e.g. --asig 2.3=0.369 2.5=0.188')
    a = ap.parse_args()
    for s in a.asig:
        b, v = s.split('='); EXT_ASIG[float(b)] = float(v)
    out = a.outdir or ('figures_4d_' + os.path.basename(os.path.normpath(a.rundirs[0])))
    S = [analyse(d, out, a.rsel) for d in a.rundirs]
    if len(S) >= 2:
        profile(S, out)
    print('wrote', out)


if __name__ == '__main__':
    main()
