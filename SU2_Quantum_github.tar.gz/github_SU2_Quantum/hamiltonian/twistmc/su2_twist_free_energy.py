#!/usr/bin/env python3
"""
su2_twist_free_energy.py

Center ('t Hooft) twist free energy for classical SU(2) lattice gauge theory,
built on su2_classical_twist.py (same quaternion algebra, exact Creutz heat
bath, Wilson real trace action and twist readout).

Part of the SU2_Quantum project (R. Sakidja, Missouri State University).
Code drafted with AI (LLM) assistance (Claude, Anthropic) and reviewed by the author.

Lattice
-------
Lx x Ly x Lt periodic (Ly = Lx), directions 0, 1, 2 = x, y, t. Even extents
(checkerboard heat bath). Plaquette weights w_p enter the action as
    S = -beta * sum_p w_p c0_p ,    c0_p = (1/2) Re Tr U_p ,
so the staple of every link carries the weight of its plaquette.

Twist
-----
A twist stack is one xy plaquette per time slice, at a fixed (x0, y0). Its
weight is interpolated as w = 1 - 2 lambda: lambda = 0 is the untwisted
theory, lambda = 1 flips the sign of those plaquettes, i.e. a Z2 center flux
through every xy plane. Then
    F_twist - F = integral_0^1 d lambda < dS/d lambda >_lambda
                = 2 beta * integral_0^1 d lambda < sum_stack c0 >_lambda .
Each run measures one lambda; combine_twist.py does the Gauss Legendre
integral over lambda. With a long time extent, (F_twist - F) / Lt approaches
the Hamiltonian twist energy of the Lx x Ly spatial torus.

Controls: --nstacks 2 places two stacks in the same planes; two center fluxes
cancel, so the integral must vanish within errors.

At lambda = 0 and lambda = 1 the full readout of su2_classical_twist.py is
recorded as well (mean c0, sum_k Var(c_k), hedgehog charges, twist density),
so the hedgehog density can be compared between the two ensembles.

Example:
  python3 su2_twist_free_energy.py --Lx 4 --Lt 16 --beta 2.2 --lam 0.5 \
      --configs 2000 --therm 500 --skip 5 --seed 42 --out run_tw/L4_T16_lam0.5_s42.json
"""
import argparse
import json
import os
import time

import numpy as np

from su2_classical_twist import (SU2Lattice3D, qmul, qdag, transport, measure, FIELDS, tau_int)

PLANES = [(0, 1), (1, 2), (2, 0)]
PLANE_INDEX = {frozenset(p): i for i, p in enumerate(PLANES)}


class TwistedLattice(SU2Lattice3D):
    def __init__(self, Lx, Lt, beta, rng, lam=0.0, nstacks=1):
        shape = (Lx, Lx, Lt)
        if any(n % 2 for n in shape):
            raise SystemExit("all extents must be even (checkerboard heat bath)")
        self.shape = shape
        self.L = Lx
        self.beta = beta
        self.rng = rng
        self.links = np.zeros((3,) + shape + (4,))
        self.links[..., 0] = 1.0
        self.parity = (np.indices(shape).sum(axis=0) % 2).astype(bool)
        self.W = np.ones((3,) + shape)
        self.stacks = [(Lx - 1, Lx - 1), (Lx // 2 - 1, Lx // 2 - 1)][:nstacks]
        for (x0, y0) in self.stacks:
            self.W[0, x0, y0, :] = 1.0 - 2.0 * lam

    def staples(self, mu):
        U = self.links
        s = np.zeros(self.shape + (4,))
        for nu in range(3):
            if nu == mu:
                continue
            p = PLANE_INDEX[frozenset((mu, nu))]
            Wf = self.W[p]                       # plaquette based at x
            Wb = self.shift(self.W[p], nu, -1)   # plaquette based at x - nu
            Unu = U[nu]
            Umu_xnu = self.shift(U[mu], nu)
            Unu_xmu = self.shift(U[nu], mu)
            s += Wf[..., None] * qmul(Unu_xmu, qmul(qdag(Umu_xnu), qdag(Unu)))
            Unu_b = self.shift(Unu, nu, -1)
            Umu_b = self.shift(U[mu], nu, -1)
            Unu_bm = self.shift(Unu_b, mu)
            s += Wb[..., None] * qmul(qdag(Unu_bm), qmul(qdag(Umu_b), Unu_b))
        return s

    def plaquettes(self):
        U = self.links
        P = np.empty((3,) + self.shape + (4,))
        for p, (mu, nu) in enumerate(PLANES):
            P[p] = qmul(U[mu], qmul(self.shift(U[nu], mu),
                                     qmul(qdag(self.shift(U[mu], nu)), qdag(U[nu]))))
        return P

    def twist_density(self, P):
        T_c0 = np.zeros(self.shape)
        T_or = np.zeros(self.shape)
        for p in range(3):
            for rho in range(3):
                Pt = transport(self.links[rho], self.shift(P[p], rho))
                d0 = P[p][..., 0] - Pt[..., 0]
                dv = P[p][..., 1:] - Pt[..., 1:]
                T_c0 += 2.0 * d0 * d0
                T_or += 2.0 * np.sum(dv * dv, axis=-1)
        return T_c0 + T_or, T_c0, T_or

    def stack_c0(self, P=None):
        """Mean c0 over all stack plaquettes (one per time slice per stack)."""
        if P is None:
            P = self.plaquettes()
        return float(np.mean([P[0, x0, y0, :, 0].mean() for (x0, y0) in self.stacks]))


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--Lx", type=int, required=True, help="spatial extent (Lx = Ly)")
    ap.add_argument("--Lt", type=int, required=True, help="time extent")
    ap.add_argument("--beta", type=float, default=2.2)
    ap.add_argument("--lam", type=float, required=True, help="twist interpolation, 0 untwisted, 1 twisted")
    ap.add_argument("--nstacks", type=int, default=1, choices=[1, 2])
    ap.add_argument("--configs", type=int, default=1000)
    ap.add_argument("--therm", type=int, default=500)
    ap.add_argument("--skip", type=int, default=5)
    ap.add_argument("--seed", type=int, default=42)
    ap.add_argument("--full", choices=["auto", "yes", "no"], default="auto",
                    help="full twist readout per config (auto: only at lambda 0 and 1)")
    ap.add_argument("--checkpoint-every", type=int, default=200)
    ap.add_argument("--save-configs", type=int, default=-1,
                    help="number of configurations to keep for the vortex eye analysis "
                         "(default: 20 at lambda 0 and 1, none otherwise; 0 disables)")
    ap.add_argument("--resume", action="store_true")
    ap.add_argument("--out", required=True)
    a = ap.parse_args()

    full = a.full == "yes" or (a.full == "auto" and a.lam in (0.0, 1.0))
    nsave = a.save_configs if a.save_configs >= 0 else (20 if a.lam in (0.0, 1.0) else 0)
    save_every = max(a.configs // nsave, 1) if nsave > 0 else 0
    cfg_file = a.out.replace(".json", "") + "_configs.npz"
    saved = []
    os.makedirs(os.path.dirname(os.path.abspath(a.out)) or ".", exist_ok=True)
    ckpt = a.out.replace(".json", "") + "_ckpt.npz"
    rng = np.random.default_rng(a.seed)
    lat = TwistedLattice(a.Lx, a.Lt, a.beta, rng, a.lam, a.nstacks)

    stack, rows, done = [], [], 0
    if a.resume and os.path.exists(ckpt):
        d = np.load(ckpt, allow_pickle=False)
        lat.links = d["links"]
        rng.bit_generator.state = json.loads(str(d["rng_state"]))
        stack = list(d["stack"]); rows = [list(r) for r in d["rows"]] if d["rows"].size else []
        done = int(d["sweeps"])
        if save_every and os.path.exists(cfg_file):
            saved = list(np.load(cfg_file)["links"])
        print(f"[resume] {len(stack)} configs restored", flush=True)

    t0 = time.time()
    if done == 0:
        for _ in range(a.therm):
            lat.heatbath_sweep()
        done = a.therm

    def write(final):
        s = np.array(stack)
        tau = tau_int(s) if len(s) > 8 else 1.0
        res = dict(Lx=a.Lx, Ly=a.Lx, Lt=a.Lt, beta=a.beta, lam=a.lam, nstacks=a.nstacks,
                   stacks=lat.stacks, seed=a.seed, therm=a.therm, skip=a.skip,
                   n_configs=len(s), finished=final,
                   stack_c0_mean=float(s.mean()) if len(s) else None,
                   stack_c0_std=float(s.std()) if len(s) else None,
                   tau_int=tau,
                   stack_c0_err=float(s.std() * np.sqrt(tau / max(len(s), 1))) if len(s) else None,
                   n_stack_plaquettes=a.nstacks * a.Lt,
                   action="Wilson real trace, weights 1 - 2*lambda on the twist stacks (exact Creutz heat bath)",
                   wall_seconds=time.time() - t0)
        if rows:
            r = np.array(rows)
            vol = a.Lx * a.Lx * a.Lt
            res["full"] = {f: [float(r[:, i].mean()), float(r[:, i].std() / np.sqrt(len(r)))]
                           for i, f in enumerate(FIELDS)}
            res["full"]["Q_sq_per_cell"] = [float(r[:, FIELDS.index("Q_sq_sum")].mean() / vol),
                                            float(r[:, FIELDS.index("Q_sq_sum")].std() / np.sqrt(len(r)) / vol)]
        json.dump(res, open(a.out, "w"), indent=1)
        if saved:
            np.savez_compressed(cfg_file, links=np.array(saved), W=lat.W.astype(np.float32),
                                Lx=a.Lx, Lt=a.Lt, beta=a.beta, lam=a.lam, stacks=np.array(lat.stacks))
            res["configs_file"] = os.path.basename(cfg_file)
            res["n_saved_configs"] = len(saved)
            json.dump(res, open(a.out, "w"), indent=1)
        np.savez_compressed(ckpt, links=lat.links, rng_state=json.dumps(rng.bit_generator.state),
                            stack=np.array(stack), rows=np.array(rows), sweeps=done)
        return res

    while len(stack) < a.configs:
        for _ in range(a.skip):
            lat.heatbath_sweep()
        done += a.skip
        P = lat.plaquettes()
        stack.append(lat.stack_c0(P))
        if save_every and len(stack) % save_every == 0 and len(saved) < nsave:
            saved.append(lat.links.astype(np.float32))
        if full:
            m = measure(lat)
            rows.append([m[f] for f in FIELDS])
        if len(stack) % a.checkpoint_every == 0:
            write(False)
            print(f"[ckpt] {len(stack)}/{a.configs} configs, {time.time()-t0:.0f}s", flush=True)
    res = write(True)
    print(json.dumps({k: v for k, v in res.items() if k != "full"}, indent=1))


if __name__ == "__main__":
    main()
