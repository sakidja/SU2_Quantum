#!/bin/bash
# Third lattice size for the twist scaling test: periodic 3x1.
# Run from the package directory, after updating the code:
#   bash slurm/submit_3x1.sh
# Local timing (2 cores): jmax 1.5 builds in 8 min, 0.5 GB. Cost grows roughly
# 60x per half step in jmax, so jmax 2 and 2.5 are the Perlmutter jobs.
# Part of the SU2_Quantum project. Drafted with AI (LLM) assistance (Claude, Anthropic).
set -e
mkdir -p logs results
# Fewer worker processes for the larger truncations: each worker holds whole
# blocks of the basis, and the largest jmax 2.5 blocks take several GB each.
sub () {  # name jmax walltime nproc
  sbatch --job-name=$1 --time=$3 \
         --export=ALL,SYSTEM=torus3x1,JMAX=$2,NPROC=$4,TWISTS="--twist 1 1 1 --twist -1 1 1" slurm/run_case.sbatch
}
sub su2_t31_j1.5 1.5 00:30:00 128
sub su2_t31_j2   2   06:00:00 64
sub su2_t31_j2.5 2.5 36:00:00 32
# If su2_t31_j2.5 ends OUT_OF_MEMORY, resubmit it alone with nproc 16.
