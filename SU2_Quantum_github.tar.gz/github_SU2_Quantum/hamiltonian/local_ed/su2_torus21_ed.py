"""
2x1 periodic SU(2) lattice (Lx = 2, Ly = 1), gauge fixed, with and without a
center ('t Hooft) twist. Compared with the 1x1 periodic lattice to see how the
twist energy depends on lattice size.

Part of the SU2_Quantum project (R. Sakidja, Missouri State University).
Code drafted with AI (LLM) assistance (Claude, Anthropic) and reviewed by the author.

Geometry
--------
Sites A (x = 0) and B (x = 1). Links: xA: A -> B, xB: B -> A (periodic),
yA: A -> A, yB: B -> B (periodic in y with Ly = 1).
Plaquettes: P_A = xA yB xA^dag yA^dag,  P_B = xB yA xB^dag yB^dag.
Gauge fixing: xA = 1. Dynamical links X = xB, YA = yA, YB = yB:
    P_A = YB YA^dag,   P_B = X YA X^dag YB^dag.
Gauss law at A gives the field on the fixed link: E_xA = -(R_X + K_YA), K = L + R, so
    sum E^2 = C(X) + C(YA) + C(YB) + (R_X + K_YA)^2.
H = (g^2/2) sum E^2 + (4/g^2) sum_p (1 - s_p c0_p).
A twist s_A = -1 on one plaquette cannot be removed by flipping links (every
link flip changes the sign of both plaquettes or neither), so it is a genuine
center flux. Truncation: every link, including xA, carries j <= jmax.

Invariant basis for three links (reps a, b, c on X, YA, YB):
    sum_M |((a b) k, c) J M>_left |((a b) k', c) J M>_right
labelled (a, b, c, k, k', J).
"""
import numpy as np
import scipy.sparse as sp
import json, time
from su2_lattice_core import LinkSpace, cg, jlist, mlist

H2 = [0.5, -0.5]


def kron3(A, B, C):
    return sp.kron(sp.kron(A, B, format="csr"), C, format="csr")


def coupled_vectors(a, b, c, k, J, M):
    """Components of |((a b) k, c) J M> as dict over (ma, mb, mc)."""
    out = {}
    for mk in mlist(k):
        mc = M - mk
        if abs(mc) > c + 1e-9:
            continue
        w1 = cg(k, mk, c, mc, J, M)
        if w1 == 0.0:
            continue
        for ma in mlist(a):
            mb = mk - ma
            if abs(mb) > b + 1e-9:
                continue
            w2 = cg(a, ma, b, mb, k, mk)
            if w2 != 0.0:
                out[(ma, mb, mc)] = out.get((ma, mb, mc), 0.0) + w1 * w2
    return out


def invariant_basis_three(spaces, jmax):
    sX, sA, sB = spaces
    nA, nB = sA.dim, sB.dim
    rows, cols, vals, labels = [], [], [], []
    col = 0
    for a in jlist(jmax):
        for b in jlist(jmax):
            for c in jlist(jmax):
                ks = [abs(a - b) + i for i in range(int(round(a + b - abs(a - b))) + 1)]
                for J in jlist(a + b + c):
                    paths = [k for k in ks if abs(k - c) - 1e-9 <= J <= k + c + 1e-9 and abs((k + c + J) - round(k + c + J)) < 1e-9]
                    for k in paths:
                        for kp in paths:
                            ent = {}
                            for M in mlist(J):
                                Lv = coupled_vectors(a, b, c, k, J, M)
                                Rv = coupled_vectors(a, b, c, kp, J, M)
                                for (ma, mb, mc), u in Lv.items():
                                    for (na, nb, nc), v in Rv.items():
                                        r = (sX.idx[(a, ma, na)] * nA + sA.idx[(b, mb, nb)]) * nB + sB.idx[(c, mc, nc)]
                                        ent[r] = ent.get(r, 0.0) + u * v
                            nrm = np.sqrt(sum(x * x for x in ent.values()))
                            if nrm < 1e-12:
                                continue
                            for r, x in ent.items():
                                rows.append(r); cols.append(col); vals.append(x / nrm)
                            labels.append((a, b, c, k, kp, J))
                            col += 1
    N = sX.dim * nA * nB
    return sp.csr_matrix((vals, (rows, cols)), shape=(N, col)), labels


def build(jmax):
    jcut = jmax + 1.0
    sX, sA, sB = LinkSpace(jcut), LinkSpace(jcut), LinkSpace(jcut)
    B, labels = invariant_basis_three((sX, sA, sB), jmax)
    IX, IA, IB = (sp.identity(s.dim, format="csr") for s in (sX, sA, sB))
    LX, KX = sX.generators()
    LA, KA = sA.generators()
    _, KB = sB.generators()
    RX = [KX[i] - LX[i] for i in range(3)]
    # gauge invariance check
    Kerr = max(abs((kron3(KX[i], IA, IB) + kron3(IX, KA[i], IB) + kron3(IX, IA, KB[i])) @ B).max() for i in range(3))
    # electric field on the gauge fixed link xA: (R_X + K_YA)^2
    Exa = [kron3(RX[i], IA, IB) + kron3(IX, KA[i], IB) for i in range(3)]
    Cxa = sum((B.T.conjugate() @ (E.conjugate().T @ (E @ B))) for E in Exa)
    Cxa = np.real(Cxa.toarray())
    w, V = np.linalg.eigh(0.5 * (Cxa + Cxa.T))
    keep = w <= jmax * (jmax + 1) + 1e-8
    # allowed Casimir values are j(j+1); confirm
    allowed = np.array([j * (j + 1) for j in jlist(4 * jmax + 2)])
    cas_err = max(np.min(np.abs(allowed - x)) for x in w)
    Vk = V[:, keep]
    Cdiag = np.array([a * (a + 1) + b * (b + 1) + c * (c + 1) for (a, b, c, k, kp, J) in labels])
    EC = V[:, keep].T @ (np.diag(Cdiag) + Cxa) @ V[:, keep]
    # plaquette operators
    cA = sp.csr_matrix((B.shape[0],) * 2)
    for p in H2:
        for q in H2:
            # (1/2) Tr(YB YA^dag) = (1/2) sum YB_pq (YA^dag)_qp
            cA = cA + 0.5 * kron3(IX, sA.Mdag(q, p), sB.M(p, q))
    cB = sp.csr_matrix((B.shape[0],) * 2)
    for p in H2:
        for q in H2:
            for r in H2:
                for t in H2:
                    # (1/2) X_pq YA_qr (X^dag)_rt (YB^dag)_tp
                    cB = cB + 0.5 * kron3(sX.M(p, q) @ sX.Mdag(r, t), sA.M(q, r), sB.Mdag(t, p))
    CA = Vk.T @ (B.T @ (cA @ B)).toarray() @ Vk
    CB = Vk.T @ (B.T @ (cB @ B)).toarray() @ Vk
    return dict(B=B, Vk=Vk, EC=EC, CA=CA, CB=CB, cA=cA, cB=cB, n=Vk.shape[1], Kerr=Kerr, cas_err=cas_err)


def solve(S, g2, sA=1, sB=1, nlev=4):
    n = S["n"]
    H = 0.5 * g2 * S["EC"] + (4.0 / g2) * (2 * np.eye(n) - sA * S["CA"] - sB * S["CB"])
    H = 0.5 * (H + H.T)
    w, v = np.linalg.eigh(H)
    psi = S["B"] @ (S["Vk"] @ v[:, 0])
    a = S["cA"] @ psi
    b = S["cB"] @ psi
    return dict(g2=g2, E=w[:nlev].tolist(), gap=w[1] - w[0],
                c0_A=float(psi @ a), c0_B=float(psi @ b),
                sumVar_A=float(1 - a @ a), sumVar_B=float(1 - b @ b))


if __name__ == "__main__":
    out = {}
    g2s = [1.0, 1.5, 4 / 2.2, 2.5, 3.0, 4.0, 5.0, 8.0]
    for jmax in [0.5, 1.0, 1.5]:
        t = time.time()
        S = build(jmax)
        print(f"jmax={jmax}: {S['n']} states, gauge check {S['Kerr']:.1e}, Casimir check {S['cas_err']:.1e}, {time.time()-t:.1f}s", flush=True)
        out[str(jmax)] = {"untwisted": [solve(S, g) for g in g2s],
                          "twisted": [solve(S, g, sA=-1) for g in g2s],
                          "twisted_B": [solve(S, g, sB=-1) for g in g2s],
                          "double": [solve(S, g, sA=-1, sB=-1) for g in g2s]}
    json.dump(out, open("su2_torus21_results.json", "w"), indent=1)
