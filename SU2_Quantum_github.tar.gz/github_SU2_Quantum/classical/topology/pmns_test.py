#!/usr/bin/env python3
"""
pmns_test.py
Laptop test (no NERSC): how likely is the measured lepton mixing under the
SU(2) three mode picture? Figure T9 and pmns_test_summary.json.

Background (job 13). For loops larger than the correlation length the mode
populations s_i^2 / sum s^2 of the 3x3 colour by plane matrix M[a, p] = w_p^a
sit at 0.6924 / 0.2664 / 0.0412, and the orientation scrambled null gives the
same numbers to 1e-5. That is the value for three independent Haar random SU(2)
holonomies. This script
  1. confirms that fixed point, and that real lattice loops reproduce not only
     the mean populations but their full per sample distribution
     (a small local lattice, --lattice, default on);
  2. test T1: the measured electron row |U_e1|^2, |U_e2|^2, |U_e3|^2 against the
     per sample population distribution (density percentile p value), with the
     anarchy baselines: a Haar random U(3) row and a Haar random O(3) row;
  3. test T2: the three mixing angles read from the plane by mode rotation V of the
     same SVD (M = U S V^T, modes ordered by population) against O(3) and U(3) Haar;
  4. T3: the CP phase. The SU(2) adjoint is real, so V is a real rotation and
     delta_CP is 0 or 180 degrees; compared with the global fit.

Measured values: NuFIT 6.0 (Esteban et al., JHEP 12 (2024) 216), normal ordering,
IC24 with SK atmospheric data; the IC19 set is printed for comparison.

  python pmns_test.py                     # about 2 minutes, writes figures_pmns/
  python pmns_test.py --no-lattice --n 4000000
"""
import argparse
import json
import os
import sys
import time

import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

FS = float(os.environ.get('FIGSCALE', '1'))
plt.rcParams.update({'font.size': 11 * FS, 'axes.spines.top': False, 'axes.spines.right': False})
COL = ['#2A6FB0', '#C27A12', '#2E9E6B', '#B4457A', '#555555']

NUFIT = {   # normal ordering, best fit and 1 sigma
    'IC24 with SK': dict(s12=(0.308, 0.012), s13=(0.02215, 0.00056), s23=(0.470, 0.017), dcp=(212, 33)),
    'IC19 without SK': dict(s12=(0.307, 0.012), s13=(0.02195, 0.00054), s23=(0.561, 0.012), dcp=(177, 20)),
}


def erow(p):
    s12, s13 = p['s12'][0], p['s13'][0]
    return np.array([(1 - s12) * (1 - s13), s12 * (1 - s13), s13])


# ---------------------------------------------------------------- samplers
def haar_su2_M(n, rng):
    q = rng.normal(size=(n, 3, 4))
    q /= np.linalg.norm(q, axis=-1, keepdims=True)
    return np.transpose(q[..., 1:], (0, 2, 1))              # (n, colour a, plane p)


def lattice_M(L, beta, R, ntherm, nconf, skip, seed):
    from su2_topology_heatbath import sweep
    from topo_measure import line_products
    from locked_modes import square_loops
    rng = np.random.default_rng(seed)
    links = np.zeros((3, L, L, L, 4)); links[..., 0] = 1.0
    idx = np.indices((L, L, L)).sum(0) % 2
    for _ in range(ntherm):
        sweep(links, beta, rng, idx)
    out = []
    for _ in range(nconf):
        for _ in range(skip):
            sweep(links, beta, rng, idx)
        lines = [line_products(links[mu], mu, R) for mu in range(3)]
        W = square_loops(links, R, lines).reshape(3, L ** 3, 4)
        out.append(np.transpose(W[..., 1:], (1, 2, 0)))     # (sites, a, p)
    return np.concatenate(out)


def modes(M):
    U, s, Vt = np.linalg.svd(M)                              # descending s
    e = s ** 2 / (s ** 2).sum(-1, keepdims=True)
    V = np.transpose(Vt, (0, 2, 1))                          # (n, plane, mode)
    return e, V


def angles_from_rows(K):
    """K: (n, 3, 3) with |K|^2 doubly stochastic, rows = flavours (e, mu, tau),
    columns = mass states (1, 2, 3). Returns sin^2 theta12, theta13, theta23."""
    A = np.abs(K) ** 2
    s13 = A[:, 0, 2]
    c13 = np.clip(1 - s13, 1e-300, None)
    return A[:, 0, 1] / c13, s13, A[:, 1, 2] / c13


def haar_O3(n, rng):
    Q, R = np.linalg.qr(rng.normal(size=(n, 3, 3)))
    return Q * np.sign(np.diagonal(R, axis1=1, axis2=2))[:, None, :]


def haar_U3(n, rng):
    Z = rng.normal(size=(n, 3, 3)) + 1j * rng.normal(size=(n, 3, 3))
    Q, R = np.linalg.qr(Z)
    d = np.diagonal(R, axis1=1, axis2=2)
    return Q * (d / np.abs(d))[:, None, :]


# ---------------------------------------------------------------- statistics
def density_pvalue(X, x0, bins, rng_, smooth=1.0):
    """X: (n, k) samples, x0: (k,). Histogram density, lightly smoothed; returns
    (p, rho0): p is the probability carried by cells whose density is at or below the
    density at x0 (within 2 percent, so a flat distribution gives p near 1; small p means
    x0 sits in a sparse region), rho0 the probability density at x0."""
    from scipy.ndimage import gaussian_filter
    H, edges = np.histogramdd(X, bins=bins, range=rng_)
    H = gaussian_filter(H / H.sum(), smooth, mode='nearest')
    H = H / H.sum()
    ix = tuple(int(np.clip(np.searchsorted(e, v, side='right') - 1, 0, bins - 1)) for e, v in zip(edges, x0))
    vol = np.prod([(e[1] - e[0]) for e in edges])
    return float(H[H <= 1.02 * H[ix]].sum()), float(H[ix] / vol)


def sorted_rows(A):
    return -np.sort(-A, axis=-1)


def main():
    ap = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument('--n', type=int, default=2_000_000)
    ap.add_argument('--no-lattice', action='store_true')
    ap.add_argument('--L', type=int, default=16)
    ap.add_argument('--beta', type=float, default=2.2)
    ap.add_argument('--R', type=int, default=3)
    ap.add_argument('--nconf', type=int, default=120)
    ap.add_argument('--seed', type=int, default=20260925)
    ap.add_argument('--job13', default=os.path.join(os.path.dirname(os.path.abspath(__file__)),
                                                    '..', '..', 'data', 'nersc_summaries', 'lmodes_summary_L24.json'))
    ap.add_argument('--outdir', default='figures_pmns')
    a = ap.parse_args()
    os.makedirs(a.outdir, exist_ok=True)
    rng = np.random.default_rng(a.seed)
    t0 = time.time()
    S = dict(nufit='NuFIT 6.0, JHEP 12 (2024) 216, normal ordering', n_samples=a.n)

    # 1. fixed point
    eH, VH = modes(haar_su2_M(a.n, rng))
    fixed = eH.mean(0)
    print('SU(2) Haar fixed point, populations  :', np.round(fixed, 4))
    S['fixed_point'] = fixed.tolist()
    med = np.median(eH, 0)
    print('SU(2) Haar per sample medians          :', np.round(med, 4), '(the distribution is skewed; mode 3 most of all)')
    S['fixed_point_median'] = med.tolist()
    if os.path.exists(a.job13):
        j = json.load(open(a.job13))
        big = np.array(j['shares_real_all'][3:]).mean(0)
        print('job 13 (L = 24, R = 4..7), real loops :', np.round(big, 4))
        S['job13_R4to7'] = big.tolist()
    eL = VL = None
    if not a.no_lattice:
        print(f'local lattice: L={a.L} beta={a.beta} R={a.R} nconf={a.nconf} ...', flush=True)
        ML = lattice_M(a.L, a.beta, a.R, 300, a.nconf, 5, a.seed + 1)
        eL, VL = modes(ML)
        print('local lattice loops, populations       :', np.round(eL.mean(0), 4), f'({len(eL)} loop triples)')
        qs = [0.1, 0.5, 0.9]
        print('  per sample quantiles of mode 3, lattice | Haar:',
              np.round(np.quantile(eL[:, 2], qs), 4), '|', np.round(np.quantile(eH[:, 2], qs), 4))
        S['lattice'] = dict(L=a.L, beta=a.beta, R=a.R, n=len(eL), mean=eL.mean(0).tolist(),
                            q_mode3=np.quantile(eL[:, 2], qs).tolist(), q_mode3_haar=np.quantile(eH[:, 2], qs).tolist(),
                            q_mode1=np.quantile(eL[:, 0], qs).tolist(), q_mode1_haar=np.quantile(eH[:, 0], qs).tolist())

    # baselines for the electron row
    rowU3 = sorted_rows(np.abs(haar_U3(a.n, rng)[:, 0, :]) ** 2)
    rowO3 = sorted_rows(haar_O3(a.n, rng)[:, 0, :] ** 2)
    models1 = {'SU(2) populations': eH, 'U(3) Haar row (anarchy)': rowU3, 'O(3) Haar row': rowO3}
    if eL is not None:
        models1['SU(2) populations, lattice'] = eL

    # 2. T1
    S['T1'] = {}
    print('\nT1  electron row vs per sample populations (density percentile p value; 1 typical, 0 extreme)')
    for tag, p in NUFIT.items():
        x0 = erow(p)
        print(f'  measured electron row ({tag}): {np.round(x0, 4)}')
        S['T1'][tag] = dict(row=x0.tolist())
        rho = {}
        for name, X in models1.items():
            pv, rho[name] = density_pvalue(X[:, [0, 2]], x0[[0, 2]], 40, [(1 / 3, 1), (0, 1 / 3)])
            dist = float(np.linalg.norm(X.mean(0) - x0))
            print(f'    {name:30s} mean {np.round(X.mean(0), 4)}  |mean - measured| {dist:.4f}  '
                  f'p {pv:.3f}  density at measured {rho[name]:.2f}')
            S['T1'][tag][name] = dict(mean=X.mean(0).tolist(), dist=dist, p=pv, density=rho[name])
        base = rho['SU(2) populations']
        for name in ('U(3) Haar row (anarchy)', 'O(3) Haar row'):
            print(f'    likelihood ratio SU(2) populations : {name} = {base / rho[name]:.2f}')
            S['T1'][tag]['LR_vs_' + name] = base / rho[name]

    # 3. T2  angles from V (rows: planes as flavours, columns: modes by population)
    angH = angles_from_rows(VH)
    angO = angles_from_rows(haar_O3(a.n, rng))
    angU = angles_from_rows(haar_U3(a.n, rng))
    models2 = {'SU(2) V rotation': angH, 'O(3) Haar': angO, 'U(3) Haar (anarchy)': angU}
    if VL is not None:
        models2['SU(2) V rotation, lattice'] = angles_from_rows(VL)
    S['T2'] = {}
    print('\nT2  mixing angles from the plane by mode rotation V')
    for tag, p in NUFIT.items():
        x0 = np.array([p['s12'][0], p['s13'][0], p['s23'][0]])
        S['T2'][tag] = {}
        print(f'  measured ({tag}): sin2 12, 13, 23 = {x0}')
        for name, (a12, a13, a23) in models2.items():
            X = np.stack([a12, a13, a23], 1)
            pv, rho = density_pvalue(X, x0, 20, [(0, 1)] * 3)
            p13 = float((a13 <= x0[1]).mean())
            print(f'    {name:28s} P(sin2 th13 <= measured) {p13:.3f}   joint density p {pv:.3f}  density {rho:.2f}')
            S['T2'][tag][name] = dict(P_s13_le=p13, p_joint=pv, density=rho)

    # 4. T3
    S['T3'] = {tag: dict(dcp_deg=p['dcp'][0], err=p['dcp'][1],
                         sigma_from_180=abs(p['dcp'][0] - 180) / p['dcp'][1],
                         sigma_from_0=min(abs(p['dcp'][0] - 360), abs(p['dcp'][0])) / p['dcp'][1])
               for tag, p in NUFIT.items()}
    print('\nT3  CP phase: a real rotation gives delta_CP = 0 or 180 deg')
    for tag, v in S['T3'].items():
        print(f'  {tag}: {v["dcp_deg"]} +/- {v["err"]} deg, {v["sigma_from_180"]:.2f} sigma from 180, '
              f'{v["sigma_from_0"]:.2f} sigma from 0')

    with open(os.path.join(a.outdir, 'pmns_test_summary.json'), 'w') as f:
        json.dump(S, f, indent=1)

    # figure T9
    fig, ax = plt.subplots(1, 3, figsize=(18, 5.3))
    H, xe, ye = np.histogram2d(eH[:, 0], eH[:, 2], bins=80, range=[(1 / 3, 1), (0, 1 / 3)])
    ax[0].imshow(np.log10(H.T + 1), origin='lower', aspect='auto', extent=[xe[0], xe[-1], ye[0], ye[-1]], cmap='Blues')
    for (name, X), c, mk in zip(list(models1.items())[:3], [COL[0], COL[1], COL[2]], ['o', 's', '^']):
        m = X.mean(0); ax[0].plot(m[0], m[2], mk, color=c, ms=9, mec='k', label=f'{name}, mean')
    x0 = erow(NUFIT['IC24 with SK'])
    ax[0].plot(x0[0], x0[2], '*', color=COL[3], ms=16, mec='k', label='measured electron row')
    ax[0].set_xlabel('largest weight'); ax[0].set_ylabel('smallest weight')
    ax[0].set_title('(a) three populations, per sample (SU(2) Haar)'); ax[0].legend(fontsize=8 * FS, loc='upper right')
    bins = np.linspace(0, 1 / 3, 60)
    for (name, X), c in zip(models1.items(), [COL[0], COL[1], COL[2], COL[4]]):
        ls = '--' if 'lattice' in name else '-'
        ax[1].hist(X[:, 2], bins=bins, density=True, histtype='step', lw=2, color=c, ls=ls, label=name)
    ax[1].axvline(x0[2], color=COL[3], lw=2, label=r'measured $|U_{e3}|^2$')
    ax[1].set_xlabel('smallest weight'); ax[1].set_ylabel('density')
    ax[1].set_title('(b) the third mode'); ax[1].legend(fontsize=8 * FS)
    xs = np.linspace(0, 0.2, 400)
    for (name, (_, a13, _)), c in zip(models2.items(), [COL[0], COL[2], COL[1], COL[4]]):
        ls = '--' if 'lattice' in name else '-'
        ax[2].plot(xs, np.searchsorted(np.sort(a13), xs) / len(a13), ls, color=c, lw=2, label=name)
    ax[2].axvline(NUFIT['IC24 with SK']['s13'][0], color=COL[3], lw=2, label=r'measured $\sin^2\theta_{13}$')
    ax[2].set_xlabel(r'$\sin^2\theta_{13}$'); ax[2].set_ylabel('cumulative probability')
    ax[2].set_title(r'(c) $\theta_{13}$ from the rotation'); ax[2].legend(fontsize=8 * FS)
    fig.tight_layout(); fig.savefig(os.path.join(a.outdir, 'FigT9_pmns_test.png'), dpi=250, bbox_inches='tight')
    plt.close(fig)
    print(f'\nwrote {a.outdir}  ({time.time() - t0:.0f} s)')


if __name__ == '__main__':
    main()
