#!/usr/bin/env python3
"""
Post-process rank checkpoints on Perlmutter: load thermalized links,
run the production measurement on them, and dump SITE-LEVEL fields
(Q per cell, theta, |div F|, m*_CTC) for topology visualization.

Runs serially on a login/compute node - no MPI needed, one checkpoint
at a time. Output: one npz per checkpoint with the full 3D fields.

USAGE
  python postprocess_topology.py ckpt_cl_L32_rank4.npz [more ckpts...]
  # or all ranks at once:
  python postprocess_topology.py ckpt_cl_L32_rank*.npz

>>> ONE LINE TO EDIT, marked [EDIT] below: import your measurement
>>> function from your production script so the fields are computed by
>>> YOUR construction, not a reimplementation.
"""

import sys
import numpy as np

# [EDIT] import your production measurement here, e.g.:
# from ctc_su2_production import measure_fields
# It must accept the links array (3, L, L, L, 4) and return the
# site/cell-level arrays BEFORE reduction, e.g.:
#   fields = measure_fields(links)
#   fields['Q']      -> (L, L, L)  hedgehog charge per cell
#   fields['theta']  -> (L, L, L)  per site
#   fields['divF']   -> (L, L, L)  |div F| per site
#   fields['m_ctc']  -> (L, L, L)  theta / |div F| per site
# If your measure() currently reduces to scalars internally, copy it,
# strip the reductions, and return the arrays instead - no other change.
from YOUR_PRODUCTION_MODULE import measure_fields  # [EDIT]


def process(ckpt_path):
    z = np.load(ckpt_path)
    links = z['links']                      # (3, L, L, L, 4)
    L = links.shape[1]
    sweeps = int(z['sweeps_done'])
    n_rows = z['rows'].shape[0]

    fields = measure_fields(links)

    out = ckpt_path.replace('ckpt_', 'fields_').replace('.npz', '_topo.npz')
    np.savez_compressed(
        out,
        L=L,
        sweeps_done=sweeps,
        n_configs_recorded=n_rows,
        source=ckpt_path,
        **{k: np.asarray(v) for k, v in fields.items()},
    )

    # cross-check: reduced values from the dumped fields should match
    # the checkpoint's own last measurement row (rows[-1]) if the links
    # are exactly the last measured config. Print both; small drift means
    # the checkpoint was saved a few sweeps past the last measurement.
    q = np.asarray(fields.get('Q'))
    m = np.asarray(fields.get('m_ctc'))
    print(f'{ckpt_path}: L={L} sweeps={sweeps} rows={n_rows} -> {out}')
    if q is not None:
        print(f'  sum Q^2 from fields : {float((q**2).sum()):.6f}')
    if m is not None:
        print(f'  m*_CTC median       : {float(np.median(m)):.6f}')
        print(f'  m*_CTC min          : {float(m.min()):.6f}')
    print(f'  rows[-1] (for comparison): {z["rows"][-1]}')


if __name__ == '__main__':
    if len(sys.argv) < 2:
        sys.exit('usage: postprocess_topology.py <ckpt.npz> [more...]')
    for p in sys.argv[1:]:
        process(p)
