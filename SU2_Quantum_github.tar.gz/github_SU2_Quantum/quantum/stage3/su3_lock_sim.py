#!/usr/bin/env python3
"""
su3_lock_sim.py
SU(3) version of the Stage 3 topological lock (companion to lock_sim.py).

A probe is put in superposition; one branch is transported around a closed
loop of N SU(3) links. Its coherence after n loops is
    C_n = (1/3) Tr(W^n),   W = U_1 U_2 ... U_N  (the loop holonomy)
(complex in SU(3); the Hadamard test reads Re and Im separately).

Random ensemble : every link independent Haar SU(3).
Locked ensemble : U_j = V_j R V_{j+1}^+ with V_j Haar and
                  R = G diag(e^{i a/N}, e^{i a/N}, e^{-2i a/N}) G^+, G Haar.
                  Every link is still exactly Haar distributed, so the local
                  statistics are identical to the random ensemble, but the loop
                  carries a fixed class: W = V_1 G diag(e^{ia},e^{ia},e^{-2ia}) G^+ V_1^+.
                  a = 2 pi/3 gives W = exp(2 pi i/3) * identity: the Z3 center vortex.
Noise           : every link multiplied by exp(i eta sum_a u_a lambda_a/2), u random unit.

Local statistic: Sigma = 1 - <|Tr U / 3|^2>, the SU(3) analog of
sum_k Var(c_k) = 1 - <c0^2>; Haar gives exactly 1 - 1/9 = 8/9 (SU(2): 3/4).

Usage
    python su3_lock_sim.py                   # writes su3_lock_results.json
    python su3_lock_sim.py --ncfg 20000      # more statistics
"""
import argparse
import json

import numpy as np
from scipy.linalg import expm

# Gell-Mann matrices
LAM = np.zeros((8, 3, 3), complex)
LAM[0][0, 1] = LAM[0][1, 0] = 1
LAM[1][0, 1] = -1j; LAM[1][1, 0] = 1j
LAM[2][0, 0] = 1; LAM[2][1, 1] = -1
LAM[3][0, 2] = LAM[3][2, 0] = 1
LAM[4][0, 2] = -1j; LAM[4][2, 0] = 1j
LAM[5][1, 2] = LAM[5][2, 1] = 1
LAM[6][1, 2] = -1j; LAM[6][2, 1] = 1j
LAM[7] = np.diag([1, 1, -2]) / np.sqrt(3)
OMEGA = np.exp(2j * np.pi / 3)


def haar_su3(rng):
    Z = (rng.normal(size=(3, 3)) + 1j * rng.normal(size=(3, 3))) / np.sqrt(2)
    Q, R = np.linalg.qr(Z)
    Q = Q @ np.diag(np.diag(R) / np.abs(np.diag(R)))
    return Q / np.linalg.det(Q) ** (1 / 3)


def noise(rng, eta):
    if eta <= 0:
        return np.eye(3, dtype=complex)
    u = rng.normal(size=8); u /= np.linalg.norm(u)
    return expm(1j * eta * rng.normal() * np.einsum('a,aij->ij', u, LAM) / 2)


def config(rng, N, kind, a, eta):
    if kind == 'random':
        links = [haar_su3(rng) for _ in range(N)]
    else:
        V = [haar_su3(rng) for _ in range(N)]
        G = haar_su3(rng)
        R = G @ np.diag(np.exp(1j * a / N * np.array([1, 1, -2]))) @ G.conj().T
        links = [V[j] @ R @ V[(j + 1) % N].conj().T for j in range(N)]
    return [noise(rng, eta) @ U for U in links]


def run(kind, N=8, n_max=12, n_cfg=4000, a=2 * np.pi / 3, eta=0.0, seed=0):
    rng = np.random.default_rng(seed)
    C = np.zeros((n_cfg, n_max + 1), complex)
    t = []
    for i in range(n_cfg):
        links = config(rng, N, kind, a, eta)
        t.extend(np.trace(U) / 3 for U in links)
        W = np.eye(3, dtype=complex)
        for U in links:
            W = W @ U
        Wn = np.eye(3, dtype=complex)
        for n in range(n_max + 1):
            C[i, n] = np.trace(Wn) / 3
            Wn = Wn @ W
    t = np.array(t)
    return dict(kind=kind, N=N, a=a, eta=eta, n_cfg=n_cfg,
                local_mean_trace=[float(t.real.mean()), float(t.imag.mean())],
                local_Sigma=float(1 - (np.abs(t) ** 2).mean()),
                C_re=C.real.mean(0).tolist(), C_im=C.imag.mean(0).tolist(),
                C_err=(np.abs(C).std(0) / np.sqrt(n_cfg)).tolist(),
                C_abs=np.abs(C).mean(0).tolist())


def expected_locked(a, n_max=12):
    n = np.arange(n_max + 1)
    return ((2 * np.exp(1j * n * a) + np.exp(-2j * n * a)) / 3)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('--ncfg', type=int, default=4000)
    ap.add_argument('--out', default='su3_lock_results.json')
    args = ap.parse_args()
    n = args.ncfg
    out = {}
    out['random'] = run('random', n_cfg=n, seed=1)
    out['locked_Z3'] = run('locked', a=2 * np.pi / 3, n_cfg=n, seed=2)
    out['locked_pi2'] = run('locked', a=np.pi / 2, n_cfg=n, seed=5)
    for eta in (0.05, 0.1, 0.2):
        out[f'locked_Z3_noise{eta}'] = run('locked', a=2 * np.pi / 3, eta=eta, n_cfg=n, seed=3)
        out[f'random_noise{eta}'] = run('random', eta=eta, n_cfg=n, seed=4)
    out['length_scan'] = {}
    for N in (4, 8, 16, 32, 64):
        out['length_scan'][N] = dict(
            locked=run('locked', N=N, a=2 * np.pi / 3, n_cfg=max(n // 4, 500), seed=10 + N),
            locked_noise=run('locked', N=N, a=2 * np.pi / 3, eta=0.05, n_cfg=max(n // 4, 500), seed=20 + N))
    out['expected_Z3'] = dict(re=expected_locked(2 * np.pi / 3).real.tolist(),
                              im=expected_locked(2 * np.pi / 3).imag.tolist())
    with open(args.out, 'w') as f:
        json.dump(out, f, indent=1)
    for k, v in out.items():
        if k in ('length_scan', 'expected_Z3'):
            continue
        print(f"{k:22s} Sigma={v['local_Sigma']:.4f}  Re C_n(0..6)={np.round(v['C_re'][:7], 3)}"
              f"  Im={np.round(v['C_im'][:4], 3)}")
    print('length scan (Re C_1, locked / locked+noise 0.05):')
    for N, v in out['length_scan'].items():
        print(f"  N={N:3d}  {v['locked']['C_re'][1]:+.4f}  {v['locked_noise']['C_re'][1]:+.4f}")


if __name__ == '__main__':
    main()
