#!/usr/bin/env python3
"""
topo_measure.py
Topology measurements on a 3D SU(2) gauge configuration.

Input format (identical to the production checkpoints ckpt_cl_L*_rank*.npz):
    links : float64 array, shape (3, L, L, L, 4)
            scalar first unit quaternions, links[mu][x] = U_mu(x)

Quaternion product convention is the one used in the production and
analysis scripts (analysis/twist_visualization.py), so every number here
is directly comparable with the S6 campaign.

What is measured on one configuration (function measure):
  1. Plaquette channel: <c0>, <c0^2>, sum_k Var(c_k).
  2. Hedgehog charge per unit cell: n(x) = c(x)/|c(x)| with c(x) the
     plaquette Pauli vector summed over the three planes at site x; the
     degree of n on each cell surface (12 triangles, signed solid angles)
     is an integer Q per cell. Reported: <Q^2>, <|Q|>, charged fraction,
     total Q (zero on the torus by topology), charge histogram.
  3. Charge correlator C_Q(r) = <Q(x) Q(x+r)>: contact term C_Q(0),
     radial profile, running sum S(R) = sum_{|r|<=R} C_Q(r), and the
     structure factor chi(k) at the smallest lattice momenta. chi(0) is
     identically zero because the total charge vanishes, so the contact
     term must be cancelled exactly by a negative tail.
  4. Wilson loops W(R,T) = <1/2 Tr U(loop)> for R,T <= rmax, averaged over
     all positions and the three planes. Square loops also give the
     holonomy angle psi = arccos(1/2 Tr W) (histogram, compared with the
     Haar density (2/pi) sin^2 psi) and the neutrino probe quantities for
     transport around the loop: coherence C_n = <1/2 Tr W^n> = <cos n psi>
     for n = 1..nmax and the probe variance V_nu = 1 - <(1/2 Tr W)^2>.
  6. Center vortices (vortex_stats): direct maximal center gauge, center
     projection, P-vortex plaquettes. Every square loop is classified by
     the number n_v of P-vortices piercing its flat surface; the full,
     gauge invariant loop value and the probe coherence cos(k psi) are
     averaged per class. A Z2 lock shows up as <1/2 Tr W>_{n_v} / <..>_0
     -> (-1)^{n_v}: every vortex adds a phase pi to the transported probe.
  5. Lock test: for square R x R loops, the Wilson loop value is binned by
     the hedgehog content of the unit cells directly above and below the
     flat surface spanned by the loop (a slab of 2*slab layers). Two
     counts per loop: N = sum |Q| (number of hedgehogs, with multiplicity)
     and q = sum Q (net charge). Output: <W | N>, <W | q>, and a null
     baseline in which the charge field is displaced by a random offset
     so any geometric link between loop and charge is destroyed.

Pure numpy, no MPI; the drivers (su2_topology_heatbath.py and
measure_checkpoints.py) handle parallelism.
"""

import numpy as np

PLANES = [(0, 1), (0, 2), (1, 2)]


# ------------------------------------------------------------ quaternions
def qmul(p, q):
    a0, av = p[..., 0], p[..., 1:]
    b0, bv = q[..., 0], q[..., 1:]
    c0 = a0 * b0 - (av * bv).sum(-1)
    cv = a0[..., None] * bv + b0[..., None] * av + np.cross(av, bv)
    return np.concatenate([c0[..., None], cv], axis=-1)


def qconj(q):
    out = q.copy()
    out[..., 1:] *= -1
    return out


def shift(a, mu, n=1):
    """a(x + n*mu) on the periodic lattice (site axes are 0,1,2)."""
    return np.roll(a, -n, axis=mu)


def plaquette(links, mu, nu):
    Um, Un = links[mu], links[nu]
    return qmul(qmul(Um, shift(Un, mu)), qmul(qconj(shift(Um, nu)), qconj(Un)))


# ------------------------------------------------------------ 1. plaquettes
def plaquette_stats(links):
    P = np.stack([plaquette(links, m, n) for m, n in PLANES])  # (3,L,L,L,4)
    c0 = P[..., 0]
    ck = P[..., 1:].reshape(-1, 3)
    return dict(
        mean_c0=float(c0.mean()),
        mean_c0sq=float((c0 ** 2).mean()),
        sumvar_ck=float(ck.var(axis=0).sum()),
        mean_ck=[float(v) for v in ck.mean(axis=0)],
    ), P


# ------------------------------------------------------------ 2. hedgehogs
def _solid_angle(a, b, c):
    """Signed solid angle of the spherical triangle (a,b,c), unit vectors."""
    num = (a * np.cross(b, c)).sum(-1)
    den = 1.0 + (a * b).sum(-1) + (b * c).sum(-1) + (c * a).sum(-1)
    return 2.0 * np.arctan2(num, den)


# Cube corners indexed by offsets (i,j,k) in {0,1}^3. Each face listed with
# its four corners ordered counterclockwise seen from OUTSIDE the cube, so
# the triangle normals point outward. Diagonal: corner 0 to corner 2.
_FACES = [
    [(0, 0, 0), (0, 1, 0), (1, 1, 0), (1, 0, 0)],  # z = 0, normal -z
    [(0, 0, 1), (1, 0, 1), (1, 1, 1), (0, 1, 1)],  # z = 1, normal +z
    [(0, 0, 0), (1, 0, 0), (1, 0, 1), (0, 0, 1)],  # y = 0, normal -y
    [(0, 1, 0), (0, 1, 1), (1, 1, 1), (1, 1, 0)],  # y = 1, normal +y
    [(0, 0, 0), (0, 0, 1), (0, 1, 1), (0, 1, 0)],  # x = 0, normal -x
    [(1, 0, 0), (1, 1, 0), (1, 1, 1), (1, 0, 1)],  # x = 1, normal +x
]


def hedgehog_field(P):
    """Integer hedgehog charge per unit cell, shape (L,L,L).

    P: stacked plaquettes (3, L, L, L, 4) in the order of PLANES.
    """
    c = P[..., 1:].sum(axis=0)                       # (L,L,L,3)
    n = c / np.linalg.norm(c, axis=-1, keepdims=True)
    corner = {}
    for i in (0, 1):
        for j in (0, 1):
            for k in (0, 1):
                v = n
                if i: v = np.roll(v, -1, axis=0)
                if j: v = np.roll(v, -1, axis=1)
                if k: v = np.roll(v, -1, axis=2)
                corner[(i, j, k)] = v
    omega = 0.0
    for f in _FACES:
        a, b, cc, d = (corner[t] for t in f)
        omega = omega + _solid_angle(a, b, cc) + _solid_angle(a, cc, d)
    return np.rint(omega / (4 * np.pi)).astype(np.int64)


def hedgehog_stats(Q):
    vals, cnt = np.unique(Q, return_counts=True)
    return dict(
        Q_total=int(Q.sum()),
        Q_sq_per_cell=float((Q ** 2).mean()),
        Q_abs_per_cell=float(np.abs(Q).mean()),
        charged_fraction=float((Q != 0).mean()),
        Q_hist={int(v): int(c) for v, c in zip(vals, cnt)},
    )


# ------------------------------------------------------------ 3. C_Q(r)
def charge_correlator(Q, rmax=None):
    L = Q.shape[0]
    V = Q.size
    F = np.fft.fftn(Q.astype(float))
    S = (np.abs(F) ** 2) / V                          # chi(k) = sum_r C(r) e^{ikr}
    C = np.fft.ifftn(np.abs(F) ** 2).real / V         # C(r) = <Q(x)Q(x+r)>
    ax = np.minimum(np.arange(L), L - np.arange(L))
    xx, yy, zz = np.meshgrid(ax, ax, ax, indexing='ij')
    r2 = xx ** 2 + yy ** 2 + zz ** 2
    rmax = rmax or L // 2
    # exact shells for the first few |r|^2, then unit width radial bins
    shells = {}
    for s in (0, 1, 2, 3, 4, 5, 6, 8, 9):
        m = r2 == s
        if m.any():
            shells[s] = dict(C=float(C[m].mean()), n=int(m.sum()))
    rr = np.sqrt(r2)
    prof = []
    for r in range(rmax + 1):
        m = (rr >= r - 0.5) & (rr < r + 0.5)
        prof.append(float(C[m].mean()))
    running = [float(C[rr <= R + 1e-9].sum()) for R in range(rmax + 1)]
    kx = np.fft.fftfreq(L) * L
    KX, KY, KZ = np.meshgrid(kx, kx, kx, indexing='ij')
    k2 = (KX ** 2 + KY ** 2 + KZ ** 2).astype(int)
    chik = {}
    for s in (0, 1, 2, 3, 4):
        m = k2 == s
        if m.any():
            chik[s] = float(S[m].mean())
    return dict(C_shell=shells, C_profile=prof, running_sum=running,
                chi_k=chik)


# ------------------------------------------------------------ 4. Wilson loops
def line_products(U, mu, rmax):
    """lines[r](x) = U_mu(x) U_mu(x+mu) ... U_mu(x+(r-1)mu), r = 0..rmax."""
    L = U.shape[0]
    one = np.zeros_like(U); one[..., 0] = 1.0
    out = [one, U.copy()]
    for r in range(2, rmax + 1):
        out.append(qmul(out[-1], shift(U, mu, r - 1)))
    return out


def wilson_loops(links, rmax, keep_square=True):
    """Returns W[R,T] (R,T = 1..rmax) averaged over positions and planes,
    and, if keep_square, the full per site 1/2 Tr W for square loops:
    sq[R] -> array (3, L, L, L) in plane order PLANES."""
    lines = [line_products(links[mu], mu, rmax) for mu in range(3)]
    W = np.zeros((rmax + 1, rmax + 1))
    sq = {}
    for p, (mu, nu) in enumerate(PLANES):
        for R in range(1, rmax + 1):
            a = lines[mu][R]
            for T in range(1, rmax + 1):
                b = lines[nu][T]
                w = qmul(qmul(a, shift(b, mu, R)),
                         qmul(qconj(shift(a, nu, T)), qconj(b)))[..., 0]
                W[R, T] += w.mean() / 3.0
                if keep_square and R == T:
                    sq.setdefault(R, np.zeros((3,) + w.shape))[p] = w
    return W, sq


def holonomy_stats(sq, nmax=6, nbins=36):
    """Neutrino probe around square loops: C_n = <cos n psi>, V_nu, psi histogram."""
    out = {}
    edges = np.linspace(0, np.pi, nbins + 1)
    for R, w in sq.items():
        psi = np.arccos(np.clip(w, -1, 1)).ravel()
        h, _ = np.histogram(psi, bins=edges)
        out[R] = dict(
            C_n=[float(np.cos(n * psi).mean()) for n in range(1, nmax + 1)],
            V_nu=float(1.0 - (w ** 2).mean()),
            psi_hist=h.tolist(),
        )
    return out, edges


# ------------------------------------------------------------ 5. lock test
def _box_sum_2d(A, ax1, ax2, R):
    """sum_{i,j=0}^{R-1} A(x + i*ax1 + j*ax2), periodic."""
    s = np.zeros_like(A)
    for i in range(R):
        s += np.roll(A, -i, axis=ax1)
    t = np.zeros_like(A)
    for j in range(R):
        t += np.roll(s, -j, axis=ax2)
    return t


def lock_test(Q, sq, slab=1, nmax_bin=8, rng=None):
    """Bin square loop values by the hedgehog content of the slab of cells
    adjacent to the flat surface of the loop.

    Loop of size R in plane (mu,nu) at base site x, third axis rho.
    Adjacent cells: base y with y_mu in [x_mu, x_mu+R-1],
    y_nu in [x_nu, x_nu+R-1], y_rho in [x_rho-slab, x_rho+slab-1].
    """
    rng = rng or np.random.default_rng(0)
    absQ = np.abs(Q).astype(float)
    Qf = Q.astype(float)
    L = Q.shape[0]
    # null: displace the charge field by a random nonzero offset
    off = tuple(int(v) for v in rng.integers(L // 4, 3 * L // 4, size=3))
    absQn = np.roll(absQ, off, axis=(0, 1, 2))
    Qn = np.roll(Qf, off, axis=(0, 1, 2))
    res = {}
    for R, w in sq.items():
        accN = np.zeros((2, nmax_bin + 1, 2))   # [real/null, N bin, (sum W, count)]
        accq = np.zeros((2, 2 * nmax_bin + 1, 2))
        for p, (mu, nu) in enumerate(PLANES):
            rho = 3 - mu - nu
            for k, (aQ, sQ) in enumerate([(absQ, Qf), (absQn, Qn)]):
                N = 0; q = 0
                for d in range(-slab, slab):
                    N = N + np.roll(_box_sum_2d(aQ, mu, nu, R), -d, axis=rho)
                    q = q + np.roll(_box_sum_2d(sQ, mu, nu, R), -d, axis=rho)
                Nb = np.clip(np.rint(N).astype(int), 0, nmax_bin)
                qb = np.clip(np.rint(q).astype(int), -nmax_bin, nmax_bin) + nmax_bin
                wv = w[p]
                accN[k, :, 0] += np.bincount(Nb.ravel(), weights=wv.ravel(), minlength=nmax_bin + 1)
                accN[k, :, 1] += np.bincount(Nb.ravel(), minlength=nmax_bin + 1)
                accq[k, :, 0] += np.bincount(qb.ravel(), weights=wv.ravel(), minlength=2 * nmax_bin + 1)
                accq[k, :, 1] += np.bincount(qb.ravel(), minlength=2 * nmax_bin + 1)
        res[R] = dict(byN=accN.tolist(), byq=accq.tolist())
    return res


# ------------------------------------------------------------ driver
def measure(links, rmax=None, nmax=6, slab=1, lock_R=None, rng=None, vortex=True):
    """vortex=False skips the center gauge fixing (the most expensive part)."""
    L = links.shape[1]
    rmax = rmax or min(8, L // 2)
    out = {}
    ps, P = plaquette_stats(links)
    out.update(ps)
    Q = hedgehog_field(P)
    out.update(hedgehog_stats(Q))
    out['corr'] = charge_correlator(Q)
    W, sq = wilson_loops(links, rmax)
    out['W'] = W.tolist()
    hs, _ = holonomy_stats(sq, nmax=nmax)
    out['holonomy'] = hs
    lock_R = lock_R or [R for R in (1, 2, 3, 4) if R <= rmax]
    out['lock'] = lock_test(Q, {R: sq[R] for R in lock_R}, slab=slab, rng=rng)
    if vortex:
        out['vortex'] = vortex_stats(links, sq, Q)
    return out


# ------------------------------------------------------------ 6. center vortices
def max_center_gauge(links, iters=1000, tol=1e-7, rng=None, omega=1.9):
    """Direct maximal center gauge: maximize sum_links (1/2 Tr U)^2 = sum U0^2.

    Site update: with h the gauge rotation at x, (h U_mu(x))_0 = h . u~ with
    u~ = (U0, -U_vec), and (U_mu(x-mu) h^+)_0 = h . U_mu(x-mu). So the local
    objective is h^T M h with M = sum (u~ u~^T + v v^T); h = top eigenvector.
    Checkerboard sweeps until the objective stops improving.
    Returns the gauge transformed links (gauge invariant observables unchanged).
    """
    U = links.copy()
    L = U.shape[1]
    par = np.indices((L, L, L)).sum(0) % 2
    if rng is not None:                       # random gauge start (Gribov copies)
        g = rng.normal(size=(L, L, L, 4)); g /= np.linalg.norm(g, axis=-1, keepdims=True)
        for mu in range(3):
            U[mu] = qmul(qmul(g, U[mu]), qconj(shift(g, mu)))
    last = -1.0
    for it in range(iters):
        for p in (0, 1):
            m = par == p
            M = np.zeros((int(m.sum()), 4, 4))
            for mu in range(3):
                u = U[mu][m].copy(); u[:, 1:] *= -1
                v = shift(U[mu], mu, -1)[m]
                M += u[:, :, None] * u[:, None, :] + v[:, :, None] * v[:, None, :]
            w, vec = np.linalg.eigh(M)
            h = vec[:, :, -1]
            h = h * np.sign(h[:, :1] + 1e-300)          # h0 >= 0: shortest rotation
            if omega != 1.0:                            # overrelaxation: h -> h^omega
                th = np.arccos(np.clip(h[:, 0], -1, 1))
                nv = h[:, 1:] / np.maximum(np.sin(th), 1e-12)[:, None]
                h = np.concatenate([np.cos(omega * th)[:, None],
                                    nv * np.sin(omega * th)[:, None]], axis=1)
            H = np.zeros((L, L, L, 4)); H[..., 0] = 1.0; H[m] = h
            for mu in range(3):
                U[mu] = qmul(qmul(H, U[mu]), qconj(shift(H, mu)))
        obj = float((U[..., 0] ** 2).mean())
        if abs(obj - last) < tol:
            break
        last = obj
    U /= np.linalg.norm(U, axis=-1, keepdims=True)
    return U, obj, it + 1


def vortex_stats(links, sq, Q, nv_max=6, nbins=36, rng=None):
    """Center projection after maximal center gauge.

    P-vortex plaquette: product of the four projected link signs is -1.
    For each square loop, n_v = number of P-vortex plaquettes on its flat
    surface; its projected sign is (-1)^n_v (Stokes). The full (unprojected,
    gauge invariant) loop value 1/2 Tr W and the probe coherence cos(n psi)
    are then binned by n_v: the thermal vacuum version of the Stage 3 lock.
    Also: P-vortex plaquettes on the faces of charged vs neutral hedgehog cells.
    """
    Ug, obj, nit = max_center_gauge(links, rng=rng)
    z = np.sign(Ug[..., 0])
    pv = {}
    for mu, nu in PLANES:
        pv[(mu, nu)] = (z[mu] * shift(z[nu], mu) * shift(z[mu], nu) * z[nu]) < 0
    dens = float(np.mean([v.mean() for v in pv.values()]))
    edges = np.linspace(0, np.pi, nbins + 1)
    out = dict(mcg_objective=obj, mcg_iters=nit, pvortex_density=dens, loops={})
    for R, w in sq.items():
        acc = np.zeros((nv_max + 1, 8))       # count, sum W (= cos psi), sum W^2, sum cos(n psi) for n = 2..6
        hist = np.zeros((2, nbins))           # even / odd n_v
        for p, (mu, nu) in enumerate(PLANES):
            nv = np.rint(_box_sum_2d(pv[(mu, nu)].astype(float), mu, nu, R)).astype(int)
            wv = w[p]
            psi = np.arccos(np.clip(wv, -1, 1))
            nb = np.clip(nv, 0, nv_max)
            for k, val in enumerate([np.ones_like(wv), wv, wv ** 2, np.cos(2 * psi),
                                     np.cos(3 * psi), np.cos(4 * psi), np.cos(5 * psi),
                                     np.cos(6 * psi)]):
                acc[:, k] += np.bincount(nb.ravel(), weights=val.ravel(), minlength=nv_max + 1)
            for par_ in (0, 1):
                sel = (nv % 2) == par_
                hist[par_] += np.histogram(psi[sel], bins=edges)[0]
        out['loops'][R] = dict(acc=acc.tolist(), psi_hist_even_odd=hist.tolist())
    # hedgehogs vs vortices: P-plaquettes on the 6 faces of each cell
    faces = 0
    for (mu, nu), v in pv.items():
        rho = 3 - mu - nu
        faces = faces + v.astype(int) + np.roll(v, -1, axis=rho).astype(int)
    ch = Q != 0
    out['faces_pv_charged'] = float(faces[ch].mean()) if ch.any() else 0.0
    out['faces_pv_neutral'] = float(faces[~ch].mean())
    out['frac_charged_on_vortex'] = float((faces[ch] > 0).mean()) if ch.any() else 0.0
    out['frac_neutral_on_vortex'] = float((faces[~ch] > 0).mean())
    return out
