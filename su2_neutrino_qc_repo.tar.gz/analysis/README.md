# Analysis scripts

Post-processing and figure generation for the classical SU(2) Wilson companion
study (Supplementary Section S6 of the preprint).

These scripts consume the outputs of the production campaign:

- `results_cl_L{16,24,32}.npz` - per-configuration observables and pooled
  site-level m*_CTC histograms (2000 configurations per volume, beta = 2.2)
- `ckpt_cl_L32_rank{0..31}.npz` - full SU(2) gauge-field checkpoints, one per
  MPI rank (key `links`, scalar-first unit quaternions, shape (3, L, L, L, 4))

## Scripts

| Script | Input | Output |
|---|---|---|
| `floor_quantiles.py` | results npz | Figure S9: pooled m*_CTC distributions and the volume-stable quantile ladder (q0.01% / q0.1% / q1%) |
| `twist_visualization.py` | rank checkpoints | Figure S10: mid-plane twist slices, all configurations; Figure S11: per-configuration means and the ensemble-averaged two-point correlation |
| `postprocess_topology.py` | rank checkpoints + the production `measure_fields` | Site-level field dumps (Q, theta, divF, m*) for topology visualization; requires one import edit marked [EDIT] |

The twist quantity in `twist_visualization.py` is the plaquette Pauli-vector
magnitude |c(x)| = sqrt(1 - c0^2) = sin(theta(x)), plane-averaged per site -
the same c_k components whose variance is the central quantity of the paper.

## Requirements

numpy, scipy, matplotlib. No MPI needed; all scripts run serially on a laptop.

This work was assisted by LLMs for scripts and drafting. The concept, its
development, and the verification of every result remain the responsibility
of the author.
