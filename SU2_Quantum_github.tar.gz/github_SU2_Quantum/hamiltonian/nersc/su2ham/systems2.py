"""
Lattice specifications shared by both engines, and builders for the compact
engine (engine2). The geometry, gauge fixing trees and Gauss law fields are
documented in systems.py; the specs below are the same.

Part of the SU2_Quantum project (R. Sakidja, Missouri State University).
Code drafted with AI (LLM) assistance (Claude, Anthropic) and reviewed by the author.
"""
from .engine2 import CompactSystem

F, T = False, True

SPECS = {
    "single": dict(N=1, plaquettes=[[(0, F)]], energy=[(4.0, "cas", 0)], fields=[], names=["P"]),
    "open2x1": dict(N=2, plaquettes=[[(0, F)], [(1, F), (0, T)]],
                    energy=[(1.0, "cas", 0), (3.0, "cas", 1), (3.0, "field", [(0, "L"), (1, "L")])],
                    fields=[[(0, "L"), (1, "L")]], names=["P1", "P2"]),
    "torus1x1": dict(N=2, plaquettes=[[(0, F), (1, F), (0, T), (1, T)]],
                     energy=[(1.0, "cas", 0), (1.0, "cas", 1)], fields=[], names=["P"]),
    "torus2x1": dict(N=3, plaquettes=[[(2, F), (1, T)], [(0, F), (1, F), (0, T), (2, T)]],
                     energy=[(1.0, "cas", 0), (1.0, "cas", 1), (1.0, "cas", 2),
                             (1.0, "field", [(0, "R"), (1, "K")])],
                     fields=[[(0, "R"), (1, "K")]], names=["P_A", "P_B"]),
    "torus3x1": dict(N=4, plaquettes=[[(2, F), (1, T)], [(3, F), (2, T)], [(0, F), (1, F), (0, T), (3, T)]],
                     energy=[(1.0, "cas", l) for l in range(4)] +
                            [(1.0, "field", [(0, "R"), (1, "K")]), (1.0, "field", [(0, "R"), (1, "K"), (2, "K")])],
                     fields=[[(0, "R"), (1, "K")], [(0, "R"), (1, "K"), (2, "K")]], names=["P_0", "P_1", "P_2"]),
    "torus2x2": dict(N=5, plaquettes=[[(2, F)], [(0, F), (1, T), (2, T)], [(4, F), (3, T)],
                                      [(1, F), (3, F), (0, T), (4, T)]],
                     energy=[(1.0, "cas", l) for l in range(5)] +
                            [(1.0, "field", [(0, "L"), (2, "L"), (4, "R")]),
                             (1.0, "field", [(1, "L"), (4, "L"), (2, "R")]),
                             (1.0, "field", [(1, "K"), (3, "L"), (4, "L"), (2, "R")])],
                     fields=[[(0, "L"), (2, "L"), (4, "R")], [(1, "L"), (4, "L"), (2, "R")],
                             [(1, "K"), (3, "L"), (4, "L"), (2, "R")]],
                     names=["P00", "P10", "P01", "P11"]),
}


def build2(name, jmax, verbose=False):
    s = SPECS[name]
    sysm = CompactSystem(s["N"], jmax, s["plaquettes"], s["energy"], constraints=s["fields"], verbose=verbose)
    sysm.names = s["names"]
    if name == "open2x1":
        sysm.corr_word = [(0, F), (0, F), (1, T)]   # (1/2) Tr(P1 P2^dag), as in systems.py
    return sysm
