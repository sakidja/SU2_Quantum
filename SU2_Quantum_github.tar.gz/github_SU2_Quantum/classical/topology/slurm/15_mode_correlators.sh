#!/bin/bash -l
# Job 15: correlations of the three twist modes in space (Figure T11).
# One beta per submission. The lock scale t a g^2 < 7 spans t < 7 beta / 4 lattice units, so larger
# beta resolves it with more points (5, 7 and 8 for beta 3.0, 4.0, 5.0); three betas also test that
# the effective masses in units of g^2 agree across the lattice spacing.
#   sbatch slurm/15_mode_correlators.sh 3.0        (L = 32, loops R = 1 to 4)
#   sbatch slurm/15_mode_correlators.sh 4.0
#   sbatch slurm/15_mode_correlators.sh 5.0 32 5   (loops up to R = 5 at the finest spacing)
# No gauge fixing is needed (singular values are gauge invariant), so this is faster than job 14.
# Resubmit the same line to resume if the time limit is hit.
#SBATCH -A mXXXX                  # <-- your NERSC project
#SBATCH -C cpu
#SBATCH -q regular
#SBATCH -N 1
#SBATCH -t 03:00:00
#SBATCH -J su2topo_mcorr
#SBATCH -o %x_%j.out
BETA=${1:-3.0}
L=${2:-32}
RMAX=${3:-4}
cd "$SLURM_SUBMIT_DIR/.."
source slurm/env_perlmutter.sh
srun -n 128 -c 2 --cpu-bind=cores "$PY" mode_correlators.py \
     --L $L --beta $BETA --ntherm 800 --nmeas 200 --skip 10 --rmax $RMAX \
     --out runs/mc${L}_b${BETA} --wall $(( 3*3600 - 900 ))
FIGSCALE=1.55 "$PY" mode_correlators_analysis.py runs/mc${L}_b${BETA} --outdir figures_mcorr_L${L}_b${BETA}
