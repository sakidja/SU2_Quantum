#!/usr/bin/env python3
"""
ungauged.py: SU(2) lattice Hamiltonians with NO gauge fixing and NO Gauss law
constraint, optionally with a term that breaks local gauge invariance
explicitly. The vacuum is then asked whether it satisfies Gauss law at every
site on its own.

    python ungauged.py --system single --jmax 1 --g2 1.8181818 --kappa 0 0.1 0.3 1.0 --out results/ungauged_single_j1

Part of the SU2_Quantum project (R. Sakidja, Missouri State University).
Code drafted with AI (LLM) assistance (Claude, Anthropic) and reviewed by the author.

Setup
-----
Every link is dynamical, in the full Peter Weyl space e^j_{mn}(U_l),
j <= jmax, with no tree, no singlet projection and no constraint anywhere.
    H = (g^2/2) sum_l C_l + (4/g^2) sum_p (1 - s_p c0_p) + kappa sum_l (1 - (1/2) Tr U_l)
The last term is a link potential. It is NOT gauge invariant (Tr U_l changes
under a local rotation at either end of the link), so for kappa > 0 the
dynamics itself no longer respects the local symmetry.

Readout, for the lowest levels of H
-----------------------------------
* <G_s^2> at every site s, the Gauss law Casimir (sum over links touching s of
  the left generator for outgoing links and the right generator for incoming
  links). Zero means no color charge at s.
* <c0_p> and <c0_p^2> per plaquette, energies, and the gap from the ground
  state to the lowest level that carries charge (kappa = 0).
At kappa = 0 the Gauss operators commute with H (checked numerically), so the
question "does the ground state satisfy Gauss law everywhere" has an exact
answer. At kappa > 0 they do not commute, and <G_s^2> in the ground state
measures how much local symmetry the vacuum keeps when the dynamics breaks it.

Validation: at kappa = 0 the ground state energy must equal the gauge fixed
engine's value (systems2 'single', 'torus1x1', 'torus2x1' at the same jmax),
since gauge fixing only removes states the constraint already excludes.

Systems (sites, links start -> end, plaquettes)
    single    4 sites A B C D; 0:A->B 1:B->C 2:C->D 3:D->A; one plaquette
    torus1x1  1 site; 0:x 1:y; plaquette U0 U1 U0^ U1^
    torus2x1  2 sites; x links 0:0->1 1:1->0; y links 2:0->0 3:1->1; two plaquettes
Full dimension is (sum_j (2j+1)^2)^N_links: single j1 38416, j1.5 810000;
torus1x1 j3 19600, j4 81225; torus2x1 j1 38416.
"""
import argparse
import itertools
import json
import time

import numpy as np
import scipy.sparse as sp
import scipy.sparse.linalg as spla

from su2ham.engine import jvals, dim, spin_matrices, apply_mult, HALF

F, T = False, True
SYSTEMS = {
    "single": dict(nlinks=4, links=[(0, 1), (1, 2), (2, 3), (3, 0)], nsites=4,
                   plaquettes=[[(0, F), (1, F), (2, F), (3, F)]], engine="single"),
    "torus1x1": dict(nlinks=2, links=[(0, 0), (0, 0)], nsites=1,
                     plaquettes=[[(0, F), (1, F), (0, T), (1, T)]], engine="torus1x1"),
    "torus2x1": dict(nlinks=4, links=[(0, 1), (1, 0), (0, 0), (1, 1)], nsites=2,
                     plaquettes=[[(0, F), (3, F), (0, T), (2, T)], [(1, F), (2, F), (1, T), (3, T)]],
                     engine="torus2x1"),
}


class LinkSpace:
    """One link: basis e^j_{mn}, j <= jmax, index order (j, m, n)."""

    def __init__(self, jmax):
        self.js = jvals(jmax)
        self.off = {}
        n = 0
        for j in self.js:
            self.off[j] = n
            n += dim(j) ** 2
        self.n = n
        self.cas = sp.diags(np.concatenate([[j * (j + 1)] * dim(j) ** 2 for j in self.js])).tocsr()
        # generators: L^a acts on m with S^T, R^a acts on n with -S (engine convention)
        self.L, self.R = [], []
        for a in range(3):
            La, Ra = [], []
            for j in self.js:
                S = spin_matrices(j)[a]
                I = np.eye(dim(j))
                La.append(np.kron(S.T, I))
                Ra.append(np.kron(I, -S))
            self.L.append(sp.block_diag(La, format="csr"))
            self.R.append(sp.block_diag(Ra, format="csr"))
        # multiplication operators by (U)_{pq} and (U^dagger)_{pq}
        self.M = {}
        for dag in (False, True):
            for p in HALF:
                for q in HALF:
                    cols = []
                    for j in self.js:
                        d = dim(j)
                        for m in range(d):
                            for nn in range(d):
                                Tin = np.zeros((1, d, d))
                                Tin[0, m, nn] = 1.0
                                out = apply_mult({(j,): Tin}, 0, p, q, dagger=dag)
                                col = np.zeros(self.n, complex)
                                for (k,), Tk in out.items():
                                    if k in self.off:
                                        col[self.off[k]:self.off[k] + dim(k) ** 2] = Tk[0].ravel()
                                cols.append(col)
                    A = np.array(cols).T
                    self.M[(dag, p, q)] = sp.csr_matrix(A)

    def trace_U(self):
        """(1/2) Tr U_l as an operator on the link."""
        return 0.5 * sum(self.M[(False, p, p)] for p in HALF)


def kron_all(ops):
    out = ops[0]
    for o in ops[1:]:
        out = sp.kron(out, o, format="csr")
    return out


def build(system, jmax):
    s = SYSTEMS[system]
    ls = LinkSpace(jmax)
    N = s["nlinks"]
    I = sp.identity(ls.n, format="csr")
    # A link that appears twice in a plaquette word passes through j = jmax + 1/2
    # between the two multiplications. Those intermediate representations are
    # kept (as in the gauge fixed engine: the operator is truncated, not the
    # individual multiplications), by forming each link's product in the space
    # extended by one step and restricting the result to j <= jmax.
    repeats = any(len({l for l, _ in w}) < len(w) for w in s["plaquettes"])
    lx = LinkSpace(jmax + 0.5) if repeats else ls
    keep = np.concatenate([np.ones(dim(j) ** 2, bool) if j in ls.off else np.zeros(dim(j) ** 2, bool) for j in lx.js])
    Pj = sp.csr_matrix(np.eye(lx.n)[keep])          # (ls.n, lx.n)
    Ix = sp.identity(lx.n, format="csr")

    def lift(op, l):
        return kron_all([op if k == l else I for k in range(N)])

    Eel = sum(lift(ls.cas, l) for l in range(N))
    plaqs = []
    for word in s["plaquettes"]:
        P = None
        for idx in itertools.product(HALF, repeat=len(word)):
            per_link = [Ix] * N
            for step, (l, dag) in enumerate(word):
                p, q = idx[step], idx[(step + 1) % len(word)]
                per_link[l] = lx.M[(dag, p, q)] @ per_link[l]
            term = kron_all([Pj @ op @ Pj.T for op in per_link])
            P = term if P is None else P + term
        P = 0.5 * P
        P = 0.5 * (P + P.conj().T)
        plaqs.append(P.real.tocsr())
    gauss = []
    for site in range(s["nsites"]):
        G2 = None
        for a in range(3):
            Ga = None
            for l, (start, end) in enumerate(s["links"]):
                if start == site:
                    t = lift(ls.L[a], l); Ga = t if Ga is None else Ga + t
                if end == site:
                    t = lift(ls.R[a], l); Ga = t if Ga is None else Ga + t
            G2 = Ga @ Ga if G2 is None else G2 + Ga @ Ga
        gauss.append(G2.real.tocsr())
    breaking = sum(lift(I - ls.trace_U(), l) for l in range(N))
    breaking = 0.5 * (breaking + breaking.conj().T)
    return dict(n=Eel.shape[0], Eel=Eel.tocsr(), plaqs=plaqs, gauss=gauss, breaking=breaking.real.tocsr(), spec=s)


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--system", default="single")
    ap.add_argument("--jmax", type=float, default=1.0)
    ap.add_argument("--g2", type=float, nargs="+", default=[1.0, 1.8181818, 3.0])
    ap.add_argument("--kappa", type=float, nargs="+", default=[0.0, 0.1, 0.3, 1.0, 3.0])
    ap.add_argument("--levels", type=int, default=24)
    ap.add_argument("--out", required=True)
    a = ap.parse_args()
    t0 = time.time()
    S = build(a.system, a.jmax)
    n, nP, nS = S["n"], len(S["plaqs"]), len(S["gauss"])
    print(f"{a.system} jmax={a.jmax}: full space {n} states, no gauge fixing, no constraint ({time.time()-t0:.1f}s)", flush=True)
    Hmag = sum(sp.identity(n) - P for P in S["plaqs"])
    comm = max(abs(G @ Hmag - Hmag @ G).max() for G in S["gauss"])
    print(f"  max |[G_s^2, H_magnetic]| = {comm:.2e} (must vanish)", flush=True)
    # independent check of the ground state energy at kappa = 0 against the gauge fixed engine
    ref = None
    try:
        from su2ham.systems2 import build2
        ref = build2(S["spec"]["engine"], a.jmax)
    except Exception as e:
        print(f"  [note] gauge fixed engine not available for the check: {e}")

    records = []
    for tw in ([1] * nP, [-1] + [1] * (nP - 1)):
        for g2 in a.g2:
            for kap in a.kappa:
                H = 0.5 * g2 * S["Eel"]
                for sg, P in zip(tw, S["plaqs"]):
                    H = H + (4.0 / g2) * (sp.identity(n) - sg * P)
                if kap:
                    H = H + kap * S["breaking"]
                H = H.tocsr()
                k = min(a.levels, n - 2)
                if n <= 3000:
                    w, v = np.linalg.eigh(H.toarray()); w, v = w[:k], v[:, :k]
                else:
                    w, v = spla.eigsh(H, k=k, which="SA", tol=1e-10)
                    o = np.argsort(w); w, v = w[o], v[:, o]
                G2 = np.array([[float(np.real(v[:, i] @ (G @ v[:, i]))) for G in S["gauss"]] for i in range(k)])
                c0 = np.array([[float(np.real(v[:, i] @ (P @ v[:, i]))) for P in S["plaqs"]] for i in range(k)])
                c0sq = np.array([[float(np.real((P @ v[:, i]) @ (P @ v[:, i]))) for P in S["plaqs"]] for i in range(k)])
                tot = G2.sum(axis=1)
                charged = [i for i in range(k) if tot[i] > 0.25]
                gap = float(w[charged[0]] - w[0]) if charged else None
                rec = dict(system=a.system, jmax=a.jmax, g2=g2, kappa=kap, twist=tw, n=n,
                           E=w.tolist(), gauss_sq=G2.tolist(), c0=c0.tolist(), c0sq=c0sq.tolist(),
                           ground_gauss_sq=G2[0].tolist(), ground_sumVar=(1 - c0sq[0]).tolist(),
                           gap_to_charged=gap, n_charged_in_window=len(charged))
                if ref is not None and kap == 0.0:
                    wr, _ = ref.lowest(g2, signs=tw, k=1)
                    rec["E0_gauge_fixed_engine"] = float(wr[0])
                records.append(rec)
                gs = " ".join(f"{x:.2e}" for x in G2[0])
                extra = f"  gauge fixed engine E0={rec['E0_gauge_fixed_engine']:.6f}" if "E0_gauge_fixed_engine" in rec else ""
                print(f"  twist={tw} g2={g2:.4f} kappa={kap:g}: E0={w[0]:.6f}{extra}  <G_s^2> ground=[{gs}]  "
                      f"gap to first charged level={gap if gap is None else round(gap, 4)}  "
                      f"c0={c0[0][0]:+.4f} sumVar={1-c0sq[0][0]:.4f}", flush=True)
                json.dump(records, open(a.out + ".json", "w"), indent=1)
    print(f"wrote {a.out}.json ({time.time()-t0:.1f}s)")


if __name__ == "__main__":
    main()
