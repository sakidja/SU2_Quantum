#!/usr/bin/env python3
"""
su2_4d_potential_analysis.py
String tension from su2_4d_potential.py runs, one method at every coupling.

  python su2_4d_potential_analysis.py runs/pot_L16_b2.2 runs/pot_L16_b2.3 runs/pot_L16_b2.4 runs/pot_L20_b2.5

For each run: V(R, T) = ln[W(R,T)/W(R,T+1)] from the multihit loops (raw loops shown for
comparison), jackknife errors over chains, V(R) taken at T = --t0 (default 3), and a fit
V(R) = V0 + sigma R - e/R over R = --rmin..R_max (points with error < 0.1). Writes
potential_summary.json and FigPot_potential.png, and prints the --asig argument for
su2_4d_analysis.py so the lock profile uses this scale.
"""
import argparse
import glob
import json
import os
import re
import warnings

import numpy as np
from scipy.optimize import curve_fit
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

warnings.simplefilter('ignore', RuntimeWarning)
FS = float(os.environ.get('FIGSCALE', '1'))
plt.rcParams.update({'font.size': 11 * FS, 'axes.spines.top': False, 'axes.spines.right': False})
COL = ['#2A6FB0', '#C27A12', '#2E9E6B', '#B4457A', '#555555']


def load(d):
    files = sorted(glob.glob(os.path.join(d, 'pot_L*_b*_rank*.npz')),
                   key=lambda p: int(re.search(r'rank(\d+)', p).group(1)))
    ch, meta = [], None
    for p in files:
        z = np.load(p, allow_pickle=False)
        if len(z['raw']) == 0:
            continue
        meta = json.loads(str(z['meta'])); ch.append((z['raw'], z['mh']))
    if len(ch) == 1:
        r, m = ch[0]; cut = np.array_split(np.arange(len(r)), min(10, len(r)))
        ch = [(r[i], m[i]) for i in cut]
    return ch, meta


def jack(ch, fn):
    S = [(r.sum(0), m.sum(0), len(r)) for r, m in ch]
    tr = sum(s[0] for s in S); tm = sum(s[1] for s in S); tn = sum(s[2] for s in S)
    full = fn(tr / tn, tm / tn)
    n = len(S)
    jk = np.array([fn((tr - s[0]) / (tn - s[2]), (tm - s[1]) / (tn - s[2])) for s in S])
    err = np.sqrt((n - 1) / n * np.nansum((jk - np.nanmean(jk, 0)) ** 2, 0))
    return full, err


def cornell(r, v0, s, e):
    return v0 + s * r - e / r


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument('rundirs', nargs='+')
    ap.add_argument('--t0', type=int, default=3)
    ap.add_argument('--rmin', type=int, default=2)
    ap.add_argument('--outdir', default='figures_4d_potential')
    a = ap.parse_args()
    os.makedirs(a.outdir, exist_ok=True)
    out, asig = {}, []
    fig, ax = plt.subplots(1, 2, figsize=(13, 4.8))
    for i, d in enumerate(a.rundirs):
        ch, meta = load(d)
        if not ch:
            print('no data in', d); continue
        beta, L, rmax = meta['beta'], meta['L'], meta['rmax']
        t0 = min(a.t0, meta.get('tmax', rmax) - 1)
        Vfn = lambda raw, mh, which: np.log(mh[:, t0] / mh[:, t0 + 1]) if which else np.log(raw[:, t0] / raw[:, t0 + 1])
        Vm, Vme = jack(ch, lambda r, m: Vfn(r, m, 1))
        Vr, Vre = jack(ch, lambda r, m: Vfn(r, m, 0))
        R = np.arange(len(Vm))
        ok = (R >= a.rmin) & np.isfinite(Vm) & (Vme > 0) & (Vme < 0.1)
        res = dict(beta=beta, L=L, t0=t0, n_configs=int(sum(len(r) for r, _ in ch)), n_chains=len(ch),
                   V_multihit={int(r): [float(Vm[r]), float(Vme[r])] for r in R[1:]},
                   V_raw={int(r): [float(Vr[r]), float(Vre[r])] for r in R[1:]})
        if ok.sum() >= 3:
            p, cv = curve_fit(cornell, R[ok], Vm[ok], p0=[0.5, 0.1, 0.25], sigma=Vme[ok], absolute_sigma=True,
                              maxfev=20000)
            s, se = p[1], np.sqrt(cv[1, 1])
            chi2 = float((((Vm[ok] - cornell(R[ok], *p)) / Vme[ok]) ** 2).sum())
            res.update(a2_sigma=[float(s), float(se)], a_sqrt_sigma=[float(np.sqrt(s)), float(0.5 * se / np.sqrt(s))],
                       e=float(p[2]), V0=float(p[0]), chi2=chi2, dof=int(ok.sum() - 3), R_fit=R[ok].tolist())
            asig.append(f'{beta}={np.sqrt(s):.4f}')
            xx = np.linspace(1, R.max(), 200)
            ax[0].plot(xx, cornell(xx, *p), '-', color=COL[i % 5], lw=1)
        out[f'b{beta}_L{L}'] = res
        ax[0].errorbar(R[1:], Vm[1:], yerr=Vme[1:], fmt='o', color=COL[i % 5], capsize=3, label=f'beta = {beta}, L = {L}')
        ax[1].errorbar(R[1:] + 0.08, Vme[1:] / np.maximum(Vre[1:], 1e-12), fmt='s', color=COL[i % 5])
        print(f"beta {beta} L {L}: {res['n_configs']} configs, T0 = {t0}")
        print('  V(R) multihit: ' + ', '.join(f'{Vm[r]:.4f}({Vme[r]:.4f})' for r in R[1:]))
        print('  V(R) raw:      ' + ', '.join(f'{Vr[r]:.4f}({Vre[r]:.4f})' for r in R[1:]))
        if 'a2_sigma' in res:
            print(f"  a^2 sigma = {res['a2_sigma'][0]:.4f} +/- {res['a2_sigma'][1]:.4f}, a sqrt(sigma) = "
                  f"{res['a_sqrt_sigma'][0]:.4f} +/- {res['a_sqrt_sigma'][1]:.4f}, chi2/dof = {res['chi2']:.1f}/{res['dof']}")
    ax[0].set_xlabel('R'); ax[0].set_ylabel(r'$aV(R)$ (multihit)'); ax[0].legend(fontsize=9 * FS)
    ax[0].set_title('(a) static potential and Cornell fits')
    ax[1].set_xlabel('R'); ax[1].set_ylabel('error ratio, multihit / raw'); ax[1].axhline(1, color='k', lw=0.6)
    ax[1].set_title('(b) noise reduction'); ax[1].set_yscale('log')
    fig.tight_layout(); fig.savefig(os.path.join(a.outdir, 'FigPot_potential.png'), dpi=200, bbox_inches='tight')
    json.dump(out, open(os.path.join(a.outdir, 'potential_summary.json'), 'w'), indent=1)
    if asig:
        print('\nfor the lock profile:  su2_4d_analysis.py <runs> --asig ' + ' '.join(asig))
    print('wrote', a.outdir)


if __name__ == '__main__':
    main()
